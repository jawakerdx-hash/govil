"use client";

import { useEffect, useRef, useState } from "react";

interface ScanEvent {
  type: "connected" | "module_update" | "scan_started" | "scan_completed" | "pong";
  scanId: string;
  module?: string;
  status?: string;
  progress?: number;
  findings?: any[];
  result?: any;
  timestamp?: number;
}

export function useScanWebSocket(scanId: string | null) {
  const [progress, setProgress] = useState(0);
  const [currentModule, setCurrentModule] = useState("");
  const [status, setStatus] = useState("connecting");
  const [result, setResult] = useState<any>(null);
  const [timeline, setTimeline] = useState<ScanEvent[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!scanId) return;

    const wsUrl = (process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8000").replace("http", "ws");
    const ws = new WebSocket(`${wsUrl}/api/v1/ws/scan/${scanId}`);
    wsRef.current = ws;

    ws.onopen = () => setStatus("connected");
    ws.onmessage = (msg) => {
      try {
        const event: ScanEvent = JSON.parse(msg.data);
        setTimeline((prev) => [...prev.slice(-50), event]);

        switch (event.type) {
          case "scan_started":
            setStatus("running");
            setProgress(0);
            break;
          case "module_update":
            setCurrentModule(event.module || "");
            setProgress(event.progress || 0);
            break;
          case "scan_completed":
            setStatus("completed");
            setProgress(100);
            setResult(event.result);
            break;
          case "pong":
            break;
        }
      } catch {}
    };

    ws.onerror = () => setStatus("error");
    ws.onclose = () => {
      if (status !== "completed") setStatus("disconnected");
    };

    // Ping every 25s to keep alive
    const ping = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) ws.send("ping");
    }, 25000);

    return () => {
      clearInterval(ping);
      ws.close();
    };
  }, [scanId]);

  return { progress, currentModule, status, result, timeline };
}
