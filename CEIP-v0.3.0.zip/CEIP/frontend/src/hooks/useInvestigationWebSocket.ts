"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import type { WSWSEvent } from "@/lib/investigation-api";

interface InvestigationWSState {
  connected: boolean;
  status: string;
  currentPhase: number;
  progress: number;
  totalJobs: number;
  completedJobs: number;
  failedJobs: number;
  runningJobs: number;
  evidenceCount: number;
  assetCount: number;
  findingCount: number;
  riskScore: number;
  riskLevel: string;
  events: WSWSEvent[];
  currentPhaseName: string;
}

export function useInvestigationWebSocket(investigationId: string | null | undefined) {
  const [state, setState] = useState<InvestigationWSState>({
    connected: false,
    status: "connecting",
    currentPhase: 0,
    progress: 0,
    totalJobs: 0,
    completedJobs: 0,
    failedJobs: 0,
    runningJobs: 0,
    evidenceCount: 0,
    assetCount: 0,
    findingCount: 0,
    riskScore: 0,
    riskLevel: "LOW",
    events: [],
    currentPhaseName: "",
  });

  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!investigationId) return;

    const wsUrl = (process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8000").replace(/^http/, "ws");
    const ws = new WebSocket(`${wsUrl}/api/v1/investigations/ws/${investigationId}`);
    wsRef.current = ws;

    ws.onopen = () => {
      setState((prev) => ({ ...prev, connected: true, status: "connected" }));
    };

    ws.onmessage = (msg) => {
      try {
        const event: WSWSEvent = JSON.parse(msg.data);

        setState((prev) => {
          const events = [...prev.events, event].slice(-500);

          switch (event.type) {
            case "investigation_created":
              return { ...prev, status: "created", events };
            case "investigation_started":
              return {
                ...prev,
                status: "running",
                totalJobs: (event.total_jobs as number) || prev.totalJobs,
                events,
              };
            case "investigation_completed":
              return {
                ...prev,
                status: "completed",
                progress: 100,
                riskScore: (event.risk_score as number) || prev.riskScore,
                riskLevel: (event.risk_level as string) || prev.riskLevel,
                evidenceCount: (event.evidence_count as number) || prev.evidenceCount,
                assetCount: (event.asset_count as number) || prev.assetCount,
                findingCount: (event.finding_count as number) || prev.findingCount,
                events,
              };
            case "investigation_paused":
              return { ...prev, status: "paused", events };
            case "investigation_cancelled":
              return { ...prev, status: "cancelled", events };
            case "investigation_resumed":
              return { ...prev, status: "running", events };
            case "phase_started":
              return {
                ...prev,
                currentPhase: (event.phase as number) || prev.currentPhase,
                currentPhaseName: (event.phase_name as string) || prev.currentPhaseName,
                events,
              };
            case "phase_completed":
              return { ...prev, events };
            case "job_started":
              return {
                ...prev,
                runningJobs: prev.runningJobs + 1,
                events,
              };
            case "job_completed":
              return {
                ...prev,
                completedJobs: prev.completedJobs + 1,
                runningJobs: Math.max(0, prev.runningJobs - 1),
                evidenceCount: prev.evidenceCount + ((event.evidence_count as number) || 0),
                progress: prev.totalJobs > 0
                  ? ((prev.completedJobs + 1) / prev.totalJobs) * 100
                  : 0,
                events,
              };
            case "job_failed":
              return {
                ...prev,
                failedJobs: prev.failedJobs + 1,
                runningJobs: Math.max(0, prev.runningJobs - 1),
                events,
              };
            default:
              return { ...prev, events };
          }
        });
      } catch {}
    };

    ws.onerror = () => {
      setState((prev) => ({ ...prev, connected: false }));
    };

    ws.onclose = () => {
      setState((prev) =>
        prev.status !== "completed" ? { ...prev, connected: false } : prev
      );
    };

    // Keepalive ping
    const ping = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) ws.send("ping");
    }, 25000);

    return () => {
      clearInterval(ping);
      ws.close();
    };
  }, [investigationId]);

  return state;
}
