"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { useInvestigationWebSocket } from "@/hooks/useInvestigationWebSocket";
import {
  getInvestigation,
  getInvestigationProgress,
  getInvestigationTimeline,
  getPhasesInfo,
  cancelInvestigation,
  pauseInvestigation,
  resumeInvestigation,
  type InvestigationDetail,
  type TimelineEvent,
} from "@/lib/investigation-api";

const SEV_COLORS: Record<string, string> = {
  CRITICAL: "bg-red-500",
  HIGH: "bg-orange-500",
  MEDIUM: "bg-yellow-500",
  LOW: "bg-blue-500",
  INFO: "bg-slate-500",
};

const STATUS_COLORS: Record<string, string> = {
  running: "bg-green-500",
  completed: "bg-blue-500",
  failed: "bg-red-500",
  paused: "bg-yellow-500",
  cancelled: "bg-slate-500",
  pending: "bg-slate-600",
};

export default function InvestigationDashboard() {
  const params = useParams();
  const id = params?.id as string;

  const [detail, setDetail] = useState<InvestigationDetail | null>(null);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [phaseNames, setPhaseNames] = useState<Record<number, string>>({});
  const [activeTab, setActiveTab] = useState<"overview" | "phases" | "timeline">("overview");

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const ws = useInvestigationWebSocket(id);

  // Load initial data
  useEffect(() => {
    if (!id) return;
    setLoading(true); setLoadError("");
    Promise.all([
      getInvestigation(id),
      getInvestigationTimeline(id),
      getPhasesInfo(),
    ]).then(([inv, tl, phases]) => {
      setDetail(inv);
      setTimeline(tl);
      const names: Record<number, string> = {};
      for (const [num, info] of Object.entries((phases as any).phases || {})) {
        names[parseInt(num)] = (info as any).name;
      }
      setPhaseNames(names);
    }).catch((e) => {
      setLoadError(e?.message || "Failed to load investigation");
    }).finally(() => setLoading(false));
  }, [id]);

  const progress = ws.connected ? ws.progress : detail?.progress_pct || 0;
  const status = ws.connected ? ws.status : detail?.status || "loading";

  if (loading && !detail) {
    return (
      <div className="min-h-screen bg-[#020617] flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full" />
      </div>
    );
  }
  if (loadError && !detail) {
    return (
      <div className="min-h-screen bg-[#020617] flex items-center justify-center">
        <div className="text-center"><p className="text-red-400 text-lg">{loadError}</p><p className="text-slate-500 text-sm mt-2">Check that the investigation exists and the server is running.</p></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#020617] text-[#F8FAFC] flex" style={{ fontFamily: "'Fira Sans', sans-serif" }}>
      {/* Main Content */}
      <div className="flex-1 p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight" style={{ fontFamily: "'Fira Code', monospace" }}>
              Investigation: <span className="text-cyan-300">{detail?.domain || id}</span>
            </h1>
            <div className="flex items-center gap-3 mt-2">
              <span className={`w-2 h-2 rounded-full ${STATUS_COLORS[status] || "bg-slate-500"}`} />
              <span className="text-sm uppercase tracking-wider text-slate-400">{status}</span>
              <span className="text-xs text-slate-600">
                Phase {ws.currentPhase || detail?.current_phase || 0}/19
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-2">
            {status === "running" && (
              <button
                onClick={() => pauseInvestigation(id)}
                className="px-4 py-2 rounded-lg bg-yellow-500/20 border border-yellow-500/30 text-yellow-400 text-sm hover:bg-yellow-500/30 transition-all"
              >
                Pause
              </button>
            )}
            {status === "paused" && (
              <button
                onClick={() => resumeInvestigation(id)}
                className="px-4 py-2 rounded-lg bg-green-500/20 border border-green-500/30 text-green-400 text-sm hover:bg-green-500/30 transition-all"
              >
                Resume
              </button>
            )}
            {(status === "running" || status === "paused") && (
              <button
                onClick={() => cancelInvestigation(id)}
                className="px-4 py-2 rounded-lg bg-red-500/20 border border-red-500/30 text-red-400 text-sm hover:bg-red-500/30 transition-all"
              >
                Cancel
              </button>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-slate-400">
            <span>Overall Progress</span>
            <span>{progress.toFixed(0)}%</span>
          </div>
          <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, progress)}%` }}
            />
          </div>
        </div>

        {/* Counters */}
        <div className="grid grid-cols-6 gap-3">
          {[
            { label: "Total Jobs", value: ws.totalJobs || detail?.total_jobs || 0, color: "text-slate-300" },
            { label: "Completed", value: ws.completedJobs || detail?.completed_jobs || 0, color: "text-green-400" },
            { label: "Running", value: ws.runningJobs || detail?.running_jobs || 0, color: "text-blue-400" },
            { label: "Failed", value: ws.failedJobs || detail?.failed_jobs || 0, color: "text-red-400" },
            { label: "Evidence", value: ws.evidenceCount || detail?.evidence_count || 0, color: "text-cyan-400" },
            { label: "Findings", value: ws.findingCount || detail?.finding_count || 0, color: "text-yellow-400" },
          ].map((c) => (
            <div key={c.label} className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
              <div className={`text-xl font-bold ${c.color}`} style={{ fontFamily: "'Fira Code', monospace" }}>
                {c.value}
              </div>
              <div className="text-xs text-slate-500 mt-1">{c.label}</div>
            </div>
          ))}
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-1 border-b border-white/5">
          {(["overview", "phases", "timeline"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-sm capitalize transition-all ${
                activeTab === tab
                  ? "border-b-2 border-cyan-400 text-cyan-300"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-2 gap-4">
            {/* Phase Pipeline */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/5">
              <h3 className="text-sm font-semibold text-slate-300 mb-3">Investigation Pipeline</h3>
              <div className="space-y-1 max-h-96 overflow-y-auto">
                {detail?.phases?.map((phase) => {
                  const isCurrent = phase.phase_number === (ws.currentPhase || detail.current_phase);
                  const isDone = phase.status === "completed" || phase.status === "completed_with_errors";
                  const isRunning = phase.status === "running";
                  const name = phaseNames[phase.phase_number] || phase.name;

                  return (
                    <div
                      key={phase.phase_number}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all ${
                        isCurrent ? "bg-cyan-500/10 border border-cyan-500/20" : ""
                      }`}
                    >
                      <span
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-mono ${
                          isDone ? "bg-green-500/20 text-green-400" :
                          isRunning ? "bg-blue-500/20 text-blue-400 animate-pulse" :
                          "bg-white/5 text-slate-600"
                        }`}
                      >
                        {isDone ? "✓" : isRunning ? "▶" : phase.phase_number}
                      </span>
                      <span className="flex-1 text-slate-400 truncate">{name}</span>
                      <span className="text-xs text-slate-600">
                        {phase.completed_jobs}/{phase.job_count}
                        {phase.failed_jobs > 0 && (
                          <span className="text-red-400 ml-1">({phase.failed_jobs}✗)</span>
                        )}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Risk & Stats */}
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                <h3 className="text-sm font-semibold text-slate-300 mb-2">Risk Assessment</h3>
                <div className="flex items-baseline gap-2">
                  <span
                    className="text-3xl font-bold"
                    style={{ fontFamily: "'Fira Code', monospace" }}
                  >
                    {ws.riskScore || detail?.risk_score || 0}
                  </span>
                  <span className="text-slate-500">/100</span>
                  <span className={`ml-2 px-2 py-0.5 rounded text-xs font-semibold ${
                    (ws.riskLevel || detail?.risk_level) === "CRITICAL" ? "bg-red-500/20 text-red-400" :
                    (ws.riskLevel || detail?.risk_level) === "HIGH" ? "bg-orange-500/20 text-orange-400" :
                    (ws.riskLevel || detail?.risk_level) === "MEDIUM" ? "bg-yellow-500/20 text-yellow-400" :
                    "bg-blue-500/20 text-blue-400"
                  }`}>
                    {ws.riskLevel || detail?.risk_level || "LOW"}
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                <h3 className="text-sm font-semibold text-slate-300 mb-2">Assets & Evidence</h3>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <div className="text-lg font-mono text-cyan-300">{ws.assetCount || detail?.asset_count || 0}</div>
                    <div className="text-xs text-slate-500">Assets</div>
                  </div>
                  <div>
                    <div className="text-lg font-mono text-purple-300">{ws.evidenceCount || detail?.evidence_count || 0}</div>
                    <div className="text-xs text-slate-500">Evidence</div>
                  </div>
                  <div>
                    <div className="text-lg font-mono text-yellow-300">{detail?.intelligence_cases || 0}</div>
                    <div className="text-xs text-slate-500">Intel Cases</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "phases" && (
          <div className="space-y-4">
            {detail?.phases?.map((phase) => {
              const name = phaseNames[phase.phase_number] || phase.name;
              const pct = phase.job_count > 0 ? Math.round((phase.completed_jobs / phase.job_count) * 100) : 0;

              return (
                <div key={phase.phase_number} className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-slate-300">
                      Phase {phase.phase_number}: {name}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-xs ${
                      phase.status === "completed" ? "bg-green-500/20 text-green-400" :
                      phase.status === "running" ? "bg-blue-500/20 text-blue-400" :
                      phase.status === "completed_with_errors" ? "bg-yellow-500/20 text-yellow-400" :
                      "bg-slate-500/20 text-slate-400"
                    }`}>
                      {phase.status}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-white/5 rounded-full">
                    <div
                      className={`h-full rounded-full transition-all ${
                        phase.status === "completed" ? "bg-green-500" :
                        phase.status === "completed_with_errors" ? "bg-yellow-500" :
                        phase.status === "running" ? "bg-blue-500" : "bg-slate-600"
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="flex justify-between mt-1 text-xs text-slate-500">
                    <span>{phase.completed_jobs}/{phase.job_count} jobs</span>
                    {phase.failed_jobs > 0 && <span className="text-red-400">{phase.failed_jobs} failed</span>}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activeTab === "timeline" && (
          <div className="space-y-1 max-h-[60vh] overflow-y-auto">
            {timeline.map((entry, i) => (
              <div key={i} className="flex items-start gap-3 px-3 py-2 rounded-lg hover:bg-white/5 text-sm">
                <span className="text-xs text-slate-600 font-mono w-20 shrink-0">
                  {entry.created_at ? new Date(entry.created_at).toLocaleTimeString() : ""}
                </span>
                <span className={`w-20 shrink-0 text-xs px-1.5 py-0.5 rounded ${
                  entry.event_type.includes("started") ? "bg-blue-500/10 text-blue-400" :
                  entry.event_type.includes("completed") ? "bg-green-500/10 text-green-400" :
                  entry.event_type.includes("failed") ? "bg-red-500/10 text-red-400" :
                  "bg-slate-500/10 text-slate-400"
                }`}>
                  {entry.event_type.replace(/_/g, " ")}
                </span>
                <span className="text-slate-400">{entry.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
