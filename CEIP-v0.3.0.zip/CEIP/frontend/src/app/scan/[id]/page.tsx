"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { getScanStatus, getScanResult } from "@/lib/api-client";

const MODULES = [
  "M1-Discovery", "M2-Correlation", "M3-Vulnerability",
  "M4-ThreatIntel", "M5-RiskEngine", "M6-AIAnalysis", "M7-Reports",
];

export default function ScanProgressPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const searchParams = useSearchParams();
  const domain = searchParams.get("domain") || "";
  const [progress, setProgress] = useState(0);
  const [currentModule, setCurrentModule] = useState("Initializing...");
  const [logs, setLogs] = useState<string[]>([]);
  const [status, setStatus] = useState("running");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    const interval = setInterval(async () => {
      try {
        const s = await getScanStatus(id as string);
        setProgress(s.progress || 0);
        setCurrentModule(s.current_module || "");
        setLogs(s.logs || []);
        setStatus(s.status);
        if (s.status === "completed") {
          clearInterval(interval);
          router.push(`/dashboard/${id}?domain=${encodeURIComponent(domain)}`);
        }
        if (s.status === "failed") {
          clearInterval(interval);
          setError("Scan failed. Please try again.");
        }
      } catch {
        // keep polling
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [id, domain]);

  return (
    <main className="min-h-screen bg-gray-950 text-white flex items-center justify-center">
      <div className="max-w-2xl w-full px-6">
        <h1 className="text-3xl font-bold mb-2">Scanning {domain}</h1>
        <p className="text-gray-400 mb-8">Status: {status}</p>

        <div className="w-full bg-gray-800 rounded-full h-4 mb-4">
          <div
            className="bg-gradient-to-r from-blue-500 to-cyan-400 h-4 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-center text-gray-400 mb-6">{progress}% — {currentModule}</p>

        <div className="space-y-2 mb-6">
          {MODULES.map((m, i) => (
            <div
              key={m}
              className={`flex items-center gap-3 px-4 py-2 rounded-lg text-sm ${
                i < Math.floor(progress / (100 / MODULES.length))
                  ? "bg-blue-900/30 text-blue-300"
                  : "bg-gray-800/50 text-gray-600"
              }`}
            >
              <span className={i < Math.floor(progress / (100 / MODULES.length)) ? "text-green-400" : "text-gray-600"}>
                {i < Math.floor(progress / (100 / MODULES.length)) ? "✓" : "○"}
              </span>
              {m}
            </div>
          ))}
        </div>

        {error && <p className="text-red-400 text-center">{error}</p>}

        <div className="bg-gray-900 rounded-xl p-4 max-h-40 overflow-y-auto">
          {logs.slice(-10).map((log, i) => (
            <p key={i} className="text-gray-500 text-xs font-mono">{log}</p>
          ))}
        </div>
      </div>
    </main>
  );
}
