"use client";

import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import { listInvestigations, type InvestigationSummary } from "@/lib/investigation-api";

export default function ScansPage() {
  const [investigations, setInvestigations] = useState<InvestigationSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    listInvestigations()
      .then((data) => setInvestigations(data.investigations || []))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="flex min-h-screen bg-[#020617] text-slate-200">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2" style={{ fontFamily: "'Fira Code', monospace" }}>
            Investigations
          </h1>
          <p className="text-slate-400">All security investigations — real data from InvestigationOrchestrator</p>
        </header>

        {loading && (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full" />
          </div>
        )}

        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
            {error}
          </div>
        )}

        {!loading && !error && investigations.length === 0 && (
          <div className="bg-white/5 border border-white/10 rounded-xl p-8 text-center">
            <div className="text-4xl mb-4">◎</div>
            <h2 className="text-xl font-bold text-white mb-2">No Investigations Yet</h2>
            <p className="text-slate-400 mb-6">Start a scan from the dashboard to create your first investigation.</p>
            <a href="/" className="inline-flex px-6 py-3 rounded-xl bg-[#22C55E] hover:bg-[#16a34a] text-black font-semibold transition-all">
              New Scan
            </a>
          </div>
        )}

        {!loading && investigations.length > 0 && (
          <div className="space-y-3">
            {investigations.map((inv) => (
              <a
                key={inv.id}
                href={`/investigation/${inv.id}`}
                className="block p-4 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm font-semibold text-slate-200">{inv.domain}</span>
                    <span className="ml-3 text-xs text-slate-500">ID: {inv.id.slice(0, 8)}...</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                      inv.status === "completed" ? "bg-green-500/20 text-green-400" :
                      inv.status === "running" ? "bg-blue-500/20 text-blue-400" :
                      inv.status === "failed" ? "bg-red-500/20 text-red-400" :
                      "bg-slate-500/20 text-slate-400"
                    }`}>
                      {inv.status}
                    </span>
                    <span className="text-xs text-slate-500">{inv.progress_pct.toFixed(0)}%</span>
                    <span className="text-xs text-slate-600">
                      {inv.evidence_count} evidence · Risk: {inv.risk_level}
                    </span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
