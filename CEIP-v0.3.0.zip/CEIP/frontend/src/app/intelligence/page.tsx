"use client";

import { useEffect, useState } from "react";
import { listInvestigations, type InvestigationSummary } from "@/lib/investigation-api";

const SEV_STYLE: Record<string, string> = {
  CRITICAL: "border-red-500/30 bg-red-500/5",
  HIGH: "border-orange-500/30 bg-orange-500/5",
  MEDIUM: "border-yellow-500/30 bg-yellow-500/5",
  LOW: "border-blue-500/30 bg-blue-500/5",
};

const SEV_DOT: Record<string, string> = {
  CRITICAL: "bg-red-500",
  HIGH: "bg-orange-500",
  MEDIUM: "bg-yellow-500",
  LOW: "bg-blue-500",
};

interface IntelCase {
  case_id: string;
  title: string;
  executive_summary: string;
  risk_level: string;
  confidence: number;
  priority: string;
  evidence: string[];
  affected_assets: string[];
  attack_path: string[];
  threat_context: string;
  business_impact: string;
  root_cause: string;
  recommendations: string[];
  kill_chain_stages: string[];
  analyst_notes: string;
  related_findings: string[];
  created_at: string | null;
}

interface AttackChain {
  chain_id: string;
  title: string;
  severity: string;
  risk_score: number;
  confidence: number;
  steps: Array<{ step_number: number; source: string; target: string; action: string }>;
  kill_chain_stages: string[];
  blocked: boolean;
  mitigations: string[];
}

interface RiskCorr {
  dimensions: Record<string, number>;
  overall_score: number;
  risk_level: string;
  factor_breakdown: Array<{ dimension: string; score: number; weight: number; contribution: number }>;
}

interface GraphData {
  nodes: Array<{ id: string; type: string; label: string; layer: number; group: string; severity?: string }>;
  edges: Array<{ source: string; target: string; type: string; label: string; group: string }>;
  node_count: number;
  edge_count: number;
  crown_jewels: string[];
  entry_points: string[];
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function fetchIntel(endpoint: string) {
  const token = typeof window !== "undefined" ? localStorage.getItem("ceip_token") : null;
  const res = await fetch(`${API_BASE}${endpoint}`, {
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

export default function IntelligencePage() {
  const [investigations, setInvestigations] = useState<InvestigationSummary[]>([]);
  const [selectedInv, setSelectedInv] = useState<string>("");
  const [cases, setCases] = useState<IntelCase[]>([]);
  const [chains, setChains] = useState<AttackChain[]>([]);
  const [risk, setRisk] = useState<RiskCorr | null>(null);
  const [graph, setGraph] = useState<GraphData | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"cases" | "chains" | "risk" | "graph">("cases");
  const [expandedCase, setExpandedCase] = useState<string | null>(null);

  const [invError, setInvError] = useState("");

  useEffect(() => {
    listInvestigations()
      .then((data) => setInvestigations(data.investigations || []))
      .catch((e) => setInvError(e.message || "Failed to load investigations"));
  }, []);

  useEffect(() => {
    if (!selectedInv) return;
    setLoading(true);

    Promise.all([
      fetchIntel(`/api/v1/intelligence/cases/${selectedInv}`).catch(() => []),
      fetchIntel(`/api/v1/intelligence/attack-chains/${selectedInv}`).catch(() => []),
      fetchIntel(`/api/v1/intelligence/risk-correlation/${selectedInv}`).catch(() => null),
      fetchIntel(`/api/v1/intelligence/graph/${selectedInv}`).catch(() => null),
    ]).then(([c, ch, r, g]) => {
      setCases(c || []);
      setChains(ch || []);
      setRisk(r);
      setGraph(g);
      setLoading(false);
    });
  }, [selectedInv]);

  return (
    <div className="min-h-screen bg-[#020617] text-[#F8FAFC]" style={{ fontFamily: "'Fira Sans', sans-serif" }}>
      <div className="p-6 space-y-6 max-w-[1800px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight" style={{ fontFamily: "'Fira Code', monospace" }}>
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
                Security Intelligence
              </span>
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              {cases.length} cases · {chains.length} attack chains · {risk ? `${(risk.overall_score * 100).toFixed(0)}/100 risk` : "—"}
            </p>
          </div>
          <select
            value={selectedInv}
            onChange={(e) => setSelectedInv(e.target.value)}
            className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-slate-300 focus:outline-none focus:border-purple-500/50"
          >
            <option value="">Select investigation...</option>
            {investigations.map((inv) => (
              <option key={inv.id} value={inv.id}>
                {inv.domain} ({inv.status})
              </option>
            ))}
          </select>
        </div>

        {loading && (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full" />
          </div>
        )}

        {!selectedInv && !loading && (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500">
            <span className="text-4xl mb-4">⬡</span>
            <p>Select an investigation to view intelligence</p>
          </div>
        )}

        {selectedInv && !loading && (
          <>
            {/* Tabs */}
            <div className="flex gap-1 border-b border-white/5">
              {[
                { key: "cases" as const, label: `Intelligence Cases (${cases.length})` },
                { key: "chains" as const, label: `Attack Chains (${chains.length})` },
                { key: "risk" as const, label: "Risk Correlation" },
                { key: "graph" as const, label: "Relationship Graph" },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-4 py-2 text-sm transition-all ${
                    activeTab === tab.key
                      ? "border-b-2 border-purple-400 text-purple-300"
                      : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* CASES TAB */}
            {activeTab === "cases" && (
              <div className="space-y-4">
                {cases.map((c) => (
                  <div
                    key={c.case_id}
                    className={`rounded-xl border ${SEV_STYLE[c.risk_level] || "border-white/5"} overflow-hidden`}
                  >
                    <button
                      onClick={() => setExpandedCase(expandedCase === c.case_id ? null : c.case_id)}
                      className="w-full p-4 text-left hover:bg-white/5 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-2 h-2 rounded-full ${SEV_DOT[c.risk_level]}`} />
                        <span className="text-xs font-mono text-slate-500">{c.case_id}</span>
                        <span className="flex-1 text-sm font-semibold text-slate-200">{c.title}</span>
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          c.priority === "CRITICAL" ? "bg-red-500/20 text-red-400" :
                          c.priority === "HIGH" ? "bg-orange-500/20 text-orange-400" :
                          "bg-blue-500/20 text-blue-400"
                        }`}>
                          {c.priority}
                        </span>
                        <span className="text-xs text-slate-500">{(c.confidence * 100).toFixed(0)}% conf</span>
                      </div>
                    </button>

                    {expandedCase === c.case_id && (
                      <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
                        {/* Executive Summary */}
                        <div>
                          <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Executive Summary</h4>
                          <p className="text-sm text-slate-300 leading-relaxed">{c.executive_summary}</p>
                        </div>

                        {/* Affected Assets + Attack Path */}
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Affected Assets</h4>
                            <div className="flex flex-wrap gap-1">
                              {c.affected_assets.map((a) => (
                                <span key={a} className="px-2 py-0.5 rounded bg-white/5 text-xs text-slate-400">{a}</span>
                              ))}
                            </div>
                          </div>
                          <div>
                            <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Attack Path</h4>
                            <div className="space-y-0.5">
                              {c.attack_path.map((step, i) => (
                                <div key={i} className="flex items-center gap-2 text-xs">
                                  <span className="text-slate-600">{i + 1}.</span>
                                  <span className="text-slate-400">{step}</span>
                                  {i < c.attack_path.length - 1 && <span className="text-purple-500">↓</span>}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Business Impact + Threat Context */}
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Business Impact</h4>
                            <p className="text-xs text-slate-400">{c.business_impact}</p>
                          </div>
                          <div>
                            <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Root Cause</h4>
                            <p className="text-xs text-slate-400">{c.root_cause}</p>
                          </div>
                        </div>

                        {/* Recommendations */}
                        <div>
                          <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Recommendations</h4>
                          <div className="space-y-1">
                            {c.recommendations.map((r, i) => (
                              <div key={i} className="flex items-center gap-2 text-xs text-slate-400">
                                <span className="text-green-500">►</span>
                                {r}
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Kill Chain + Analyst Notes */}
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Kill Chain Stages</h4>
                            <div className="flex flex-wrap gap-1">
                              {c.kill_chain_stages.map((s) => (
                                <span key={s} className="px-2 py-0.5 rounded bg-purple-500/10 text-xs text-purple-400">
                                  {s.replace(/_/g, " ")}
                                </span>
                              ))}
                            </div>
                          </div>
                          <div>
                            <h4 className="text-xs uppercase tracking-wider text-slate-500 mb-1">Analyst Notes</h4>
                            <p className="text-xs text-slate-500 italic">{c.analyst_notes}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* CHAINS TAB */}
            {activeTab === "chains" && (
              <div className="space-y-4">
                {chains.map((chain) => (
                  <div key={chain.chain_id} className="p-4 rounded-xl bg-white/5 border border-white/5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${SEV_DOT[chain.severity] || "bg-slate-500"}`} />
                        <span className="text-sm font-semibold text-slate-200">{chain.title}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs">
                        <span className="text-slate-500">Risk: {chain.risk_score.toFixed(0)}</span>
                        <span className="text-slate-500">Conf: {(chain.confidence * 100).toFixed(0)}%</span>
                        {chain.blocked && <span className="px-2 py-0.5 rounded bg-green-500/20 text-green-400">Blocked</span>}
                      </div>
                    </div>

                    {/* Steps visualization */}
                    <div className="flex items-center gap-2 flex-wrap py-2">
                      {chain.steps.map((step, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <div className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs">
                            <span className="text-slate-500">{step.source}</span>
                            <span className="text-purple-500 mx-1">→</span>
                            <span className="text-slate-300">{step.target}</span>
                          </div>
                          {i < chain.steps.length - 1 && (
                            <span className="text-purple-600 text-lg">↓</span>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Kill chain stages */}
                    <div className="flex gap-1 mt-2">
                      {chain.kill_chain_stages.map((s) => (
                        <span key={s} className="px-2 py-0.5 rounded bg-purple-500/10 text-[10px] text-purple-400 uppercase">
                          {s.replace(/_/g, " ")}
                        </span>
                      ))}
                    </div>

                    {/* Mitigations */}
                    {chain.mitigations.length > 0 && (
                      <div className="mt-2 space-y-0.5">
                        {chain.mitigations.map((m, i) => (
                          <div key={i} className="text-xs text-green-400">► {m}</div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* RISK TAB */}
            {activeTab === "risk" && risk && (
              <div className="space-y-6">
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <div className="flex items-baseline gap-3 mb-4">
                    <span className="text-4xl font-bold" style={{ fontFamily: "'Fira Code', monospace" }}>
                      {(risk.overall_score * 100).toFixed(0)}
                    </span>
                    <span className="text-slate-500">/100</span>
                    <span className={`px-3 py-1 rounded text-sm font-semibold ${
                      risk.risk_level === "CRITICAL" ? "bg-red-500/20 text-red-400" :
                      risk.risk_level === "HIGH" ? "bg-orange-500/20 text-orange-400" :
                      "bg-blue-500/20 text-blue-400"
                    }`}>
                      {risk.risk_level}
                    </span>
                  </div>

                  {/* 8 dimension bars */}
                  <div className="space-y-2">
                    {Object.entries(risk.dimensions).map(([key, value]) => (
                      <div key={key} className="flex items-center gap-3">
                        <span className="w-32 text-xs text-slate-500 capitalize text-right">
                          {key.replace(/_/g, " ")}
                        </span>
                        <div className="flex-1 h-3 bg-white/5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              value >= 0.75 ? "bg-red-500" : value >= 0.5 ? "bg-orange-500" : value >= 0.25 ? "bg-yellow-500" : "bg-blue-500"
                            }`}
                            style={{ width: `${value * 100}%` }}
                          />
                        </div>
                        <span className="w-10 text-xs text-slate-400 text-right" style={{ fontFamily: "'Fira Code', monospace" }}>
                          {(value * 100).toFixed(0)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Factor breakdown */}
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <h3 className="text-sm font-semibold text-slate-300 mb-3">Risk Factor Breakdown</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {risk.factor_breakdown.map((f) => (
                      <div key={f.dimension} className="flex items-center justify-between px-3 py-2 rounded-lg bg-white/5 text-xs">
                        <span className="text-slate-400 capitalize">{f.dimension.replace(/_/g, " ")}</span>
                        <span className="text-slate-500">
                          {(f.score * 100).toFixed(0)}% × {f.weight.toFixed(2)} = {" "}
                          <span className="text-purple-400">{(f.contribution * 100).toFixed(1)}%</span>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* GRAPH TAB */}
            {activeTab === "graph" && graph && (
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-xl font-bold text-purple-300" style={{ fontFamily: "'Fira Code', monospace" }}>
                      {graph.node_count}
                    </div>
                    <div className="text-xs text-slate-500">Nodes</div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-xl font-bold text-cyan-300" style={{ fontFamily: "'Fira Code', monospace" }}>
                      {graph.edge_count}
                    </div>
                    <div className="text-xs text-slate-500">Edges</div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-xl font-bold text-yellow-300" style={{ fontFamily: "'Fira Code', monospace" }}>
                      {graph.crown_jewels.length}
                    </div>
                    <div className="text-xs text-slate-500">Crown Jewels</div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-xl font-bold text-green-300" style={{ fontFamily: "'Fira Code', monospace" }}>
                      {graph.entry_points.length}
                    </div>
                    <div className="text-xs text-slate-500">Entry Points</div>
                  </div>
                </div>

                {/* Graph layer breakdown */}
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <h3 className="text-sm font-semibold text-slate-300 mb-3">Graph Layer Breakdown</h3>
                  <div className="space-y-1">
                    {Array.from({ length: 7 }, (_, i) => i + 1).map((layer) => {
                      const nodes = graph.nodes.filter((n) => n.layer === layer);
                      const colors: Record<number, string> = {
                        1: "bg-blue-500", 2: "bg-cyan-500", 3: "bg-green-500",
                        4: "bg-yellow-500", 5: "bg-orange-500", 6: "bg-red-500", 7: "bg-purple-500",
                      };
                      const labels: Record<number, string> = {
                        1: "Domains", 2: "IPs", 3: "Services", 4: "Technologies",
                        5: "Findings", 6: "Threats", 7: "Business Assets",
                      };
                      return (
                        <div key={layer} className="flex items-center gap-3 text-xs">
                          <span className="w-32 text-slate-500">{labels[layer]}</span>
                          <div className="flex-1 h-2 bg-white/5 rounded-full">
                            <div
                              className={`h-full rounded-full ${colors[layer] || "bg-slate-500"}`}
                              style={{ width: `${(nodes.length / Math.max(graph.node_count, 1)) * 100}%` }}
                            />
                          </div>
                          <span className="w-8 text-slate-400 text-right">{nodes.length}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Nodes table */}
                <div className="p-4 rounded-xl bg-white/5 border border-white/5 max-h-96 overflow-y-auto">
                  <h3 className="text-sm font-semibold text-slate-300 mb-3">Nodes ({graph.node_count})</h3>
                  <div className="space-y-1">
                    {graph.nodes.slice(0, 50).map((node) => (
                      <div key={node.id} className="flex items-center gap-3 px-2 py-1 rounded hover:bg-white/5 text-xs">
                        <span className="w-20 text-slate-600 uppercase">{node.type}</span>
                        <span className="flex-1 text-slate-400 truncate">{node.label}</span>
                        <span className="text-slate-600">Layer {node.layer}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
