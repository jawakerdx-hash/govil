"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { startScan } from "@/lib/api-client";

export default function LandingPage() {
  const [domain, setDomain] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  async function handleScan(e: React.FormEvent) {
    e.preventDefault();
    if (!domain.trim()) return;
    setLoading(true); setError("");
    try {
      const clean = domain.trim().replace(/^https?:\/\//, "").replace(/\/$/, "").split("/")[0].replace(/^www\./, "");
      const result = await startScan(clean);
      router.push(`/scan/${result.scan_id}?domain=${encodeURIComponent(clean)}`);
    } catch (err: any) { setError(err.message || "Scan failed"); }
    finally { setLoading(false); }
  }

  return (
    <main className="min-h-screen bg-[#020617] text-[#F8FAFC] flex items-center justify-center relative overflow-hidden" style={{fontFamily:"'Fira Sans',sans-serif"}}>
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-transparent to-cyan-900/20 pointer-events-none" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl" />

      <div className="relative max-w-3xl w-full px-6 text-center z-10">
        <div className="mb-2 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#22C55E]/10 border border-[#22C55E]/20 text-[#22C55E] text-xs font-medium tracking-wider uppercase" style={{fontFamily:"'Fira Code',monospace"}}>
          v1.0 GA · Production Ready
        </div>
        <h1 className="text-6xl font-bold mt-4 mb-2 tracking-tight" style={{fontFamily:"'Fira Code',monospace"}}>
          <span className="bg-gradient-to-r from-blue-400 via-cyan-300 to-green-400 bg-clip-text text-transparent">CEIP</span>
        </h1>
        <p className="text-lg text-slate-400 mb-10 max-w-xl mx-auto">
          Cyber Exposure Intelligence Platform — External Security Rating & Continuous Threat Monitoring
        </p>

        <form onSubmit={handleScan} className="flex gap-3 max-w-xl mx-auto">
          <div className="flex-1 relative">
            <input
              type="text"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              placeholder="dumyah.com"
              className="w-full px-5 py-4 rounded-xl bg-white/5 backdrop-blur-xl border border-white/10 text-white text-lg focus:outline-none focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 placeholder-slate-600 transition-all duration-200"
              disabled={loading}
              style={{fontFamily:"'Fira Code',monospace"}}
            />
          </div>
          <button
            type="submit"
            disabled={loading || !domain.trim()}
            className="px-8 py-4 rounded-xl bg-[#22C55E] hover:bg-[#16a34a] disabled:bg-slate-800 disabled:text-slate-600 font-semibold text-lg text-black transition-all duration-200 cursor-pointer disabled:cursor-not-allowed"
          >
            {loading ? (
              <span className="flex items-center gap-2"><span className="animate-spin w-4 h-4 border-2 border-black/30 border-t-black rounded-full" />Scanning</span>
            ) : "Scan"}
          </button>
        </form>
        {error && <p className="mt-4 text-red-400 text-sm">{error}</p>}

        <div className="mt-16 grid grid-cols-3 gap-4 max-w-2xl mx-auto">
          {[
            { label: "Attack Surface", value: "Discovery" },
            { label: "Vulnerabilities", value: "CVE + Misconfig" },
            { label: "Security Rating", value: "0-100 Score" },
          ].map((s) => (
            <div key={s.label} className="p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/5 hover:border-white/10 transition-all duration-200 cursor-pointer">
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-1">{s.label}</div>
              <div className="text-sm text-slate-300">{s.value}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
