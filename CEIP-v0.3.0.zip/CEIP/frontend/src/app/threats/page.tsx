"use client";

import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export default function ThreatIntelligencePage() {
  const [domain, setDomain] = useState("");
  const [threats, setThreats] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function fetchThreats() {
    if (!domain.trim()) return;
    setLoading(true);
    setError("");
    try {
      const token = localStorage.getItem("ceip_token");
      const res = await fetch(`${API_BASE}/api/v1/threats/${domain.trim()}`, {
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      setThreats(await res.json());
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen bg-[#020617] text-slate-200">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2" style={{ fontFamily: "'Fira Code', monospace" }}>
            Threat Intelligence
          </h1>
          <p className="text-slate-400">Real IOC matching from ThreatService — no mock data</p>
        </header>

        <div className="flex gap-3 mb-8">
          <input
            type="text"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && fetchThreats()}
            placeholder="example.com"
            className="flex-1 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
          />
          <button
            onClick={fetchThreats}
            disabled={loading}
            className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-semibold transition-all"
          >
            {loading ? "Searching..." : "Search"}
          </button>
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm mb-4">
            {error}
          </div>
        )}

        {loading && (
          <div className="flex justify-center py-10">
            <div className="animate-spin w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full" />
          </div>
        )}

        {!loading && !error && !threats && (
          <div className="bg-white/5 border border-white/10 rounded-xl p-8 text-center text-slate-500">
            Enter a domain above to query real threat intelligence
          </div>
        )}

        {threats && (
          <>
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="bg-white/5 border border-white/10 rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-rose-400" style={{ fontFamily: "'Fira Code', monospace" }}>
                  {threats.matches_count || 0}
                </div>
                <div className="text-sm text-slate-500 mt-1">Total Matches</div>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-red-400" style={{ fontFamily: "'Fira Code', monospace" }}>
                  {threats.malicious || 0}
                </div>
                <div className="text-sm text-slate-500 mt-1">Malicious</div>
              </div>
              <div className="bg-white/5 border border-white/10 rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-amber-400" style={{ fontFamily: "'Fira Code', monospace" }}>
                  {threats.suspicious || 0}
                </div>
                <div className="text-sm text-slate-500 mt-1">Suspicious</div>
              </div>
            </div>

            {threats.matches?.length > 0 && (
              <div className="space-y-2">
                <h2 className="text-lg font-bold text-white mb-3">Threat Matches</h2>
                {threats.matches.map((m: any, i: number) => (
                  <div key={i} className="p-3 rounded-lg bg-white/5 border border-white/5 text-sm">
                    <span className={`inline-block px-2 py-0.5 rounded text-xs font-semibold mr-2 ${
                      m.severity === "malicious" ? "bg-red-500/20 text-red-400" : "bg-yellow-500/20 text-yellow-400"
                    }`}>
                      {m.severity}
                    </span>
                    <span className="text-slate-300">{m.matched_asset}</span>
                    <span className="ml-2 text-xs text-slate-500">[{m.threat_category}]</span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
