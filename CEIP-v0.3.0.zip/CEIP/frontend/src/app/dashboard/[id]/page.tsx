'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { getScanResult } from '@/lib/api-client';
import type { ScanResult } from '@/lib/types';

const SEV_COLORS: Record<string, string> = { CRITICAL:'text-red-400', HIGH:'text-orange-400', MEDIUM:'text-yellow-400', LOW:'text-green-400' };
const SEV_BG: Record<string, string> = { CRITICAL:'bg-red-950/50 border-red-500/30', HIGH:'bg-orange-950/50 border-orange-500/30', MEDIUM:'bg-yellow-950/50 border-yellow-500/30', LOW:'bg-green-950/50 border-green-500/30' };

export default function ScanDashboardPage() {
  const rawParams = useParams();
  const id = rawParams.id as string;
  const router = useRouter();
  const searchParams = useSearchParams();
  const domain = searchParams.get('domain') || 'Unknown Domain';

  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pdfLoading, setPdfLoading] = useState('');

  useEffect(() => {
    (async () => {
      setLoading(true); setError(null);
      try { setScanResult(await getScanResult(id) as ScanResult); }
      catch { setError('Failed to fetch scan results.'); }
      finally { setLoading(false); }
    })();
  }, [id]);

  async function downloadPDF(type: string) {
    setPdfLoading(type);
    try {
      const pdfUrl = process.env.NEXT_PUBLIC_PDF_URL || 'http://localhost:8090';
      const payload: Record<string, unknown> = { executive_report: scanResult?.executive_dashboard };
      if (type === 'technical') payload.technical_report = {
        critical_findings: (scanResult?.findings||[]).map(f=>({type:f.type,severity:f.severity,description:f.title,priority:f.severity==='CRITICAL'?'P1':'P2'})),
        attack_surface_summary: `${scanResult?.subdomains?.length||0} subdomains`,
        threat_campaigns: [], infrastructure_exposure: [], identity_exposure: [], attack_paths: [],
        misconfiguration_summary: `${scanResult?.total_findings||0} findings`,
      };
      const res = await fetch(`${pdfUrl}/render/${type}`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
      if (res.ok) {
        const data = await res.json();
        if (data.download_url) {
          const a = document.createElement('a'); a.href = `${pdfUrl}${data.download_url}`; a.download = `${domain}_${type}_report.pdf`; a.click();
        }
      }
    } catch { /* PDF download failed silently */ }
    finally { setPdfLoading(''); }
  }

  if (loading) return <div className="flex min-h-screen bg-[#020617] items-center justify-center"><div className="animate-spin w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full"/></div>;
  if (error) return <div className="flex min-h-screen bg-[#020617] items-center justify-center text-red-400">{error}</div>;
  if (!scanResult) return <div className="flex min-h-screen bg-[#020617] items-center justify-center text-slate-400">No scan data available</div>;

  const findings = scanResult.findings || [];
  const sevCounts = scanResult.severity_counts || { CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0 };
  const subdomains = Array.from(new Set(findings.map(f=>f.subdomain).filter(Boolean)));

  return (
    <div className="flex min-h-screen bg-[#020617] text-[#F8FAFC]" style={{fontFamily:"'Fira Sans',sans-serif"}}>
      <main className="flex-1 p-8 overflow-y-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <button onClick={() => router.push('/scans')} className="text-xs text-slate-500 hover:text-slate-300 mb-1">&larr; Back to Investigations</button>
            <h1 className="text-3xl font-bold text-white" style={{fontFamily:"'Fira Code',monospace"}}>{domain}</h1>
            <p className="text-sm text-slate-400 mt-1">Scan ID: {id.slice(0,8)}... &middot; {findings.length} findings</p>
          </div>
          <div className="flex gap-3">
            {['executive','technical','compliance'].map(t=>(
              <button key={t} onClick={()=>downloadPDF(t)} disabled={!!pdfLoading}
                className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-sm text-slate-300 hover:bg-white/10 disabled:opacity-50 transition-all capitalize">
                {pdfLoading===t ? 'Downloading...' : `Download ${t}`}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-8">
          {Object.entries(sevCounts).map(([s,c])=>(
            <div key={s} className={`p-4 rounded-xl border ${SEV_BG[s]||'bg-white/5 border-white/10'}`}>
              <div className={`text-2xl font-bold ${SEV_COLORS[s]||'text-slate-400'}`} style={{fontFamily:"'Fira Code',monospace"}}>{c as number}</div>
              <div className="text-xs text-slate-500 uppercase tracking-wider">{s}</div>
            </div>
          ))}
        </div>

        <div className="space-y-3">
          <h2 className="text-lg font-bold text-white">Findings</h2>
          {findings.map((f,i)=>(
            <div key={i} className="p-4 rounded-xl bg-white/5 border border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2 py-0.5 rounded text-xs font-bold ${f.severity==='CRITICAL'?'bg-red-500/20 text-red-400':f.severity==='HIGH'?'bg-orange-500/20 text-orange-400':f.severity==='MEDIUM'?'bg-yellow-500/20 text-yellow-400':'bg-blue-500/20 text-blue-400'}`}>{f.severity}</span>
                <span className="text-sm font-semibold text-slate-200">{f.title}</span>
              </div>
              {f.description && <p className="text-xs text-slate-400 mb-2">{f.description}</p>}
              <div className="flex gap-4 text-xs text-slate-500">
                {f.subdomain && <span>📍 {f.subdomain}</span>}
                {f.module_source && <span>🔬 {f.module_source}</span>}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
