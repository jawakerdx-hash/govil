import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CEIP — Cyber Exposure Intelligence Platform",
  description: "Enterprise External Security Rating & Continuous Threat Monitoring",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#020617] text-[#F8FAFC] antialiased" style={{fontFamily:"'Fira Sans', sans-serif"}}>
        {children}
      </body>
    </html>
  );
}
