"use client";

import { useState } from "react";
import Sidebar from "@/components/Sidebar";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

const REPORT_TYPES = [
  { type: "executive", title: "Executive Report", desc: "CEO-level summary with risk score, grade, business impact", icon: "◈" },
  { type: "technical", title: "Technical Report", desc: "SOC-level detail with CVEs, evidence, attack paths", icon: "◇" },
  { type: "compliance", title: "Compliance Report", desc: "PCI DSS, ISO 27001, NIST CSF, CIS Controls mapping", icon: "◎" },
  { type: "monitoring", title: "Monitoring Report", desc: "Continuous monitoring history, diffs, alerts", icon: "◉" },
  { type: "threat", title: "Threat Report", desc: "IOC matches, threat categories, confidence levels", icon: "⚠" },
  { type: "risk", title: "Risk Report", desc: "Risk scores, trends, factor breakdown", icon: "◆" },
];

export default function ReportsPage() {
  const [domain, setDomain] = useState("");
  const [reportType, setReportType] = useState("executive");
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function generateReport() {
    if (!domain.trim()) return;
    setLoading(true);
    setError("");
    try {
      const token = localStorage.getItem("ceip_token");
      const res = await fetch(`${API_BASE}/api/v1/reports/${reportType}/${domain.trim()}`, {
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      setReport(await res.json());
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen bg-[#020617] text-slate-200">
      <Sidebar />
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2" style={{ fontFamily: "'Fira Code', monospace" }}>
            Reports
          </h1>
          <p className="text-slate-400">Enterprise security reports generated from persisted investigation data</p>
        </header>

        <div className="flex gap-3 mb-4">
          <input
            type="text"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && generateReport()}
            placeholder="example.com"
            className="flex-1 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-slate-600 focus:outline-none focus:border-blue-500/50"
          />
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            className="px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white focus:outline-none"
          >
            {REPORT_TYPES.map((r) => (
              <option key={r.type} value={r.type}>{r.title}</option>
            ))}
          </select>
          <button
            onClick={generateReport}
            disabled={loading}
            className="px-6 py-3 rounded-xl bg-green-600 hover:bg-green-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-semibold transition-all"
          >
            {loading ? "Generating..." : "Generate"}
          </button>
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm mb-4">
            {error}
          </div>
        )}

        <div className="grid grid-cols-3 gap-4 mb-8">
          {REPORT_TYPES.map((r) => (
            <div
              key={r.type}
              onClick={() => { setReportType(r.type); setReport(null); }}
              className={`bg-white/5 border rounded-xl p-6 cursor-pointer transition-all ${
                reportType === r.type ? "border-blue-500/30 bg-blue-500/5" : "border-white/10 hover:border-white/20"
              }`}
            >
              <div className="text-2xl mb-3">{r.icon}</div>
              <h3 className="text-lg font-bold text-white mb-2">{r.title}</h3>
              <p className="text-sm text-slate-400">{r.desc}</p>
            </div>
          ))}
        </div>

        {loading && (
          <div className="flex justify-center py-10">
            <div className="animate-spin w-8 h-8 border-2 border-green-500/30 border-t-green-500 rounded-full" />
          </div>
        )}

        {report && !loading && (
          <div className="bg-white/5 border border-white/10 rounded-xl p-6">
            <h2 className="text-lg font-bold text-white mb-2">{report.title}</h2>
            <p className="text-xs text-slate-500 mb-4">Generated: {report.generated_at} | Domain: {report.domain}</p>
            {report.sections?.map((s: any, i: number) => (
              <div key={i} className="mb-4">
                <h3 className="text-sm font-bold text-slate-300 mb-1">{s.title}</h3>
                {s.description && <p className="text-xs text-slate-400 mb-2">{s.description}</p>}
                {s.items?.slice(0, 10).map((item: string, j: number) => (
                  <div key={j} className="text-xs text-slate-500 pl-3">- {item}</div>
                ))}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
