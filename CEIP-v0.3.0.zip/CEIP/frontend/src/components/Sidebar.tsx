"use client";

import { usePathname } from "next/navigation";

const NAV_ITEMS = [
  { label: "Dashboard", path: "/", icon: "□" },
  { label: "Investigations", path: "/scans", icon: "◎" },
  { label: "Intelligence", path: "/intelligence", icon: "⬡" },
  { label: "Reports", path: "/reports", icon: "▣" },
  { label: "Threat Intel", path: "/threats", icon: "⚠" },
];

export default function Sidebar() {
  const pathname = usePathname();
  return (
    <aside className="w-56 bg-[#020617] border-r border-white/5 flex flex-col h-screen sticky top-0 shrink-0">
      <div className="p-4 border-b border-white/5">
        <a href="/" className="text-sm font-bold tracking-wider text-white hover:opacity-80 transition-opacity cursor-pointer" style={{fontFamily:"'Fira Code',monospace"}}>
          <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">CEIP</span>
        </a>
        <p className="text-[10px] text-slate-600 mt-0.5 uppercase tracking-widest">Security Platform</p>
      </div>
      <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map(item => {
          const isActive = pathname === item.path || (item.path !== "/" && pathname.startsWith(item.path));
          return (
            <a key={item.path} href={item.path}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150 cursor-pointer ${
                isActive ? 'bg-white/10 text-white' : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
              }`}>
              <span className="text-xs w-4 text-center">{item.icon}</span>
              <span>{item.label}</span>
            </a>
          );
        })}
      </nav>
      <div className="p-3 border-t border-white/5">
        <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-white/5 text-xs text-slate-400">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
          v1.1 GA
        </div>
      </div>
    </aside>
  );
}
