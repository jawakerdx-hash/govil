/** CEIP API Client — single source, aligned with backend routes */
const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function ceipFetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const token = typeof window !== "undefined" ? localStorage.getItem("ceip_token") : null;
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options?.headers,
    },
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

export async function fetchDashboard(domain: string) {
  return ceipFetch(`/api/v1/dashboard/executive/${domain}`);
}

export async function fetchRisk(domain: string) {
  return ceipFetch(`/api/v1/risk/${domain}`);
}

export async function fetchThreats(domain: string) {
  return ceipFetch(`/api/v1/threats/${domain}`);
}

export async function fetchInvestigationReport(investigationId: string) {
  return ceipFetch(`/api/v1/investigations/${investigationId}/report`);
}

export { API_BASE };
