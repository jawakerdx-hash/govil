/** CEIP TypeScript type definitions — aligned with M1-M33 schemas */

export interface ScanRequest {
  domain: string;
  tenant_id?: string;
}

export interface ScanStatus {
  scan_id: string;
  domain: string;
  status: "pending" | "running" | "completed" | "failed";
  progress: number; // 0-100
  current_module: string; // e.g. "M3-Vulnerability"
  logs: string[];
  started_at: string;
  completed_at?: string;
}

export interface Vulnerability {
  vuln_id: string;
  cve?: string;
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  title: string;
  affected_asset: string;
  exploitability_score: number;
}

export interface ThreatCampaign {
  campaign_id: string;
  confidence: number;
  phases: string[];
}

export interface DarkWebSignal {
  intel_type: string;
  severity: string;
  title: string;
  description?: string;
}

export interface BrandDomain {
  domain: string;
  similarity_score: number;
  detection_methods: string[];
  risk_level: string;
}

export interface ExecutiveDashboard {
  security_score: number;
  risk_grade: string;
  trend: string;
  business_summary: string;
  top_risks: Array<{ dimension: string; score: number; risk_level: string }>;
  brand_exposure_summary: string;
  dark_web_exposure_summary: string;
}

export interface SOCDashboard {
  critical_vulnerabilities: Vulnerability[];
  active_threat_campaigns: ThreatCampaign[];
  exposed_assets: Array<{ asset_id: string; type: string; value: string }>;
  attack_paths: Array<{ path_id: string; risk: number; confidence: number }>;
  identity_exposure: Array<{ entity_id: string; type: string }>;
  real_time_alerts: string[];
}

export interface AIAnalysis {
  posture_summary: string;
  key_risk_drivers: Array<{ dimension: string; score: number }>;
  attacker_perspective: string;
  threat_context: Array<{ campaign?: string; relevance?: string }>;
  risk_explanation: string;
  mitigation_plan: Array<{ dimension: string; priority: string; strategy: string }>;
}

export interface ScanResult {
  scan_id: string;
  domain: string;
  executive_dashboard: ExecutiveDashboard;
  soc_dashboard: SOCDashboard;
  security_analysis: AIAnalysis;
  external_security_rating: {
    overall_score: number;
    grade: string;
    risk_level: string;
    dimension_scores: Record<string, { value: number }>;
  };
  report_metadata: {
    generated_at: string;
    confidence_score: number;
  };
}

export interface PDFStatus {
  status: "processing" | "complete" | "error";
  download_url?: string;
}
