const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function ceipFetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const token = typeof window !== "undefined" ? localStorage.getItem("ceip_token") : null;
  const tenant = typeof window !== "undefined" ? localStorage.getItem("ceip_tenant") : null;
  const res = await fetch(API_BASE + endpoint, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: "Bearer " + token } : {}),
      ...(tenant ? { "X-TENANT-ID": tenant } : {}),
      ...(options?.headers || {}),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "API error " + res.status }));
    throw new Error(err.error || err.detail || "API error " + res.status);
  }
  return res.json();
}

export async function startScan(domain: string, tenantId?: string): Promise<{ scan_id: string }> {
  return ceipFetch("/api/v1/scan", {
    method: "POST",
    body: JSON.stringify({ domain, tenant_id: tenantId }),
  });
}

export async function getScanStatus(scanId: string): Promise<any> {
  return ceipFetch("/api/v1/scan/status/" + scanId);
}

export async function getScanResult(scanId: string): Promise<any> {
  return ceipFetch("/api/v1/scan/result/" + scanId);
}

export async function getExecutiveReport(scanId: string): Promise<Blob> {
  const res = await fetch(API_BASE + "/report/" + scanId + "/pdf/executive");
  return res.blob();
}

export async function getTechnicalReport(scanId: string): Promise<Blob> {
  const res = await fetch(API_BASE + "/report/" + scanId + "/pdf/technical");
  return res.blob();
}

export async function getComplianceReport(scanId: string): Promise<Blob> {
  const res = await fetch(API_BASE + "/report/" + scanId + "/pdf/compliance");
  return res.blob();
}

export { ceipFetch, API_BASE };
