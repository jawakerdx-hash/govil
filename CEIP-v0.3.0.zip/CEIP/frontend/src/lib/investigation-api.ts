/** Investigation API client */
const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function invFetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const token = typeof window !== "undefined" ? localStorage.getItem("ceip_token") : null;
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options?.headers,
    },
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

export interface InvestigationSummary {
  id: string;
  domain: string;
  tenant_id: string;
  status: string;
  priority: string;
  current_phase: number;
  progress_pct: number;
  risk_score: number;
  risk_level: string;
  evidence_count: number;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
}

export interface PhaseSummary {
  phase_number: number;
  name: string;
  status: string;
  job_count: number;
  completed_jobs: number;
  failed_jobs: number;
  started_at: string | null;
  completed_at: string | null;
}

export interface InvestigationDetail {
  id: string;
  domain: string;
  tenant_id: string;
  status: string;
  priority: string;
  current_phase: number;
  progress_pct: number;
  total_jobs: number;
  completed_jobs: number;
  failed_jobs: number;
  running_jobs: number;
  evidence_count: number;
  asset_count: number;
  finding_count: number;
  risk_score: number;
  risk_level: string;
  intelligence_cases: number;
  error_message: string | null;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
  phases: PhaseSummary[];
}

export interface InvestigationProgress {
  investigation_id: string;
  domain: string;
  status: string;
  current_phase: number;
  progress_pct: number;
  total_jobs: number;
  completed_jobs: number;
  failed_jobs: number;
  running_jobs: number;
  evidence_count: number;
  asset_count: number;
  finding_count: number;
  risk_score: number;
  risk_level: string;
  phases: PhaseSummary[];
}

export interface EvidenceItem {
  id: string;
  evidence_type: string;
  severity: string;
  title: string;
  description: string | null;
  source_module: string;
  entity_type: string;
  entity_value: string;
  confidence: number;
  verified: boolean;
}

export interface TimelineEvent {
  phase: number | null;
  event_type: string;
  message: string;
  sequence: number;
  created_at: string;
}

export interface IntelligenceCase {
  case_id: string;
  title: string;
  executive_summary: string;
  risk_level: string;
  confidence: number;
  evidence: string[];
  affected_assets: string[];
  attack_path: string[];
  threat_context: string;
  business_impact: string;
  root_cause: string;
  recommendations: string[];
  priority: string;
}

export interface WSWSEvent {
  type: string;
  investigation_id: string;
  domain?: string;
  phase?: number;
  phase_name?: string;
  job_count?: number;
  [key: string]: unknown;
}

// Investigation API
export async function createInvestigation(domain: string, tenantId?: string, startImmediately?: boolean): Promise<{ id: string; domain: string; status: string }> {
  return invFetch("/api/v1/investigations", {
    method: "POST",
    body: JSON.stringify({
      domain,
      tenant_id: tenantId || "default",
      start_immediately: startImmediately !== false,
    }),
  });
}

export async function getInvestigation(id: string): Promise<InvestigationDetail> {
  return invFetch(`/api/v1/investigations/${id}`);
}

export async function listInvestigations(tenantId?: string, status?: string): Promise<{ investigations: InvestigationSummary[]; total: number }> {
  const params = new URLSearchParams();
  if (tenantId) params.set("tenant_id", tenantId);
  if (status) params.set("status", status);
  return invFetch(`/api/v1/investigations?${params.toString()}`);
}

export async function getInvestigationProgress(id: string): Promise<InvestigationProgress> {
  return invFetch(`/api/v1/investigations/${id}/progress`);
}

export async function getInvestigationEvidence(id: string, evidenceType?: string): Promise<EvidenceItem[]> {
  const params = evidenceType ? `?evidence_type=${evidenceType}` : "";
  return invFetch(`/api/v1/investigations/${id}/evidence${params}`);
}

export async function getInvestigationTimeline(id: string, limit?: number): Promise<TimelineEvent[]> {
  return invFetch(`/api/v1/investigations/${id}/timeline?limit=${limit || 100}`);
}

export async function getInvestigationIntelligence(id: string): Promise<IntelligenceCase[]> {
  return invFetch(`/api/v1/investigations/${id}/intelligence`);
}

export async function getInvestigationReport(id: string) {
  return invFetch(`/api/v1/investigations/${id}/report`);
}

export async function getInvestigationJobs(id: string, phase?: number) {
  const params = phase ? `?phase=${phase}` : "";
  return invFetch(`/api/v1/investigations/${id}/jobs${params}`);
}

export async function startInvestigation(id: string) {
  return invFetch(`/api/v1/investigations/${id}/start`, { method: "POST" });
}

export async function pauseInvestigation(id: string) {
  return invFetch(`/api/v1/investigations/${id}/pause`, { method: "POST" });
}

export async function resumeInvestigation(id: string) {
  return invFetch(`/api/v1/investigations/${id}/resume`, { method: "POST" });
}

export async function cancelInvestigation(id: string) {
  return invFetch(`/api/v1/investigations/${id}/cancel`, { method: "POST" });
}

export async function retryJob(id: string, jobId: string) {
  return invFetch(`/api/v1/investigations/${id}/jobs/${jobId}/retry`, { method: "POST" });
}

export async function getPhasesInfo() {
  return invFetch("/api/v1/investigations/phases/info");
}
