# CEIP — Cyber Exposure Intelligence Platform

## Quick Start

```bash
uv sync
cp .env.example .env   # edit with your API key
uv run python -m ceip ask "hello"
```

## Commands

| Command | Description |
|---|---|
| `python -m ceip ask "..."` | Send message to GLM-5.2 |

## API

```bash
uv run uvicorn src.api.app:create_app --factory --reload
# GET http://localhost:8000/health
```

## Dev

```bash
uv sync --extra dev
uv run ruff check .
uv run mypy src/
uv run pytest
```

## Architecture

Modular monolith. 10 bounded contexts planned. Milestone 1: foundation shell only.
