# CEIP — Request Flow

## CLI Flow: `python agent.py discover example.com`

```
1. agent.py:main() parses args
2. Settings() loads from .env
3. setup_logging() configures structlog
4. init_db(settings) creates tables if needed
5. create_engine(settings) → AsyncEngine
6. create_session_factory(engine) → async_sessionmaker
7. async with factory() as db:
8.   DiscoveryService(db).start("example.com")
9.     ├── resolve_dns(domain) → A, AAAA, NS, MX, TXT, SOA, CNAME
10.    ├── discover_subdomains(domain) → brute force
11.    ├── discover_crtsh(domain) → Certificate Transparency
12.    ├── fingerprint_http(host) → server headers
13.    ├── fingerprint_ssl(host) → cert metadata
14.    ├── enrich_ip(ip) → reverse DNS, ASN
15.    └── Persist all results to discovery tables
16.   DiscoveryService.get_job(job_id) → eager-loaded result
17. Print results to stdout
18. db.commit()
19. engine.dispose()
```

## CLI Flow: `python agent.py risk example.com`

```
1-7. Same bootstrap as discover
8. RiskEngine(db).assess("example.com")
9.   ├── _load_domain_data() → loads from 5 contexts
10.  ├── _score_asset(host, findings, threats, exposure, clusters)
11.  │     ├── vuln_weight (40%): CVEs × severity multiplier
12.  │     ├── threat_weight (30%): IOC matches × threat multiplier
13.  │     ├── exposure_weight (20%): public IP + missing headers
14.  │     └── importance_weight (10%): cluster membership size
15.  └── _persist() → RiskScore + RiskFactor tables
16. Print risk scores, levels, top priorities
17. db.commit()
```

## API Flow: `GET /api/v1/identity/{domain}`

```
1. HTTP request → FastAPI router
2. Depends(get_db) → yields AsyncSession
3. Depends(get_settings) → yields Settings (cached)
4. get_service(db, settings) → IdentityExposureService(repo, settings)
5. svc.scan(domain)
6.   ├── repo.clear_domain(domain) → removes old results
7.   ├── provider.collect(domain) → 12 mock findings
8.   ├── For each finding: create Exposure, Evidence, Correlation
9.   └── _build_summary() → compute scores + counts
10. Return IdentitySummaryResponse (Pydantic → JSON)
```

## AI Analyst Flow: `GET /api/v1/ai/analysis/{domain}`

```
1. HTTP request → FastAPI router
2. AIAnalystService(db, settings, http_client).analyze(domain)
3.   ├── _load_context(domain) → discovery, vuln, threat, correlation,
4.   │                          risk, identity_exposure data
5.   ├── build_analyst_prompt(context) → structured system + data prompt
6.   ├── GLMClient.chat([Message(role="user", content=prompt)])
7.   │     POST https://api.z.ai/api/paas/v4/chat/completions
8.   └── _parse_sections(response.content) → named sections
9. Return structured report with sections
```
