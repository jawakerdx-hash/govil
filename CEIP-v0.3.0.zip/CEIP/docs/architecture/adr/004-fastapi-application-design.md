# ADR-004: FastAPI Application Design

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP needs an HTTP API for dashboard integration, external clients, and internal tooling. The framework must support async I/O, automatic OpenAPI generation, and Pydantic integration.

## Decision

**FastAPI** as the web framework with a factory pattern (`create_app()`). Routes are organized by context under `src/api/routes/`. Each route module defines its own `APIRouter` with a context-specific prefix. The app factory assembles all routers at startup.

## Consequences

- **Positive:** Async-native (Starlette). Auto-generated OpenAPI docs at `/docs`. Pydantic validation built-in. Dependency injection via `Depends()`. Lightweight compared to Django REST Framework.
- **Negative:** Less ecosystem than Django (fewer third-party packages). No built-in admin interface.
- **Mitigation:** Use FastAPI's dependency injection for auth, DB sessions, and service resolution.

## Alternatives Considered

- **Django + DRF:** Rejected — synchronous by default, heavier, less suited for async scanning workloads.
- **Flask + OpenAPI:** Rejected — no native async, manual OpenAPI generation.
- **Litestar:** Considered but FastAPI has larger community and more production references.
