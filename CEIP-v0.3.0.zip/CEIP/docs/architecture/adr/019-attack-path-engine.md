# ADR-019: Attack Path Engine

**Status:** Accepted (Hardened)
**Date:** 2026-07-04

## Context

CEIP collects extensive security data across 10 bounded contexts. The platform must answer: "How would an attacker reach critical assets from the internet?" This requires modeling possible attack paths from discovered evidence.

## Decision

**Deterministic graph traversal with reachability model.** A `GraphBuilder` constructs an attack graph from persisted monitoring snapshots: assets become nodes, relationships become edges with reachability attributes. `PathRules` define edge patterns. Paths are assembled by traversing the graph. Scoring considers security controls, crown jewel classification, and kill chain stage coverage.

## Architecture

```
Persisted Snapshots → GraphBuilder → AttackGraph (nodes + edges + controls)
                                         ↓
Rules → Edge Patterns → Candidate Paths → Kill Chain Mapping
                                         ↓
                              Scoring (controls × evidence)
                                         ↓
                              PathRanker (multi-axis)
                                         ↓
                              Explainability (evidence per edge)
```

## Reachability Model

Every edge includes: `reachable`, `blocked`, `blocked_by`, `requires_authentication`, `requires_existing_access`, `internet_reachable`, `confidence`. A path only exists if all edges are reachable. Blocked edges are recorded in `graph.blocked_paths`.

## Security Control Model

Controls detected from evidence (Cloudflare CDN, WAF) influence scoring: `effect_likelihood` (reduces attacker success probability), `effect_complexity` (increases difficulty), `effect_confidence` (increases assessment confidence). Absent controls are noted.

## Crown Jewel Classification

16 asset types classified with `criticality`, `business_value`, `exposure`. Critical: admin_panel, database, secret, cloud_account, critical_asset, critical_data. Paths affecting crown jewels receive higher business impact scores.

## Kill Chain Mapping

11 stages (Reconnaissance → Impact). Each node maps to a stage. Missing stages are documented, never fabricated. Kill chain coverage informs completeness assessment.

## Path Ranking

Multi-axis: highest risk, highest confidence, lowest complexity, highest business impact. `PathRanker` separates generation from scoring.

## Consequences

- **Positive:** Evidence-backed edges. Explainable paths. Controls affect scoring. Crown jewels prioritize. Kill chain shows coverage gaps.
- **Negative:** Graph traversal complexity O(n²) for dense graphs. Rule maintenance required.
- **Mitigation:** Domain-granularity limits graph size. Rules are data classes for easy extension.

## Alternatives Considered

- **Graph database:** Rejected — PostgreSQL adjacency lists are sufficient for domain-scope graphs.
- **AI path generation:** Rejected — hallucination risk. Deterministic only.
