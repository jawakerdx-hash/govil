# ADR-012: AI Analyst Architecture

**Status:** Accepted  
**Date:** 2026-07-04

## Context

CEIP must generate human-readable security analysis reports from structured data. Reports must be understandable by both executives and engineers.

## Decision

**AI Security Analyst** using GLM-5.2 with a structured prompt template. `AIAnalystService` loads all context data (discovery, vulnerabilities, threats, correlation, risk, identity exposure), builds a comprehensive prompt via `build_analyst_prompt()`, sends it to the LLM, and parses the structured response into sections (Executive Summary, Technical Findings, Attack Scenario, Business Impact, Remediation Plan, Risk Justification).

## Consequences

- **Positive:** Produces SOC-quality reports in seconds. Uses only collected data — never invents. Structured output is parseable.
- **Negative:** LLM latency (2-19s). Token limits constrain input data size. Quality depends on prompt engineering.
- **Mitigation:** Temperature set to 0.3 for consistency. System prompt enforces data-only responses. Sections are parseable for downstream consumers.

## Alternatives Considered

- **Template-based reports:** Rejected — cannot generate narrative analysis or attack scenarios from structured data.
- **Local model (Ollama):** Considered for air-gapped deployments. Architecture supports swapping the LLM client.
