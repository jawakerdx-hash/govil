# ADR-007: Discovery Engine Design

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP must discover externally exposed assets for any domain: DNS records, subdomains, HTTP services, SSL certificates, and IP enrichment. The engine must be extensible for future data sources.

## Decision

**Synchronous DNS resolution** via `dnspython` wrapped in `asyncio.run_in_executor()`. Discovery steps are orchestrated sequentially within a single service call: DNS records → subdomain brute force → Certificate Transparency (crt.sh) → HTTP fingerprinting → SSL certificate extraction → IP enrichment (ASN, reverse DNS).

## Consequences

- **Positive:** All discovery results in one API call. Data is consistent — everything shares a single discovery job ID. No Celery dependency for basic discovery.
- **Negative:** Synchronous flow can be slow for large domains (many subdomains). crt.sh calls are HTTP-dependent and can timeout.
- **Mitigation:** Thread pool for DNS resolution. Timeout limits on each step. Future: extract long-running scans to Celery tasks.

## Alternatives Considered

- **Celery tasks per step:** Rejected for MVP — added Redis dependency and operational complexity. Will be adopted when scan volume requires it.
- **Async DNS (aiodns):** Rejected — `dnspython` is more mature and well-tested. Thread pool provides sufficient concurrency.
