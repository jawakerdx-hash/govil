# ADR-008: Correlation Engine

**Status:** Accepted  
**Date:** 2026-07-03

## Context

Discovered assets (IPs, domains, certificates, services) must be connected into a relationship graph. Relationships enable clustering (shared IP, shared ASN, shared CDN) and exposure grouping.

## Decision

**Deterministic rule-based correlation** in `CorrelationService`. Six correlation rules: IP→Domain mapping, shared IP grouping, certificate SAN linking, shared ASN grouping, shared CDN/server grouping, shared TLS issuer grouping. Results stored in `AssetRelationship`, `AssetCluster`, and `ExposureGroup` tables.

## Consequences

- **Positive:** No graph database dependency. Rules are explicit, testable, and auditable. PostgreSQL is sufficient for the current relationship volume.
- **Negative:** Graph traversal requires recursive CTEs or application-level graph walking. Does not scale to millions of assets with deep relationships.
- **Mitigation:** Relationship model supports future migration to Neo4j. Graph queries are abstracted behind the service layer.

## Alternatives Considered

- **Neo4j:** Rejected for MVP — adds operational complexity. Will be adopted when graph queries become a bottleneck.
- **Machine learning clustering:** Rejected — deterministic rules are more explainable and sufficient for current needs.
