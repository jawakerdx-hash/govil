# ADR-020: Brand Protection & Domain Impersonation Engine

## Status
Accepted

## Context
As the CEIP platform grows, its brand becomes a target for malicious actors. Attackers frequently register fraudulent domains that impersonate legitimate services to conduct phishing campaigns, distribute malware, or execute social engineering attacks. CEIP needs a robust brand protection capability to detect external domains that impersonate customer brands. This system must identify potentially malicious domain variations — such as typosquats, homograph attacks, and deceptive subdomains — using evidence-backed deterministic analysis.

## Decision
The Brand Protection engine operates using strictly **passive, deterministic collection methods**. The system does not engage in phishing, browser automation, or authentication against suspect domains. All findings are evidence-backed, providing clear mathematical or structural justification for why a domain is flagged.

## Architecture

1. **Provider Abstraction**: `BrandProtectionProvider` ABC defines the interface. `LocalBrandProvider` generates candidate domains. `ProviderRegistry` manages pluggable providers.
2. **Detection Algorithms**: 11 deterministic functions covering typosquatting, homograph, keyboard adjacency, prefix/suffix, hyphen abuse, and subdomain abuse.
3. **Classification**: 8 categories — Typosquatting, Lookalike, Homograph, IDN, Brand Abuse, Suspicious Registration, Potential Phishing, Low Similarity.
4. **Risk Assessment**: `BrandRiskPolicy` with configurable keyword-weighted scoring (executive, auth, financial keywords as multipliers).
5. **Evidence Persistence**: Every algorithm contribution stored as `BrandEvidence` rows. Classification rationale persisted. Full reproducibility from stored evidence.

## Why passive collection
Safety, legality, reproducibility. Never interact with suspect domains — avoids executing malicious payloads, triggering attacker beacons, or violating terms of service.

## Why provider abstraction
Future providers (Certificate Transparency, WHOIS, Passive DNS, VirusTotal) plug into `ProviderRegistry` without changing service logic.

## Why deterministic similarity
Reproducible scores. No AI hallucination risk. Every flagged domain is the result of a specific, auditable mathematical rule.

## Why repository pattern
Clean separation. Service orchestrates, repository persists. No SQL in services.

## Why evidence normalization
Every finding explainable. Algorithm contributions stored individually. Classification rationale persisted. Full reproducibility from stored evidence.

## Future extensibility
New providers, new algorithms, monitoring integration, threat intel correlation.

## Consequences

**Positive**: Comprehensive brand monitoring, evidence-backed, deterministic, extensible. Clean separation of concerns.

**Negative**: `LocalBrandProvider` generates candidates without DNS verification. May include unregistered domains.

**Mitigation**: Future CT/WHOIS providers add live verification and cross-reference generated candidates against registered domains.
