# ADR-018: Testing Strategy

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP must maintain high test coverage to ensure reliability across 10 bounded contexts. Tests must be fast, deterministic, and runnable without external services.

## Decision

**pytest + pytest-asyncio** as the test framework. Tests are organized by context under `tests/`. Unit tests use in-memory SQLite (`aiosqlite`) for database isolation. HTTP tests use `TestClient` from FastAPI. LLM tests use `pytest-httpx` to mock HTTP transport and avoid real API calls.

## Consequences

- **Positive:** 13 tests cover config, health, identity, and LLM client. Tests run in <5 seconds. No PostgreSQL or Redis required for tests.
- **Negative:** SQLite does not fully replicate PostgreSQL behavior (UUID handling, JSONB). Some PostgreSQL-specific features are untestable locally.
- **Mitigation:** Integration tests with testcontainers-python planned for CI. PostgreSQL-specific features documented as known test gaps.

## Alternatives Considered

- **unittest:** Rejected — less expressive, more boilerplate.
- **Docker-based tests for all runs:** Rejected — too slow for development. Reserved for CI integration tests.
