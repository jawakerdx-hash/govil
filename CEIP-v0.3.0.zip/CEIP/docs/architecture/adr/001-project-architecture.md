# ADR-001: Project Architecture

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP (Cyber Exposure Intelligence Platform) is an enterprise-grade platform for continuous discovery, correlation, prioritization, and monitoring of externally exposed digital assets. The system must be maintainable for years, support multiple developers, and scale from a single deployment to multi-region.

## Decision

**Modular Monolith** using Domain-Driven Design with bounded contexts as Python packages under `src/contexts/`. Each context owns its models, service layer, and API routes. Cross-context communication occurs through service calls, not direct database access.

## Consequences

- **Positive:** Single deployment unit simplifies operations. Package boundaries enforce module isolation. Can extract contexts into microservices later.
- **Negative:** Shared database schema means contexts are coupled at the data layer. Cross-context joins are possible, which can become problematic at scale.
- **Mitigation:** Repository pattern per context. Contexts never access another context's tables directly.

## Alternatives Considered

- **Microservices:** Rejected — premature distribution for a single-team project. Would add network latency, operational complexity, and deployment overhead with no benefit at current scale.
- **Django monolith:** Rejected — Django apps encourage tight coupling. No compile-time module boundaries.
- **Serverless:** Rejected — scanning workloads require long-lived TCP connections. Cold starts unacceptable.
