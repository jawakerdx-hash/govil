# ADR-014: Provider Abstraction

**Status:** Accepted  
**Date:** 2026-07-04

## Context

CEIP needs to support multiple identity exposure data sources (HaveIBeenPwned, DeHashed, GitHub, Hunter, LeakCheck) without modifying business logic when switching or adding providers.

## Decision

**Provider abstraction** via `IdentityProvider` ABC with methods: `collect(domain)`, `search_email(email)`, `search_username(username)`, `search_domain(domain)`. `ProviderRegistry` resolves the configured provider from settings (`IDENTITY_PROVIDER=local`). `IdentityExposureService` receives a provider instance through its constructor — it never instantiates one directly.

## Consequences

- **Positive:** Adding HaveIBeenPwned = implement `IdentityProvider` + one line in `ProviderRegistry._providers`. Zero service changes. Runtime provider switching via environment variable.
- **Negative:** ABC constrains to a common interface — provider-specific features (e.g., breach details, raw API responses) must be normalized into `IdentityResult`.
- **Mitigation:** `NormalizedEvidence` carries provider-specific `raw_data` alongside normalized fields.

## Alternatives Considered

- **Direct API calls in service:** Rejected — tightly couples service to provider implementations.
- **Adapter pattern per provider:** Considered but adds indirection. Current ABC + Registry is simpler.
