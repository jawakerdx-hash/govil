# ADR-016: Configuration Management

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP needs configuration for API keys, database URLs, provider selection, log levels, and timeouts. Configuration must be environment-aware (dev, prod) and never hardcoded.

## Decision

**Pydantic Settings** (`pydantic-settings`) with a `.env` file. Single `Settings` class in `src/config.py` with typed fields and defaults. Environment variables override `.env` values. Secrets (API keys) are never committed — `.env` is in `.gitignore`.

## Consequences

- **Positive:** Type-safe configuration. Auto-loads from `.env`. IDE autocompletion for all settings. Easy to add new settings.
- **Negative:** All settings in one class — could become large. No hierarchical configuration.
- **Mitigation:** Keep settings flat and well-documented. Split into provider-specific configs when needed.

## Alternatives Considered

- **ConfigParser/INI files:** Rejected — no type safety, no env var override.
- **Django settings:** Rejected — CEIP is not a Django project.
- **Vault/Secrets Manager:** Rejected for MVP — adds operational complexity. Will be adopted for production secrets.
