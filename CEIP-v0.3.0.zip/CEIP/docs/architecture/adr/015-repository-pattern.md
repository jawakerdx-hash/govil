# ADR-015: Repository Pattern

**Status:** Accepted  
**Date:** 2026-07-04

## Context

Services must not contain SQL queries or direct database access. Database operations must be testable in isolation.

## Decision

**Repository pattern** for contexts with meaningful data access. `IdentityExposureRepository` encapsulates all CRUD operations for identity exposure tables. Service delegates persistence to the repository. Repository receives an `AsyncSession` through its constructor.

## Consequences

- **Positive:** Service is testable without a database. SQL is centralized in one class per context. Database migration (PostgreSQL → something else) requires only repository changes.
- **Negative:** Extra layer of indirection. More files. Not all contexts have repositories yet (Discovery, Correlation, Vulnerability, Threat still have inline SQL in services).
- **Mitigation:** Repositories are added incrementally as contexts mature. Simple contexts with single-table access can defer the pattern.

## Alternatives Considered

- **ORM in service:** Rejected — couples business logic to SQLAlchemy. Makes testing and database migration harder.
- **Active Record:** Rejected — mixes persistence and domain logic in the same class.
