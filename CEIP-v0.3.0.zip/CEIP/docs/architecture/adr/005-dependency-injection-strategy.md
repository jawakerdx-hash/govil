# ADR-005: Dependency Injection Strategy

**Status:** Accepted  
**Date:** 2026-07-03

## Context

Services need database sessions, providers, configuration, and HTTP clients. Hardcoding dependencies makes testing impossible and creates tight coupling.

## Decision

**Constructor-based dependency injection** without a DI framework. Every class receives its dependencies through `__init__` parameters. FastAPI routes use `Depends()` for request-scoped wiring. CLI commands manually wire dependencies.

## Consequences

- **Positive:** No framework dependency for DI. Dependencies are explicit in constructor signatures. Easy to mock in tests. Zero runtime overhead.
- **Negative:** Manual wiring in CLI code. More constructor parameters as features grow.
- **Mitigation:** Factory functions in route modules (`get_service()`, `get_db()`). Default parameter values for optional dependencies.

## Alternatives Considered

- **python-dependency-injector:** Rejected — adds framework dependency, magic container resolution, steeper learning curve.
- **Service locator pattern:** Rejected — hides dependencies, makes testing harder.
- **Global singletons:** Rejected — prevents parallel testing, creates hidden coupling.
