# ADR-011: Risk Engine

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP must compute a unified risk score for every asset, combining vulnerability findings, threat intelligence, exposure data, and asset importance. Scores must be explainable.

## Decision

**Deterministic weighted scoring** in `RiskEngine` with four weighted dimensions: Vulnerability (40%), Threat (30%), Exposure (20%), Importance (10%). Each dimension contributes 0-100 points scaled by its weight. Final score is the sum of all four dimensions, clamped to 0-100. Risk levels: LOW (0-25), MEDIUM (26-50), HIGH (51-75), CRITICAL (76-100).

## Consequences

- **Positive:** Fully explainable — every score has a breakdown of contributing factors stored in `RiskFactor` records. Weights are adjustable. No ML dependency.
- **Negative:** Weights are static and may not reflect real-world risk accurately for all industries. No adaptive learning.
- **Mitigation:** Weights are configurable constants. Future: `RiskPolicy` strategy pattern for per-industry weighting.

## Alternatives Considered

- **CVSS-only scoring:** Rejected — CVSS measures vulnerability severity only, ignores threat context and asset criticality.
- **Machine learning model:** Rejected — requires training data, not explainable, overkill for current needs.
