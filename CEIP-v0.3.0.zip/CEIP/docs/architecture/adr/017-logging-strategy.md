# ADR-017: Logging Strategy

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP needs structured logging for debugging, auditing, and operations. Logs must be machine-parseable in production and human-readable in development.

## Decision

**structlog** configured at application startup via `setup_logging()` in `src/foundation/logging_config.py`. Console output uses `ConsoleRenderer` for development; JSON output via `JSONRenderer` for production. Log level is configurable via `LOG_LEVEL` setting.

## Consequences

- **Positive:** Structured key-value pairs. Request IDs and model names included in LLM call logs. httpx and SQLAlchemy logs suppressed unless DEBUG level.
- **Negative:** structlog configuration must happen before any log call. Multiple processes (API + Celery) need separate configuration.
- **Mitigation:** `setup_logging()` is idempotent — safe to call multiple times. Factory function pattern for Celery worker logging.

## Alternatives Considered

- **Standard logging:** Rejected — unstructured, harder to parse in production.
- **loguru:** Considered — simpler API but less ecosystem integration than structlog.
