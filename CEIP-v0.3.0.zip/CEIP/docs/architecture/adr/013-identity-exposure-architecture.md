# ADR-013: Identity Exposure Architecture

**Status:** Accepted  
**Date:** 2026-07-04

## Context

CEIP must discover publicly exposed identities (emails, usernames, employees, executives, secrets, repositories) related to an organization and correlate them with existing assets.

## Decision

**Provider-based identity exposure** with `IdentityProvider` ABC. `LocalIdentityProvider` returns 12 deterministic mock findings. `IdentityExposureService` orchestrates collection, correlation, and risk assessment. Results are stored in `IdentityExposure`, `ExposureEvidence`, and `IdentityCorrelation` tables.

## Consequences

- **Positive:** Provider abstraction enables future HaveIBeenPwned, DeHashed, GitHub integration without service changes. Evidence is normalized across providers. Risk weights are configurable via `RiskPolicy`.
- **Negative:** Local provider returns mock data — not real intelligence. No real-time identity monitoring.
- **Mitigation:** Provider registry supports adding real providers in Milestone 10.

## Alternatives Considered

- **Direct HaveIBeenPwned integration:** Rejected for MVP — requires API key, rate limiting, and commercial license. Architecture supports adding it later.
- **Dehashed/SpyCloud:** Rejected — commercial APIs, significant cost. Future provider implementations.
