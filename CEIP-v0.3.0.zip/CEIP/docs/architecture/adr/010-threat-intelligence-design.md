# ADR-010: Threat Intelligence Design

**Status:** Accepted  
**Date:** 2026-07-03

## Context

Discovered assets must be checked against known threat indicators (malicious IPs, domains, ASNs). The system must support future integration with threat feeds.

## Decision

**Static IOC dataset** in `ioc_data.py` with 16 curated indicators sourced from Abuse.ch, PhishTank, CISA, GreyNoise, Feodo, Spamhaus, Censys, and Shodan. `ThreatService` matches discovered IPs and ASNs against the dataset and generates `ThreatMatch` records.

## Consequences

- **Positive:** No external API dependency. Results are reproducible. Easy to audit and extend the dataset.
- **Negative:** Static dataset becomes stale. No real-time threat feed.
- **Mitigation:** Dataset is a module — swap for AlienVault OTX, MISP, or commercial feed via provider pattern.

## Alternatives Considered

- **AlienVault OTX API:** Rejected for MVP — requires API key and internet access. Will be added as a provider.
- **MISP integration:** Rejected — requires MISP instance deployment. Future enhancement.
