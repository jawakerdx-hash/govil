# ADR-003: Context-based Modular Structure

**Status:** Accepted  
**Date:** 2026-07-03

## Context

The CEIP platform spans 10 bounded contexts: Discovery, Inventory, Assessment, Risk, Intelligence, Orchestration, Reporting, Identity, Vulnerability/Threat, and Identity Exposure. Each has distinct models, services, and API surfaces.

## Decision

Each bounded context is a Python package under `src/contexts/` with a standard internal structure:

```
src/contexts/<name>/
├── __init__.py
├── models.py       # SQLAlchemy ORM models
├── schemas.py      # Pydantic request/response
├── service.py      # Business logic
├── repository.py   # Data access (when needed)
└── providers/      # Pluggable provider implementations (when needed)
```

Contexts communicate through their public service layer only. No context imports another context's models or repositories directly.

## Consequences

- **Positive:** Consistent structure across all contexts. New developers know where to find everything. Can extract any context into a separate service by copying its package.
- **Negative:** Some boilerplate (multiple `__init__.py` files, repeated patterns). Contexts that need cross-domain joins must go through services, which can be slower than direct SQL.
- **Mitigation:** Cross-context joins use service composition, not SQL JOINs. Accept the minor performance cost for maintainability.

## Alternatives Considered

- **Flat modules per entity:** Rejected — no domain boundaries, everything becomes coupled over time.
- **Django apps:** Rejected — apps encourage tight coupling via settings and signals.
