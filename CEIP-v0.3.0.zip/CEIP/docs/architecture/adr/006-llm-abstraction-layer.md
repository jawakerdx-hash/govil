# ADR-006: LLM Abstraction Layer

**Status:** Accepted  
**Date:** 2026-07-03

## Context

CEIP uses GLM-5.2 for the AI Security Analyst. The codebase must not be locked to a single LLM provider. Future requirements may include OpenAI, Anthropic, or local models.

## Decision

**LLMClient ABC** in `src/llm/base.py` defines the contract: `async chat(messages) -> ChatResponse`. `GLMClient` implements it for the Z.AI API. The AI Analyst service depends on the ABC, never on the concrete implementation.

## Consequences

- **Positive:** Adding a new LLM provider = one new class implementing `LLMClient`. Zero changes to the AI Analyst. Provider can be swapped via configuration.
- **Negative:** ABC constrains to a common interface — provider-specific features (streaming, function calling) require interface extension.
- **Mitigation:** Extend the ABC with optional methods when provider-specific features are needed. Use `hasattr()` checks or capability flags.

## Alternatives Considered

- **OpenAI SDK directly:** Rejected — vendor lock-in, 20+ transitive dependencies, overkill for simple chat completions.
- **LangChain:** Rejected — too abstract, heavy, hides provider behavior. CEIP needs explicit control over prompts and responses.
- **httpx directly per use:** Rejected — no shared interface, duplicate code across consumers.
