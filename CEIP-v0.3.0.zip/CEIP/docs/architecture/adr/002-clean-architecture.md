# ADR-002: Clean Architecture

**Status:** Accepted  
**Date:** 2026-07-03

## Context

The codebase must remain maintainable after years of development. Business logic must be independent of frameworks, databases, and external services.

## Decision

**Clean Architecture** with four layers:

```
CLI/API  →  Service  →  Repository  →  Database
```

- **CLI/API layer** (`src/api/`, `agent.py`): HTTP and command-line interfaces. No business logic.
- **Domain/Service layer** (`src/contexts/*/service.py`): All business logic. Depends only on abstractions.
- **Repository layer** (`src/contexts/*/repository.py`): Data access. Service never writes SQL.
- **Infrastructure layer** (`src/foundation/`): Framework glue (database, logging, Celery).

Dependencies flow inward: outer layers depend on inner layers. Inner layers never import outer layers.

## Consequences

- **Positive:** Swapping FastAPI for another framework requires zero service changes. Database migration requires only repository changes. Testable in isolation.
- **Negative:** More files per feature. Indirection can feel heavy for simple CRUD.
- **Mitigation:** Only add repository layer when context has meaningful data access. Simple contexts skip it.

## Alternatives Considered

- **Active Record (Django-style):** Rejected — couples business logic to ORM. Makes testing and framework migration hard.
- **Hexagonal Architecture:** Rejected — overkill at current scale. Clean Architecture provides sufficient separation without ports/adapters ceremony.
