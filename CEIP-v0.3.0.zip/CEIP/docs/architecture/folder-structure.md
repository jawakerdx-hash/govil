# CEIP — Folder Structure

```
ceip/
├── agent.py                          # CLI entry point
├── pyproject.toml                    # Project config + deps
├── .env / .env.example               # Secrets + template
├── README.md
│
├── src/
│   ├── config.py                     # Pydantic Settings
│   │
│   ├── api/                          # FastAPI application
│   │   ├── app.py                    # create_app() factory
│   │   ├── deps.py                   # DI: get_settings()
│   │   └── routes/                   # Route modules per context
│   │       ├── health.py
│   │       ├── discovery.py
│   │       ├── correlation.py
│   │       ├── vulnerability.py
│   │       ├── threat.py
│   │       ├── risk.py
│   │       ├── analyst.py
│   │       ├── exposure.py
│   │       └── identity_exposure_api.py
│   │
│   ├── contexts/                     # Bounded contexts (DDD)
│   │   ├── discovery/               # DNS, subdomains, fingerprinting
│   │   ├── correlation/             # Asset relationship graph
│   │   ├── vulnerability/           # CVE mapping, security findings
│   │   ├── threat/                  # IOC matching
│   │   ├── risk/                    # Weighted risk scoring
│   │   ├── analyst/                 # AI security analyst
│   │   ├── exposure/                # Credential leaks, dark web
│   │   ├── identity/                # Organizations, users
│   │   └── identity_exposure/       # Identity exposure engine
│   │       ├── models.py
│   │       ├── schemas.py
│   │       ├── service.py
│   │       ├── repository.py
│   │       ├── registry.py
│   │       ├── risk_policy.py
│   │       ├── evidence.py
│   │       └── providers/
│   │           ├── base.py          # IdentityProvider ABC
│   │           └── local_provider.py
│   │
│   ├── llm/                          # LLM abstraction
│   │   ├── base.py                  # LLMClient ABC
│   │   └── glm_client.py            # GLM-5.2 implementation
│   │
│   ├── foundation/                   # Infrastructure
│   │   ├── database.py              # Async engine, session
│   │   └── logging_config.py        # structlog setup
│   │
│   └── kernel/                       # Stable cross-cutting
│       ├── base_model.py            # UUID pk + timestamps
│       └── exceptions.py            # Domain exceptions
│
├── tests/
│   ├── conftest.py
│   ├── test_config.py
│   ├── test_health.py
│   ├── test_identity.py
│   └── test_llm_client.py
│
└── docs/
    └── architecture/
        ├── system-overview.md
        ├── folder-structure.md
        ├── context-map.md
        ├── request-flow.md
        ├── dependency-graph.md
        └── adr/
            ├── 001-project-architecture.md
            ├── ...
            └── 018-testing-strategy.md
```
