# CEIP — System Overview

## What is CEIP?

Cyber Exposure Intelligence Platform — an enterprise-grade system for continuous discovery, correlation, prioritization, and monitoring of externally exposed digital assets.

## Architecture Style

**Modular Monolith** with Domain-Driven Design. 10 bounded contexts as Python packages under `src/contexts/`. Clean Architecture layers: API → Service → Repository → Database.

## Technology Stack

| Component | Technology |
|---|---|
| Runtime | Python 3.13 |
| Web Framework | FastAPI |
| ORM | SQLAlchemy 2.x (async) |
| Database | PostgreSQL (dev: SQLite) |
| Validation | Pydantic v2 |
| Configuration | pydantic-settings (.env) |
| Logging | structlog |
| LLM | GLM-5.2 via Z.AI API |
| DNS | dnspython |
| HTTP Client | httpx |
| Testing | pytest + pytest-asyncio |
| Linting | ruff |
| Type Checking | mypy (strict) |

## Bounded Contexts

| Context | Purpose | Tables |
|---|---|---|
| `discovery` | DNS, subdomains, HTTP fingerprinting, SSL, IP enrichment | 6 |
| `correlation` | Asset relationships, clusters, exposure groups | 3 |
| `vulnerability` | CVE mapping, exposure scoring, security findings | 2 |
| `threat` | IOC matching, threat indicators | 2 |
| `risk` | Weighted risk scoring, risk factors | 2 |
| `analyst` | AI-powered security report generation | 0 |
| `exposure` | Credential leaks, dark web intelligence | 2 |
| `identity` | Organizations, users | 2 |
| `identity_exposure` | Identity exposure, evidence, correlation | 3 |

## API Surface

12 route modules under `src/api/routes/` serving REST endpoints at `/api/v1/`. Auto-generated OpenAPI docs at `/docs`.

## CLI

9 commands via `python agent.py`: `ask`, `discover`, `correlate`, `vuln`, `threats`, `risk`, `analyze`, `identity`, `darkweb`.

## Quality Gates

- `ruff check`: 0 errors
- `mypy src/ agent.py`: 0 issues
- `pytest`: 13 tests, all passing
