# CEIP — Dependency Graph

## Build Dependencies

```
ceip (pyproject.toml)
├── fastapi>=0.115.0
├── uvicorn[standard]>=0.34.0
├── httpx>=0.28.0
├── pydantic>=2.10.0
├── pydantic-settings>=2.7.0
├── sqlalchemy[asyncio]>=2.0.36
├── asyncpg>=0.30.0
├── alembic>=1.14.0
├── redis[hiredis]>=5.2.0
├── structlog>=24.4.0
├── pyjwt>=2.10.0
├── bcrypt>=4.2.0
├── dnspython>=2.7.0
└── python-multipart>=0.0.18

dev:
├── pytest>=8.3.0
├── pytest-asyncio>=0.24.0
├── pytest-httpx>=0.32.0
├── aiosqlite>=0.20.0
├── ruff>=0.8.0
└── mypy>=1.13.0
```

## Module Dependency Graph

```
agent.py
├── src/config.py
├── src/foundation/logging_config.py
├── src/foundation/database.py
├── src/llm/base.py
├── src/llm/glm_client.py
├── src/contexts/discovery/service.py
├── src/contexts/correlation/service.py
├── src/contexts/vulnerability/service.py
├── src/contexts/threat/service.py
├── src/contexts/risk/engine.py
├── src/contexts/analyst/service.py
├── src/contexts/exposure/service.py
└── src/contexts/identity_exposure/service.py
    ├── src/contexts/identity_exposure/repository.py
    ├── src/contexts/identity_exposure/registry.py
    │   └── src/contexts/identity_exposure/providers/base.py
    │       └── src/contexts/identity_exposure/providers/local_provider.py
    ├── src/contexts/identity_exposure/risk_policy.py
    └── src/contexts/identity_exposure/evidence.py

src/api/app.py
├── src/api/routes/health.py
├── src/api/routes/discovery.py
├── src/api/routes/correlation.py
├── src/api/routes/vulnerability.py
├── src/api/routes/threat.py
├── src/api/routes/risk.py
├── src/api/routes/analyst.py
├── src/api/routes/exposure.py
└── src/api/routes/identity_exposure_api.py
    └── src/contexts/identity_exposure/service.py

All routes depend on:
├── src/api/deps.py → src/config.py
└── src/foundation/database.py → src/config.py
```

## Cross-Context Dependencies

Discovery is the foundational context. All other contexts read Discovery data:

```
discovery ← correlation
discovery ← vulnerability
discovery ← threat
discovery ← risk (reads discovery + vuln + threat + correlation)
discovery ← analyst (reads all)
discovery ← identity_exposure (independent, no discovery dependency)
```

No circular dependencies exist. All dependency arrows point from analysis contexts toward the discovery foundation.
