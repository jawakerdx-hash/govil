# CEIP SaaS — M31 Production Architecture

## 1. SERVICE BOUNDARIES

| Service | Responsibility | Input | Output | Scaling |
| :--- | :--- | :--- | :--- | :--- |
| **frontend** | React SPA, static assets, routing, UI state | HTTPS requests (browsers) | HTML/JS/CSS, JSON consumption | CDN cached, 3 replicas |
| **backend-api** | Auth, REST/GraphQL endpoints, RBAC, req validation | HTTPS REST/GraphQL, Redis cache lookups | JSON responses, Kafka events | HPA (CPU 70%), 5-20 pods |
| **go-discovery** | High-perf asset enumeration, port scanning, DNS | Kafka `asset.raw`, scheduled scan triggers | Kafka `asset.enriched`, `vulnerability.found` | HPA (queue depth), 10-50 pods |
| **kafka** | Event backbone, async decoupling, buffering | Event production from services | Event consumption to subscribers | 5 broker nodes, RF=3 |
| **opensearch** | Full-text search, graph relations, log indexing | REST `_bulk` indexing, search queries | JSON search results, aggregations | 3 master, 5 data nodes (100GB) |
| **redis** | Session store, rate limiting, caching, pub/sub | GET/SET commands, pub/sub messages | Key-value data, cache hits | 3 node cluster, HA |
| **scheduler** | Cron jobs, scan scheduling, report generation triggers | Time-based triggers, DB status checks | Kafka `report.requested`, API calls | 2 replicas (leader election) |
| **notification** | Email/Slack/Webhook delivery, alert routing | Kafka `alert.generated` | SMTP/HTTPS payloads | 3 replicas |
| **pdf-renderer** | Headless Chrome PDF generation | Kafka `report.requested` | S3 PDF URL, DB status update | HPA (queue depth), 2-10 pods |

## 2. KAFKA TOPICS

| Topic | Key Type | Partitions | Retention |
| :--- | :--- | :--- | :--- |
| `asset.raw` | domain (string) | 12 | 7 days |
| `asset.enriched` | domain (string) | 12 | 14 days |
| `vulnerability.found` | vuln_id (string) | 6 | 30 days |
| `threat.detected` | threat_id (string) | 6 | 30 days |
| `risk.updated` | domain (string) | 6 | 90 days |
| `alert.generated` | alert_id (string) | 3 | 7 days |
| `darkweb.leak` | leak_id (string) | 3 | 90 days |
| `report.requested` | report_id (string) | 3 | 7 days |

## 3. KUBERNETES SERVICES

5 deployments: api-gateway (3 replicas, 1000m CPU), backend-worker (5 replicas, 2000m CPU), go-discovery (10 replicas, 500m CPU), opensearch (StatefulSet 3 nodes, 2000m CPU), redis (StatefulSet 3 nodes, 1000m CPU)

## 4. API CONTRACTS

6 endpoints: GET /dashboard/executive, GET /dashboard/soc, GET /graph/{domain}, GET /risk/{domain}, POST /ai-analyst/ask, GET /reports/{type}

## 5. FRONTEND PAGES

9 pages: /dashboard, /soc, /graph, /assets, /threats, /risk, /ai-analyst, /reports, /memory — each with component trees mapped to M20-M30

## 6. DEPLOYMENT

dev: docker-compose | staging: k3s | prod: GKE/EKS + HPA + ArgoCD GitOps
