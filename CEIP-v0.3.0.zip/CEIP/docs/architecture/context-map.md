# CEIP — Context Map

## Bounded Context Relationships

```
                          ┌──────────────────┐
                          │    identity      │
                          │  (orgs, users)   │
                          └────────┬─────────┘
                                   │ provides tenant context
                                   ▼
┌──────────────┐    reads     ┌──────────────┐
│  discovery   │◄────────────│  correlation  │
│  (assets)    │────────────►│  (relationships)│
└──────┬───────┘   feeds     └──────┬───────┘
       │                            │
       │ provides assets            │ provides clusters
       ▼                            ▼
┌──────────────┐              ┌──────────────┐
│ vulnerability│              │    threat     │
│  (CVEs)      │              │  (IOCs)       │
└──────┬───────┘              └──────┬───────┘
       │                            │
       │ provides findings          │ provides matches
       ▼                            ▼
┌──────────────────────────────────────────┐
│               risk                       │
│  (weighted scoring: V40% T30% E20% I10%) │
└──────────────────┬───────────────────────┘
                   │
                   │ provides risk data
                   ▼
┌──────────────────────────────────────────┐
│              analyst                     │
│  (AI reports from all contexts)          │
└──────────────────┬───────────────────────┘
                   │
                   │ provides identity context
                   ▼
┌──────────────────────────────────────────┐
│        identity_exposure                 │
│  (provider-based identity scanning)      │
└──────────────────────────────────────────┘
```

## Communication Patterns

| From | To | Pattern |
|---|---|---|
| discovery | correlation | Service call — reads assets, writes relationships |
| discovery | vulnerability | Service call — reads services, writes findings |
| discovery | threat | Service call — reads IPs, writes matches |
| vulnerability | risk | Service call — reads findings, writes scores |
| threat | risk | Service call — reads matches, writes scores |
| correlation | risk | Service call — reads clusters, writes scores |
| discovery | analyst | Data loading — reads all data for domain |
| all contexts | analyst | Data loading — reads findings, threats, risk, identity |

## Data Ownership

Each context owns its tables exclusively. No context performs direct SQL against another context's tables. Cross-context data access is through the owning context's service layer.
