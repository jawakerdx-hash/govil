# CEIP Deep Scan — AI Hunt Strategy
## Red Team Methodology for Autonomous Investigation

---

## Core Principles

1. **Assume breach mindset** — Every finding is an entry point. The AI must think "if I were attacking, what would I do next?"
2. **Evidence over assumptions** — Never flag something critical without confirming it. False positives destroy trust.
3. **Chain findings** — A medium finding + a low finding + context = a critical attack path. Connect dots.
4. **Time-boxed depth** — 5 minutes per phase. Go DEEP on the most promising target, don't spread thin.
5. **Hunt the anomaly** — The most interesting finding is always the one that doesn't fit the pattern.

---

## PHASE 2: DEEP SURFACE MAPPING (5 min)

### Target Selection
Before scanning, the AI MUST answer: "Which discovered host has the highest attack surface?"

Decision tree:
```
Is there a web app? (HTTP 200, not just CDN redirect)
├── YES → Focus here. This is the entry point.
└── NO  → Check dev/staging/test. These have weaker security.
```

### Discovery Priority (ordered by value)

**Tier 1 — API Discovery (highest value)**
```
/swagger-ui.html, /swagger/index.html, /api-docs, /openapi.json
/api/swagger.json, /api/v1/openapi.json, /api/schema/
/graphql, /graphiql, /playground, /api/graphql
/.well-known/openid-configuration, /.well-known/oauth-authorization-server
/js/swagger-initializer.js, /swagger-resources
```
Red team note: Swagger/GraphQL = instant API map. This is gold. Spend time here.

**Tier 2 — Debug & Admin (if accessible = critical)**
```
/_debugbar, /_debugbar/open, /telescope, /telescope/requests
/horizon, /horizon/dashboard, /pulse, /nova
/phpinfo.php, /info.php, /_profiler, /symfony/profiler
/actuator, /actuator/health, /actuator/env, /actuator/mappings
/admin, /administrator, /console, /dashboard, /manage
/wp-admin, /wp-login.php, /user/login, /auth/login
```
Red team note: If ANY of these return 200 or 302 (not SPA catch-all) → mark as HIGH immediately. Debug endpoints expose internals.

**Tier 3 — Config & Secrets (if readable = critical)**
```
/.env, /.env.local, /.env.production, /.env.backup, /.env.example
/.git/config, /.git/HEAD, /.svn/entries, /.DS_Store
/wp-config.php, /config.php, /settings.py, /application.properties
/package.json, /composer.json, /yarn.lock, /Gemfile.lock
/docker-compose.yml, /Dockerfile, /docker-compose.override.yml
/robots.txt, /sitemap.xml, /security.txt
```
Red team note: If `.env` returns real content (not SPA shell) → CRITICAL. Extract every key, URL, credential. Check each.

**Tier 4 — Backup & Archive (rare but lethal)**
```
/backup, /backups, /db.sql, /dump.sql, /export.sql, /database.sql
/backup.zip, /backup.tar.gz, /site.zip, /www.zip, /archive.tar.gz
/logs, /log, /error.log, /access.log, /debug.log
/tmp, /temp, /cache, /storage/logs, /storage/framework
```
Red team note: `.sql` or `.zip` files downloadable = game over. CRITICAL immediately.

**Tier 5 — Environment Discovery**
```
/dev, /test, /testing, /staging, /uat, /sandbox, /demo, /beta
/dev., /staging., /test., /uat.  (subdomain prefixes)
/admin., /internal., /staff., /employee., /partner.
```

### Decision Logic
After surface mapping, the AI MUST produce:
- **Top 3 most promising targets** (ranked by attack surface)
- **Critical findings that need immediate escalation** (debug endpoints, exposed configs)
- **False positives to mark** (SPA catch-all, CDN generic pages)

---

## PHASE 3: JAVASCRIPT & SOURCE INTELLIGENCE (5 min)

### Target Selection
Only analyze JS on hosts that returned real HTML (not SPA shells or CDN redirects).

### Analysis Layers

**Layer 1 — Source Map Discovery**
```
Check every .js file for: //# sourceMappingURL=
Append .map to every JS URL found
If source map found → FULL source code recovery
Red team note: Source maps = original unminified code. This is the motherlode.
```

**Layer 2 — Route & Endpoint Extraction**
```
Regex patterns to search for in JS:
  api/[a-zA-Z0-9_/-]+               → API routes
  /api/v[0-9]+/[a-zA-Z0-9_/-]+      → Versioned API routes  
  ["'`](https?://[^"'`]+)["'`]      → Hardcoded URLs
  ["'`](/[a-zA-Z0-9_/-]+)["'`]       → Internal paths
  \.[a-z]{2,4}\?                     → Static file references
  new WebSocket\(["'`]([^"'`]+)      → WebSocket endpoints
  fetch\(["'`]([^"'`]+)              → Fetch API calls
  axios\.(get|post|put|delete)\(     → Axios API calls
```

**Layer 3 — Secrets & Credentials**
```
Search for:
  (apiKey|api_key|API_KEY|apikey)\s*[:=]\s*["'][A-Za-z0-9_-]{10,}
  (token|accessToken|authToken|bearer)\s*[:=]\s*["'][A-Za-z0-9._-]{10,}
  (password|passwd|pwd|secret)\s*[:=]\s*["'][^"']{3,}
  (privateKey|private_key|PRIVATE KEY)
  -----BEGIN (RSA|EC|DSA|OPENSSH) PRIVATE KEY-----
  (aws_access_key_id|AWS_ACCESS_KEY_ID|AKIA[A-Z0-9]{16})
  (mongodb|mysql|postgres|redis|jdbc)://[^"'\s]+
  (firebase|supabase|appwrite)\.(io|com|app)
  (stripe|paypal|braintree)_(key|secret|token)
  (google|facebook|github|twitter|linkedin)_(client_id|client_secret|app_id)
  eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}  (JWT)
```

**Layer 4 — Feature Flags & Debug Logic**
```
Search for:
  debug\s*[:=]\s*(true|1)
  isDev\s*[:=]\s*(true|1)
  isProduction\s*[:=]\s*(false|0)
  environment\s*[:=]\s*["'](development|staging|local)
  logLevel\s*[:=]\s*["'](debug|trace)
  bypass|skipAuth|noAuth|mockAuth
```

### Decision Logic
For every finding, the AI must answer:
- Is this a real credential or a placeholder?
- What system does this credential access?
- Is there a related finding from another phase that confirms this?
- What's the blast radius if this is compromised?

---

## PHASE 4: AUTH & AUTHORIZATION (5 min)

### ⚠️ CRITICAL RULES
- **NEVER test credentials on production without explicit authorization**
- **Detection is OK. Exploitation is NOT.**
- **Max 3 attempts per endpoint. Lockout = liability.**
- **Document what you WOULD test, don't actually brute-force.**

### What the AI CAN do (detection only)

**JWT Analysis**
```
1. Detect JWT in cookies, localStorage refs, or API responses
2. Decode JWT header + payload (no key needed — it's base64)
3. Check:
   - alg: "none" → CRITICAL (accepts unsigned tokens)
   - alg: "HS256" with weak secret → HIGH
   - exp: expired → info
   - kid: path traversal? (../../etc/passwd) → HIGH
   - iss/aud mismatch → info
4. Look for JWT refresh patterns in JS
```

**OAuth/SSO Flow Mapping**
```
1. Detect OAuth endpoints: /oauth/authorize, /oauth/token, /oidc/...
2. Identify providers: Google, Facebook, Microsoft, Okta, Auth0, Keycloak
3. Check for:
   - redirect_uri validation (can be bypassed?)
   - state parameter (missing = CSRF risk)
   - PKCE (missing on SPAs = auth code interception)
   - response_type=token (implicit flow = token in URL)
```

**Session & Token Analysis**
```
1. Check Set-Cookie headers for:
   - HttpOnly (missing = XSS can steal)
   - Secure (missing = MITM can steal)  
   - SameSite (missing = CSRF risk)
   - session cookie name patterns (PHPSESSID, JSESSIONID, laravel_session)
2. Check for CSRF tokens in forms/responses
3. Check rate limiting headers:
   - X-RateLimit-Remaining, Retry-After
   - Missing = no rate limiting → brute-force possible
```

**Authorization Surface**
```
1. Identify role-based endpoints:
   - /admin/*, /api/admin/*, /manage/*
   - Different responses for different roles?
2. Look for IDOR patterns in JS:
   - /api/users/{id}, /api/orders/{id}
   - Check if {id} is sequential or UUID (UUID = harder to enumerate)
3. Check CORS headers:
   - Access-Control-Allow-Origin: * → any site can call API
   - Access-Control-Allow-Credentials: true + wildcard → CRITICAL
```

### Decision Output
The AI must produce:
- **Auth surface map**: what protects each endpoint?
- **Weakest link**: which auth mechanism is most likely breakable?
- **Token inventory**: every token/JWT/session found, where found, what it protects

---

## PHASE 5: INPUT & FILE PROCESSING (5 min)

### ⚠️ CRITICAL RULES
- **NEVER upload actual shells or malware**
- **Detection: find upload endpoints, identify what they accept**
- **Test upload with safe content only (text file, small image)**

### Upload Surface Discovery

**Find Upload Endpoints**
```
In HTML: <input type="file">, <form enctype="multipart/form-data">
In JS:   FormData, .upload(), .post() with file, multer references
In API:  POST /upload, /api/upload, /files, /media, /attachments
         PUT /api/users/{id}/avatar, /api/profile/photo
```

**For each upload endpoint found, document:**
```
1. URL + method
2. Accepted file types (from HTML accept= or API docs)
3. Max size (from HTML or error messages)
4. Storage destination (local / S3 / CloudFront URL in response?)
5. Authentication required?
6. Response format (does it return the file URL?)
```

### Parser Detection

**Identify what processes the input**
```
Look for indicators in responses:
  - "ImageMagick", "imagemagick" → image processing
  - "wkhtmlto", "pdfkit", "dompdf" → PDF generation (SSRF vector)
  - "phpoffice", "phpexcel", "libreoffice" → document parsing
  - "unzip", "ziparchive", "tar" → archive extraction
  - "xml", "soap", "wsdl" → XML processing (XXE vector)
  - "unserialize", "deserialize" → object deserialization (RCE vector)
```

**SSRF Detection**
```
Check for:
  - URL parameters: ?url=, ?path=, ?file=, ?fetch=, ?proxy=, ?redirect=
  - Webhook/import/export features
  - PDF generator with user-controlled URLs
  - Image proxy: /img/proxy?url=, /media/fetch?src=
  - WebSocket proxy patterns in JS
For each SSRF vector, document:
  - What protocols are likely accepted? (http, file, gopher, dict?)
  - Is response reflected? (blind SSRF vs full SSRF)
```

### Cloud Storage Detection

**Identify storage type**
```
1. S3 detection:
   - Response headers: x-amz-*, Server: AmazonS3
   - URL patterns: s3.amazonaws.com, s3-{region}.amazonaws.com
2. CloudFront:
   - Response headers: x-amz-cf-id, cf-ray, Via, CloudFront
3. Azure Blob:
   - URL patterns: blob.core.windows.net
4. GCP Storage:
   - URL patterns: storage.googleapis.com
```

**For each storage finding:**
```
1. Is the bucket/container name exposed?
2. Is directory listing enabled?
3. Are signed URLs needed? (check for Signature=, Expires=, AWSAccessKeyId=)
4. Is there a CORS misconfiguration? (public write access?)
```

### Decision Output
The AI must produce:
- **Upload endpoint inventory** with accepted types and auth requirements
- **SSRF candidate list** ranked by exploitability (reflected > blind)
- **Storage exposure assessment** (public buckets? signed URLs? CORS?)
- **Top 3 most dangerous input vectors** (what would a pentester try first?)

---

## CROSS-PHASE CORRELATION RULES

The AI must connect findings across phases. These are the highest-value correlations:

| Phase 2 Finding | Phase 3 Finding | Combined Impact |
|---|---|---|
| Swagger/OpenAPI found | API key in JS | CRITICAL — key + API map = full access |
| Debug endpoint (200) | Debug flag in JS | HIGH — confirmed active debug mode |
| Admin panel (200) | Default password in JS | CRITICAL — admin access |
| S3 bucket URL | AWS key in JS | CRITICAL — storage compromise |
| /graphql found | JWT in localStorage | HIGH — GraphQL + token = data dump |
| .env accessible | Database URL inside | CRITICAL — full database access |

---

## ESCALATION RULES

When should the AI mark something as CRITICAL?

```
is CRITICAL if:
  - Real credential found (not placeholder/example)
  - Debug endpoint returns actual debug data
  - Config file readable with real content  
  - Source map recovered exposing full source
  - S3 bucket with public write access
  - JWT with alg:none or HS256 with guessable secret
  - SQL/backup file downloadable
  - SSRF confirmed + cloud metadata accessible

is HIGH if:
  - Admin/login panel found (even without credentials)
  - Swagger/GraphQL playground exposed
  - JWT/API key found in JS (unconfirmed usage)
  - Upload endpoint with no file type restrictions
  - CORS misconfiguration (credentials + wildcard)
  - Rate limiting missing on login/reset endpoints

is MEDIUM if:
  - Missing security headers on production
  - Debug paths return 200 (but content is SPA shell)
  - Technology versions exposed in headers
  - robots.txt/sitemap.xml with internal paths
  - Cookie without Secure/HttpOnly flags (but not auth cookie)

is LOW if:
  - Informational exposures (TXT records, email addresses)
  - Missing headers on non-production hosts
  - Brand typosquatting domains
```

---

## HUNT LOOP ALGORITHM

```
LOOP (5 minutes per phase):
  1. COLLECT: Run discovery tools for current phase
  2. ANALYZE: AI reviews all findings
  3. CORRELATE: Cross-reference with previous phases
  4. PRIORITIZE: Which finding gives the most attack surface?
  5. DIG DEEPER: Focus on top finding, run specific checks
  6. ESCALATE: If CRITICAL found → report immediately
  7. DOCUMENT: Every finding with evidence + confidence
  8. NEXT: Move to next most promising target
```

The AI should NEVER:
- Run the same check twice on the same target
- Spread thin across all targets equally
- Mark SPA catch-all as real findings
- Test credentials on production systems
- Upload actual malicious files

The AI should ALWAYS:
- Prioritize depth over breadth
- Connect findings across phases
- Provide evidence for every claim
- Flag uncertainty (confidence < 50%)
- Recommend manual verification for criticals
