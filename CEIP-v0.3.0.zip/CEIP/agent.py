#!/usr/bin/env python3
"""CEIP CLI — single entry point.

Usage::

    python agent.py ask "What is a vulnerability?"
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from typing import Any

import httpx
import structlog

from src.config import Settings
from src.foundation.logging_config import setup_logging
from src.kernel.exceptions import APIError, ConfigurationError
from src.llm.base import Message
from src.llm.glm_client import GLMClient


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="agent", description="CEIP Agent")
    sub = parser.add_subparsers(dest="command")
    ask_parser = sub.add_parser("ask", help="Send a message to the LLM")
    ask_parser.add_argument("message", help="The message to send")

    discover_parser = sub.add_parser("discover", help="Discover DNS + subdomains for a domain")
    discover_parser.add_argument("domain", help="Domain to discover (e.g. example.com)")

    correlate_parser = sub.add_parser(
        "correlate", help="Run correlation on discovery data"
    )
    correlate_parser.add_argument(
        "domain", help="Domain to correlate (e.g. example.com)"
    )

    vuln_parser = sub.add_parser("vuln", help="Run vulnerability assessment")
    vuln_parser.add_argument("domain", help="Domain to assess (e.g. example.com)")

    threat_parser = sub.add_parser("threats", help="Run threat intelligence assessment")
    threat_parser.add_argument("domain", help="Domain to assess (e.g. example.com)")

    risk_parser = sub.add_parser("risk", help="Run risk assessment")
    risk_parser.add_argument("domain", help="Domain to assess (e.g. example.com)")

    analyze_parser = sub.add_parser("analyze", help="AI security analyst report")
    analyze_parser.add_argument("domain", help="Domain to analyze (e.g. example.com)")

    identity_parser = sub.add_parser("identity", help="Identity exposure assessment")
    identity_parser.add_argument("domain", help="Domain to assess (e.g. example.com)")

    darkweb_parser = sub.add_parser("darkweb", help="Dark web intelligence")
    darkweb_parser.add_argument("domain", help="Domain to assess (e.g. example.com)")

    monitor_parser = sub.add_parser("monitor", help="Continuous monitoring")
    mon_sub = monitor_parser.add_subparsers(dest="mon_action")
    mon_sub.add_parser("start", help="Start monitoring a domain").add_argument("domain")
    mon_sub.add_parser("run", help="Run monitoring now").add_argument("domain")
    mon_sub.add_parser("history", help="Monitoring history").add_argument("domain")
    mon_sub.add_parser("diff", help="Show changes").add_argument("domain")
    mon_sub.add_parser("alerts", help="Show alerts").add_argument("domain")

    dash_parser = sub.add_parser("dashboard", help="Dashboard views")
    dash_sub = dash_parser.add_subparsers(dest="dash_action")
    dash_sub.add_parser("executive", help="Executive dashboard").add_argument("domain")
    dash_sub.add_parser("soc", help="SOC dashboard").add_argument("domain")
    dash_sub.add_parser("summary", help="Executive summary").add_argument("domain")

    report_parser = sub.add_parser("report", help="Generate report")
    rep_sub = report_parser.add_subparsers(dest="rep_action")
    for rt in ["executive", "technical", "monitoring", "identity", "threat", "risk"]:
        rep_sub.add_parser(rt, help=f"{rt.title()} report").add_argument("domain")

    ap_parser = sub.add_parser("attack-path", help="Simulate attack paths")
    ap_parser.add_argument("domain", help="Domain to analyze")

    brand_parser = sub.add_parser("brand", help="Brand protection analysis")
    brand_sub = brand_parser.add_subparsers(dest="brand_action")
    brand_sub.add_parser("scan", help="Scan for brand impersonation").add_argument("brand")
    brand_sub.add_parser("summary", help="Brand summary").add_argument("brand")
    brand_sub.add_parser("risk", help="Brand risk").add_argument("brand")

    investigate_parser = sub.add_parser("investigate", help="AI-powered security investigation")
    investigate_parser.add_argument("request", help="Investigation request in natural language")

    args = parser.parse_args(argv)
    if args.command not in (
        "ask", "discover", "correlate", "vuln", "threats", "risk",
        "analyze", "identity", "darkweb", "monitor", "dashboard", "report",
        "attack-path", "brand", "investigate",
    ):
        parser.print_help()
        return 1

    # --- Bootstrap ---
    try:
        settings = Settings()
    except Exception as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 1

    logger = setup_logging(settings.log_level).bind(component="cli")

    # --- Correlate (no LLM needed) ---
    if args.command == "correlate":
        return asyncio.run(_correlate(settings, logger, args.domain))

    # --- Vulnerability (no LLM needed) ---
    if args.command == "vuln":
        return asyncio.run(_vuln(settings, logger, args.domain))

    # --- Threats (no LLM needed) ---
    if args.command == "threats":
        return asyncio.run(_threats(settings, logger, args.domain))

    # --- Risk (no LLM needed) ---
    if args.command == "risk":
        return asyncio.run(_risk(settings, logger, args.domain))

    # --- Identity (no LLM needed) ---
    if args.command == "identity":
        return asyncio.run(_identity(settings, logger, args.domain))

    # --- Darkweb (no LLM needed) ---
    if args.command == "darkweb":
        return asyncio.run(_darkweb(settings, logger, args.domain))

    # --- Monitor (no LLM needed) ---
    if args.command == "monitor":
        return asyncio.run(_monitor(settings, logger, args))

    # --- Dashboard (no LLM needed) ---
    if args.command == "dashboard":
        return asyncio.run(_dashboard(settings, args))

    # --- Report (no LLM needed) ---
    if args.command == "report":
        return asyncio.run(_report(settings, args))

    # --- Attack Path (no LLM needed) ---
    if args.command == "attack-path":
        return asyncio.run(_attack_path_cmd(settings, args))

    # --- Brand Protection (no LLM needed) ---
    if args.command == "brand":
        return asyncio.run(_brand_cmd(settings, args))

    # --- Analyze (needs LLM) ---
    if args.command == "analyze":
        if not settings.glm_api_key:
            print("Error: GLM_API_KEY not set in .env", file=sys.stderr)
            return 1
        http_client = httpx.AsyncClient(timeout=httpx.Timeout(120))
        try:
            return asyncio.run(_analyze(settings, logger, http_client, args.domain))
        finally:
            asyncio.run(http_client.aclose())

    # --- Investigate (M32 AI Orchestrator) ---
    if args.command == "investigate":
        from src.contexts.ai.orchestrator import AIOrchestrator
        orch = AIOrchestrator()
        result = asyncio.run(orch.investigate("default", args.request))
        print(f"Intent: {result.get('intent', 'Unknown')}")
        print(f"Agents: {', '.join(result.get('agents_used', []))}")
        print(f"Strategy: {result.get('routing_strategy', '')}")
        conf_score = result.get('confidence_score', 0)
        conf_level = result.get('confidence_level', 'LOW')
        print(f"Confidence: {conf_score:.2f} ({conf_level})")
        analysis = result.get("final_analysis", {})
        print(f"\nAnalysis: {analysis.get('analysis', 'No analysis')}")
        print(f"Evidence: {len(result.get('evidence_summary', []))} items")
        for e in result.get("evidence_summary", []):
            print(f"  - {e}")
        return 0

    # --- Discover (no LLM needed) ---
    if args.command == "discover":
        return asyncio.run(_discover(settings, logger, args.domain))

    # --- Ask (needs LLM) ---
    if not settings.glm_api_key:
        print("Error: GLM_API_KEY not set in .env", file=sys.stderr)
        return 1

    http_client = httpx.AsyncClient(timeout=httpx.Timeout(settings.http_timeout))

    try:
        llm = GLMClient(settings, http_client, logger)
        return asyncio.run(_ask(llm, logger, args.message))
    except ConfigurationError as exc:
        logger.error("Configuration error", error=str(exc))
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except APIError as exc:
        logger.error("API error", error=str(exc))
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    finally:
        asyncio.run(http_client.aclose())


async def _discover(
    settings: Settings, logger: structlog.BoundLogger, domain: str
) -> int:
    """Run DNS + subdomain discovery and print results."""
    from src.contexts.discovery.service import DiscoveryService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = DiscoveryService(db)
        logger.info("discover", domain=domain)
        print(f"Discovering {domain} ...")
        job = await svc.start(domain)
        # Re-fetch with eager-loaded relationships
        reloaded = await svc.get_job(job.id)
        assert reloaded is not None, "Job vanished after creation"
        job = reloaded

        print(f"\nStatus: {job.status}")
        if job.error:
            print(f"Error: {job.error}")
            return 1

        print(f"\nDNS Records ({len(job.dns_records)}):")
        for r in job.dns_records:
            val = r.value[:80] + "..." if len(r.value) > 80 else r.value
            print(f"  {r.record_type:6} {val}")

        print(f"\nSubdomains ({len(job.subdomains)}):")
        for s in job.subdomains:
            print(f"  {s.name:40} [{s.source}]")

        if job.services:
            print(f"\nServices ({len(job.services)}):")
            for srv in job.services:
                server = srv.server or "(no server header)"
                print(f"  {srv.host:40} HTTP {srv.status_code}  server={server}")

        if job.certificates:
            print(f"\nCertificates ({len(job.certificates)}):")
            for c in job.certificates:
                print(f"  {c.host:40} issued by {c.issuer or '?'}")

        if job.ip_enrichments:
            print(f"\nIP Enrichment ({len(job.ip_enrichments)}):")
            for e in job.ip_enrichments:
                parts = [e.ip]
                if e.reverse_dns:
                    parts.append(f"PTR={e.reverse_dns}")
                if e.asn:
                    parts.append(f"ASN={e.asn}")
                if e.asn_org:
                    parts.append(f"Org={e.asn_org}")
                print(f"  {'  '.join(parts)}")

        print(f"\nJob ID: {job.id}")
        await db.commit()
    await engine.dispose()
    return 0


async def _correlate(
    settings: Settings, logger: structlog.BoundLogger, domain: str
) -> int:
    """Run correlation analysis on existing discovery data."""
    from src.contexts.correlation.service import CorrelationService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = CorrelationService(db)
        logger.info("correlate", domain=domain)
        print(f"Correlating {domain} ...")
        result = await svc.correlate(domain)

        if not result.get("relationships") and not result.get("clusters"):
            print(
                f"No discovery data for '{domain}'."
                f" Run `python agent.py discover {domain}` first."
            )
            return 1

        rels = result["relationships"]
        clusters = result["clusters"]
        groups = result["exposure_groups"]

        print(f"\n{result['summary']}")

        if rels:
            print(f"\nRelationships ({len(rels)}):")
            for r in rels:
                src = r['source_value'][:35]
                tgt = r['target_value'][:35]
                rel = r['relationship']
                print(f"  {src:35} --[{rel:12}]--> {tgt}")

        if clusters:
            print(f"\nClusters ({len(clusters)}):")
            for c in clusters:
                print(f"  [{c['cluster_type']:12}] {c['name'][:60]} ({c['member_count']} members)")

        if groups:
            print(f"\nExposure Groups ({len(groups)}):")
            for g in groups:
                print(f"  [{g['group_type']:16}] {g['name'][:60]}")

        await db.commit()
    await engine.dispose()
    return 0


async def _vuln(
    settings: Settings, logger: structlog.BoundLogger, domain: str
) -> int:
    """Run vulnerability assessment on existing discovery data."""
    from src.contexts.vulnerability.service import VulnerabilityService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = VulnerabilityService(db)
        logger.info("vuln", domain=domain)
        print(f"Assessing {domain} ...")
        result = await svc.assess(domain)

        if not result.get("findings"):
            print(f"No discovery data for '{domain}'. Run discover first.")
            return 1

        findings = result["findings"]

        print(f"\n{result['summary']}")

        if findings:
            print(f"\nFindings ({len(findings)}):")
            for f in findings:
                sev = f["severity"].upper()
                cve = f.get("cve_id") or "N/A"
                print(f"  [{sev:8}] {cve:16} {f['title'][:70]}")

        await db.commit()
    await engine.dispose()
    return 0


async def _threats(
    settings: Settings, logger: structlog.BoundLogger, domain: str
) -> int:
    """Run threat intelligence assessment."""
    from src.contexts.threat.models import ThreatIndicator, ThreatMatch  # noqa: F401
    from src.contexts.threat.service import ThreatService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = ThreatService(db)
        logger.info("threats", domain=domain)
        print(f"Assessing threats for {domain} ...")
        result = await svc.assess(domain)

        if "No discovery" in result.get("summary", ""):
            print(f"No discovery data for '{domain}'. Run discover first.")
            return 1

        matches = result["matches"]
        print(f"\n{result['summary']}")

        if matches:
            print(f"\nThreat Matches ({len(matches)}):")
            for m in matches:
                sev = m["severity"].upper()
                cat = m.get("threat_category", "unknown")
                print(f"  [{sev:10}] [{cat:10}] {m['matched_asset']}")

        await db.commit()
    await engine.dispose()
    return 0


async def _risk(
    settings: Settings, logger: structlog.BoundLogger, domain: str
) -> int:
    """Run risk assessment."""
    from src.contexts.risk.engine import RiskEngine
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        risk = RiskEngine(db)
        logger.info("risk", domain=domain)
        print(f"Computing risk for {domain} ...")
        result = await risk.assess(domain)

        if "No discovery" in result.get("summary", ""):
            print(f"No discovery data for '{domain}'. Run discover first.")
            return 1

        scores = result["scores"]
        print(f"\n{result['summary']}")

        if scores:
            print("\nTop Risk Assets:")
            top = sorted(scores, key=lambda s: s["score"], reverse=True)[:5]
            for s in top:
                level = s["level"]
                print(
                    f"  [{level:8}] {s['asset_identifier'][:35]:35} "
                    f"score={s['score']:5.0f}  "
                    f"(V:{s['vuln_weight']:.0f} T:{s['threat_weight']:.0f} "
                    f"E:{s['exposure_weight']:.0f} I:{s['importance_weight']:.0f})"
                )

            if result["top_risks"]:
                print("\nWhat to fix first:")
                for r in result["top_risks"]:
                    print(f"  -> {r}")

        await db.commit()
    await engine.dispose()
    return 0


async def _identity(
    settings: Settings, logger: structlog.BoundLogger, domain: str
) -> int:
    """Run identity exposure assessment."""
    from src.contexts.identity_exposure.models import IdentityExposure  # noqa: F401
    from src.contexts.identity_exposure.repository import IdentityExposureRepository
    from src.contexts.identity_exposure.service import IdentityExposureService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        repo = IdentityExposureRepository(db)
        svc = IdentityExposureService(repo=repo, settings=settings)
        logger.info("identity", domain=domain)
        print(f"Scanning identity exposure for {domain} ...")
        result = await svc.scan(domain)
        _print_identity_result(result)
        await db.commit()
    await engine.dispose()
    return 0


async def _darkweb(
    settings: Settings, logger: structlog.BoundLogger, domain: str
) -> int:
    """Run dark web intelligence assessment."""
    from src.contexts.exposure.models import DarkWebIntel  # noqa: F401
    from src.contexts.exposure.service import ExposureService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = ExposureService(db)
        logger.info("darkweb", domain=domain)
        print(f"Checking dark web intelligence for {domain} ...")
        result = await svc.assess_darkweb(domain)
        _print_darkweb(result)
        await db.commit()
    await engine.dispose()
    return 0


def _print_identity_result(result: dict[str, Any]) -> None:
    """Print identity exposure results."""
    print(f"\n{result.get('summary', '')}")
    score = result.get("exposure_score", 0)
    risk = result.get("risk_contribution", 0)
    print(f"  Score: {score} | Risk: +{risk}")
    sev = result.get("severity_counts", {})
    c = sev.get("CRITICAL", 0)
    h = sev.get("HIGH", 0)
    m = sev.get("MEDIUM", 0)
    lw = sev.get("LOW", 0)
    print(f"  Critical: {c} | High: {h} | Medium: {m} | Low: {lw}")
    if result.get("top_findings"):
        print("\n  Top Findings:")
        for f in result["top_findings"]:
            print(f"    {f}")


def _print_exposure(result: dict[str, Any]) -> None:
    """Print identity exposure results."""
    print(f"\n{result.get('summary', '')}")
    exposures = result.get("exposures", [])
    if exposures:
        print(f"\nIdentity Exposures ({len(exposures)}):")
        for e in exposures:
            sev = e["severity"]
            print(f"  [{sev:8}] [{e['entity_type']:8}] {e['entity'][:60]}")
            if e.get("description"):
                print(f"           {e['description'][:100]}")


def _print_darkweb(result: dict[str, Any]) -> None:
    """Print dark web intelligence results."""
    print(f"\n{result.get('summary', '')}")
    items = result.get("dark_web_intel", [])
    if items:
        print(f"\nDark Web Signals ({len(items)}):")
        for i in items:
            sev = i["severity"]
            print(f"  [{sev:8}] [{i['intel_type']:12}] {i['title'][:70]}")


async def _monitor(
    settings: Settings, logger: structlog.BoundLogger, args: Any
) -> int:
    """Continuous monitoring commands."""
    from src.contexts.monitoring.models import MonitoringJob  # noqa: F401
    from src.contexts.monitoring.repository import MonitoringRepository
    from src.contexts.monitoring.service import MonitoringService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        repo = MonitoringRepository(db)
        svc = MonitoringService(db, repo)
        action = getattr(args, "mon_action", "run")
        domain = getattr(args, "domain", "")
        rc = 0

        if action == "start":
            job = await svc.start_job(domain, "manual")
            print(f"Monitoring started for {domain} (schedule: {job.schedule})")
            print(f"Job ID: {job.id}")
        elif action == "run":
            print(f"Running monitoring for {domain} ...")
            result = await svc.run(domain, trigger="cli")
            _print_monitor_result(result)
            if result["status"] != "completed":
                rc = 1
        elif action == "history":
            result = await svc.get_history(domain)
            print(f"\nMonitoring History: {domain} ({result['total']} executions)")
            for e in result["executions"]:
                st = e["status"].upper()
                dur = f"{e['duration_ms']}ms" if e["duration_ms"] else "N/A"
                print(f"  [{st}] v{e['scan_version']} {e['started_at']} ({dur})")
        elif action == "diff":
            result = await svc.get_diff(domain)
            print(f"\nDiff: {domain}")
            print(f"  {result['summary']}")
            for c in result.get("changes", []):
                print(f"  [{c['severity']}] {c['change_type']}: {c['entity_identifier'][:60]}")
        elif action == "alerts":
            result = await svc.get_alerts(domain)
            print(f"\nAlerts: {domain} ({result['total']})")
            for a in result["alerts"]:
                ack = "[ACK]" if a["acknowledged"] else "[NEW]"
                print(f"  {ack} [{a['severity']}] {a['alert_type']}: {a['title'][:70]}")
        else:
            print(f"Unknown monitor action: {action}")
            rc = 1

        await db.commit()
    await engine.dispose()
    return rc


async def _attack_path_cmd(settings: Settings, args: Any) -> int:  # noqa: E501
    """Run attack path simulation."""
    from src.contexts.attack_path.engine import AttackPathEngine
    from src.contexts.attack_path.repository import AttackPathRepository
    from src.contexts.attack_path.service import AttackPathService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        repo = AttackPathRepository(db)
        eng = AttackPathEngine(db)
        svc = AttackPathService(repo, eng)
        domain = getattr(args, "domain", "")
        result = await svc.run(domain)
        print(f"\nAttack Path Analysis: {domain}")
        print(f"  Overall Exposure: {result['overall_exposure']}")
        crit = result['critical_paths']
        high = result['high_paths']
        print(f"  Paths: {result['path_count']} ({crit} critical, {high} high)")
        for p in result["paths"]:
            nm = str(p['name']).replace('→', '->')
            jewels = p.get('crown_jewels_affected', [])
            jewel_str = f" (jewels: {', '.join(jewels)})" if jewels else ""
            print(f"\n  [{p['level']}] {nm} (score={p['overall_score']:.0f}){jewel_str}")
            lh = p['likelihood']
            im = p['impact']
            cx = p['complexity']
            ex = p['exposure']
            print(f"    L:{lh:.1f} I:{im:.1f} C:{cx:.1f} E:{ex:.1f}")
            if p.get('kill_chain_stages'):
                stages = " -> ".join(s.replace("_", " ").title() for s in p['kill_chain_stages'])
                print(f"    Kill Chain: {stages}")
            if p.get("mitigations"):
                print(f"    Fix: {p['mitigations'][:120]}")
        if result.get("top_mitigations"):
            print("\n  Top Mitigations:")
            for m in result["top_mitigations"]:
                print(f"    - {m}")
        await db.commit()
    await engine.dispose()
    return 0


async def _brand_cmd(settings: Settings, args: Any) -> int:
    """Run brand protection scan."""
    from src.contexts.brand_protection.repository import BrandRepository
    from src.contexts.brand_protection.service import BrandProtectionService
    from src.foundation.database import create_engine, create_session_factory, init_db

    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        repo = BrandRepository(db)
        svc = BrandProtectionService(repo)
        brand = getattr(args, "brand", "")
        result = await svc.scan(brand)
        action = getattr(args, "brand_action", "scan")
        print(f"\nBrand Protection: {brand}")
        print(f"  {result['summary']}")
        if action in ("scan", "summary"):
            if result["domains"]:
                print("\n  Top Suspect Domains:")
                for d in result["domains"][:10]:
                    m = d['detection_methods'][:35]
                    lvl = d['risk_level']
                    dom = d['domain']
                    sim = d['similarity_score']
                    print(f"    [{lvl:8}] {dom:30} sim={sim:.2f} [{m}]")
        elif action == "risk":
            c = result['critical']
            h = result['high']
            med = result['medium']
            lo = result['low']
            print("\n  Risk Breakdown:")
            print(f"    Critical: {c} | High: {h} | Medium: {med} | Low: {lo}")
        await db.commit()
    await engine.dispose()
    return 0


async def _report(settings: Settings, args: Any) -> int:
    """Generate report."""
    from src.contexts.reporting.service import ReportingService
    from src.foundation.database import create_engine, create_session_factory

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = ReportingService(db)
        rtype = getattr(args, "rep_action", "executive")
        domain = getattr(args, "domain", "")
        result = await svc.generate(domain, rtype)
        print(f"\n{result['title']}")
        print(f"Generated: {result['generated_at']}")
        for section in result.get("sections", []):
            print(f"\n  ## {section['title']}")
            if section.get("description"):
                print(f"  {section['description']}")
            for item in section.get("items", [])[:10]:
                print(f"    - {item}")
    await engine.dispose()
    return 0


async def _dashboard(settings: Settings, args: Any) -> int:
    """Dashboard aggregation views."""
    from src.contexts.dashboard.service import DashboardService
    from src.foundation.database import create_engine, create_session_factory

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = DashboardService(db)
        action = getattr(args, "dash_action", "executive")
        domain = getattr(args, "domain", "")

        if action == "executive":
            result = await svc.executive(domain)
            print(f"\nExecutive Dashboard: {domain}")
            print(f"  Overall Score: {result['overall_score']}/100 ({result['overall_level']})")
            print(f"  Critical: {result['critical_findings']} | High: {result['high_findings']}")
            print(f"  Threat Matches: {result['threat_matches']}")
            print(f"  Identity Exposures: {result['identity_exposures']}")
            print(f"  Alerts: {result['monitoring_alerts']}")
            print(f"\n  {result['executive_summary']}")
            if result.get("top_assets"):
                print("\n  Top Risk Assets:")
                for a in result["top_assets"][:5]:
                    lvl = a['risk_level']
                    ident = a['identifier'][:40]
                    print(f"    [{lvl}] {ident} score={a['risk_score']:.0f}")
        elif action == "soc":
            result = await svc.soc(domain)
            print(f"\nSOC Dashboard: {domain}")
            if result["critical_vulnerabilities"]:
                print("\n  Critical Vulns:")
                for v in result["critical_vulnerabilities"]:
                    print(f"    {v}")
            if result["threat_matches"]:
                print("\n  Threat Matches:")
                for t in result["threat_matches"]:
                    print(f"    {t}")
            if result["open_alerts"]:
                print("\n  Open Alerts:")
                for a in result["open_alerts"]:
                    print(f"    {a}")
        elif action == "summary":
            result = await svc.summary(domain)
            print(f"\n{result['summary']}")

    await engine.dispose()
    return 0


def _print_monitor_result(result: dict[str, Any]) -> None:
    print(f"\n{result.get('summary', '')}")
    print(f"Status: {result.get('status','').upper()}")
    print(f"Duration: {result.get('duration_ms')}ms")
    print(f"Changes: {result.get('changes_count', 0)}")
    print(f"Alerts: {result.get('alerts_count', 0)}")
    for a in result.get("alerts", []):
        print(f"  [{a['severity']}] {a['alert_type']}: {a['title'][:80]}")


async def _analyze(
    settings: Settings,
    logger: structlog.BoundLogger,
    http_client: httpx.AsyncClient,
    domain: str,
) -> int:
    """Generate AI security analyst report."""
    from src.contexts.analyst.service import AIAnalystService
    from src.foundation.database import create_engine, create_session_factory

    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        svc = AIAnalystService(db, settings, http_client, logger)
        logger.info("analyze", domain=domain)
        print(f"AI Security Analyst analyzing {domain} ...\n")
        result = await svc.analyze(domain)

        if result.get("error") and not result.get("report"):
            print(f"Error: {result['error']}")
            return 1

        print(result["report"])
        if result.get("tokens"):
            t = result["tokens"]
            print(f"\n[Tokens: {t['prompt']} prompt + {t['completion']} completion]")

    await engine.dispose()
    return 0


async def _ask(
    client: GLMClient, logger: structlog.BoundLogger, message: str
) -> int:
    """Send a single message and print the response."""
    logger.info("ask", message=message)
    messages = [Message(role="user", content=message)]

    try:
        response = await client.chat(messages)
    except Exception as exc:
        logger.error("LLM call failed", error=str(exc))
        raise APIError(str(exc)) from exc

    print(response.content)
    return 0


if __name__ == "__main__":
    sys.exit(main())
