"""Tests for configuration loading."""

from __future__ import annotations

from src.config import Settings


class TestSettings:
    def test_defaults(self) -> None:
        s = Settings(glm_api_key="k")
        assert s.glm_model == "glm-5.2"
        assert s.glm_base_url == "https://api.z.ai/api/paas/v4"
        assert s.http_timeout == 60
        assert s.log_level == "INFO"

    def test_loads_from_env(self, monkeypatch) -> None:
        monkeypatch.setenv("GLM_API_KEY", "env-key.test")
        s = Settings()
        assert s.glm_api_key == "env-key.test"

    def test_configured_provider(self) -> None:
        assert Settings(glm_api_key="x").configured_provider == "glm"
        assert Settings(glm_api_key="").configured_provider == "none"
