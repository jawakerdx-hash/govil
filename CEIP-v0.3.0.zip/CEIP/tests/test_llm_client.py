"""Tests for GLM client."""

from __future__ import annotations

import httpx
import pytest
from pytest_httpx import HTTPXMock

from src.llm.base import Message
from src.llm.glm_client import GLMClient


@pytest.fixture
def client(settings, http_client, silent_logger) -> GLMClient:
    return GLMClient(settings, http_client, silent_logger)


@pytest.mark.asyncio
async def test_successful_chat(client: GLMClient, httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        method="POST",
        url="https://api.z.ai/api/paas/v4/chat/completions",
        status_code=200,
        json={
            "model": "glm-5.2",
            "choices": [{"message": {"content": "Hello!"}, "finish_reason": "stop"}],
        },
    )
    response = await client.chat([Message(role="user", content="hi")])
    assert response.content == "Hello!"
    assert response.model == "glm-5.2"


@pytest.mark.asyncio
async def test_auth_error(client: GLMClient, httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        method="POST",
        url="https://api.z.ai/api/paas/v4/chat/completions",
        status_code=401,
    )
    with pytest.raises(PermissionError):
        await client.chat([Message(role="user", content="hi")])


@pytest.mark.asyncio
async def test_rate_limit(client: GLMClient, httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        method="POST",
        url="https://api.z.ai/api/paas/v4/chat/completions",
        status_code=429,
    )
    with pytest.raises(RuntimeError, match="Rate limited"):
        await client.chat([Message(role="user", content="hi")])


@pytest.mark.asyncio
async def test_timeout(client: GLMClient, httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_exception(
        httpx.TimeoutException("timed out"),
        method="POST",
        url="https://api.z.ai/api/paas/v4/chat/completions",
    )
    with pytest.raises(TimeoutError):
        await client.chat([Message(role="user", content="hi")])
