"""Tests for the CVE provider abstraction."""

from __future__ import annotations

import pytest

from src.contexts.vulnerability.cve_provider import (
    CVE,
    LocalCVEProvider,
    _version_cmp,
    _version_in_range,
)


class TestVersionHelpers:
    """Version comparison utilities."""

    def test_exact_match(self) -> None:
        assert _version_in_range("2.4.49", "2.4.49") is True

    def test_exact_mismatch(self) -> None:
        assert _version_in_range("2.4.50", "2.4.49") is False

    def test_range_match(self) -> None:
        assert _version_in_range("2.4.50", "2.4.0-2.4.54") is True

    def test_range_below(self) -> None:
        assert _version_in_range("2.3.9", "2.4.0-2.4.54") is False

    def test_range_above(self) -> None:
        assert _version_in_range("2.5.0", "2.4.0-2.4.54") is False

    def test_range_boundary_low(self) -> None:
        assert _version_in_range("8.5", "8.5-8.9") is True

    def test_range_boundary_high(self) -> None:
        assert _version_in_range("8.9", "8.5-8.9") is True

    def test_version_cmp_equal(self) -> None:
        assert _version_cmp("1.0.0", "1.0.0") == 0

    def test_version_cmp_less(self) -> None:
        assert _version_cmp("1.0.0", "1.0.1") == -1

    def test_version_cmp_greater(self) -> None:
        assert _version_cmp("2.0.0", "1.9.9") == 1

    def test_version_cmp_different_lengths(self) -> None:
        assert _version_cmp("1.0", "1.0.0") == -1


class TestCVE:
    """CVE dataclass tests."""

    def test_cve_immutable(self) -> None:
        cve = CVE(
            cve_id="CVE-2021-41773", service_type="apache",
            severity="critical", score=9.8,
            description="Path traversal in Apache",
        )
        assert cve.cve_id == "CVE-2021-41773"
        assert cve.service_type == "apache"
        assert cve.severity == "critical"
        assert cve.score == 9.8

    def test_cve_version_hint_optional(self) -> None:
        cve = CVE(
            cve_id="CVE-2023-44487", service_type="nginx",
            severity="high", score=7.5,
            description="HTTP/2 Rapid Reset",
        )
        assert cve.version_hint is None


class TestLocalCVEProvider:
    """Local CVE provider lookup tests."""

    @pytest.mark.asyncio
    async def test_lookup_apache_with_version(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("apache", "2.4.49")
        assert len(cves) > 0
        cve_ids = {c.cve_id for c in cves}
        assert "CVE-2021-41773" in cve_ids

    @pytest.mark.asyncio
    async def test_lookup_apache_no_version(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("apache")
        # Without a version, only version-agnostic CVEs are returned.
        # In the expanded dataset, most Apache CVEs have version ranges.
        # This is expected — operators should fingerprint the exact version.
        cve_ids = {c.cve_id for c in cves}
        assert len(cve_ids) == 0  # No version-agnostic Apache CVEs in the dataset

    @pytest.mark.asyncio
    async def test_lookup_nginx(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("nginx", "1.22.0")
        cve_ids = {c.cve_id for c in cves}
        assert len(cve_ids) >= 2
        assert "CVE-2022-41741" in cve_ids
        assert "CVE-2022-41742" in cve_ids

    @pytest.mark.asyncio
    async def test_lookup_unknown_service(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("nonexistent-service")
        assert len(cves) == 0

    @pytest.mark.asyncio
    async def test_lookup_openssh_range(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("openssh", "8.7")
        cve_ids = {c.cve_id for c in cves}
        assert "CVE-2023-38408" in cve_ids  # 8.5-8.9 range

    @pytest.mark.asyncio
    async def test_lookup_openssh_outside_range(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("openssh", "9.5")
        cve_ids = {c.cve_id for c in cves}
        # Should get version-agnostic CVEs but not the range-specific ones
        assert "CVE-2024-6387" in cve_ids  # version_hint=None
        assert "CVE-2023-38408" not in cve_ids  # 8.5-8.9 only

    @pytest.mark.asyncio
    async def test_lookup_caching(self) -> None:
        provider = LocalCVEProvider()
        cves1 = await provider.lookup("apache", "2.4.49")
        cves2 = await provider.lookup("apache", "2.4.49")
        assert len(cves1) == len(cves2)
        # Should hit the cache on second call
        assert cves1 == cves2

    @pytest.mark.asyncio
    async def test_lookup_cloudflare_info(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("cloudflare")
        cve_ids = {c.cve_id for c in cves}
        assert "CF-CDN-001" in cve_ids
        for c in cves:
            if c.cve_id == "CF-CDN-001":
                assert c.severity == "low"
                assert c.score == 1.0

    @pytest.mark.asyncio
    async def test_lookup_returns_cve_objects(self) -> None:
        provider = LocalCVEProvider()
        cves = await provider.lookup("apache", "2.4.49")
        for cve in cves:
            assert isinstance(cve, CVE)
            assert cve.cve_id
            assert cve.severity in ("critical", "high", "medium", "low")
            assert 0.0 <= cve.score <= 10.0
