"""Tests for the identity service."""

from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from src.contexts.identity.schemas import OrganizationCreate, UserCreate
from src.contexts.identity.service import IdentityService
from src.kernel.base_model import Base
from src.kernel.exceptions import ConflictError, NotFoundError


@pytest.fixture
async def db() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite://", echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with AsyncSession(engine) as session:
        yield session
    await engine.dispose()


@pytest.mark.asyncio
async def test_create_org(db: AsyncSession) -> None:
    svc = IdentityService(db)
    org = await svc.create_org(OrganizationCreate(name="Test", slug="test"))
    assert org.id is not None
    assert org.name == "Test"
    assert org.slug == "test"


@pytest.mark.asyncio
async def test_create_org_duplicate_slug(db: AsyncSession) -> None:
    svc = IdentityService(db)
    await svc.create_org(OrganizationCreate(name="A", slug="myorg"))
    with pytest.raises(ConflictError):
        await svc.create_org(OrganizationCreate(name="B", slug="myorg"))


@pytest.mark.asyncio
async def test_get_org_not_found(db: AsyncSession) -> None:
    svc = IdentityService(db)
    with pytest.raises(NotFoundError):
        await svc.get_org_by_slug("nonexistent")


@pytest.mark.asyncio
async def test_create_user(db: AsyncSession) -> None:
    svc = IdentityService(db)
    await svc.create_org(OrganizationCreate(name="T", slug="t"))
    user = await svc.create_user(UserCreate(
        org_slug="t", email="a@test.com", password="password123"
    ))
    assert user.email == "a@test.com"
    assert user.hashed_password != "password123"


@pytest.mark.asyncio
async def test_create_user_duplicate_email(db: AsyncSession) -> None:
    svc = IdentityService(db)
    await svc.create_org(OrganizationCreate(name="T", slug="t"))
    await svc.create_user(UserCreate(
        org_slug="t", email="dup@test.com", password="password123"
    ))
    with pytest.raises(ConflictError):
        await svc.create_user(UserCreate(
            org_slug="t", email="dup@test.com", password="password123"
        ))
