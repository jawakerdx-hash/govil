"""Tests for the deterministic risk scoring engine."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from src.contexts.risk.engine import RiskEngine, _score_to_level


class TestScoreToLevel:
    """Risk level threshold tests."""

    def test_critical_threshold(self) -> None:
        assert _score_to_level(100) == "CRITICAL"
        assert _score_to_level(76) == "CRITICAL"
        assert _score_to_level(75) == "HIGH"

    def test_high_threshold(self) -> None:
        assert _score_to_level(75) == "HIGH"
        assert _score_to_level(51) == "HIGH"
        assert _score_to_level(50) == "MEDIUM"

    def test_medium_threshold(self) -> None:
        assert _score_to_level(50) == "MEDIUM"
        assert _score_to_level(26) == "MEDIUM"
        assert _score_to_level(25) == "LOW"

    def test_low_threshold(self) -> None:
        assert _score_to_level(25) == "LOW"
        assert _score_to_level(0) == "LOW"
        assert _score_to_level(-1) == "LOW"


class TestScoreAsset:
    """Deterministic scoring logic tests."""

    @staticmethod
    def _make_security_finding(host: str, severity: str, cve_id: str, title: str):
        finding = MagicMock()
        finding.affected_asset = host
        finding.severity = severity
        finding.cve_id = cve_id
        finding.title = title
        return finding

    @staticmethod
    def _make_threat_match(host: str, severity: str, category: str):
        threat = MagicMock()
        threat.matched_asset = host
        threat.severity = severity
        threat.threat_category = category
        threat.match_type = "ioc"
        return threat

    def _engine(self):
        return RiskEngine(AsyncMock())

    # ------------------------------------------------------------------
    # Clean asset (no vulns, no threats, not public)
    # ------------------------------------------------------------------

    def test_clean_asset_scores_zero(self) -> None:
        engine = self._engine()
        result = engine._score_asset(
            host="internal-host",
            asset_type="service",
            findings=[],
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        assert result["score"] == 0.0
        assert result["level"] == "LOW"
        assert result["vuln_weight"] == 0.0
        assert result["threat_weight"] == 0.0
        assert result["exposure_weight"] == 0.0
        assert result["importance_weight"] == 0.0

    # ------------------------------------------------------------------
    # Public exposure
    # ------------------------------------------------------------------

    def test_public_ip_adds_exposure(self) -> None:
        engine = self._engine()
        result = engine._score_asset(
            host="public-host",
            asset_type="service",
            findings=[],
            threats=[],
            is_public=True,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        # public_ip = 100 * 0.6 * 0.20 = 12
        assert result["exposure_weight"] == pytest.approx(12.0, abs=0.1)
        assert result["score"] == pytest.approx(12.0, abs=0.1)

    def test_missing_hsts_adds_exposure(self) -> None:
        engine = self._engine()
        result = engine._score_asset(
            host="no-hsts-host",
            asset_type="service",
            findings=[],
            threats=[],
            is_public=False,
            has_hsts=False,
            has_csp=True,
            cluster_sizes={},
        )
        # missing_hsts = 100 * 0.3 * 0.20 = 6
        assert result["exposure_weight"] == pytest.approx(6.0, abs=0.1)

    def test_missing_csp_adds_exposure(self) -> None:
        engine = self._engine()
        result = engine._score_asset(
            host="no-csp-host",
            asset_type="service",
            findings=[],
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=False,
            cluster_sizes={},
        )
        # missing_csp = 100 * 0.2 * 0.20 = 4
        assert result["exposure_weight"] == pytest.approx(4.0, abs=0.1)

    def test_full_exposure_scores_correctly(self) -> None:
        engine = self._engine()
        result = engine._score_asset(
            host="fully-exposed",
            asset_type="service",
            findings=[],
            threats=[],
            is_public=True,
            has_hsts=False,
            has_csp=False,
            cluster_sizes={},
        )
        # public_ip(12) + missing_hsts(6) + missing_csp(4) = 22, capped at 20
        assert result["exposure_weight"] == pytest.approx(20.0, abs=0.1)
        assert result["score"] == pytest.approx(20.0, abs=0.1)

    # ------------------------------------------------------------------
    # Vulnerability scoring
    # ------------------------------------------------------------------

    def test_critical_cve_scores_max(self) -> None:
        engine = self._engine()
        finding = self._make_security_finding(
            "host1", "critical", "CVE-2021-41773", "Apache path traversal"
        )
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=[finding],
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        # critical = 100 * 1.0 * 0.40 = 40 (max for vuln)
        assert result["vuln_weight"] == pytest.approx(40.0, abs=0.1)

    def test_high_cve_scores_proportionally(self) -> None:
        engine = self._engine()
        finding = self._make_security_finding(
            "host1", "high", "CVE-2023-25690", "Apache request splitting"
        )
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=[finding],
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        # high = 100 * 0.75 * 0.40 = 30
        assert result["vuln_weight"] == pytest.approx(30.0, abs=0.1)

    def test_medium_cve_scores_half(self) -> None:
        engine = self._engine()
        finding = self._make_security_finding(
            "host1", "medium", "CVE-2025-0001", "Some medium finding"
        )
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=[finding],
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        # medium = 100 * 0.50 * 0.40 = 20
        assert result["vuln_weight"] == pytest.approx(20.0, abs=0.1)

    def test_vuln_score_capped_at_40(self) -> None:
        engine = self._engine()
        findings = [
            self._make_security_finding("host1", "critical", f"CVE-2025-{i:04d}", f"Test {i}")
            for i in range(5)
        ]
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=findings,
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        # Should be capped at 40 regardless of how many findings
        assert result["vuln_weight"] == pytest.approx(40.0, abs=0.1)

    # ------------------------------------------------------------------
    # Threat scoring
    # ------------------------------------------------------------------

    def test_malicious_threat_scores_max(self) -> None:
        engine = self._engine()
        threat = self._make_threat_match("host1", "malicious", "malware")
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=[],
            threats=[threat],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        # malicious = 100 * 1.0 * 0.30 = 30 (max for threat)
        assert result["threat_weight"] == pytest.approx(30.0, abs=0.1)

    def test_suspicious_threat_scores_partial(self) -> None:
        engine = self._engine()
        threat = self._make_threat_match("host1", "suspicious", "anomaly")
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=[],
            threats=[threat],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={},
        )
        # suspicious = 100 * 0.60 * 0.30 = 18
        assert result["threat_weight"] == pytest.approx(18.0, abs=0.1)

    # ------------------------------------------------------------------
    # Importance scoring
    # ------------------------------------------------------------------

    def test_cluster_increases_importance(self) -> None:
        engine = self._engine()
        result = engine._score_asset(
            host="cluster-host",
            asset_type="service",
            findings=[],
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={"cluster-host": 5},
        )
        # importance = min(100 * (5/10) * 0.10, 10) = min(5, 10) = 5
        assert result["importance_weight"] == pytest.approx(5.0, abs=0.1)

    def test_importance_capped_at_10(self) -> None:
        engine = self._engine()
        result = engine._score_asset(
            host="big-cluster-host",
            asset_type="service",
            findings=[],
            threats=[],
            is_public=False,
            has_hsts=True,
            has_csp=True,
            cluster_sizes={"big-cluster-host": 50},
        )
        # importance = min(100 * (50/10) * 0.10, 10) = min(50, 10) = 10
        assert result["importance_weight"] == pytest.approx(10.0, abs=0.1)

    # ------------------------------------------------------------------
    # Composite scoring
    # ------------------------------------------------------------------

    def test_composite_score_adds_all_dimensions(self) -> None:
        engine = self._engine()
        finding = self._make_security_finding(
            "host1", "critical", "CVE-2021-41773", "Apache path traversal"
        )
        threat = self._make_threat_match("host1", "malicious", "malware")
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=[finding],
            threats=[threat],
            is_public=True,
            has_hsts=False,
            has_csp=False,
            cluster_sizes={"host1": 5},
        )
        # vuln: 40 (capped), threat: 30, exposure: 20 (capped), importance: 5 = 95
        assert result["score"] == pytest.approx(95.0, abs=0.1)
        assert result["level"] == "CRITICAL"

    def test_factors_list_is_populated(self) -> None:
        engine = self._engine()
        finding = self._make_security_finding(
            "host1", "high", "CVE-2023-25690", "Apache request splitting"
        )
        result = engine._score_asset(
            host="host1",
            asset_type="service",
            findings=[finding],
            threats=[],
            is_public=True,
            has_hsts=False,
            has_csp=True,
            cluster_sizes={},
        )
        assert len(result["factors"]) >= 3  # vuln + public_ip + missing_hsts
        categories = {f["category"] for f in result["factors"]}
        assert "vulnerability" in categories
        assert "exposure" in categories
