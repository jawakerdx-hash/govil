"""Tests for the health endpoints."""

from __future__ import annotations

from fastapi.testclient import TestClient

from src.api.app import create_app


def test_health_returns_ok() -> None:
    client = TestClient(create_app())
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "uptime_seconds" in data


def test_liveness_returns_alive() -> None:
    client = TestClient(create_app())
    response = client.get("/health/live")
    assert response.status_code == 200
    assert response.json() == {"status": "alive"}


def test_readiness() -> None:
    client = TestClient(create_app())
    response = client.get("/health/ready")
    assert response.status_code == 200
    assert response.json()["status"] == "ready"


def test_version() -> None:
    client = TestClient(create_app())
    response = client.get("/health/version")
    assert response.status_code == 200
    assert response.json()["product"] == "CEIP"
