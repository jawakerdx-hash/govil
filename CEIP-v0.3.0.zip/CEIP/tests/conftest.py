"""Shared test fixtures."""

from __future__ import annotations

import logging

import httpx
import pytest
import structlog

from src.config import Settings


@pytest.fixture
def settings() -> Settings:
    return Settings(
        glm_api_key="test-key.abc",
        glm_base_url="https://api.z.ai/api/paas/v4",
        glm_model="glm-5.2",
        http_timeout=30,
        log_level="INFO",
    )


@pytest.fixture
def silent_logger() -> structlog.BoundLogger:
    logger = logging.getLogger("test")
    logger.setLevel(logging.CRITICAL)
    return structlog.get_logger()


@pytest.fixture
def http_client() -> httpx.AsyncClient:
    return httpx.AsyncClient()
