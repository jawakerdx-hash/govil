"""Abstract LLM client interface."""

from __future__ import annotations

from abc import ABC, abstractmethod

from pydantic import BaseModel


class Message(BaseModel):
    """A single chat message."""

    role: str = "user"
    content: str


class Usage(BaseModel):
    """Token usage statistics."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatResponse(BaseModel):
    """Response from an LLM chat request."""

    content: str
    model: str = ""
    usage: Usage | None = None
    finish_reason: str | None = None


class LLMClient(ABC):
    """Abstract interface for a language-model chat client."""

    @abstractmethod
    async def chat(
        self,
        messages: list[Message],
        *,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> ChatResponse:
        """Send messages and receive a response."""
        ...
