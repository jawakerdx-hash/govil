"""GLM-5.2 client via the Z.AI API."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any

import httpx
import structlog

from src.config import Settings
from src.llm.base import ChatResponse, LLMClient, Message, Usage


class GLMClient(LLMClient):
    """GLM-5.2 chat client using the OpenAI-compatible Z.AI endpoint."""

    def __init__(
        self,
        settings: Settings,
        http_client: httpx.AsyncClient,
        logger: structlog.BoundLogger | None = None,
    ) -> None:
        self._settings = settings
        self._http = http_client
        self._logger = logger or structlog.get_logger()

    async def chat(
        self,
        messages: list[Message],
        *,
        temperature: float = 0.7,
        max_tokens: int = 1024,
    ) -> ChatResponse:
        request_id = uuid.uuid4().hex[:12]
        log = self._logger.bind(request_id=request_id, model=self._settings.glm_model)

        url = f"{self._settings.glm_base_url}/chat/completions"
        payload = {
            "model": self._settings.glm_model,
            "messages": [m.model_dump() for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "thinking": {"type": "disabled"},
        }
        headers = {
            "Authorization": f"Bearer {self._settings.glm_api_key}",
            "Content-Type": "application/json",
        }

        log.debug("Sending chat request", url=url)

        t0 = time.perf_counter()
        try:
            response = await self._http.post(url, headers=headers, json=payload)
        except httpx.TimeoutException as exc:
            log.warning("Request timed out")
            raise TimeoutError(f"Request to {url} timed out") from exc
        except httpx.NetworkError as exc:
            log.warning("Network error")
            raise ConnectionError(f"Network error calling {url}: {exc}") from exc

        latency_ms = (time.perf_counter() - t0) * 1000
        parsed = self._parse(response, log)

        log.info(
            "Chat complete",
            latency_ms=round(latency_ms, 1),
            prompt_tokens=parsed.usage.prompt_tokens if parsed.usage else 0,
            completion_tokens=parsed.usage.completion_tokens if parsed.usage else 0,
            total_tokens=parsed.usage.total_tokens if parsed.usage else 0,
            finish_reason=parsed.finish_reason,
            status_code=response.status_code,
        )
        return parsed

    def _parse(self, response: httpx.Response, log: structlog.BoundLogger) -> ChatResponse:
        status = response.status_code
        body = response.text[:2000]

        if status in (401, 403):
            raise PermissionError(f"GLM API returned {status}. Check GLM_API_KEY.")
        if status == 429:
            raise RuntimeError("Rate limited (HTTP 429). Retry after 5s.")
        if status >= 400:
            raise RuntimeError(f"GLM API error HTTP {status}: {body}")

        try:
            data: dict[str, Any] = response.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise ValueError(f"GLM returned invalid JSON: {body[:500]}") from exc

        try:
            choice = data["choices"][0]
            content: str = choice["message"]["content"]
            model: str = data.get("model", self._settings.glm_model)
            finish: str | None = choice.get("finish_reason")
            usage_raw = data.get("usage", {})

            usage = Usage(
                prompt_tokens=usage_raw.get("prompt_tokens", 0),
                completion_tokens=usage_raw.get("completion_tokens", 0),
                total_tokens=usage_raw.get("total_tokens", 0),
            ) if usage_raw else None

            return ChatResponse(content=content, model=model, usage=usage, finish_reason=finish)
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError(f"GLM response missing expected fields: {exc}") from exc
