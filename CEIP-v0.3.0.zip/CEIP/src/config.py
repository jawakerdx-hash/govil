"""Application configuration from environment variables."""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Top-level configuration loaded from .env and environment."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # LLM (GLM — legacy, kept for backward compat)
    glm_api_key: str = ""
    glm_base_url: str = "https://api.z.ai/api/paas/v4"
    glm_model: str = "glm-5.2"

    # AI Intelligence Layer (configurable — Anthropic, OpenAI, or any compatible API)
    ai_api_key: str = ""
    ai_api_url: str = "https://api.anthropic.com/v1/messages"
    ai_model: str = "claude-haiku-4-5-20251001"
    ai_max_tokens: int = 4096
    ai_temperature: float = 0.3
    ai_timeout: int = 60
    ai_max_retries: int = 3
    ai_rate_limit_rpm: int = 50
    ai_enabled: bool = True  # set to false to disable AI analysis
    ai_budget_per_scan: int = 50000  # max tokens per scan

    # Database
    database_url: str = "postgresql+asyncpg://ceip:ceip@localhost:5432/ceip"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Logging
    log_level: str = "INFO"

    # HTTP
    http_timeout: int = 60

    # Identity exposure
    identity_provider: str = "local"

    # Gateway / Auth (>=32 chars for HS256 compliance — RFC 7518 §3.2)
    gateway_secret: str = "ceip-dev-secret-change-in-production-32c"

    # C99.nl OSINT API
    c99_api_key: str = ""
    c99_enabled: bool = True

    # App
    debug: bool = False

    @property
    def configured_provider(self) -> str:
        if self.glm_api_key:
            return "glm"
        return "none"
