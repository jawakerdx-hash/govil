"""Core interfaces for the Security Rating Engine."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class FactorResult:
    """Output from a single security rating factor."""

    factor_name: str
    score: float
    weight: float
    confidence: float
    coverage: float
    findings: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    affected_assets: list[str] = field(default_factory=list)
    business_impact: str = "LOW"
    evidence: dict[str, Any] = field(default_factory=dict)


class SecurityRatingFactor(ABC):
    """Abstract factor contributing to the security rating."""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    async def evaluate(self, domain: str) -> FactorResult: ...

    @property
    def default_weight(self) -> float:
        return 0.05


class WeightPolicy(ABC):
    """Configurable factor weighting strategy."""

    @abstractmethod
    def get_weights(self) -> dict[str, float]: ...


class NormalizationEngine(ABC):
    """Normalizes raw factor scores before weighting."""

    @abstractmethod
    def normalize(self, factors: list[FactorResult]) -> list[FactorResult]: ...


class ConfidenceEngine(ABC):
    """Calculates overall confidence from factor confidence + coverage."""

    @abstractmethod
    def calculate(self, factors: list[FactorResult], coverage: float) -> dict[str, Any]: ...


class CoverageEngine(ABC):
    """Calculates platform visibility / asset coverage."""

    @abstractmethod
    async def calculate(self, domain: str) -> dict[str, Any]: ...


class GradeEngine(ABC):
    """Maps numeric scores to letter grades."""

    @abstractmethod
    def to_grade(self, score: float) -> dict[str, Any]: ...
