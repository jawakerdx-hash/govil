"""Security rating repository — read/write rating data only."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import RatingFactorRecord, RatingHistory, SecurityRating


class RatingRepository:
    """Persistence for security ratings. Never reads from other contexts."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def get_latest(self, domain: str) -> SecurityRating | None:
        r = await self._db.execute(
            select(SecurityRating)
            .where(SecurityRating.domain == domain)
            .order_by(SecurityRating.created_at.desc())
            .limit(1)
        )
        return r.scalar_one_or_none()

    async def save_rating(self, rating: SecurityRating) -> None:
        self._db.add(rating)
        await self._db.flush()

    async def save_factor_record(self, record: RatingFactorRecord) -> None:
        self._db.add(record)

    async def save_history(self, entry: RatingHistory) -> None:
        self._db.add(entry)

    async def get_history(self, domain: str, limit: int = 20) -> list[RatingHistory]:
        r = await self._db.execute(
            select(RatingHistory)
            .where(RatingHistory.domain == domain)
            .order_by(RatingHistory.recorded_at.desc())
            .limit(limit)
        )
        return list(r.scalars().all())

    async def get_factors(self, rating_id: str) -> list[RatingFactorRecord]:
        r = await self._db.execute(
            select(RatingFactorRecord).where(RatingFactorRecord.rating_id == rating_id)
        )
        return list(r.scalars().all())

    async def flush(self) -> None:
        await self._db.flush()
