"""Trend engine — detects score movement direction."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import RatingHistory


class TrendEngine:
    """Analyzes rating history to detect trends."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def analyze(self, domain: str) -> dict[str, Any]:
        r = await self._db.execute(
            select(RatingHistory)
            .where(RatingHistory.domain == domain)
            .order_by(RatingHistory.recorded_at.desc())
            .limit(10)
        )
        entries = list(r.scalars().all())

        if not entries:
            return {"domain": domain, "trend": "unknown", "entries": 0}

        current = entries[0]
        scores = [e.overall_score for e in entries]

        if len(scores) >= 2:
            delta = round(scores[0] - scores[-1], 1)
            if delta > 5:
                trend = "improving"
            elif delta < -5:
                trend = "declining"
            else:
                trend = "stable"
        else:
            delta = 0.0
            trend = "initial"

        return {
            "domain": domain,
            "current_score": current.overall_score,
            "current_grade": current.letter_grade,
            "previous_score": current.previous_score,
            "delta": current.delta,
            "trend": trend,
            "score_range": {"min": min(scores), "max": max(scores)},
            "entries": len(entries),
        }
