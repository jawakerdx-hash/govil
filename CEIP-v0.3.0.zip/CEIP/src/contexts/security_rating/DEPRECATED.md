# DEPRECATED — M17

This context has been superseded by M24 Security Rating Engine at:
`src/contexts/infrastructure_graph/security_rating.py`

M24 consumes the unified M20-M27 pipeline output, providing richer inputs
(M22 probabilistic layer, M23 threat intelligence, M20 graph centrality).

M17 factors and DB tables are retained for reference but no longer active.
All rating computation now flows through the unified InfrastructureGraphEngine.
