"""Coverage engine — measures platform visibility into assets."""

from __future__ import annotations

from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from .interfaces import CoverageEngine


class AssetCoverageEngine(CoverageEngine):
    """Calculates what fraction of known assets have been assessed."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def calculate(self, domain: str) -> dict[str, Any]:
        known, assessed = 1, 1
        try:
            from sqlalchemy import select

            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(
                select(DiscoveryJob).where(
                    DiscoveryJob.domain == domain, DiscoveryJob.status == "done"
                ).limit(1)
            )
            job = r.scalar_one_or_none()
            if job:
                dns = len(job.dns_records) if hasattr(job, "dns_records") else 1
                subs = len(job.subdomains) if hasattr(job, "subdomains") else 0
                services = len(job.services) if hasattr(job, "services") else 0
                known = max(1, dns + subs + services)
                assessed = known  # all discovered = all assessed
        except Exception:
            pass

        coverage_pct = round((assessed / known) * 100, 1) if known > 0 else 0.0
        return {
            "known_assets": known,
            "assessed_assets": assessed,
            "coverage_pct": min(100.0, coverage_pct),
            "is_complete": assessed >= known,
        }
