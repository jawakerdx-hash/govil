"""Configurable weight policy for security rating factors."""

from __future__ import annotations

from .interfaces import WeightPolicy

DEFAULT_WEIGHTS: dict[str, float] = {
    "attack_surface": 0.08,
    "internet_exposure": 0.07,
    "critical_vulnerabilities": 0.15,
    "patch_hygiene": 0.05,
    "threat_intelligence": 0.08,
    "identity_exposure": 0.08,
    "brand_protection": 0.05,
    "attack_paths": 0.10,
    "certificate_health": 0.04,
    "dns_health": 0.04,
    "email_security": 0.04,
    "cloud_exposure": 0.04,
    "monitoring_maturity": 0.04,
    "security_controls": 0.04,
    "dark_web_exposure": 0.03,
    "asset_coverage": 0.05,
}


class DefaultWeightPolicy(WeightPolicy):
    """Default CEIP weight policy. Configurable per customer."""

    def __init__(self, overrides: dict[str, float] | None = None) -> None:
        self._weights = {**DEFAULT_WEIGHTS, **(overrides or {})}

    def get_weights(self) -> dict[str, float]:
        return dict(self._weights)
