"""Security rating ORM models."""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import DateTime, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class SecurityRating(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "security_ratings"

    domain: Mapped[str] = mapped_column(String(255), index=True)
    overall_score: Mapped[float] = mapped_column(Float, default=0.0)
    letter_grade: Mapped[str] = mapped_column(String(4), default="F")
    confidence_score: Mapped[float] = mapped_column(Float, default=0.0)
    confidence_level: Mapped[str] = mapped_column(String(16), default="LOW")
    coverage_pct: Mapped[float] = mapped_column(Float, default=0.0)
    factor_count: Mapped[int] = mapped_column(Integer, default=0)
    evidence_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class RatingHistory(UUIDMixin, Base):
    __tablename__ = "rating_history"

    domain: Mapped[str] = mapped_column(String(255), index=True)
    overall_score: Mapped[float] = mapped_column(Float, default=0.0)
    letter_grade: Mapped[str] = mapped_column(String(4), default="F")
    previous_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    delta: Mapped[float | None] = mapped_column(Float, nullable=True)
    trend: Mapped[str] = mapped_column(String(16), default="stable")
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(UTC))
    factors_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class RatingFactorRecord(UUIDMixin, Base):
    __tablename__ = "rating_factors"

    rating_id: Mapped[str] = mapped_column(String(36), index=True)
    factor_name: Mapped[str] = mapped_column(String(64))
    score: Mapped[float] = mapped_column(Float, default=0.0)
    weight: Mapped[float] = mapped_column(Float, default=0.0)
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    coverage: Mapped[float] = mapped_column(Float, default=0.0)
    findings_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    recommendations_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class BenchmarkProfile(UUIDMixin, Base):
    __tablename__ = "benchmark_profiles"

    profile_name: Mapped[str] = mapped_column(String(64), unique=True)
    profile_type: Mapped[str] = mapped_column(String(32))
    data_json: Mapped[str | None] = mapped_column(Text, nullable=True)
