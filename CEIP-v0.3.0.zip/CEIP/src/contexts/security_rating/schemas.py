"""Security rating Pydantic schemas."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class FactorSummary(BaseModel):
    name: str
    score: float
    weight: float
    confidence: float
    model_config = {"from_attributes": True}


class RatingResponse(BaseModel):
    id: UUID
    domain: str
    overall_score: float
    letter_grade: str
    confidence_score: float
    confidence_level: str
    coverage_pct: float
    factor_count: int
    model_config = {"from_attributes": True}


class HistoryEntry(BaseModel):
    id: UUID
    score: float
    grade: str
    delta: float | None = None
    trend: str = "stable"
    recorded_at: str
    model_config = {"from_attributes": True}


class BenchmarkComparison(BaseModel):
    profile_name: str
    expected_score: float
    actual_score: float
    gap: float
    factor_diffs: dict[str, float] = {}
    model_config = {"from_attributes": True}
