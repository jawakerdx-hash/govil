"""Security Rating Engine — orchestrates the full rating pipeline."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from .confidence import EvidenceConfidenceEngine
from .coverage import AssetCoverageEngine
from .factor_registry import FactorRegistry
from .grading import LetterGrader
from .interfaces import FactorResult
from .normalization import ScoreNormalizer
from .weights import DefaultWeightPolicy


class SecurityRatingEngine:
    """Read-only engine. Factors discovered via FactorRegistry."""

    def __init__(self, db: AsyncSession, registry: FactorRegistry | None = None) -> None:
        self._db = db
        self._registry = registry or FactorRegistry.with_defaults()
        self._weights = DefaultWeightPolicy()
        self._normalizer = ScoreNormalizer()
        self._grader = LetterGrader()
        self._confidence = EvidenceConfidenceEngine()
        self._coverage = AssetCoverageEngine(db)

    async def calculate(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()

        # 1. Coverage
        cov_data = await self._coverage.calculate(domain)
        coverage_pct = cov_data["coverage_pct"]

        # 2. Evaluate all factors via registry
        factors: list[FactorResult] = []
        weights = self._weights.get_weights()
        factor_instances = self._registry.create_all(db=self._db)
        for factor in factor_instances:
            try:
                result = await factor.evaluate(domain)
                result.weight = weights.get(result.factor_name, factor.default_weight)
                factors.append(result)
            except Exception:
                factors.append(FactorResult(
                    factor_name=factor.name, score=50.0,
                    weight=0.05, confidence=0.1, coverage=0.0,
                    findings=["Factor evaluation failed"],
                ))

        # 3. Normalize
        factors = self._normalizer.normalize(factors)

        # 4. Weighted score
        overall = sum(f.score * f.weight for f in factors)
        overall = max(0.0, min(100.0, round(overall, 1)))

        # 5. Grade
        grade = self._grader.to_grade(overall)

        # 6. Confidence
        conf = self._confidence.calculate(factors, coverage_pct)

        # 7. Factor breakdown
        factor_breakdown = [
            {
                "name": f.factor_name, "score": f.score, "weight": f.weight,
                "confidence": f.confidence, "coverage": f.coverage,
                "findings": f.findings, "recommendations": f.recommendations,
                "contribution": round(f.score * f.weight, 2),
            }
            for f in factors
        ]

        # 8. Top weaknesses (lowest-scoring factors)
        sorted_factors = sorted(factors, key=lambda f: f.score)
        top_weaknesses = [
            {"factor": f.factor_name, "score": f.score, "recommendations": f.recommendations}
            for f in sorted_factors[:3] if f.score < 70
        ]

        return {
            "domain": domain,
            "overall_score": overall,
            "letter_grade": grade["letter"],
            "grade_description": grade["description"],
            "confidence_score": conf["confidence_score"],
            "confidence_level": conf["confidence_level"],
            "confidence_explanation": conf["explanation"],
            "coverage_pct": coverage_pct,
            "factor_count": len(factors),
            "factor_breakdown": factor_breakdown,
            "top_weaknesses": top_weaknesses,
            "evidence_json": json.dumps({
                "factors": factor_breakdown,
                "coverage": cov_data,
                "confidence": conf,
            }),
        }
