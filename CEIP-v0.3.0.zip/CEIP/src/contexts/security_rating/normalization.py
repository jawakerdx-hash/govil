"""Normalization engine — prevents any single factor from dominating."""

from __future__ import annotations

from .interfaces import FactorResult, NormalizationEngine

MAX_FACTOR_CONTRIBUTION = 0.30
CAP_PENALTY = 0.85


class ScoreNormalizer(NormalizationEngine):
    """Normalizes raw factor scores with penalty caps.

    No single factor may contribute more than 30% of the final score.
    """

    def normalize(self, factors: list[FactorResult]) -> list[FactorResult]:
        if not factors:
            return factors

        for f in factors:
            # Clamp extreme scores
            f.score = max(0.0, min(100.0, f.score))
            # Apply penalty cap for very low scores
            if f.score < 20:
                f.score = max(0.0, f.score * CAP_PENALTY)
            # Normalize weight contribution
            f.weight = min(f.weight, MAX_FACTOR_CONTRIBUTION)

        # Rebalance weights to sum to 1.0
        total_weight = sum(f.weight for f in factors)
        if total_weight > 0:
            for f in factors:
                f.weight = f.weight / total_weight

        return factors
