"""Security rating service — orchestrates rating calculation and persistence."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from .engine import SecurityRatingEngine
from .models import RatingFactorRecord, RatingHistory, SecurityRating
from .repository import RatingRepository


class SecurityRatingService:
    """Orchestrates rating calculation, history tracking, and trend analysis."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._repo = RatingRepository(db)
        self._engine = SecurityRatingEngine(db)

    async def calculate(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        result = await self._engine.calculate(domain)

        previous = await self._repo.get_latest(domain)
        prev_score = previous.overall_score if previous else None
        delta = round(result["overall_score"] - prev_score, 1) if prev_score is not None else None
        trend = _compute_trend(delta) if delta is not None else "initial"

        # Persist rating
        rating = SecurityRating(
            domain=domain,
            overall_score=result["overall_score"],
            letter_grade=result["letter_grade"],
            confidence_score=result["confidence_score"],
            confidence_level=result["confidence_level"],
            coverage_pct=result["coverage_pct"],
            factor_count=result["factor_count"],
            evidence_json=result["evidence_json"],
        )
        await self._repo.save_rating(rating)

        # Persist factor records
        for fb in result["factor_breakdown"]:
            record = RatingFactorRecord(
                rating_id=str(rating.id),
                factor_name=fb["name"], score=fb["score"],
                weight=fb["weight"], confidence=fb["confidence"],
                coverage=fb["coverage"],
                findings_json=json.dumps(fb.get("findings", [])),
                recommendations_json=json.dumps(fb.get("recommendations", [])),
            )
            await self._repo.save_factor_record(record)

        # Persist history
        history = RatingHistory(
            domain=domain,
            overall_score=result["overall_score"],
            letter_grade=result["letter_grade"],
            previous_score=prev_score,
            delta=delta,
            trend=trend,
            factors_json=json.dumps(result["factor_breakdown"]),
        )
        await self._repo.save_history(history)
        await self._repo.flush()

        result["rating_id"] = str(rating.id)
        result["previous_score"] = prev_score
        result["delta"] = delta
        result["trend"] = trend
        return result

    async def show(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        rating = await self._repo.get_latest(domain)
        if rating is None:
            return await self.calculate(domain)
        factors = await self._repo.get_factors(str(rating.id))
        return {
            "rating_id": str(rating.id),
            "domain": domain,
            "overall_score": rating.overall_score,
            "letter_grade": rating.letter_grade,
            "confidence_score": rating.confidence_score,
            "confidence_level": rating.confidence_level,
            "coverage_pct": rating.coverage_pct,
            "factor_count": rating.factor_count,
            "factors": [
                {"name": f.factor_name, "score": f.score, "weight": f.weight,
                 "confidence": f.confidence}
                for f in factors
            ],
        }

    async def history(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        entries = await self._repo.get_history(domain)
        return {
            "domain": domain,
            "total_entries": len(entries),
            "history": [
                {
                    "id": str(e.id), "score": e.overall_score,
                    "grade": e.letter_grade, "delta": e.delta,
                    "trend": e.trend, "recorded_at": str(e.recorded_at),
                }
                for e in entries
            ],
        }


def _compute_trend(delta: float) -> str:
    if delta > 5:
        return "improving"
    if delta < -5:
        return "declining"
    return "stable"
