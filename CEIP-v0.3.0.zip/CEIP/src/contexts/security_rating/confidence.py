"""Confidence engine — evidence-quality-based confidence scoring."""

from __future__ import annotations

from typing import Any

from .interfaces import ConfidenceEngine, FactorResult


class EvidenceConfidenceEngine(ConfidenceEngine):
    """Calculates overall confidence from factor-level confidence + coverage."""

    def calculate(self, factors: list[FactorResult], coverage: float) -> dict[str, Any]:
        if not factors:
            return {
                "confidence_score": 0.0, "confidence_level": "LOW",
                "explanation": "No factors evaluated",
            }

        avg_conf = sum(f.confidence for f in factors) / len(factors)
        coverage_factor = min(1.0, coverage / 100.0)
        avg_coverage = sum(f.coverage for f in factors) / len(factors)

        score = round(
            (avg_conf * 0.6 + coverage_factor * 0.25 + avg_coverage * 0.15) * 100, 1
        )

        if score >= 80:
            level = "HIGH"
        elif score >= 50:
            level = "MEDIUM"
        else:
            level = "LOW"

        return {
            "confidence_score": score,
            "confidence_level": level,
            "avg_factor_confidence": round(avg_conf, 3),
            "coverage_factor": round(coverage_factor, 3),
            "explanation": (
                f"Confidence {level}: avg factor confidence={avg_conf:.2f}, "
                f"coverage={coverage:.0f}%, avg factor coverage={avg_coverage:.2f}"
            ),
        }
