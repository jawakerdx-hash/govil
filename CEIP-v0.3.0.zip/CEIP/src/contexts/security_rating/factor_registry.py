"""Factor registry — plugin discovery for security rating factors."""

from __future__ import annotations

from .interfaces import SecurityRatingFactor


class FactorRegistry:
    """Registry of SecurityRatingFactor plugins.

    The engine discovers factors through this registry.
    Factor lists are never hardcoded inside services.
    """

    def __init__(self) -> None:
        self._factors: dict[str, type[SecurityRatingFactor]] = {}

    def register(self, factor_cls: type[SecurityRatingFactor]) -> None:
        self._factors[factor_cls.__name__] = factor_cls

    def list(self) -> list[str]:
        return sorted(self._factors)

    def create_all(self, **kwargs: object) -> list[SecurityRatingFactor]:
        return [cls(**kwargs) for cls in self._factors.values()]

    @classmethod
    def with_defaults(cls) -> FactorRegistry:
        reg = cls()
        from .factors.asset_coverage import AssetCoverageFactor
        from .factors.attack_paths import AttackPathsFactor
        from .factors.attack_surface import AttackSurfaceFactor
        from .factors.brand_protection import BrandProtectionFactor
        from .factors.certificate_health import CertificateHealthFactor
        from .factors.cloud_exposure import CloudExposureFactor
        from .factors.critical_vulnerabilities import CriticalVulnerabilitiesFactor
        from .factors.dark_web_exposure import DarkWebExposureFactor
        from .factors.dns_health import DNSHealthFactor
        from .factors.email_security import EmailSecurityFactor
        from .factors.identity_exposure import IdentityExposureFactor
        from .factors.internet_exposure import InternetExposureFactor
        from .factors.monitoring_maturity import MonitoringMaturityFactor
        from .factors.patch_hygiene import PatchHygieneFactor
        from .factors.security_controls import SecurityControlsFactor
        from .factors.threat_intelligence import ThreatIntelligenceFactor

        for fc in [
            AttackSurfaceFactor, InternetExposureFactor,
            CriticalVulnerabilitiesFactor, PatchHygieneFactor,
            ThreatIntelligenceFactor, IdentityExposureFactor,
            BrandProtectionFactor, AttackPathsFactor,
            CertificateHealthFactor, DNSHealthFactor,
            EmailSecurityFactor, CloudExposureFactor,
            MonitoringMaturityFactor, SecurityControlsFactor,
            DarkWebExposureFactor, AssetCoverageFactor,
        ]:
            reg.register(fc)
        return reg
