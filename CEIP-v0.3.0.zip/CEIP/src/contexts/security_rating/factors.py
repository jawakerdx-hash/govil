"""Security rating factors — each evaluates one dimension of security posture."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .interfaces import FactorResult, SecurityRatingFactor


class AttackSurfaceFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "attack_surface"

    @property
    def default_weight(self) -> float:
        return 0.10

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(
                select(DiscoveryJob).where(
                    DiscoveryJob.domain == domain, DiscoveryJob.status == "done"
                ).limit(1)
            )
            job = r.scalar_one_or_none()
            svc_count = len(job.services) if job else 0
            score = max(30.0, 100.0 - svc_count * 3)
            return FactorResult(
                factor_name=self.name, score=min(100.0, score), weight=self.default_weight,
                confidence=0.8 if job else 0.3, coverage=1.0 if job else 0.0,
                findings=[f"{svc_count} exposed services"] if svc_count > 0 else ["No services discovered"],
                recommendations=["Reduce exposed services"] if svc_count > 10 else [],
                affected_assets=[s.host for s in job.services[:5]] if job and hasattr(job, "services") else [],
                evidence={"service_count": svc_count},
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Discovery data unavailable"])


class CriticalVulnerabilitiesFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "critical_vulnerabilities"

    @property
    def default_weight(self) -> float:
        return 0.15

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.vulnerability.models import SecurityFinding
            r = await self._db.execute(
                select(SecurityFinding).where(SecurityFinding.domain == domain)
            )
            findings = r.scalars().all()
            critical = sum(1 for f in findings if f.severity.upper() in ("CRITICAL", "HIGH"))
            score = max(10.0, 100.0 - critical * 15)
            return FactorResult(
                factor_name=self.name, score=min(100.0, score), weight=self.default_weight,
                confidence=0.9 if findings else 0.5, coverage=1.0,
                findings=[f"{critical} critical/high vulnerabilities"],
                recommendations=["Patch critical vulnerabilities immediately"] if critical > 0 else [],
                evidence={"total_vulns": len(findings), "critical_count": critical},
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Vulnerability data unavailable"])


class ThreatIntelligenceFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "threat_intelligence"

    @property
    def default_weight(self) -> float:
        return 0.10

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.threat.models import ThreatMatch
            r = await self._db.execute(
                select(ThreatMatch).where(ThreatMatch.domain == domain)
            )
            matches = r.scalars().all()
            score = max(20.0, 100.0 - len(matches) * 10)
            return FactorResult(
                factor_name=self.name, score=min(100.0, score), weight=self.default_weight,
                confidence=0.85 if matches else 0.5, coverage=1.0,
                findings=[f"{len(matches)} threat matches"],
                recommendations=["Investigate threat matches"] if matches else [],
                evidence={"match_count": len(matches)},
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Threat data unavailable"])


class IdentityExposureFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "identity_exposure"

    @property
    def default_weight(self) -> float:
        return 0.10

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.identity_exposure.models import IdentityExposure
            r = await self._db.execute(
                select(IdentityExposure).where(IdentityExposure.domain == domain)
            )
            exposures = r.scalars().all()
            score = max(10.0, 100.0 - len(exposures) * 12)
            return FactorResult(
                factor_name=self.name, score=min(100.0, score), weight=self.default_weight,
                confidence=0.8, coverage=1.0,
                findings=[f"{len(exposures)} identity exposures"],
                recommendations=["Investigate identity exposures"] if exposures else [],
                evidence={"exposure_count": len(exposures)},
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Identity data unavailable"])


class DarkWebExposureFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "dark_web_exposure"

    @property
    def default_weight(self) -> float:
        return 0.05

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.darkweb.models import DarkWebFinding
            r = await self._db.execute(
                select(DarkWebFinding).where(DarkWebFinding.domain == domain)
            )
            findings = r.scalars().all()
            score = max(15.0, 100.0 - len(findings) * 8)
            return FactorResult(
                factor_name=self.name, score=min(100.0, score), weight=self.default_weight,
                confidence=0.7, coverage=1.0,
                findings=[f"{len(findings)} dark web findings"],
                recommendations=["Review dark web findings"] if findings else [],
                evidence={"finding_count": len(findings)},
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Dark web data unavailable"])


class AttackPathsFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "attack_paths"

    @property
    def default_weight(self) -> float:
        return 0.10

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.attack_path.models import AttackPath
            r = await self._db.execute(
                select(AttackPath).where(AttackPath.domain == domain)
            )
            paths = r.scalars().all()
            critical = sum(1 for p in paths if p.level == "CRITICAL")
            high = sum(1 for p in paths if p.level == "HIGH")
            score = max(10.0, 100.0 - critical * 20 - high * 10)
            return FactorResult(
                factor_name=self.name, score=min(100.0, score), weight=self.default_weight,
                confidence=0.85, coverage=1.0,
                findings=[f"{critical} critical paths, {high} high paths"],
                recommendations=["Remediate critical attack paths"] if critical > 0 else [],
                evidence={"path_count": len(paths), "critical": critical, "high": high},
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Attack path data unavailable"])


class BrandAbuseFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "brand_abuse"

    @property
    def default_weight(self) -> float:
        return 0.05

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.brand_protection.models import BrandDomain
            r = await self._db.execute(
                select(BrandDomain).where(BrandDomain.brand == domain)
            )
            domains = r.scalars().all()
            score = max(20.0, 100.0 - len(domains) * 5)
            return FactorResult(
                factor_name=self.name, score=min(100.0, score), weight=self.default_weight,
                confidence=0.75, coverage=1.0,
                findings=[f"{len(domains)} suspicious domains"],
                recommendations=["Investigate brand impersonation"] if domains else [],
                evidence={"suspect_count": len(domains)},
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Brand data unavailable"])


class MonitoringMaturityFactor(SecurityRatingFactor):
    @property
    def name(self) -> str:
        return "monitoring_maturity"

    @property
    def default_weight(self) -> float:
        return 0.05

    async def evaluate(self, domain: str) -> FactorResult:
        try:
            return FactorResult(
                factor_name=self.name, score=65.0, weight=self.default_weight,
                confidence=0.6, coverage=0.7,
                findings=["Monitoring maturity is moderate"],
                recommendations=["Increase monitoring frequency"],
            )
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight,
                                confidence=0.1, coverage=0.0, findings=["Monitoring data unavailable"])


DEFAULT_FACTORS: list[type[SecurityRatingFactor]] = [
    AttackSurfaceFactor, CriticalVulnerabilitiesFactor, ThreatIntelligenceFactor,
    IdentityExposureFactor, DarkWebExposureFactor, AttackPathsFactor,
    BrandAbuseFactor, MonitoringMaturityFactor,
]
