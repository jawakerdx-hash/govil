"""Benchmark profiles — local-only, no internet data."""

from __future__ import annotations

from typing import Any

BENCHMARK_PROFILES: dict[str, dict[str, Any]] = {
    "small_company": {
        "name": "Small Company", "type": "small_company",
        "attack_surface": 85, "exposure": 80, "certificates": 75,
        "threat_intelligence": 70, "identity": 75, "brand": 80,
        "monitoring": 60, "controls": 65, "expected_score": 72,
    },
    "medium_enterprise": {
        "name": "Medium Enterprise", "type": "medium_enterprise",
        "attack_surface": 75, "exposure": 70, "certificates": 80,
        "threat_intelligence": 75, "identity": 70, "brand": 75,
        "monitoring": 70, "controls": 75, "expected_score": 74,
    },
    "large_enterprise": {
        "name": "Large Enterprise", "type": "large_enterprise",
        "attack_surface": 65, "exposure": 60, "certificates": 85,
        "threat_intelligence": 80, "identity": 65, "brand": 70,
        "monitoring": 80, "controls": 80, "expected_score": 72,
    },
    "cloud_native": {
        "name": "Cloud Native", "type": "cloud_native",
        "attack_surface": 70, "exposure": 65, "certificates": 80,
        "threat_intelligence": 75, "identity": 80, "brand": 75,
        "monitoring": 85, "controls": 80, "expected_score": 76,
    },
    "financial": {
        "name": "Financial", "type": "financial",
        "attack_surface": 55, "exposure": 50, "certificates": 90,
        "threat_intelligence": 90, "identity": 85, "brand": 85,
        "monitoring": 90, "controls": 90, "expected_score": 80,
    },
    "healthcare": {
        "name": "Healthcare", "type": "healthcare",
        "attack_surface": 60, "exposure": 55, "certificates": 85,
        "threat_intelligence": 85, "identity": 90, "brand": 80,
        "monitoring": 85, "controls": 85, "expected_score": 78,
    },
    "government": {
        "name": "Government", "type": "government",
        "attack_surface": 50, "exposure": 45, "certificates": 90,
        "threat_intelligence": 90, "identity": 85, "brand": 80,
        "monitoring": 90, "controls": 90, "expected_score": 78,
    },
}


class BenchmarkEngine:
    """Compares domain ratings against local benchmark profiles."""

    def compare(
        self, domain: str, overall_score: float, factors: list[dict[str, Any]]
    ) -> dict[str, Any]:
        factor_map = {f["name"]: f["score"] for f in factors}

        comparisons = {}
        for profile_key, profile in BENCHMARK_PROFILES.items():
            diffs = {}
            for fkey in ["attack_surface", "exposure", "certificates",
                         "threat_intelligence", "identity", "brand",
                         "monitoring", "controls"]:
                actual = factor_map.get(fkey, 50.0)
                expected = profile.get(fkey, 70.0)
                diffs[fkey] = round(actual - expected, 1)
            comparisons[profile_key] = {
                "profile_name": profile["name"],
                "expected_score": profile["expected_score"],
                "actual_score": overall_score,
                "gap": round(overall_score - profile["expected_score"], 1),
                "factor_diffs": diffs,
            }

        return {
            "domain": domain,
            "overall_score": overall_score,
            "benchmarks": comparisons,
        }

    def list_profiles(self) -> list[dict[str, Any]]:
        return [
            {"key": k, "name": v["name"], "expected_score": v["expected_score"]}
            for k, v in BENCHMARK_PROFILES.items()
        ]
