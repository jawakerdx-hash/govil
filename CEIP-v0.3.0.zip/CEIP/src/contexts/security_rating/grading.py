"""Letter grade mapping — deterministic score-to-grade conversion."""

from __future__ import annotations

from typing import Any

GRADE_SCALE: list[tuple[str, int, int]] = [
    ("A+", 95, 100), ("A", 90, 94), ("A-", 85, 89),
    ("B+", 80, 84), ("B", 75, 79), ("B-", 70, 74),
    ("C+", 65, 69), ("C", 60, 64), ("C-", 55, 59),
    ("D", 40, 54), ("F", 0, 39),
]


class LetterGrader:
    """Deterministic score-to-letter-grade conversion."""

    def to_grade(self, score: float) -> dict[str, Any]:
        clamped = max(0.0, min(100.0, round(score, 1)))
        for letter, low, high in GRADE_SCALE:
            if low <= clamped <= high:
                return {
                    "score": clamped, "letter": letter,
                    "range": f"{low}-{high}",
                    "passing": letter[0] in ("A", "B"),
                    "description": _grade_description(letter),
                }
        return {"score": clamped, "letter": "F", "range": "0-39", "passing": False,
                "description": "Critical security deficiencies requiring immediate attention"}


def _grade_description(letter: str) -> str:
    return {
        "A+": "Exceptional security posture, industry-leading",
        "A": "Excellent security posture",
        "A-": "Very strong security posture, minor improvements possible",
        "B+": "Strong security posture, some gaps identified",
        "B": "Good security posture, notable areas for improvement",
        "B-": "Adequate security posture, several gaps identified",
        "C+": "Below average, multiple areas require attention",
        "C": "Below average, significant gaps in security controls",
        "C-": "Weak security posture, urgent improvements needed",
        "D": "Poor security posture, critical improvements required",
        "F": "Failing security posture, immediate remediation essential",
    }.get(letter, "No description available")
