"""Cloud Exposure factor."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class CloudExposureFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "cloud_exposure"
    @property
    def default_weight(self) -> float: return 0.04
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        return FactorResult(factor_name=self.name, score=60.0,
            weight=self.default_weight, confidence=0.3, coverage=0.1,
            findings=["Cloud exposure assessment limited"],
            recommendations=["Enable cloud asset discovery"],
            evidence={"status": "limited"})
