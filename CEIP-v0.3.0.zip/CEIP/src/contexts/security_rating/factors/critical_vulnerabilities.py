"""Critical Vulnerabilities factor."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class CriticalVulnerabilitiesFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "critical_vulnerabilities"
    @property
    def default_weight(self) -> float: return 0.15
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.vulnerability.models import SecurityFinding
            r = await self._db.execute(select(SecurityFinding).where(SecurityFinding.domain == domain))
            findings = r.scalars().all()
            critical = sum(1 for f in findings if f.severity.upper() in ("CRITICAL", "HIGH"))
            score = max(10.0, 100.0 - critical * 15)
            return FactorResult(factor_name=self.name, score=min(100.0, score),
                weight=self.default_weight, confidence=0.9 if findings else 0.5, coverage=1.0,
                findings=[f"{critical} critical/high CVEs"],
                recommendations=["Patch critical vulns"] if critical > 0 else [],
                evidence={"total": len(findings), "critical": critical})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Vulnerability data unavailable"])
