"""Internet Exposure factor."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class InternetExposureFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "internet_exposure"
    @property
    def default_weight(self) -> float: return 0.07
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(select(DiscoveryJob).where(
                DiscoveryJob.domain == domain, DiscoveryJob.status == "done").limit(1))
            job = r.scalar_one_or_none()
            public = sum(1 for s in (job.services if job else []) if hasattr(s, "host"))
            score = max(25.0, 100.0 - public * 5)
            return FactorResult(factor_name=self.name, score=min(100.0, score),
                weight=self.default_weight, confidence=0.8 if job else 0.3,
                coverage=1.0 if job else 0.0,
                findings=[f"{public} internet-facing assets"],
                recommendations=["Reduce public footprint"] if public > 8 else [],
                evidence={"public_assets": public})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Exposure data unavailable"])
