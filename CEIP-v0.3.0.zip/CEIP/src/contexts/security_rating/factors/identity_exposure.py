"""Identity Exposure factor."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class IdentityExposureFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "identity_exposure"
    @property
    def default_weight(self) -> float: return 0.08
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.identity_exposure.models import IdentityExposure
            r = await self._db.execute(select(IdentityExposure).where(IdentityExposure.domain == domain))
            exposures = r.scalars().all()
            score = max(10.0, 100.0 - len(exposures) * 12)
            return FactorResult(factor_name=self.name, score=min(100.0, score),
                weight=self.default_weight, confidence=0.8, coverage=1.0,
                findings=[f"{len(exposures)} identity exposures"],
                recommendations=["Investigate exposures"] if exposures else [],
                evidence={"count": len(exposures)})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Identity data unavailable"])
