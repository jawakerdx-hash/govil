"""Asset Coverage factor."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class AssetCoverageFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "asset_coverage"
    @property
    def default_weight(self) -> float: return 0.05
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from sqlalchemy import select

            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(select(DiscoveryJob).where(
                DiscoveryJob.domain == domain, DiscoveryJob.status == "done").limit(1))
            job = r.scalar_one_or_none()
            if job:
                svc = len(job.services) if hasattr(job, "services") else 0
                subs = len(job.subdomains) if hasattr(job, "subdomains") else 0
                return FactorResult(factor_name=self.name, score=min(100.0, (svc + subs) * 5),
                    weight=self.default_weight, confidence=0.8, coverage=1.0,
                    findings=[f"{svc} services, {subs} subdomains discovered"],
                    evidence={"services": svc, "subdomains": subs})
            return FactorResult(factor_name=self.name, score=30.0,
                weight=self.default_weight, confidence=0.3, coverage=0.0,
                findings=["No discovery data"], recommendations=["Run discovery"])
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Coverage data unavailable"])
