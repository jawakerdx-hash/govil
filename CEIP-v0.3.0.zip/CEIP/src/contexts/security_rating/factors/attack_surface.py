"""Attack Surface factor."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class AttackSurfaceFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "attack_surface"
    @property
    def default_weight(self) -> float: return 0.08
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(select(DiscoveryJob).where(DiscoveryJob.domain == domain, DiscoveryJob.status == "done").limit(1))
            job = r.scalar_one_or_none()
            svc = len(job.services) if job else 0
            score = max(30.0, 100.0 - svc * 3)
            return FactorResult(factor_name=self.name, score=min(100.0, score), weight=self.default_weight, confidence=0.8 if job else 0.3, coverage=1.0 if job else 0.0, findings=[f"{svc} exposed services"], affected_assets=[s.host for s in job.services[:5]] if job and hasattr(job, "services") else [], evidence={"services": svc})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0, weight=self.default_weight, confidence=0.1, coverage=0.0, findings=["Discovery unavailable"])
