"""Threat Intelligence factor."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class ThreatIntelligenceFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "threat_intelligence"
    @property
    def default_weight(self) -> float: return 0.08
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.threat.models import ThreatMatch
            r = await self._db.execute(select(ThreatMatch).where(ThreatMatch.domain == domain))
            matches = r.scalars().all()
            score = max(20.0, 100.0 - len(matches) * 10)
            return FactorResult(factor_name=self.name, score=min(100.0, score),
                weight=self.default_weight, confidence=0.85 if matches else 0.5, coverage=1.0,
                findings=[f"{len(matches)} threat matches"],
                recommendations=["Investigate matches"] if matches else [],
                evidence={"matches": len(matches)})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Threat data unavailable"])
