"""Patch Hygiene factor."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class PatchHygieneFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "patch_hygiene"
    @property
    def default_weight(self) -> float: return 0.05
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from sqlalchemy import select

            from src.contexts.vulnerability.models import SecurityFinding
            r = await self._db.execute(select(SecurityFinding).where(SecurityFinding.domain == domain))
            findings = r.scalars().all()
            old = sum(1 for f in findings if hasattr(f, "created_at"))
            score = max(40.0, 100.0 - old * 5)
            return FactorResult(factor_name=self.name, score=min(100.0, score),
                weight=self.default_weight, confidence=0.7, coverage=1.0,
                findings=[f"{len(findings)} vulns, {old} aged"],
                recommendations=["Establish patch SLA"] if old > 3 else [],
                evidence={"total": len(findings), "aged": old})
        except Exception:
            return FactorResult(factor_name=self.name, score=65.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Patch data unavailable"])
