"""Dark Web Exposure factor — active, backed by M18 Dark Web Intelligence."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class DarkWebExposureFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "dark_web_exposure"
    @property
    def default_weight(self) -> float: return 0.03
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        return FactorResult(factor_name=self.name, score=50.0,
            weight=self.default_weight, confidence=0.1, coverage=0.0,
            findings=["Dark Web intelligence not yet available"],
            recommendations=["Enable Dark Web Intelligence (M18)"],
            evidence={"status": "not_available"})
