"""Attack Paths factor."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class AttackPathsFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "attack_paths"
    @property
    def default_weight(self) -> float: return 0.10
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.attack_path.models import AttackPath
            r = await self._db.execute(select(AttackPath).where(AttackPath.domain == domain))
            paths = r.scalars().all()
            crit = sum(1 for p in paths if p.level == "CRITICAL")
            high = sum(1 for p in paths if p.level == "HIGH")
            score = max(10.0, 100.0 - crit * 20 - high * 10)
            return FactorResult(factor_name=self.name, score=min(100.0, score),
                weight=self.default_weight, confidence=0.85, coverage=1.0,
                findings=[f"{crit} critical, {high} high paths"],
                recommendations=["Remediate critical paths"] if crit > 0 else [],
                evidence={"paths": len(paths), "critical": crit, "high": high})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Attack path data unavailable"])
