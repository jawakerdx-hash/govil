"""DNS Health factor."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class DNSHealthFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "dns_health"
    @property
    def default_weight(self) -> float: return 0.04
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from sqlalchemy import select

            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(select(DiscoveryJob).where(
                DiscoveryJob.domain == domain, DiscoveryJob.status == "done").limit(1))
            job = r.scalar_one_or_none()
            records = len(job.dns_records) if job and hasattr(job, "dns_records") else 0
            score = max(40.0, 100.0 if records > 3 else 60.0)
            return FactorResult(factor_name=self.name, score=score,
                weight=self.default_weight, confidence=0.7 if job else 0.3,
                coverage=1.0 if job else 0.0,
                findings=[f"{records} DNS records found"],
                evidence={"dns_records": records})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["DNS data unavailable"])
