"""Security rating factor plugins."""
