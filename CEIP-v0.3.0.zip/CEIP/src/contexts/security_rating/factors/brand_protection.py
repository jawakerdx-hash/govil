"""Brand Protection factor."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..interfaces import FactorResult, SecurityRatingFactor


class BrandProtectionFactor(SecurityRatingFactor):
    @property
    def name(self) -> str: return "brand_protection"
    @property
    def default_weight(self) -> float: return 0.05
    def __init__(self, db: AsyncSession) -> None: self._db = db
    async def evaluate(self, domain: str) -> FactorResult:
        try:
            from src.contexts.brand_protection.models import BrandDomain
            r = await self._db.execute(select(BrandDomain).where(BrandDomain.brand == domain))
            domains = r.scalars().all()
            score = max(20.0, 100.0 - len(domains) * 5)
            return FactorResult(factor_name=self.name, score=min(100.0, score),
                weight=self.default_weight, confidence=0.75, coverage=1.0,
                findings=[f"{len(domains)} suspect domains"],
                recommendations=["Investigate impersonation"] if domains else [],
                evidence={"suspects": len(domains)})
        except Exception:
            return FactorResult(factor_name=self.name, score=50.0,
                weight=self.default_weight, confidence=0.1, coverage=0.0,
                findings=["Brand data unavailable"])
