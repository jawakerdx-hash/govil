"""AI Security Analyst — generates human-readable reports from structured data."""

from __future__ import annotations

from typing import Any

import httpx
import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import Settings
from src.contexts.analyst.prompts import build_analyst_prompt
from src.contexts.correlation.models import AssetCluster
from src.contexts.discovery.repository import DiscoveryRepository
from src.contexts.risk.engine import RiskEngine
from src.contexts.threat.models import ThreatMatch
from src.contexts.vulnerability.models import SecurityFinding
from src.llm.base import Message
from src.llm.glm_client import GLMClient


class AIAnalystService:
    """Generate AI-powered security analysis reports from CEIP data."""

    def __init__(
        self,
        db: AsyncSession,
        settings: Settings,
        http_client: httpx.AsyncClient,
        logger: structlog.BoundLogger | None = None,
    ) -> None:
        self._db = db
        self._settings = settings
        self._http = http_client
        self._logger = logger or structlog.get_logger()
        self._discovery_repo = DiscoveryRepository(db)

    async def analyze(self, domain: str) -> dict[str, Any]:
        """Load all data, build prompt, call LLM, return structured report."""
        domain = domain.lower().strip()

        # Load all context data
        context = await self._load_context(domain)

        if context.get("error"):
            return {"domain": domain, "report": context["error"],
                    "sections": {}, "error": context["error"]}

        # Build prompt
        prompt_text = build_analyst_prompt(context)

        # Call LLM
        llm = GLMClient(self._settings, self._http, self._logger)
        response = await llm.chat(
            [Message(role="user", content=prompt_text)],
            max_tokens=2048,
            temperature=0.3,
        )

        # Parse sections from response
        sections = self._parse_sections(response.content)

        return {
            "domain": domain,
            "report": response.content,
            "sections": sections,
            "summary": sections.get("EXECUTIVE SUMMARY", response.content[:300]),
            "model": response.model,
            "tokens": {
                "prompt": response.usage.prompt_tokens if response.usage else 0,
                "completion": response.usage.completion_tokens if response.usage else 0,
            },
        }

    # ------------------------------------------------------------------
    # Context loading
    # ------------------------------------------------------------------

    async def _load_context(self, domain: str) -> dict[str, Any]:
        """Load all structured data for a domain."""
        # Discovery
        job = await self._discovery_repo.get_latest_done(domain)

        if job is None:
            return {"error": f"No discovery data for {domain}. Run discovery first."}

        context: dict[str, Any] = {
            "discovery": {
                "dns_count": len(job.dns_records),
                "subdomain_count": len(job.subdomains),
                "service_count": len(job.services),
            },
        }

        # Vulnerability
        find_result = await self._db.execute(
            select(SecurityFinding).where(SecurityFinding.domain == domain)
        )
        findings = find_result.scalars().all()
        context["vulnerabilities"] = {
            "findings": [
                {
                    "severity": f.severity,
                    "cve_id": f.cve_id,
                    "title": f.title,
                    "affected_asset": f.affected_asset,
                }
                for f in findings
            ]
        }

        # Threats
        threat_result = await self._db.execute(
            select(ThreatMatch).where(ThreatMatch.domain == domain)
        )
        threats = threat_result.scalars().all()
        context["threats"] = {
            "matches": [
                {
                    "severity": t.severity,
                    "threat_category": t.threat_category,
                    "matched_asset": t.matched_asset,
                    "match_type": t.match_type,
                }
                for t in threats
            ]
        }

        # Correlation
        cluster_result = await self._db.execute(
            select(AssetCluster).where(AssetCluster.domain == domain)
        )
        clusters = cluster_result.scalars().all()
        context["correlation"] = {
            "clusters": [
                {
                    "name": c.name,
                    "cluster_type": c.cluster_type,
                    "member_count": c.member_count,
                }
                for c in clusters
            ]
        }

        # Risk
        risk_engine = RiskEngine(self._db)
        risk_data = await risk_engine.assess(domain)
        context["risk"] = {
            "overall_score": risk_data.get("overall_score", 0),
            "overall_risk_level": risk_data.get("overall_risk_level", "LOW"),
            "summary": risk_data.get("summary", ""),
            "top_risks": risk_data.get("top_risks", []),
        }

        # Identity Exposure
        from src.contexts.identity_exposure.repository import IdentityExposureRepository
        from src.contexts.identity_exposure.service import IdentityExposureService

        id_repo = IdentityExposureRepository(self._db)
        id_svc = IdentityExposureService(repo=id_repo)
        id_data = await id_svc.scan(domain)
        context["identity_exposure"] = {
            "total_exposures": id_data.get("total_exposures", 0),
            "emails_found": id_data.get("emails_found", 0),
            "executives_found": id_data.get("executives_found", 0),
            "admins_found": id_data.get("admins_found", 0),
            "repositories_found": id_data.get("repositories_found", 0),
            "secrets_found": id_data.get("secrets_found", 0),
            "exposure_score": id_data.get("exposure_score", 0),
            "risk_contribution": id_data.get("risk_contribution", 0),
            "top_findings": id_data.get("top_findings", []),
            "summary": id_data.get("summary", ""),
        }

        # Attack Paths
        try:
            from src.contexts.attack_path.engine import AttackPathEngine
            from src.contexts.attack_path.repository import AttackPathRepository
            from src.contexts.attack_path.service import AttackPathService

            ap_repo = AttackPathRepository(self._db)
            ap_engine = AttackPathEngine(self._db)
            ap_svc = AttackPathService(ap_repo, ap_engine)
            ap_data = await ap_svc.run(domain)
            context["attack_paths"] = {
                "path_count": ap_data.get("path_count", 0),
                "overall_exposure": ap_data.get("overall_exposure", "LOW"),
                "critical_paths": ap_data.get("critical_paths", 0),
                "crown_jewels": ap_data.get("graph_info", {}).get("crown_jewels", []),
                "blocked_paths": ap_data.get("graph_info", {}).get("blocked_paths", []),
                "controls": [
                    f"{c['name']} ({'active' if c['present'] else 'absent'})"
                    for c in ap_data.get("graph_info", {}).get("controls", [])
                ],
                "top_paths": [
                    f"[{p['level']}] {p['name']} (score={p['overall_score']:.0f})"
                    f" — jewels: {', '.join(p.get('crown_jewels_affected', []))}"
                    for p in ap_data.get("paths", [])[:3]
                ],
                "top_mitigations": ap_data.get("top_mitigations", []),
            }
        except Exception:
            context["attack_paths"] = {"path_count": 0}

        return context

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_sections(report: str) -> dict[str, str]:
        """Parse the LLM output into named sections."""
        sections: dict[str, str] = {}
        current_section = "PREAMBLE"
        current_content: list[str] = []

        for line in report.splitlines():
            if line.strip().startswith("## ") and not line.strip().startswith("### "):
                if current_content:
                    sections[current_section] = "\n".join(current_content).strip()
                current_section = line.strip().lstrip("#").strip().upper()
                current_content = []
            else:
                current_content.append(line)

        if current_content:
            sections[current_section] = "\n".join(current_content).strip()

        return sections
