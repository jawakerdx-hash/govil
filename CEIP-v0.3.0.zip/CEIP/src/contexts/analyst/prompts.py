"""Prompt template for the AI Security Analyst."""

from __future__ import annotations

from typing import Any

SYSTEM_PROMPT = """You are a Senior Cybersecurity Analyst. Your job is to analyze security data
and produce a structured report. Follow these rules strictly:

1. Use ONLY the data provided. Never invent vulnerabilities, threats, or findings.
2. If data is missing, say "Insufficient data" — never guess.
3. Be conservative. Prefer "unknown" over speculation.
4. Every claim must reference a specific finding from the data.
5. Format your response using the EXACT section headers below.

---

## EXECUTIVE SUMMARY

[2-3 sentences in plain language. What was found, risk level, why it matters.]

## TECHNICAL FINDINGS

- **Vulnerabilities:** [list each real CVE/finding with severity]
- **Exposure Points:** [list exposed services, missing headers, open ports]
- **Threat Intelligence:** [list IOC matches or state "No threat matches found"]
- **Infrastructure:** [key assets, clusters, CDN usage]

## ATTACK SCENARIO

[Step-by-step attacker path using real findings. Start from Internet, end at impact.
 Each step must reference a real finding. If no clear path exists, state why.]

## BUSINESS IMPACT

- **Data Exposure:** [based on exposed services/ports]
- **Service Downtime Risk:** [based on single points of failure]
- **Compliance Risk:** [relevant frameworks: ISO 27001, NIST CSF, PCI DSS]
- **Reputation Risk:** [based on exposure type]

## REMEDIATION PLAN

- **P0 — Fix Immediately:** [critical actions]
- **P1 — Fix Soon:** [high-priority actions]
- **P2 — Improve Later:** [medium/low improvements]

## RISK JUSTIFICATION

[Explain WHY the risk score exists. Break down vulnerability, threat, exposure,
 and importance contributions using actual data.]

---

Remember: only use the data provided below. Never invent.
"""


def build_analyst_prompt(context: dict[str, Any]) -> str:
    """Build a complete prompt from structured CEIP data."""
    parts = [SYSTEM_PROMPT, "\n---\n", "## ASSET DATA FOR ANALYSIS\n"]

    # Risk summary
    risk = context.get("risk", {})
    parts.append(f"**Overall Risk Score:** {risk.get('overall_score', 'N/A')}/100 "
                 f"({risk.get('overall_risk_level', 'N/A')})")
    parts.append(f"**Summary:** {risk.get('summary', 'N/A')}")

    # Vulnerabilities
    vulns = context.get("vulnerabilities", {}).get("findings", [])
    if vulns:
        parts.append(f"\n### Vulnerabilities ({len(vulns)} found)")
        for v in vulns:
            parts.append(
                f"- [{v.get('severity', '?').upper()}] {v.get('cve_id') or 'MISCONFIG'}: "
                f"{v.get('title', '')}"
            )
    else:
        parts.append("\n### Vulnerabilities: None found")

    # Threats
    threats = context.get("threats", {}).get("matches", [])
    if threats:
        parts.append(f"\n### Threat Intelligence ({len(threats)} matches)")
        for t in threats:
            parts.append(
                f"- [{t.get('severity', '?').upper()}] {t.get('threat_category', '?')}: "
                f"{t.get('matched_asset', '')} ({t.get('match_type', '')})"
            )
    else:
        parts.append("\n### Threat Intelligence: No matches found")

    # Assets
    discovery = context.get("discovery", {})
    if discovery:
        dns_count = discovery.get("dns_count", 0)
        sub_count = discovery.get("subdomain_count", 0)
        svc_count = discovery.get("service_count", 0)
        parts.append(
            f"\n### Infrastructure: {dns_count} DNS records, "
            f"{sub_count} subdomains, {svc_count} services"
        )

    # Clusters
    clusters = context.get("correlation", {}).get("clusters", [])
    if clusters:
        parts.append(f"\n### Infrastructure Clusters ({len(clusters)}):")
        for c in clusters:
            parts.append(f"- {c.get('name', '?')} ({c.get('cluster_type', '?')}, "
                        f"{c.get('member_count', 0)} members)")

    # Top risks
    top = risk.get("top_risks", [])
    if top:
        parts.append("\n### Top Risk Priorities:")
        for r in top:
            parts.append(f"- {r}")

    # Identity Exposure
    identity = context.get("identity_exposure", {})
    if identity.get("total_exposures", 0) > 0:
        parts.append(f"\n### Identity Exposure ({identity.get('total_exposures')} findings)")
        parts.append(f"- Exposure Score: {identity.get('exposure_score')}")
        parts.append(f"- Risk Contribution: {identity.get('risk_contribution')}")
        parts.append(f"- Emails: {identity.get('emails_found', 0)}")
        parts.append(f"- Executives: {identity.get('executives_found', 0)}")
        parts.append(f"- Admins: {identity.get('admins_found', 0)}")
        parts.append(f"- Repositories: {identity.get('repositories_found', 0)}")
        parts.append(f"- Secrets: {identity.get('secrets_found', 0)}")
        tf = identity.get("top_findings", [])
        if tf:
            parts.append("Top Identity Findings:")
            for f in tf[:3]:
                parts.append(f"  - {f}")
        parts.append(f"Summary: {identity.get('summary', '')}")
        parts.append(
            "\nThe AI Analyst report MUST include an Identity Exposure Summary section "
            "covering: executive/admin identities found, public repositories, "
            "public secrets, social engineering risk assessment, business impact, "
            "and recommended mitigations. Only report actual collected data. "
            "Never invent findings."
        )

    # Attack Paths
    ap = context.get("attack_paths", {})
    if ap.get("path_count", 0) > 0:
        parts.append(f"\n### Attack Path Analysis ({ap.get('path_count')} paths)")
        parts.append(f"- Overall Exposure: {ap.get('overall_exposure', 'LOW')}")
        parts.append(f"- Critical Paths: {ap.get('critical_paths', 0)}")
        if ap.get("top_paths"):
            parts.append("Top Attack Paths:")
            for p in ap["top_paths"]:
                parts.append(f"  - {p}")
        if ap.get("top_mitigations"):
            parts.append("Priority Mitigations:")
            for m in ap["top_mitigations"]:
                parts.append(f"  - {m}")
        parts.append(
            "\nThe AI Analyst report MUST include an Attack Path Analysis section "
            "describing the most likely attacker paths, weakest controls, and "
            "highest-impact mitigations. Only report persisted paths. Never invent."
        )

    return "\n".join(parts)
