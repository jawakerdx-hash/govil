"""Threat intelligence service — IOC matching and threat enrichment."""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.contexts.discovery.models import DiscoveryJob
from src.contexts.threat.ioc_data import IOC_DATASET
from src.contexts.threat.models import ThreatIndicator, ThreatMatch


class ThreatService:
    """Match discovered assets against known threat indicators."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def assess(self, domain: str) -> dict[str, Any]:
        """Run threat assessment against a domain's discovery data."""
        domain = domain.lower().strip()

        result = await self._db.execute(
            select(DiscoveryJob)
            .options(
                selectinload(DiscoveryJob.dns_records),
                selectinload(DiscoveryJob.ip_enrichments),
            )
            .where(
                DiscoveryJob.domain == domain,
                DiscoveryJob.status == "done",
            )
            .order_by(DiscoveryJob.created_at.desc())
            .limit(1)
        )
        job = result.scalar_one_or_none()

        if job is None:
            return {"domain": domain, "matches_count": 0,
                    "matches": [], "summary": f"No discovery data for {domain}"}

        # Ensure IOC dataset is loaded
        await self._ensure_indicators()

        matches: list[dict[str, Any]] = []

        # Collect all discoverable values
        ips: set[str] = set()
        asns: set[str] = set()

        for r in job.dns_records:
            if r.record_type in ("A", "AAAA"):
                ips.add(r.value)

        for e in job.ip_enrichments:
            if e.asn:
                asns.add(e.asn)

        # Collect discovered domains for IOC domain matching
        discovered_domains: set[str] = {domain}
        for sub in job.subdomains:
            discovered_domains.add(sub.name)

        # Match IPs, ASNs, and domains against IOC dataset
        for entry in IOC_DATASET:
            ioc_type, value, category, severity, confidence, source, desc = entry

            if ioc_type == "ip" and value in ips:
                matches.append({
                    "matched_asset": value,
                    "match_type": "exact_ip",
                    "threat_category": category,
                    "severity": severity,
                    "confidence": confidence,
                    "evidence_json": json.dumps({
                        "source": source or "IOC dataset",
                        "description": desc,
                    }),
                })

            if ioc_type == "asn" and value in asns:
                matches.append({
                    "matched_asset": value,
                    "match_type": "asn_match",
                    "threat_category": category,
                    "severity": severity,
                    "confidence": confidence,
                    "evidence_json": json.dumps({
                        "source": source or "IOC dataset",
                        "description": desc,
                    }),
                })

            if ioc_type == "domain" and value in discovered_domains:
                matches.append({
                    "matched_asset": value,
                    "match_type": "exact_domain",
                    "threat_category": category,
                    "severity": severity,
                    "confidence": confidence,
                    "evidence_json": json.dumps({
                        "source": source or "IOC dataset",
                        "description": desc,
                    }),
                })

        # Persist matches
        await self._persist(domain, job.id, matches)

        # Summary
        severity_counts = {"malicious": 0, "suspicious": 0, "clean": 0}
        for m in matches:
            sev = m["severity"]
            if sev in severity_counts:
                severity_counts[sev] += 1

        return {
            "domain": domain,
            "matches_count": len(matches),
            "malicious": severity_counts["malicious"],
            "suspicious": severity_counts["suspicious"],
            "clean": severity_counts["clean"],
            "matches": matches,
            "summary": (
                f"{len(matches)} threat matches: "
                f"{severity_counts['malicious']} malicious, "
                f"{severity_counts['suspicious']} suspicious"
            ),
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _ensure_indicators(self) -> None:
        """Load IOC dataset into the database if not already present."""
        existing = await self._db.execute(
            select(ThreatIndicator).limit(1)
        )
        if existing.scalar_one_or_none() is not None:
            return

        for entry in IOC_DATASET:
            ioc_type, value, category, severity, confidence, source, desc = entry
            self._db.add(ThreatIndicator(
                indicator_type=ioc_type,
                value=value,
                threat_category=category,
                severity=severity,
                confidence=confidence,
                source=source,
                description=desc,
            ))

        await self._db.flush()

    async def _persist(
        self,
        domain: str,
        job_id: Any,
        matches: list[dict[str, Any]],
    ) -> None:
        """Store threat matches."""
        old = await self._db.execute(
            select(ThreatMatch).where(ThreatMatch.domain == domain)
        )
        for row in old.scalars().all():
            await self._db.delete(row)

        for m in matches:
            self._db.add(ThreatMatch(
                job_id=job_id,
                domain=domain,
                matched_asset=m["matched_asset"],
                match_type=m["match_type"],
                threat_category=m.get("threat_category"),
                severity=m["severity"],
                confidence=m.get("confidence", "medium"),
                evidence_json=m.get("evidence_json"),
            ))

        await self._db.flush()
