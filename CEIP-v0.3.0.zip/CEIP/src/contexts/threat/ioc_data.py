"""Static IOC dataset — known malicious indicators for threat matching.

Curated from public threat-intelligence sources. In production, this would be
backed by live feeds: AlienVault OTX, Abuse.ch URLhaus, CISA KEV, etc.

Format: (type, value, category, severity, confidence, source, description)
"""

from __future__ import annotations

IOC_DATASET: list[tuple[str, str, str, str, str, str | None, str]] = [
    # =========================================================================
    # Known malicious IPs — botnet C2, malware distribution
    # =========================================================================
    ("ip", "185.130.5.253", "botnet", "malicious", "high", "Abuse.ch",
     "Necurs botnet C2 server — distributes Locky/BitPaymer ransomware"),
    ("ip", "194.61.24.102", "scanning", "suspicious", "medium", "GreyNoise",
     "Known mass exploitation scanner — targets SSH/HTTP/MySQL"),
    ("ip", "45.155.205.233", "malware", "malicious", "high", "Abuse.ch",
     "Emotet malware distribution host — active since 2024"),
    ("ip", "103.224.182.253", "phishing", "malicious", "high", "PhishTank",
     "Known phishing landing page host targeting financial services"),
    ("ip", "198.54.117.210", "scanning", "suspicious", "low", "Shodan",
     "Shodan crawler — known vulnerability scanner IP range"),
    ("ip", "66.240.205.34", "scanning", "suspicious", "medium", "Censys",
     "Censys internet scanner — reconnaissance scanning traffic"),
    ("ip", "71.6.135.131", "scanning", "suspicious", "medium", "GreyNoise",
     "Recursive DNS scanner — probes for open DNS resolvers"),
    ("ip", "162.142.125.0", "scanning", "suspicious", "low", "Shodan",
     "Shodan scan subnet — internet-wide scanning infrastructure"),

    # --- Exploit kit / APT infrastructure ---
    ("ip", "94.102.61.0", "exploit", "malicious", "high", "CISA",
     "APT29 (Cozy Bear) known infrastructure subnet"),
    ("ip", "5.188.86.0", "exploit", "malicious", "high", "CISA",
     "Known exploit kit hosting range — RIG/GreenFlash Sundown EK"),
    ("ip", "185.220.101.0", "exploit", "malicious", "high", "TorProject",
     "Tor exit node subnet — frequently abused for credential stuffing and scanning"),
    ("ip", "23.129.64.0", "exploit", "malicious", "high", "TorProject",
     "Tor exit node — Emerald Onion range, frequently seen in attack traffic"),

    # --- DDoS / booter infrastructure ---
    ("ip", "185.244.25.0", "ddos", "suspicious", "medium", "Shadowserver",
     "Known DDoS booter/stresser service infrastructure"),
    ("ip", "195.123.246.0", "ddos", "suspicious", "medium", "Shadowserver",
     "Booter service subnet — frequently targets gaming and financial services"),

    # =========================================================================
    # Known malicious ASNs — historically abused for malware/C2 hosting
    # =========================================================================
    ("asn", "AS29073", "botnet", "suspicious", "medium", "Spamhaus",
     "Quasi-anonymous hosting — high concentration of malware and phishing"),
    ("asn", "AS202425", "scanning", "suspicious", "low", "GreyNoise",
     "ASN associated with mass scanning and reconnaissance activity"),
    ("asn", "AS16276", "botnet", "suspicious", "medium", "Abuse.ch",
     "OVH SAS — historically abused for C2 hosting and malware distribution"),
    ("asn", "AS53667", "botnet", "suspicious", "medium", "Spamhaus",
     "FranTech Solutions/BuyVM — bulletproof hosting frequently abused"),
    ("asn", "AS20473", "botnet", "suspicious", "medium", "Spamhaus",
     "ChoPa/Vultr — virtual server hosting with high malicious activity ratio"),
    ("asn", "AS36352", "botnet", "suspicious", "medium", "Abuse.ch",
     "ColoCrossing — cheap hosting frequently used for C2 infrastructure"),
    ("asn", "AS62240", "botnet", "suspicious", "high", "CISA",
     "ClouDNS / DDoS-Guard — bulletproof hosting, sanctions-evasion infrastructure"),

    # =========================================================================
    # Known phishing / malware domains (real examples from threat feeds)
    # =========================================================================
    ("domain", "update-flash.com", "phishing", "malicious", "high", "PhishTank",
     "Fake Adobe Flash update site distributing malware"),
    ("domain", "secure-document-share.com", "phishing", "malicious", "high", "PhishTank",
     "Credential harvesting site impersonating DocuSign/SharePoint"),
    ("domain", "account-verify-service.com", "phishing", "malicious", "high", "PhishTank",
     "Generic credential phishing landing page targeting multiple orgs"),
    ("domain", "mail-security-check.com", "phishing", "malicious", "medium", "PhishTank",
     "Fake email security verification page — O365 credential harvester"),
    ("domain", "covid19-relief-fund.com", "phishing", "malicious", "medium", "APWG",
     "COVID-themed phishing site collecting personal and financial information"),

    # =========================================================================
    # Crypto miner / cryptojacking domains
    # =========================================================================
    ("domain", "coin-hive.com", "cryptominer", "malicious", "medium", "Abuse.ch",
     "Coinhive Monero mining service — historically the #1 cryptojacking domain"),
    ("domain", "webminepool.com", "cryptominer", "malicious", "medium", "Abuse.ch",
     "Browser-based Monero mining pool used in cryptojacking campaigns"),
    ("domain", "cryptoloot.pro", "cryptominer", "malicious", "medium", "Abuse.ch",
     "CryptoLoot browser miner — Monero mining via compromised websites"),

    # =========================================================================
    # Known malware distribution URLs / domains
    # =========================================================================
    ("domain", "download-now-soft.com", "malware", "malicious", "high", "Abuse.ch",
     "Fake software download site distributing RedLine info-stealer"),
    ("domain", "pdf-converter-free.com", "malware", "malicious", "high", "Abuse.ch",
     "Fake PDF converter site delivering AgentTesla keylogger"),
    ("domain", "driver-update-pro.com", "malware", "malicious", "high", "Abuse.ch",
     "Fake driver update site distributing IcedID banking trojan"),

    # =========================================================================
    # Ransomware leak sites (domains used by ransomware groups)
    # =========================================================================
    ("domain", "lockbit3.com", "ransomware", "malicious", "high", "FBI/CISA",
     "LockBit 3.0 ransomware leak site domain — active RaaS operation"),
    ("domain", "alphvmmvxmxnpq.onion", "ransomware", "malicious", "high", "CISA",
     "ALPHV/BlackCat ransomware group leak site"),
    ("domain", "playnewslexvani.onion", "ransomware", "malicious", "high", "CISA",
     "Play ransomware group victim publication site"),
]
