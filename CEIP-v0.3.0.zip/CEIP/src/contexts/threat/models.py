"""Threat intelligence ORM models — indicators and matches."""

from __future__ import annotations

import uuid

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class ThreatIndicator(UUIDMixin, Base):
    """A known threat indicator — malicious IP, domain, ASN, etc."""

    __tablename__ = "threat_indicators"

    indicator_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # ip, domain, asn, subnet
    value: Mapped[str] = mapped_column(String(512), nullable=False)
    threat_category: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # phishing, malware, scanning, botnet, exploit
    severity: Mapped[str] = mapped_column(
        String(16), nullable=False
    )  # malicious, suspicious, clean
    confidence: Mapped[str] = mapped_column(
        String(16), default="medium"
    )  # low, medium, high
    source: Mapped[str | None] = mapped_column(String(128), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)


class ThreatMatch(UUIDMixin, TimestampMixin, Base):
    """A match between a discovered asset and a known threat indicator."""

    __tablename__ = "threat_matches"

    job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("discovery_jobs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    indicator_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("threat_indicators.id", ondelete="SET NULL"), nullable=True
    )
    matched_asset: Mapped[str] = mapped_column(String(512), nullable=False)
    match_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # exact_ip, subnet, domain_suffix, asn_match
    threat_category: Mapped[str | None] = mapped_column(String(32), nullable=True)
    severity: Mapped[str] = mapped_column(String(16), nullable=False)
    confidence: Mapped[str] = mapped_column(String(16), default="medium")
    evidence_json: Mapped[str | None] = mapped_column(Text, nullable=True)
