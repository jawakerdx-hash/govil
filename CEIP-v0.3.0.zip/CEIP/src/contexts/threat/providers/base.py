"""Base Threat Intelligence Provider — enterprise connector framework.

Every provider implements: auth, rate limiting, retry, timeout, health check.
Returns structured ThreatIndicator objects — never raw strings.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ThreatIndicator:
    """Normalized threat indicator from any provider."""
    indicator_type: str  # ip, domain, url, hash, email
    value: str
    threat_category: str  # malware, phishing, botnet, scanning, exploit
    severity: str  # malicious, suspicious, clean
    confidence: float  # 0.0 - 1.0
    source: str  # provider name
    description: str = ""
    first_seen: str = ""
    last_seen: str = ""
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "indicator_type": self.indicator_type,
            "value": self.value,
            "threat_category": self.threat_category,
            "severity": self.severity,
            "confidence": self.confidence,
            "source": self.source,
            "description": self.description,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "tags": self.tags,
        }


@dataclass
class ProviderHealth:
    """Health status of a threat intelligence provider."""
    provider_name: str
    status: str = "unknown"  # healthy, degraded, down
    last_check: float = 0.0
    latency_ms: float = 0.0
    error: str | None = None
    quota_remaining: int | None = None


class BaseThreatProvider(ABC):
    """Abstract base for all threat intelligence providers.

    Subclasses implement _query_impl() — the framework handles
    rate limiting, retries, timeouts, and health tracking.
    """

    def __init__(
        self,
        name: str,
        base_url: str = "",
        api_key: str = "",
        timeout: float = 30.0,
        max_retries: int = 3,
        rate_limit_rps: float = 1.0,
    ) -> None:
        self.name = name
        self.base_url = base_url
        self._api_key = api_key
        self._timeout = timeout
        self._max_retries = max_retries
        self._rate_limit_rps = rate_limit_rps
        self._last_request: float = 0.0
        self._health = ProviderHealth(provider_name=name)

    @property
    def is_configured(self) -> bool:
        """Check if the provider has valid credentials."""
        return bool(self._api_key) or self._is_free_tier()

    def _is_free_tier(self) -> bool:
        """Override if provider works without API key."""
        return False

    @abstractmethod
    async def lookup_ip(self, ip: str) -> list[ThreatIndicator]:
        """Query threat intelligence for an IP address."""
        ...

    @abstractmethod
    async def lookup_domain(self, domain: str) -> list[ThreatIndicator]:
        """Query threat intelligence for a domain."""
        ...

    async def health_check(self) -> ProviderHealth:
        """Run a health check against the provider."""
        import asyncio
        import time as _time

        t0 = _time.perf_counter()
        try:
            result = await asyncio.wait_for(
                self.lookup_ip("8.8.8.8"), timeout=10
            )
            self._health.status = "healthy"
            self._health.error = None
        except Exception as e:
            self._health.status = "degraded"
            self._health.error = str(e)

        self._health.latency_ms = (_time.perf_counter() - t0) * 1000
        self._health.last_check = _time.time()
        return self._health

    async def _rate_limit(self) -> None:
        """Enforce rate limiting between requests."""
        import asyncio
        elapsed = time.time() - self._last_request
        min_interval = 1.0 / self._rate_limit_rps if self._rate_limit_rps > 0 else 0
        if elapsed < min_interval:
            await asyncio.sleep(min_interval - elapsed)
        self._last_request = time.time()

    async def _retry_request(
        self, coro: Any, attempt: int = 0
    ) -> Any:
        """Execute with retry logic and exponential backoff."""
        import asyncio
        import random

        try:
            await self._rate_limit()
            return await asyncio.wait_for(coro, timeout=self._timeout)
        except asyncio.TimeoutError:
            if attempt < self._max_retries:
                await asyncio.sleep(2 ** attempt + random.random())
                return await self._retry_request(coro, attempt + 1)
            raise
        except Exception:
            if attempt < self._max_retries:
                await asyncio.sleep(2 ** attempt + random.random())
                return await self._retry_request(coro, attempt + 1)
            raise
