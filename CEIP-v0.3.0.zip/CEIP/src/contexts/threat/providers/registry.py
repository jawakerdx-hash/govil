"""Threat Intelligence Provider Registry — manages multiple providers.

Supports: registration, health checks, graceful degradation.
If all providers fail, returns empty results — never fake data.
"""

from __future__ import annotations

import asyncio
from typing import Any

from .alienvault import AlienVaultOTXProvider
from .base import BaseThreatProvider, ProviderHealth, ThreatIndicator


class ThreatProviderRegistry:
    """Registry of threat intelligence providers.

    Queries all configured providers in parallel.
    Returns aggregated, deduplicated results.
    """

    def __init__(self) -> None:
        self._providers: dict[str, BaseThreatProvider] = {}

        # Register free providers by default
        self.register(AlienVaultOTXProvider())

    def register(self, provider: BaseThreatProvider) -> None:
        """Register a provider. Overwrites if same name."""
        self._providers[provider.name] = provider

    def unregister(self, name: str) -> None:
        self._providers.pop(name, None)

    def get(self, name: str) -> BaseThreatProvider | None:
        return self._providers.get(name)

    def list_providers(self) -> list[str]:
        return sorted(self._providers.keys())

    async def lookup_ip(self, ip: str) -> list[ThreatIndicator]:
        """Query all configured providers for IP intelligence."""
        tasks = []
        for name, provider in self._providers.items():
            if provider.is_configured:
                tasks.append(provider.lookup_ip(ip))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._merge([r for r in results if isinstance(r, list)])

    async def lookup_domain(self, domain: str) -> list[ThreatIndicator]:
        """Query all configured providers for domain intelligence."""
        tasks = []
        for name, provider in self._providers.items():
            if provider.is_configured:
                tasks.append(provider.lookup_domain(domain))

        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._merge([r for r in results if isinstance(r, list)])

    async def health_check_all(self) -> dict[str, ProviderHealth]:
        """Run health checks on all providers."""
        tasks = []
        for name, provider in self._providers.items():
            tasks.append(provider.health_check())

        results = await asyncio.gather(*tasks, return_exceptions=True)
        return {
            name: r for name, r in zip(self._providers.keys(), results)
            if isinstance(r, ProviderHealth)
        }

    @staticmethod
    def _merge(indicator_lists: list[list[ThreatIndicator]]) -> list[ThreatIndicator]:
        """Merge and deduplicate indicators from multiple providers."""
        seen: dict[str, ThreatIndicator] = {}
        for indicators in indicator_lists:
            for ind in indicators:
                key = f"{ind.indicator_type}:{ind.value}:{ind.threat_category}"
                if key not in seen or ind.confidence > seen[key].confidence:
                    seen[key] = ind
        return sorted(seen.values(), key=lambda i: i.confidence, reverse=True)


# Global singleton
threat_registry = ThreatProviderRegistry()
