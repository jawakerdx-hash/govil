"""AlienVault OTX (Open Threat Exchange) connector.

Free tier: No API key required for public pulse data.
Rate limit: 500 requests/day without key, higher with key.

Docs: https://otx.alienvault.com/api
"""

from __future__ import annotations

from typing import Any

import httpx

from .base import BaseThreatProvider, ThreatIndicator


class AlienVaultOTXProvider(BaseThreatProvider):
    """Real AlienVault OTX connector — queries live threat intelligence.

    Uses the free OTX Direct Connect API for IP/domain lookups.
    No API key required for basic queries.
    """

    BASE_URL = "https://otx.alienvault.com/api/v1"

    def __init__(self, api_key: str = "") -> None:
        super().__init__(
            name="alienvault_otx",
            base_url=self.BASE_URL,
            api_key=api_key,
            timeout=15.0,
            max_retries=2,
            rate_limit_rps=0.5,  # 1 request per 2 seconds
        )

    def _is_free_tier(self) -> bool:
        return True

    async def lookup_ip(self, ip: str) -> list[ThreatIndicator]:
        """Query OTX for IP reputation data."""
        indicators: list[ThreatIndicator] = []

        async def _query():
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                headers = {"Accept": "application/json"}
                if self._api_key:
                    headers["X-OTX-API-KEY"] = self._api_key

                # General IP info
                url = f"{self.BASE_URL}/indicators/IPv4/{ip}/general"
                resp = await client.get(url, headers=headers)
                return resp

        try:
            response = await self._retry_request(_query())
            if response.status_code == 200:
                data = response.json()
                # Extract pulse count as indicator of threat activity
                pulse_count = data.get("pulse_info", {}).get("count", 0)
                if pulse_count > 0:
                    pulses = data.get("pulse_info", {}).get("pulses", [])
                    tags = list({t for p in pulses[:5] for t in p.get("tags", [])})
                    indicators.append(ThreatIndicator(
                        indicator_type="ip",
                        value=ip,
                        threat_category=self._classify_tags(tags),
                        severity="malicious" if pulse_count >= 5 else "suspicious",
                        confidence=min(0.95, 0.5 + pulse_count * 0.05),
                        source="alienvault_otx",
                        description=f"{pulse_count} pulses in OTX",
                        tags=tags[:10],
                    ))

                # Also check URL list for this IP
                url_list = data.get("url_list", {}).get("url_list", [])
                if url_list:
                    indicators.append(ThreatIndicator(
                        indicator_type="ip",
                        value=ip,
                        threat_category="malware",
                        severity="suspicious",
                        confidence=0.6,
                        source="alienvault_otx",
                        description=f"{len(url_list)} URLs hosted on this IP",
                        tags=["malware_hosting"],
                    ))

        except Exception:
            # Graceful degradation — return empty on failure
            pass

        return indicators

    async def lookup_domain(self, domain: str) -> list[ThreatIndicator]:
        """Query OTX for domain reputation."""
        indicators: list[ThreatIndicator] = []

        async def _query():
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                headers = {"Accept": "application/json"}
                if self._api_key:
                    headers["X-OTX-API-KEY"] = self._api_key
                url = f"{self.BASE_URL}/indicators/domain/{domain}/general"
                resp = await client.get(url, headers=headers)
                return resp

        try:
            response = await self._retry_request(_query())
            if response.status_code == 200:
                data = response.json()
                pulse_count = data.get("pulse_info", {}).get("count", 0)
                if pulse_count > 0:
                    pulses = data.get("pulse_info", {}).get("pulses", [])
                    tags = list({t for p in pulses[:5] for t in p.get("tags", [])})
                    indicators.append(ThreatIndicator(
                        indicator_type="domain",
                        value=domain,
                        threat_category=self._classify_tags(tags),
                        severity="malicious" if pulse_count >= 3 else "suspicious",
                        confidence=min(0.9, 0.5 + pulse_count * 0.05),
                        source="alienvault_otx",
                        description=f"{pulse_count} pulses in OTX",
                        tags=tags[:10],
                    ))
        except Exception:
            pass

        return indicators

    @staticmethod
    def _classify_tags(tags: list[str]) -> str:
        """Classify threat category from OTX tags."""
        tag_str = " ".join(tags).lower()
        if any(t in tag_str for t in ("malware", "trojan", "rat", "ransomware")):
            return "malware"
        if any(t in tag_str for t in ("phishing", "credential")):
            return "phishing"
        if any(t in tag_str for t in ("botnet", "c2", "command")):
            return "botnet"
        if any(t in tag_str for t in ("exploit", "scanning")):
            return "exploit"
        return "suspicious"
