"""Pydantic schemas for threat API."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class ThreatMatchResponse(BaseModel):
    """A single threat match."""

    id: UUID
    matched_asset: str
    match_type: str
    threat_category: str | None = None
    severity: str
    confidence: str
    evidence_json: str | None = None

    model_config = {"from_attributes": True}


class ThreatResponse(BaseModel):
    """Complete threat intelligence view for a domain."""

    domain: str
    matches_count: int
    malicious: int = 0
    suspicious: int = 0
    clean: int = 0
    matches: list[ThreatMatchResponse] = []
    summary: str = ""
