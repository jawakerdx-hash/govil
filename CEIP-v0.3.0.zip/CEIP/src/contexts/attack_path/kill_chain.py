"""Kill Chain mapping — decomposes attack paths into MITRE-like stages."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

STAGES = [
    "reconnaissance", "initial_access", "execution", "persistence",
    "privilege_escalation", "credential_access", "discovery",
    "lateral_movement", "collection", "exfiltration", "impact",
]

STAGE_MAP = {
    "internet": "reconnaissance",
    "dns_record": "reconnaissance",
    "public_ip": "reconnaissance",
    "cdn_service": "reconnaissance",
    "public_repository": "reconnaissance",
    "http_service": "initial_access",
    "web_service": "initial_access",
    "admin_panel": "initial_access",
    "origin_ip": "discovery",
    "origin_server": "initial_access",
    "vulnerability": "execution",
    "exposed_secret": "credential_access",
    "identity_exposure": "credential_access",
    "infrastructure": "lateral_movement",
    "critical_asset": "impact",
    "critical_data": "exfiltration",
    "business_impact": "impact",
}


@dataclass
class KillChainStep:
    stage: str
    node: str
    asset_type: str
    evidence: str = ""


@dataclass
class KillChain:
    steps: list[KillChainStep] = field(default_factory=list)

    def covered_stages(self) -> list[str]:
        return list(dict.fromkeys(s.stage for s in self.steps))

    def missing_stages(self) -> list[str]:
        covered = set(self.covered_stages())
        return [s for s in STAGES if s not in covered]

    def summary(self) -> str:
        return " -> ".join(s.stage.replace("_", " ").title() for s in self.steps)


def map_kill_chain(nodes: list[dict[str, Any]]) -> KillChain:
    chain = KillChain()
    for n in nodes:
        atype = n.get("asset_type", "")
        stage = STAGE_MAP.get(atype, "execution")
        chain.steps.append(KillChainStep(
            stage=stage, node=n.get("asset", ""),
            asset_type=atype, evidence=n.get("evidence", "") or "",
        ))
    return chain
