"""Deterministic attack path rules — evidence-based path inference.

Every rule chains existing evidence into a possible attack path.
No hallucination. Every edge is backed by persisted CEIP data.
"""
# ruff: noqa: E501  — rule data steps are naturally long

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PathRule:
    name: str
    description: str
    steps: list[dict[str, str]]
    likelihood: float = 0.5
    impact: float = 0.5
    complexity: float = 0.5
    mitigations: list[str] = field(default_factory=list)


RULES: list[PathRule] = [
    PathRule(
        name="Internet → Public Service → Vulnerability → Critical Asset",
        description="Attacker discovers public service through DNS, exploits known vulnerability to reach critical systems.",
        likelihood=0.7, impact=0.8, complexity=0.4,
        steps=[
            {"asset_type": "internet", "role": "entry", "relationship": "exposes", "evidence_source": "discovery"},
            {"asset_type": "dns_record", "role": "entry", "relationship": "resolves_to", "evidence_source": "dns_records"},
            {"asset_type": "public_ip", "role": "intermediate", "relationship": "hosts", "evidence_source": "ip_enrichments"},
            {"asset_type": "http_service", "role": "intermediate", "relationship": "exposes", "evidence_source": "services"},
            {"asset_type": "vulnerability", "role": "intermediate", "relationship": "exploits", "evidence_source": "security_findings"},
            {"asset_type": "critical_asset", "role": "target", "relationship": "compromises", "evidence_source": "risk_scores"},
        ],
        mitigations=["Patch vulnerable services", "Implement WAF rules", "Network segmentation"],
    ),
    PathRule(
        name="Internet → Web App → Admin Panel → Identity → Business Impact",
        description="Public web application exposes admin panel; leaked credentials enable unauthorized access.",
        likelihood=0.6, impact=0.9, complexity=0.3,
        steps=[
            {"asset_type": "internet", "role": "entry", "relationship": "accesses", "evidence_source": "discovery"},
            {"asset_type": "web_service", "role": "entry", "relationship": "contains", "evidence_source": "services"},
            {"asset_type": "admin_panel", "role": "intermediate", "relationship": "authenticates", "evidence_source": "certificates"},
            {"asset_type": "identity_exposure", "role": "intermediate", "relationship": "compromises", "evidence_source": "identity_exposures"},
            {"asset_type": "business_impact", "role": "target", "relationship": "impacts", "evidence_source": "risk_scores"},
        ],
        mitigations=["Remove admin panels from public access", "Enforce MFA", "Monitor credential leaks"],
    ),
    PathRule(
        name="Internet → CDN Bypass → Origin Exposure → Server Compromise",
        description="CDN-protected asset exposes origin IP; attacker bypasses CDN to attack origin directly.",
        likelihood=0.5, impact=0.7, complexity=0.5,
        steps=[
            {"asset_type": "internet", "role": "entry", "relationship": "targets", "evidence_source": "discovery"},
            {"asset_type": "cdn_service", "role": "entry", "relationship": "proxies", "evidence_source": "services"},
            {"asset_type": "origin_ip", "role": "intermediate", "relationship": "exposes", "evidence_source": "ip_enrichments"},
            {"asset_type": "origin_server", "role": "intermediate", "relationship": "compromises", "evidence_source": "certificates"},
            {"asset_type": "infrastructure", "role": "target", "relationship": "controls", "evidence_source": "risk_scores"},
        ],
        mitigations=["Restrict origin to CDN IPs only", "Use authenticated origin pulls", "Monitor for origin exposure"],
    ),
    PathRule(
        name="Internet → Leaked Repository → Exposed Secret → Infrastructure Access",
        description="Public code repository contains secrets; attacker uses credentials to access infrastructure.",
        likelihood=0.4, impact=1.0, complexity=0.2,
        steps=[
            {"asset_type": "internet", "role": "entry", "relationship": "discovers", "evidence_source": "identity_exposures"},
            {"asset_type": "public_repository", "role": "entry", "relationship": "contains", "evidence_source": "identity_exposures"},
            {"asset_type": "exposed_secret", "role": "intermediate", "relationship": "grants", "evidence_source": "identity_exposures"},
            {"asset_type": "infrastructure", "role": "intermediate", "relationship": "accesses", "evidence_source": "ip_enrichments"},
            {"asset_type": "critical_data", "role": "target", "relationship": "exfiltrates", "evidence_source": "risk_scores"},
        ],
        mitigations=["Remove secrets from repositories", "Rotate exposed credentials", "Enable secret scanning"],
    ),
]
