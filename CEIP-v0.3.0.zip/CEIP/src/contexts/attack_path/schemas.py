"""Attack path schemas."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class NodeResponse(BaseModel):
    id: UUID
    asset: str
    asset_type: str
    role: str
    step_order: int
    evidence: str | None = None
    confidence: float
    model_config = {"from_attributes": True}


class EdgeResponse(BaseModel):
    id: UUID
    from_node: str
    to_node: str
    relationship: str
    evidence: str | None = None
    confidence: float
    model_config = {"from_attributes": True}


class PathResponse(BaseModel):
    id: UUID
    name: str
    overall_score: float
    level: str
    likelihood: float
    impact: float
    complexity: float
    exposure: float
    description: str | None = None
    mitigations: str | None = None
    nodes: list[NodeResponse] = []
    edges: list[EdgeResponse] = []
    model_config = {"from_attributes": True}


class AttackPathSummary(BaseModel):
    domain: str
    path_count: int
    overall_exposure: str
    top_score: float
    critical_paths: int
    high_paths: int
    medium_paths: int
    low_paths: int
    paths: list[PathResponse] = []
    top_mitigations: list[str] = []
