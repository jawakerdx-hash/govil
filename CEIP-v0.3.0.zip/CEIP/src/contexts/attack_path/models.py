"""Attack path ORM models."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy import Float, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class AttackPath(UUIDMixin, TimestampMixin, Base):
    """A complete attack path from internet to high-value asset."""

    __tablename__ = "attack_paths"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(512), nullable=False)
    overall_score: Mapped[float] = mapped_column(Float, default=0.0)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    likelihood: Mapped[float] = mapped_column(Float, default=0.5)
    impact: Mapped[float] = mapped_column(Float, default=0.5)
    complexity: Mapped[float] = mapped_column(Float, default=0.5)
    exposure: Mapped[float] = mapped_column(Float, default=0.5)
    level: Mapped[str] = mapped_column(String(16), default="LOW")
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    mitigations: Mapped[str | None] = mapped_column(Text, nullable=True)


class AttackNode(UUIDMixin, Base):
    """A single node in an attack path."""

    __tablename__ = "attack_nodes"

    attack_path_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    asset: Mapped[str] = mapped_column(String(512), nullable=False)
    asset_type: Mapped[str] = mapped_column(String(32), nullable=False)
    role: Mapped[str] = mapped_column(String(32), nullable=False)  # entry, intermediate, target, critical
    step_order: Mapped[int] = mapped_column(default=0)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)


class AttackEdge(UUIDMixin, Base):
    """A directed edge connecting two nodes in an attack path."""

    __tablename__ = "attack_edges"

    attack_path_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    from_node: Mapped[str] = mapped_column(String(512), nullable=False)
    to_node: Mapped[str] = mapped_column(String(512), nullable=False)
    relationship: Mapped[str] = mapped_column(String(64), nullable=False)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
