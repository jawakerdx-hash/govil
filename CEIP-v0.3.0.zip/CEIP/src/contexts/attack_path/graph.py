"""Attack Graph Builder — assembles graph from persisted assets and relationships.

Loads evidence → builds nodes → connects edges → produces traversable graph.
Reusable across path generation, ranking, and AI analyst context.
"""
# ruff: noqa: E501

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


@dataclass
class GraphNode:
    asset: str
    asset_type: str
    crown_jewel: bool = False
    criticality: str = "LOW"
    business_value: str = "LOW"
    exposure: str = "LOW"
    internet_reachable: bool = False
    evidence: list[str] = field(default_factory=list)


@dataclass
class GraphEdge:
    from_node: str
    to_node: str
    relationship: str
    reachable: bool = True
    blocked: bool = False
    requires_authentication: bool = False
    requires_existing_access: bool = False
    internet_reachable: bool = False
    confidence: float = 0.5
    blocked_by: str = ""
    evidence: list[str] = field(default_factory=list)


@dataclass
class SecurityControl:
    name: str
    present: bool = False
    effect_likelihood: float = 0.7   # multiplier (lower = better)
    effect_complexity: float = 1.2    # multiplier (higher = harder for attacker)
    effect_confidence: float = 1.1    # multiplier (higher = more confident)


@dataclass
class AttackGraph:
    domain: str
    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)
    controls: list[SecurityControl] = field(default_factory=list)
    crown_jewels: list[str] = field(default_factory=list)
    blocked_paths: list[str] = field(default_factory=list)


class GraphBuilder:
    """Builds an attack graph from persisted monitoring snapshots."""

    CROWN_JEWEL_MAP = {
        "admin_panel": ("CRITICAL", "HIGH", "HIGH"),
        "database": ("CRITICAL", "CRITICAL", "MEDIUM"),
        "identity_provider": ("HIGH", "CRITICAL", "MEDIUM"),
        "mail_server": ("MEDIUM", "MEDIUM", "MEDIUM"),
        "api": ("HIGH", "HIGH", "HIGH"),
        "vpn": ("HIGH", "HIGH", "LOW"),
        "cloud_account": ("CRITICAL", "CRITICAL", "LOW"),
        "repository": ("HIGH", "HIGH", "HIGH"),
        "secret": ("CRITICAL", "CRITICAL", "CRITICAL"),
        "public_website": ("LOW", "LOW", "HIGH"),
        "infrastructure": ("HIGH", "MEDIUM", "MEDIUM"),
        "critical_asset": ("CRITICAL", "CRITICAL", "MEDIUM"),
        "critical_data": ("CRITICAL", "CRITICAL", "LOW"),
        "business_impact": ("HIGH", "CRITICAL", "LOW"),
    }

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def build(self, domain: str) -> AttackGraph:
        evidence = await self._load_evidence(domain)
        graph = AttackGraph(domain=domain)
        graph.nodes = self._build_nodes(evidence)
        graph.edges = self._build_edges(evidence)
        graph.controls = self._detect_controls(evidence)
        graph.crown_jewels = [n.asset for n in graph.nodes if n.crown_jewel]
        graph.blocked_paths = self._find_blocked_paths(graph)
        return graph

    async def _load_evidence(self, domain: str) -> dict[str, Any]:
        evidence: dict[str, Any] = {}
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot
            for stype in ["discovery", "vulnerability", "identity"]:
                r = await self._db.execute(
                    select(MonitoringSnapshot).where(
                        MonitoringSnapshot.domain == domain,
                        MonitoringSnapshot.snapshot_type == stype,
                    ).order_by(MonitoringSnapshot.created_at.desc()).limit(1)
                )
                snap = r.scalar_one_or_none()
                if snap and isinstance(data := json.loads(snap.data_json), dict):
                    evidence[stype] = data
        except Exception:
            pass
        return evidence

    def _build_nodes(self, evidence: dict[str, Any]) -> list[GraphNode]:
        nodes: list[GraphNode] = []
        disc = evidence.get("discovery", {})
        vuln = evidence.get("vulnerability", {})
        ident = evidence.get("identity", {})

        nodes.append(GraphNode("internet", "internet", internet_reachable=True, exposure="HIGH"))
        if disc.get("dns_records"):
            nodes.append(GraphNode("dns_record", "dns_record", evidence=["DNS records found"]))
        has_public_ip = any("A:" in str(r) or "AAAA:" in str(r) for r in disc.get("dns_records", []))
        if has_public_ip:
            nodes.append(GraphNode("public_ip", "public_ip", internet_reachable=True, exposure="HIGH", evidence=["Public DNS A/AAAA records"]))
        if disc.get("services"):
            nodes.append(GraphNode("http_service", "http_service", internet_reachable=True, exposure="HIGH", evidence=disc["services"]))
        if any("cloudflare" in str(s).lower() for s in disc.get("services", [])):
            nodes.append(GraphNode("cdn_service", "cdn_service"))
        if has_public_ip:
            nodes.append(GraphNode("origin_ip", "origin_ip", evidence=["Origin potentially exposed via CDN bypass"]))
            nodes.append(GraphNode("origin_server", "origin_server"))
        if vuln.get("findings"):
            nodes.append(GraphNode("vulnerability", "vulnerability", evidence=vuln.get("findings", [])))
        if ident.get("exposures"):
            nodes.append(GraphNode("public_repository", "repository", crown_jewel=True, evidence=ident.get("exposures", [])))
            if any("secret" in str(e).lower() for e in ident.get("exposures", [])):
                nodes.append(GraphNode("exposed_secret", "secret", crown_jewel=True, criticality="CRITICAL", business_value="CRITICAL"))
        if ident.get("exposures"):
            nodes.append(GraphNode("identity_exposure", "identity_provider", crown_jewel=True))

        # Always add target nodes
        for atype, (crit, bv, exp) in self.CROWN_JEWEL_MAP.items():
            if atype in ["critical_asset", "critical_data", "business_impact", "infrastructure"]:
                nodes.append(GraphNode(atype, atype, crown_jewel=True, criticality=crit, business_value=bv, exposure=exp))

        return nodes

    def _build_edges(self, evidence: dict[str, Any]) -> list[GraphEdge]:
        edges: list[GraphEdge] = []
        disc = evidence.get("discovery", {})
        vuln = evidence.get("vulnerability", {})
        ident = evidence.get("identity", {})

        has_cdn = any("cloudflare" in str(s).lower() for s in disc.get("services", []))
        has_vuln = bool(vuln.get("findings"))
        has_secrets = any("secret" in str(e).lower() for e in ident.get("exposures", []))
        has_exposures = bool(ident.get("exposures"))

        # Rule edges with reachability
        edges.append(GraphEdge("internet", "dns_record", "exposes", internet_reachable=True))
        edges.append(GraphEdge("dns_record", "public_ip", "resolves_to", internet_reachable=True))
        edges.append(GraphEdge("public_ip", "http_service", "hosts", internet_reachable=True))
        edges.append(GraphEdge("http_service", "vulnerability", "exposes", reachable=has_vuln, blocked=not has_vuln, blocked_by="No vulnerabilities found"))
        edges.append(GraphEdge("vulnerability", "critical_asset", "exploits", reachable=has_vuln, blocked=not has_vuln))

        edges.append(GraphEdge("http_service", "admin_panel", "contains", requires_authentication=True))
        edges.append(GraphEdge("admin_panel", "identity_exposure", "authenticates", requires_authentication=True))
        edges.append(GraphEdge("identity_exposure", "business_impact", "impacts"))

        edges.append(GraphEdge("internet", "cdn_service", "targets", internet_reachable=True))
        edges.append(GraphEdge("cdn_service", "origin_ip", "proxies", blocked=not has_cdn, blocked_by="No CDN detected"))
        edges.append(GraphEdge("origin_ip", "origin_server", "exposes", reachable=has_cdn))
        edges.append(GraphEdge("origin_server", "infrastructure", "compromises"))

        edges.append(GraphEdge("internet", "public_repository", "discovers", reachable=has_exposures, blocked=not has_exposures))
        edges.append(GraphEdge("public_repository", "exposed_secret", "contains", reachable=has_secrets, blocked=not has_secrets))
        edges.append(GraphEdge("exposed_secret", "infrastructure", "grants", reachable=has_secrets))
        edges.append(GraphEdge("infrastructure", "critical_data", "exfiltrates"))

        return edges

    def _detect_controls(self, evidence: dict[str, Any]) -> list[SecurityControl]:
        disc = evidence.get("discovery", {})
        has_cdn = any("cloudflare" in str(s).lower() for s in disc.get("services", []))
        return [
            SecurityControl("Cloudflare CDN", present=has_cdn, effect_likelihood=0.6, effect_complexity=1.3),
            SecurityControl("Network Segmentation", present=False, effect_likelihood=0.5, effect_complexity=1.4),
            SecurityControl("WAF", present=has_cdn, effect_likelihood=0.7, effect_complexity=1.2),
            SecurityControl("MFA", present=False, effect_likelihood=0.5, effect_complexity=1.3),
            SecurityControl("HSTS", present=False),
            SecurityControl("CSP", present=False),
            SecurityControl("Authenticated Origin Pull", present=False),
            SecurityControl("Restricted Origin", present=False),
        ]

    def _find_blocked_paths(self, graph: AttackGraph) -> list[str]:
        blocked = []
        for edge in graph.edges:
            if edge.blocked:
                blocked.append(f"{edge.from_node} -> {edge.to_node}: blocked by '{edge.blocked_by}'")
        return blocked
