"""Attack path engine — deterministic graph traversal from persisted evidence."""
# ruff: noqa: E501

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.attack_path.graph import GraphBuilder
from src.contexts.attack_path.kill_chain import map_kill_chain
from src.contexts.attack_path.ranking import PathRanker
from src.contexts.attack_path.rules import RULES, PathRule


class AttackPathEngine:
    """Builds attack paths from graph traversal. Never scans."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def assess(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        graph = await GraphBuilder(self._db).build(domain)
        evidence = await self._gather_evidence(domain)
        paths = []

        for rule in RULES:
            applicable = self._evaluate_rule(rule, evidence, graph)
            if not applicable:
                continue
            score_info = self._compute_score(rule, evidence, graph)
            nodes_out = [
                {"asset_type": s["asset_type"], "role": s["role"], "asset": f"{s['asset_type']} ({domain})",
                 "evidence": f"Source: {s['evidence_source']}"}
                for s in rule.steps
            ]
            kill_chain = map_kill_chain(nodes_out)
            paths.append({
                "name": rule.name,
                "rule": rule,
                "nodes": nodes_out,
                "kill_chain": kill_chain,
                "score": score_info,
                "mitigations": rule.mitigations,
                "blocked": False,
            })

        ranked = PathRanker.rank(paths, graph)

        return {
            "domain": domain,
            "graph": {
                "node_count": len(graph.nodes),
                "edge_count": len(graph.edges),
                "crown_jewels": graph.crown_jewels,
                "blocked_paths": graph.blocked_paths,
                "controls": [{"name": c.name, "present": c.present} for c in graph.controls],
            },
            "paths": [
                {
                    "name": r.name, "risk_score": r.risk_score, "level": r.level,
                    "likelihood": r.likelihood, "business_impact": r.business_impact,
                    "complexity": r.complexity, "confidence": r.confidence,
                    "crown_jewels_affected": r.crown_jewels_affected,
                    "blocked": r.blocked, "blocked_reason": r.blocked_reason,
                }
                for r in ranked
            ],
            "path_count": len(ranked),
            "overall_exposure": self._overall_exposure(ranked),
            "controls": [{"name": c.name, "present": c.present} for c in graph.controls],
        }

    @staticmethod
    def _overall_exposure(ranked: list[Any]) -> str:
        for level in ["CRITICAL", "HIGH", "MEDIUM"]:
            if any(r.level == level for r in ranked):
                return level
        return "LOW"

    async def _gather_evidence(self, domain: str) -> dict[str, Any]:
        """Collect evidence from monitoring snapshots, falling back to live data.

        Priority: monitoring snapshots (historical) → live discovery/vuln data (current).
        """
        evidence: dict[str, Any] = {}

        # 1. Try monitoring snapshots first (historical baselines)
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot
            for stype in ["discovery", "vulnerability", "identity"]:
                r = await self._db.execute(
                    select(MonitoringSnapshot).where(
                        MonitoringSnapshot.domain == domain,
                        MonitoringSnapshot.snapshot_type == stype,
                    ).order_by(MonitoringSnapshot.created_at.desc()).limit(1)
                )
                snap = r.scalar_one_or_none()
                if snap and isinstance(data := json.loads(snap.data_json), dict):
                    evidence[stype] = data
        except Exception:
            pass

        # 2. Fall back: query live discovery data
        if "discovery" not in evidence:
            try:
                from src.contexts.discovery.repository import DiscoveryRepository
                repo = DiscoveryRepository(self._db)
                job = await repo.get_latest_done(domain)
                if job:
                    evidence["discovery"] = {
                        "services": [
                            f"{s.host}:{s.port}:{s.server or ''}"
                            for s in job.services
                        ],
                        "dns_records": [
                            f"{r.record_type}:{r.value}"
                            for r in job.dns_records
                        ],
                    }
            except Exception:
                pass

        # 3. Fall back: query live vulnerability data
        if "vulnerability" not in evidence:
            try:
                from src.contexts.vulnerability.models import SecurityFinding
                find_result = await self._db.execute(
                    select(SecurityFinding).where(SecurityFinding.domain == domain)
                )
                findings = find_result.scalars().all()
                if findings:
                    evidence["vulnerability"] = {
                        "findings": [
                            f"{f.severity}:{f.cve_id or f.finding_type}:{f.title or ''}"
                            for f in findings
                        ],
                    }
            except Exception:
                pass

        # 4. Fall back: query identity exposure data
        if "identity" not in evidence:
            try:
                from src.contexts.identity_exposure.models import IdentityExposure
                id_result = await self._db.execute(
                    select(IdentityExposure).where(IdentityExposure.domain == domain)
                )
                exposures = id_result.scalars().all()
                if exposures:
                    evidence["identity"] = {
                        "exposures": [
                            f"{e.severity}:{e.identity_type}:{e.value}"
                            for e in exposures
                        ],
                    }
            except Exception:
                pass

        # Extract booleans from the gathered evidence
        disc: Any = evidence.get("discovery", {})
        vuln: Any = evidence.get("vulnerability", {})
        ident: Any = evidence.get("identity", {})
        evidence["has_services"] = bool(disc.get("services")) if isinstance(disc, dict) else False
        evidence["has_vulnerabilities"] = bool(vuln.get("findings")) if isinstance(vuln, dict) else False
        evidence["has_identity_exposures"] = bool(ident.get("exposures")) if isinstance(ident, dict) else False
        evidence["has_cdn"] = any("cloudflare" in str(s).lower() for s in disc.get("services", [])) if isinstance(disc, dict) else False
        evidence["has_secrets"] = any("secret" in str(e).lower() for e in ident.get("exposures", [])) if isinstance(ident, dict) else False
        return evidence

    @staticmethod
    def _evaluate_rule(rule: PathRule, evidence: dict[str, Any], graph: Any) -> bool:
        for step in rule.steps:
            src = step["evidence_source"]
            if src in ("discovery",) and not evidence.get("has_services"):
                return False
            if src in ("security_findings",) and not evidence.get("has_vulnerabilities"):
                return False
            if src in ("identity_exposures",) and not evidence.get("has_identity_exposures"):
                return False
        return True

    @staticmethod
    def _compute_score(rule: PathRule, evidence: dict[str, Any], graph: Any) -> dict[str, Any]:
        likelihood = rule.likelihood
        impact = rule.impact
        complexity = rule.complexity
        for ctrl in graph.controls:
            if ctrl.present:
                likelihood *= ctrl.effect_likelihood
                complexity *= ctrl.effect_complexity
        if evidence.get("has_vulnerabilities"):
            likelihood = min(1.0, likelihood * 1.3)
        if evidence.get("has_secrets"):
            impact = min(1.0, impact * 1.4)
        if evidence.get("has_cdn"):
            complexity = max(0.1, complexity * 0.7)

        confidence = (likelihood + impact) / 2
        raw = (likelihood * 0.25 + impact * 0.30 + confidence * 0.20 + (1 - complexity) * 0.15 + 0.5 * 0.10) * 100
        score = min(100.0, round(raw, 1))
        level = "CRITICAL" if score >= 76 else "HIGH" if score >= 51 else "MEDIUM" if score >= 26 else "LOW"
        return {
            "score": score, "level": level, "likelihood": round(likelihood, 2),
            "impact": round(impact, 2), "complexity": round(complexity, 2),
            "confidence": round(confidence, 2), "exposure": 0.5,
        }
