"""Path ranking — separates generation from scoring, supports multi-axis ranking."""
# ruff: noqa: E501

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class RankedPath:
    name: str
    risk_score: float
    business_impact: float
    likelihood: float
    complexity: float
    confidence: float
    level: str
    crown_jewels_affected: list[str] = field(default_factory=list)
    kill_chain_stages: list[str] = field(default_factory=list)
    blocked: bool = False
    blocked_reason: str = ""


class PathRanker:
    """Ranks attack paths by multiple criteria."""

    @staticmethod
    def rank(paths: list[dict[str, Any]], graph: Any) -> list[RankedPath]:
        ranked = []
        for p in paths:
            score: dict[str, Any] = p.get("score", {})
            name = str(p.get("name", ""))
            jewels: list[str] = []
            if hasattr(graph, 'crown_jewels'):
                jewels = [
                    str(n.get("asset_type", "")) for n in p.get("nodes", [])
                    if str(n.get("asset_type", "")) in graph.crown_jewels
                ]
            rp = RankedPath(
                name=name,
                risk_score=float(score.get("score", 0)),
                business_impact=float(score.get("impact", 0.5)),
                likelihood=float(score.get("likelihood", 0.5)),
                complexity=float(score.get("complexity", 0.5)),
                confidence=float(score.get("confidence", 0.5)),
                level=str(score.get("level", "LOW")),
                crown_jewels_affected=jewels,
            )
            ranked.append(rp)
        return sorted(ranked, key=lambda r: r.risk_score, reverse=True)

    @staticmethod
    def by_confidence(paths: list[RankedPath]) -> list[RankedPath]:
        return sorted(paths, key=lambda r: r.confidence, reverse=True)

    @staticmethod
    def by_impact(paths: list[RankedPath]) -> list[RankedPath]:
        return sorted(paths, key=lambda r: r.business_impact, reverse=True)

    @staticmethod
    def by_complexity(paths: list[RankedPath]) -> list[RankedPath]:
        return sorted(paths, key=lambda r: r.complexity)
