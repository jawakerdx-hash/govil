"""Attack path service — orchestrates graph traversal, scoring, and persistence."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any

from src.contexts.attack_path.engine import AttackPathEngine
from src.contexts.attack_path.models import AttackEdge, AttackNode, AttackPath
from src.contexts.attack_path.repository import AttackPathRepository


class AttackPathService:
    def __init__(self, repo: AttackPathRepository, engine: AttackPathEngine) -> None:
        self._repo = repo
        self._engine = engine

    async def run(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        await self._repo.clear_domain(domain)
        result = await self._engine.assess(domain)

        paths_out = []
        for p in result["paths"]:
            ap = AttackPath(
                domain=domain, name=p["name"],
                description=", ".join(p.get("crown_jewels_affected", [])),
                overall_score=p["risk_score"], level=p["level"],
                likelihood=p["likelihood"], impact=p["business_impact"],
                complexity=p["complexity"], confidence=p["confidence"],
                mitigations="; ".join(p.get("mitigations", []) if isinstance(p.get("mitigations"), list) else []),
            )
            await self._repo.add_path(ap)

            nodes_out = []
            edges_out = []
            for i, n in enumerate(p.get("nodes", [])):
                node = AttackNode(
                    attack_path_id=str(ap.id), domain=domain,
                    asset=n.get("asset", ""), asset_type=n.get("asset_type", ""),
                    role=n.get("role", "intermediate"), step_order=i,
                    evidence=n.get("evidence", ""), confidence=p["confidence"],
                )
                await self._repo.add_node(node)
                nodes_out.append(node)
            for i in range(len(p.get("nodes", [])) - 1):
                edge = AttackEdge(
                    attack_path_id=str(ap.id), domain=domain,
                    from_node=p["nodes"][i]["asset_type"],
                    to_node=p["nodes"][i + 1]["asset_type"],
                    relationship=p["nodes"][i].get("relationship", "connects"),
                    evidence=f"Graph edge: {p['name']}", confidence=p["confidence"],
                )
                await self._repo.add_edge(edge)
                edges_out.append(edge)
            paths_out.append({
                "id": ap.id, "name": ap.name, "overall_score": ap.overall_score,
                "level": ap.level, "likelihood": ap.likelihood, "impact": ap.impact,
                "complexity": ap.complexity, "exposure": 0.5,
                "description": ap.description, "mitigations": ap.mitigations,
                "crown_jewels_affected": p.get("crown_jewels_affected", []),
                "blocked": p.get("blocked", False),
                "kill_chain_stages": [s.stage for s in p.get("kill_chain", [])] if p.get("kill_chain") else [],
                "nodes": [
                    {"id": n.id, "asset": n.asset, "asset_type": n.asset_type,
                     "role": n.role, "step_order": n.step_order,
                     "evidence": n.evidence, "confidence": n.confidence}
                    for n in nodes_out
                ],
                "edges": [
                    {"id": e.id, "from_node": e.from_node, "to_node": e.to_node,
                     "relationship": e.relationship, "evidence": e.evidence,
                     "confidence": e.confidence}
                    for e in edges_out
                ],
            })

        await self._repo.flush()
        score_levels: dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for p in paths_out:
            lvl = str(p.get("level", "LOW"))
            if lvl in score_levels:
                score_levels[lvl] += 1

        return {
            "domain": domain,
            "path_count": len(paths_out),
            "overall_exposure": result["overall_exposure"],
            "top_score": max((float(str(p.get("overall_score", 0))) for p in paths_out), default=0.0),
            "critical_paths": score_levels["CRITICAL"],
            "high_paths": score_levels["HIGH"],
            "medium_paths": score_levels["MEDIUM"],
            "low_paths": score_levels["LOW"],
            "paths": paths_out,
            "top_mitigations": list(dict.fromkeys(
                m for p in paths_out
                for m in (str(p.get("mitigations") or "")).split("; ") if m
            ))[:5],
            "graph_info": {
                "node_count": result.get("graph", {}).get("node_count", 0),
                "crown_jewels": result.get("graph", {}).get("crown_jewels", []),
                "blocked_paths": result.get("graph", {}).get("blocked_paths", []),
                "controls": result.get("graph", {}).get("controls", []),
            },
        }
