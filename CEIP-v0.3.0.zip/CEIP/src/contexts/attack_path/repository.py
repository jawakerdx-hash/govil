"""Repository for attack path persistence."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.attack_path.models import AttackEdge, AttackNode, AttackPath


class AttackPathRepository:
    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def clear_domain(self, domain: str) -> None:
        for model in (AttackPath, AttackNode, AttackEdge):
            rows = (await self._db.execute(select(model).where(model.domain == domain))).scalars().all()
            for row in rows:
                await self._db.delete(row)
        await self._db.flush()

    async def add_path(self, path: AttackPath) -> None:
        self._db.add(path)
        await self._db.flush()

    async def add_node(self, node: AttackNode) -> None:
        self._db.add(node)

    async def add_edge(self, edge: AttackEdge) -> None:
        self._db.add(edge)

    async def get_paths(self, domain: str) -> list[AttackPath]:
        r = await self._db.execute(
            select(AttackPath).where(AttackPath.domain == domain).order_by(AttackPath.overall_score.desc())
        )
        return list(r.scalars().all())

    async def get_nodes(self, path_id: str) -> list[AttackNode]:
        r = await self._db.execute(
            select(AttackNode).where(AttackNode.attack_path_id == path_id).order_by(AttackNode.step_order)
        )
        return list(r.scalars().all())

    async def get_edges(self, path_id: str) -> list[AttackEdge]:
        r = await self._db.execute(select(AttackEdge).where(AttackEdge.attack_path_id == path_id))
        return list(r.scalars().all())

    async def flush(self) -> None:
        await self._db.flush()
