"""Identity service — organization and user management."""

from __future__ import annotations

import bcrypt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.identity.models import Organization, User
from src.contexts.identity.schemas import OrganizationCreate, UserCreate
from src.kernel.exceptions import ConflictError, NotFoundError


class IdentityService:
    """Manage organizations and users."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    # -- Organizations --------------------------------------------------------

    async def create_org(self, dto: OrganizationCreate) -> Organization:
        """Create a new organization."""
        existing = await self._db.scalar(
            select(Organization).where(Organization.slug == dto.slug)
        )
        if existing:
            raise ConflictError(f"Organization with slug '{dto.slug}' already exists")

        org = Organization(name=dto.name, slug=dto.slug)
        self._db.add(org)
        await self._db.flush()
        return org

    async def get_org_by_slug(self, slug: str) -> Organization:
        """Fetch an organization by its slug."""
        org = await self._db.scalar(
            select(Organization).where(Organization.slug == slug)
        )
        if org is None:
            raise NotFoundError(f"Organization '{slug}' not found")
        return org

    # -- Users -----------------------------------------------------------------

    async def create_user(self, dto: UserCreate) -> User:
        """Create a user in an organization."""
        org = await self.get_org_by_slug(dto.org_slug)

        existing = await self._db.scalar(
            select(User).where(User.email == dto.email)
        )
        if existing:
            raise ConflictError(f"User with email '{dto.email}' already exists")

        hashed = bcrypt.hashpw(dto.password.encode(), bcrypt.gensalt()).decode()
        user = User(org_id=org.id, email=dto.email, hashed_password=hashed)
        self._db.add(user)
        await self._db.flush()
        return user

    async def get_user_by_email(self, email: str) -> User:
        """Fetch a user by email address."""
        user = await self._db.scalar(
            select(User).where(User.email == email)
        )
        if user is None:
            raise NotFoundError(f"User '{email}' not found")
        return user
