"""Brand protection service — orchestrates detection, classification, risk, and evidence."""

from __future__ import annotations

import json
from typing import Any

from src.contexts.brand_protection.classification import ClassificationEngine
from src.contexts.brand_protection.models import BrandCorrelation, BrandDomain, BrandEvidence
from src.contexts.brand_protection.pipeline import DetectionPipeline
from src.contexts.brand_protection.providers.base import BrandProtectionProvider
from src.contexts.brand_protection.providers.local import LocalBrandProvider
from src.contexts.brand_protection.repository import BrandRepository
from src.contexts.brand_protection.risk import BrandRiskPolicy
from src.contexts.brand_protection.similarity import brand_similarity


class BrandProtectionService:
    """Brand impersonation detection, classification, scoring, evidence.

    Pipeline: DetectionPipeline → ClassificationEngine → BrandRiskPolicy.

    Detection answers "what similarities exist?"
    Classification answers "what kind of brand abuse is this?"
    Risk policy answers "how severe is it?"
    """

    def __init__(
        self,
        repo: BrandRepository,
        provider: BrandProtectionProvider | None = None,
        pipeline: DetectionPipeline | None = None,
        classifier: ClassificationEngine | None = None,
    ) -> None:
        self._repo = repo
        self._provider = provider or LocalBrandProvider()
        self._risk_policy = BrandRiskPolicy()
        self._pipeline = pipeline or DetectionPipeline()
        self._classifier = classifier or ClassificationEngine.with_defaults()

    async def scan(self, brand: str) -> dict[str, Any]:
        """Run full detection pipeline and return scored, classified results."""
        brand = brand.lower().strip()
        await self._repo.clear_brand(brand)
        suspects = await self._provider.generate_suspects(brand)
        results: list[dict[str, Any]] = []

        for s in suspects:
            # Skip legitimate primary domains: {brand}.{tld} where similarity=1.0
            # means the domain IS just brand+TLD — not impersonation
            sim = brand_similarity(brand, s.domain)
            if sim["similarity_score"] >= 0.99 and s.domain.rstrip(".") in {
                f"{brand}.com", f"{brand}.net", f"{brand}.org", f"{brand}.io",
                f"{brand}.co", f"{brand}.me",
            }:
                continue

            if sim["similarity_score"] < 0.6:
                continue

            # ---- Phase 2: detection pipeline ----
            pipeline_results = self._pipeline.run(brand, s.domain)
            algo_results = {
                r.algorithm: {
                    "detected": r.detected,
                    "confidence": r.confidence,
                    "explanation": r.explanation,
                    "evidence": r.evidence,
                }
                for r in pipeline_results
            }
            # Backward-compatible detect_keywords call
            from src.contexts.brand_protection.algorithms import detect_keywords
            kw = detect_keywords(s.domain)

            # ---- Phase 3: classification via ClassificationEngine ----
            class_result = self._classifier.classify(
                brand, s.domain, algo_results, kw,
            )
            classification = class_result.classification

            # ---- Phase 4: risk scoring ----
            risk = self._risk_policy.assess(
                similarity_score=sim["similarity_score"],
                detection_methods=sim["detection_methods"],
                keywords=kw,
                is_idn=sim["is_idn"],
                domain_age_days=None,
                has_certificate=False,
            )

            # Map string likelihood/impact from BrandRiskPolicy to floats
            likelihood_map = {"Very High": 0.9, "High": 0.7, "Medium": 0.5, "Low": 0.3}
            impact_map = {"Severe": 0.95, "Major": 0.8, "Moderate": 0.5, "Minor": 0.3}
            likelihood_val = likelihood_map.get(
                str(risk.get("likelihood", "Low")), 0.3
            )
            impact_val = impact_map.get(
                str(risk.get("business_impact", "Minor")), 0.3
            )

            has_services = False

            # ---- Phase 5: persist BrandDomain (backward-compatible) ----
            bd = BrandDomain(
                brand=brand,
                domain=s.domain,
                similarity_score=sim["similarity_score"],
                detection_methods=",".join(sim["detection_methods"]),
                risk_level=risk["risk_level"],
                risk_score=risk["risk_score"],
                likelihood=likelihood_val,
                business_impact=impact_val,
                is_idn=sim["is_idn"],
                has_services=has_services,
            )
            await self._repo.add_domain(bd)

            # ---- Phase 6: persist evidence ----
            # Similarity evidence
            ev = BrandEvidence(
                domain_id=str(bd.id),
                evidence_type="similarity_analysis",
                title=f"Similarity: {sim['similarity_score']}",
                description="Methods: " + ", ".join(sim["detection_methods"]),
                source="brand_protection",
            )
            await self._repo.add_evidence(ev)

            # Per-algorithm evidence
            for algo_name, algo_val in algo_results.items():
                if algo_name in ("detect_keywords", "brand_similarity"):
                    continue
                ev_algo = BrandEvidence(
                    domain_id=str(bd.id),
                    evidence_type="algorithm_result",
                    title=f"{algo_name}: {_summarize(algo_val)}",
                    description=str(algo_val)[:500],
                    source=f"brand_protection.{algo_name}",
                )
                await self._repo.add_evidence(ev_algo)

            # Classification evidence with explainability
            ev_class = BrandEvidence(
                domain_id=str(bd.id),
                evidence_type="classification",
                title=f"Classification: {classification}",
                description=(
                    f"Domain {s.domain} classified as {classification} "
                    f"against brand '{brand}'. "
                    f"Confidence: {class_result.confidence:.2f}. "
                    f"Rules: {', '.join(class_result.matched_rules)}. "
                    f"Algorithms: {', '.join(class_result.algorithms_triggered)}. "
                    f"{class_result.explanation}"
                ),
                source="brand_protection.classification_engine",
            )
            await self._repo.add_evidence(ev_class)

            # ---- Phase 7: correlation ----
            if has_services:
                corr = BrandCorrelation(
                    domain_id=str(bd.id),
                    related_asset=s.domain,
                    relation_type="matches_discovered_asset",
                    confidence=0.8,
                )
                await self._repo.add_correlation(corr)

            results.append({
                "domain": s.domain,
                "similarity_score": sim["similarity_score"],
                "risk_level": risk["risk_level"],
                "risk_score": risk["risk_score"],
                "detection_methods": sim["detection_methods"],
                "classification": classification,
                "is_idn": sim["is_idn"],
                "has_services": has_services,
            })

        await self._repo.flush()

        # ---- Summary ----
        levels = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for r in results:
            lvl = r["risk_level"]
            if lvl in levels:
                levels[lvl] += 1
        avg_sim = sum(r["similarity_score"] for r in results) / max(len(results), 1)

        return {
            "brand": brand,
            "total_domains": len(results),
            "critical": levels["CRITICAL"],
            "high": levels["HIGH"],
            "medium": levels["MEDIUM"],
            "low": levels["LOW"],
            "avg_similarity": round(avg_sim, 3),
            "domains": [
                {
                    "id": bd.id,
                    "domain": bd.domain,
                    "brand": bd.brand,
                    "similarity_score": bd.similarity_score,
                    "detection_methods": bd.detection_methods,
                    "risk_level": bd.risk_level,
                    "risk_score": bd.risk_score,
                    "is_idn": bd.is_idn,
                    "has_certificate": bd.has_certificate,
                    "has_services": bd.has_services,
                    "likelihood": bd.likelihood,
                    "business_impact": bd.business_impact,
                    "classification": next(
                        (
                            r.get("classification", "")
                            for r in results
                            if r["domain"] == bd.domain
                        ),
                        "",
                    ),
                }
                for bd in (await self._repo.get_domains(brand))
            ],
            "top_methods": self._top_methods(results),
            "summary": (
                f"{len(results)} suspect domains for '{brand}': "
                f"{levels['CRITICAL']} critical, {levels['HIGH']} high, "
                f"avg similarity {avg_sim:.2f}"
            ),
        }

    @staticmethod
    def _top_methods(results: list[dict[str, Any]]) -> list[str]:
        from collections import Counter

        all_methods = [m for r in results for m in r.get("detection_methods", [])]
        return [m for m, _ in Counter(all_methods).most_common(5)]


def _summarize(value: Any) -> str:
    """Convert algorithm result to a short human-readable string."""
    if isinstance(value, bool):
        return "detected" if value else "not detected"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return ",".join(value) if value else "none"
    if isinstance(value, dict):
        return json.dumps({k: _summarize(v) for k, v in value.items()})
    return str(value)[:200]
