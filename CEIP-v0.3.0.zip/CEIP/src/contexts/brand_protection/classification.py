"""Classification engine — separates detection from classification."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ClassificationResult:
    """Output from the classification engine."""

    classification: str
    confidence: float
    matched_rules: list[str] = field(default_factory=list)
    algorithms_triggered: list[str] = field(default_factory=list)
    evidence_used: dict[str, Any] = field(default_factory=dict)
    risk_factors: dict[str, Any] = field(default_factory=dict)
    business_impact: str = "LOW"
    explanation: str = ""


class ClassificationRule(ABC):
    """Abstract rule for classifying brand abuse."""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def evaluate(
        self,
        brand: str,
        artifact: str,
        detection_results: dict[str, Any],
        keywords: dict[str, list[str]],
    ) -> ClassificationResult | None: ...


class RuleRegistry:
    """Registry of classification rules."""

    def __init__(self) -> None:
        self._rules: list[ClassificationRule] = []

    def register(self, rule: ClassificationRule) -> None:
        self._rules.append(rule)

    def list(self) -> list[str]:
        return [r.name for r in self._rules]

    def evaluate_all(
        self,
        brand: str,
        artifact: str,
        detection_results: dict[str, Any],
        keywords: dict[str, list[str]],
    ) -> list[ClassificationResult]:
        results: list[ClassificationResult] = []
        for rule in self._rules:
            r = rule.evaluate(brand, artifact, detection_results, keywords)
            if r is not None:
                results.append(r)
        return results


class ClassificationEngine:
    """Orchestrates classification rules to produce a single result."""

    def __init__(self, registry: RuleRegistry | None = None) -> None:
        self._registry = registry or RuleRegistry()

    def classify(
        self,
        brand: str,
        artifact: str,
        detection_results: dict[str, Any],
        keywords: dict[str, list[str]],
    ) -> ClassificationResult:
        matches = self._registry.evaluate_all(
            brand, artifact, detection_results, keywords
        )
        if not matches:
            return ClassificationResult(
                classification="Low_Similarity",
                confidence=0.1,
                explanation="No classification rules matched",
            )
        return max(matches, key=lambda r: r.confidence)

    @classmethod
    def with_defaults(cls) -> ClassificationEngine:
        from .classification_rules import DEFAULT_RULES

        reg = RuleRegistry()
        for r in DEFAULT_RULES:
            reg.register(r)
        return cls(reg)
