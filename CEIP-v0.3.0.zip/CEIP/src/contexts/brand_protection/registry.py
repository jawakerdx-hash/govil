"""Provider registry — pluggable brand protection data sources."""

from __future__ import annotations

from .providers.base import BrandProtectionProvider
from .providers.local import LocalBrandProvider


class ProviderRegistry:
    """Registry of brand protection providers.

    New providers (Certificate Transparency, WHOIS, Passive DNS, etc.)
    register here without changing any service logic.

    Usage::

        registry = ProviderRegistry()
        registry.register(LocalBrandProvider())
        provider = registry.get("local")
    """

    def __init__(self) -> None:
        self._providers: dict[str, BrandProtectionProvider] = {}

    def register(self, provider: BrandProtectionProvider) -> None:
        """Add a provider to the registry."""
        self._providers[provider.name] = provider

    def get(self, name: str) -> BrandProtectionProvider:
        """Return a provider by name.

        Raises:
            KeyError: If the provider is not registered.
        """
        if name not in self._providers:
            raise KeyError(
                f"Provider '{name}' not registered. "
                f"Available: {', '.join(sorted(self._providers))}"
            )
        return self._providers[name]

    def list(self) -> list[str]:
        """Return sorted list of registered provider names."""
        return sorted(self._providers)

    @classmethod
    def with_defaults(cls) -> ProviderRegistry:
        """Create a registry pre-loaded with the local provider."""
        reg = cls()
        reg.register(LocalBrandProvider())
        return reg
