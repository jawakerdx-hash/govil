"""Brand protection bounded context."""

from .algorithms.base import DetectionAlgorithm, DetectionResult
from .algorithms.implementations import ALL_ALGORITHMS
from .algorithms.registry import AlgorithmRegistry
from .brand_graph import BrandEdge, BrandGraph, BrandNode
from .classification import (
    ClassificationEngine,
    ClassificationResult,
    ClassificationRule,
    RuleRegistry,
)
from .classification_rules import DEFAULT_RULES
from .correlation import BrandCampaign, correlate_campaigns
from .models import BrandCorrelation, BrandDomain, BrandEvidence
from .pipeline import DetectionPipeline
from .providers.base import BrandProtectionProvider
from .providers.local import LocalBrandProvider
from .registry import ProviderRegistry
from .repository import BrandRepository
from .risk import BrandRiskPolicy, compute_risk
from .service import BrandProtectionService
from .similarity import brand_similarity

__all__ = [
    "ALL_ALGORITHMS",
    "AlgorithmRegistry",
    "BrandCampaign",
    "BrandCorrelation",
    "BrandDomain",
    "BrandEdge",
    "BrandEvidence",
    "BrandGraph",
    "BrandNode",
    "BrandProtectionProvider",
    "BrandProtectionService",
    "BrandRepository",
    "BrandRiskPolicy",
    "ClassificationEngine",
    "ClassificationResult",
    "ClassificationRule",
    "DEFAULT_RULES",
    "DetectionAlgorithm",
    "DetectionPipeline",
    "DetectionResult",
    "LocalBrandProvider",
    "ProviderRegistry",
    "RuleRegistry",
    "brand_similarity",
    "compute_risk",
    "correlate_campaigns",
]
