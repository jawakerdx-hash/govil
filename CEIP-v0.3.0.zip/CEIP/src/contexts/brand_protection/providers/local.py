"""Local provider — generates suspect domains from brand using deterministic rules."""

from __future__ import annotations

from src.contexts.brand_protection.providers.base import BrandProtectionProvider, SuspectDomain

TLDS = ["com", "net", "org", "io", "co", "app", "dev", "ai", "co.il", "co.uk", "de", "fr"]


class LocalBrandProvider(BrandProtectionProvider):
    @property
    def name(self) -> str:
        return "local"

    async def generate_suspects(self, brand: str) -> list[SuspectDomain]:
        brand = brand.lower().strip()
        domains: list[SuspectDomain] = []
        for tld in TLDS[:4]:
            domains.append(SuspectDomain(f"{brand}.{tld}"))
        # Typosquat variations
        variants = [
            f"{brand[:-1]}.com", f"{brand}s.com", f"{brand}1.com",
            f"{brand[0]}{brand[0]}{brand[1:]}.com", f"{brand}-{brand}.com",
            f"{brand[:len(brand)//2]}-{brand[len(brand)//2:]}.com",
            f"my{brand}.com", f"get{brand}.com", f"the{brand}.com",
            f"{brand}app.com", f"{brand}online.com", f"{brand}tech.com",
        ]
        for v in variants:
            domains.append(SuspectDomain(v))
        seen: set[str] = set()
        result: list[SuspectDomain] = []
        for d in domains:
            if d.domain not in seen:
                seen.add(d.domain)
                result.append(d)
        return result
