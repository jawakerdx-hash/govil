"""Brand protection provider abstraction."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class SuspectDomain:
    domain: str
    source: str = "generated"


class BrandProtectionProvider(ABC):
    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    async def generate_suspects(self, brand: str) -> list[SuspectDomain]: ...
