"""Campaign correlation — group related brand impersonation artifacts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class BrandCampaign:
    """A group of related impersonation artifacts."""

    campaign_name: str
    target: str
    artifacts: list[str] = field(default_factory=list)
    confidence: float = 0.5
    severity: str = "LOW"
    status: str = "open"
    related_findings: list[str] = field(default_factory=list)


def correlate_campaigns(
    findings: list[dict[str, Any]],
    threshold: float = 0.6,
) -> list[BrandCampaign]:
    """Deterministic campaign correlation — groups findings sharing targets.

    No AI. Groups findings by brand target and similar detection methods.
    """
    if not findings:
        return []

    campaigns: list[BrandCampaign] = []
    grouped: dict[str, list[dict[str, Any]]] = {}

    for f in findings:
        brand = f.get("brand", f.get("domain", "unknown"))
        grouped.setdefault(brand, []).append(f)

    for brand, items in grouped.items():
        if len(items) >= 2:
            domains = [i.get("domain", "") for i in items]
            confs = [i.get("confidence", 0.5) for i in items]
            campaigns.append(BrandCampaign(
                campaign_name=f"Campaign against {brand}",
                target=brand,
                artifacts=domains,
                confidence=round(sum(confs) / len(confs), 3),
                severity=_campaign_severity(items),
                related_findings=[str(i.get("id", "")) for i in items],
            ))

    return campaigns


def _campaign_severity(items: list[dict[str, Any]]) -> str:
    levels = [i.get("severity", "LOW") for i in items]
    for lvl in ["CRITICAL", "HIGH", "MEDIUM"]:
        if lvl in levels:
            return lvl
    return "LOW"
