"""Brand impersonation risk scoring."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any

RISK_WEIGHTS = {
    "likelihood": 0.25, "business_impact": 0.30, "confidence": 0.15,
    "similarity": 0.20, "exposure": 0.10,
}

DETECTION_MULTIPLIERS: dict[str, float] = {
    "typosquatting": 1.2, "keyboard_proximity": 1.0, "idn": 1.5,
    "homograph": 1.6, "character_substitution": 1.4, "hyphen_abuse": 0.9,
    "brand_prefix": 0.8, "brand_suffix": 0.8, "added_characters": 0.7,
    "missing_characters": 0.7, "unknown": 0.5,
}

KEYWORD_RISK_MULTIPLIERS: dict[str, float] = {
    "auth": 1.6,
    "financial": 1.5,
    "executive": 1.3,
}


# ---------------------------------------------------------------------------
# BrandRiskPolicy — configurable risk scoring with keyword intelligence
# ---------------------------------------------------------------------------


from dataclasses import dataclass  # noqa: E402


@dataclass
class RiskFactor:
    """A single factor contributing to the overall risk score."""

    name: str
    weight: float
    score: float
    contribution: float


class BrandRiskPolicy:
    """Configurable brand impersonation risk policy.

    Weights determine how much each dimension contributes to the final
    risk score.  Keyword matches, IDN usage, domain age, and certificate
    presence all influence the result through deterministic multipliers.
    """

    DEFAULT_WEIGHTS = {
        "similarity": 0.35,
        "idn": 0.20,
        "keywords": 0.25,
        "domain_age": 0.10,
        "hosting": 0.10,
    }

    def __init__(self, weights: dict[str, float] | None = None) -> None:
        self.weights = {**self.DEFAULT_WEIGHTS, **(weights or {})}

    def assess(
        self,
        similarity_score: float,
        detection_methods: list[str],
        keywords: dict[str, list[str]],
        is_idn: bool,
        domain_age_days: int | None,
        has_certificate: bool,
    ) -> dict[str, Any]:
        """Score a suspect domain and return a structured risk assessment."""
        factors: dict[str, RiskFactor] = {}
        confidence = 50.0

        # -- Similarity factor --
        sw = self.weights["similarity"]
        factors["similarity"] = RiskFactor(
            name="similarity", weight=sw,
            score=similarity_score,
            contribution=similarity_score * sw,
        )

        # -- IDN factor --
        iw = self.weights["idn"]
        idn_score = 100.0 if is_idn else 0.0
        factors["idn"] = RiskFactor(
            name="idn", weight=iw, score=idn_score,
            contribution=idn_score * iw,
        )

        # -- Keywords factor (values are lists of matched strings) --
        kw = self.weights["keywords"]
        kw_score = 0.0
        if keywords:
            total_matches = sum(len(v) for v in keywords.values())
            kw_score = min(100.0, total_matches * 20.0)
            for category, matches in keywords.items():
                if matches and category in KEYWORD_RISK_MULTIPLIERS:
                    kw_score *= KEYWORD_RISK_MULTIPLIERS[category]
        kw_score = min(kw_score, 100.0)
        factors["keywords"] = RiskFactor(
            name="keywords", weight=kw, score=kw_score,
            contribution=kw_score * kw,
        )

        # -- Domain age factor --
        dw = self.weights["domain_age"]
        if domain_age_days is not None:
            if domain_age_days < 30:
                da_score = 100.0
                confidence += 10.0
            elif domain_age_days < 90:
                da_score = 50.0
            else:
                da_score = 10.0
                confidence += 10.0
        else:
            da_score = 50.0
        factors["domain_age"] = RiskFactor(
            name="domain_age", weight=dw, score=da_score,
            contribution=da_score * dw,
        )

        # -- Hosting factor (placeholder until hosting intelligence exists) --
        hw = self.weights["hosting"]
        host_score = 50.0
        factors["hosting"] = RiskFactor(
            name="hosting", weight=hw, score=host_score,
            contribution=host_score * hw,
        )

        # -- Compute base risk from weighted factors --
        risk_score = sum(f.contribution for f in factors.values())

        # -- Modifiers --
        if is_idn:
            risk_score *= 1.5
        if has_certificate:
            confidence += 15.0

        risk_score = min(100.0, round(risk_score, 1))
        confidence = min(100.0, round(confidence, 1))

        # -- Level --
        if risk_score >= 76:
            level, likelihood, biz_impact = "CRITICAL", "Very High", "Severe"
        elif risk_score >= 51:
            level, likelihood, biz_impact = "HIGH", "High", "Major"
        elif risk_score >= 26:
            level, likelihood, biz_impact = "MEDIUM", "Medium", "Moderate"
        else:
            level, likelihood, biz_impact = "LOW", "Low", "Minor"

        return {
            "risk_score": risk_score,
            "risk_level": level,
            "likelihood": likelihood,
            "business_impact": biz_impact,
            "confidence": confidence,
            "factors": {k: vars(f) for k, f in factors.items()},
        }


def compute_risk(similarity: dict[str, Any], services: bool = False, certificate: bool = False) -> dict[str, Any]:
    methods = similarity.get("detection_methods", [])
    method_mult = max((DETECTION_MULTIPLIERS.get(m, 0.5) for m in methods), default=0.5)
    sim_score = similarity.get("similarity_score", 0)
    likelihood = min(1.0, sim_score * method_mult)
    business_impact = 0.5
    if sim_score > 0.9:
        business_impact = 0.8
    if services:
        business_impact = min(1.0, business_impact * 1.4)
    if certificate:
        business_impact = min(1.0, business_impact * 1.2)
    confidence = min(1.0, sim_score * 0.8 + 0.2)
    exposure = 0.5 if services else 0.3
    raw = (
        likelihood * 0.25 + business_impact * 0.30 + confidence * 0.15 +
        sim_score * 0.20 + exposure * 0.10
    ) * 100
    score = min(100.0, round(raw, 1))
    level = "CRITICAL" if score >= 76 else "HIGH" if score >= 51 else "MEDIUM" if score >= 26 else "LOW"
    return {
        "risk_score": score, "risk_level": level,
        "likelihood": round(likelihood, 2), "business_impact": round(business_impact, 2),
        "confidence": round(confidence, 2), "exposure": round(exposure, 2),
    }
