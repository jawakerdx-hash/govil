"""Brand protection schemas."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel, Field


class BrandScanRequest(BaseModel):
    brand: str = Field(min_length=2, max_length=255)


class DomainResponse(BaseModel):
    id: UUID
    domain: str
    brand: str
    similarity_score: float
    detection_methods: str
    risk_level: str
    risk_score: float
    is_idn: bool
    has_certificate: bool
    has_services: bool
    likelihood: float
    business_impact: float
    model_config = {"from_attributes": True}


class BrandSummary(BaseModel):
    brand: str
    total_domains: int
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    avg_similarity: float = 0.0
    domains: list[DomainResponse] = []
    top_methods: list[str] = []
    summary: str = ""
