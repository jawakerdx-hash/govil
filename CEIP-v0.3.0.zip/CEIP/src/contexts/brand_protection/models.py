"""Brand protection ORM models."""
# ruff: noqa: E501

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class BrandDomain(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "brand_domains"
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    brand: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    similarity_score: Mapped[float] = mapped_column(Float, default=0.0)
    detection_methods: Mapped[str] = mapped_column(String(255), default="")
    risk_level: Mapped[str] = mapped_column(String(16), default="LOW")
    risk_score: Mapped[float] = mapped_column(Float, default=0.0)
    likelihood: Mapped[float] = mapped_column(Float, default=0.5)
    business_impact: Mapped[float] = mapped_column(Float, default=0.5)
    is_idn: Mapped[bool] = mapped_column(Boolean, default=False)
    has_certificate: Mapped[bool] = mapped_column(Boolean, default=False)
    has_services: Mapped[bool] = mapped_column(Boolean, default=False)
    registration_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    registrar: Mapped[str | None] = mapped_column(String(255), nullable=True)
    hosting_ip: Mapped[str | None] = mapped_column(String(45), nullable=True)
    nameservers: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")


class BrandEvidence(UUIDMixin, Base):
    __tablename__ = "brand_evidence"
    domain_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    evidence_type: Mapped[str] = mapped_column(String(32), nullable=False)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str] = mapped_column(String(128), default="brand_protection")
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now())


class BrandCorrelation(UUIDMixin, Base):
    __tablename__ = "brand_correlations"
    domain_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    related_asset: Mapped[str] = mapped_column(String(512), nullable=False)
    relation_type: Mapped[str] = mapped_column(String(32), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)


class BrandTarget(UUIDMixin, TimestampMixin, Base):
    """A brand being monitored for impersonation."""

    __tablename__ = "brand_targets"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    org_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    severity: Mapped[str] = mapped_column(String(16), nullable=False, default="LOW")
    first_seen: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_scanned: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="active")
    provider: Mapped[str] = mapped_column(String(64), nullable=False, default="local")
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class BrandFinding(UUIDMixin, TimestampMixin, Base):
    """A single impersonation finding for a brand target."""

    __tablename__ = "brand_findings"

    target_id: Mapped[str] = mapped_column(String(36), ForeignKey("brand_targets.id"), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    candidate_domain: Mapped[str] = mapped_column(String(255), nullable=False)
    algorithm: Mapped[str] = mapped_column(String(64), nullable=False)
    classification: Mapped[str] = mapped_column(String(32), nullable=False, default="Suspicious_Registration")
    similarity_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    confidence: Mapped[float] = mapped_column(Float, nullable=False, default=0.5)
    severity: Mapped[str] = mapped_column(String(16), nullable=False, default="LOW")
    risk_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    detection_methods: Mapped[str | None] = mapped_column(Text, nullable=True)
    evidence_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    provider: Mapped[str] = mapped_column(String(64), nullable=False, default="local")
    first_seen: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_seen: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="active")
