"""Similarity engine — deterministic algorithms for domain impersonation detection.

All scores reproducible. No AI.
"""
# ruff: noqa: E501

from __future__ import annotations

import unicodedata
from typing import Any

# Character substitution table (visual lookalikes)
HOMOGRAPH_TABLE = str.maketrans({
    'a': '4', 'e': '3', 'i': '1', 'o': '0', 's': '5', 'l': '1',
    'b': '8', 'g': '9', 't': '7', 'z': '2',
})

# Keyboard adjacency (QWERTY)
KEYBOARD_NEIGHBORS: dict[str, list[str]] = {
    'a': ['q', 'w', 's', 'z'], 'b': ['v', 'g', 'h', 'n'], 'c': ['x', 'd', 'f', 'v'],
    'd': ['s', 'e', 'r', 'f', 'c', 'x'], 'e': ['w', 's', 'd', 'r', 'f'],
    'f': ['d', 'r', 't', 'g', 'v', 'c'], 'g': ['f', 't', 'y', 'h', 'b', 'v'],
    'h': ['g', 'y', 'u', 'j', 'n', 'b'], 'i': ['u', 'j', 'k', 'o', '9', '8'],
    'j': ['h', 'u', 'i', 'k', 'm', 'n'], 'k': ['j', 'i', 'o', 'l', 'm'],
    'l': ['k', 'o', 'p', ';'], 'm': ['n', 'j', 'k', 'l'], 'n': ['b', 'h', 'j', 'm'],
    'o': ['i', 'k', 'l', 'p', '0', '9'], 'p': ['o', 'l', ';', '[', '-', '0'],
    'q': ['w', 'a', 's'], 'r': ['e', 'd', 'f', 't', '5', '4'],
    's': ['a', 'w', 'e', 'd', 'x', 'z'], 't': ['r', 'f', 'g', 'y', '6', '5'],
    'u': ['y', 'j', 'i', 'k', '8', '7'], 'v': ['c', 'f', 'g', 'b'],
    'w': ['q', 'a', 's', 'e', '3', '2'], 'x': ['z', 's', 'd', 'c'],
    'y': ['t', 'g', 'h', 'u', '7', '6'], 'z': ['a', 's', 'x'],
    '0': ['o', 'p', '-', '9'], '1': ['q', '2'], '2': ['1', 'q', 'w', '3'],
    '3': ['2', 'w', 'e', '4'], '4': ['3', 'e', 'r', '5'], '5': ['4', 'r', 't', '6'],
    '6': ['5', 't', 'y', '7'], '7': ['6', 'y', 'u', '8'], '8': ['7', 'u', 'i', '9'],
    '9': ['8', 'i', 'o', '0'], '-': ['0', 'p', '='],
}


def levenshtein(s1: str, s2: str) -> int:
    if len(s1) < len(s2):
        return levenshtein(s2, s1)
    if len(s2) == 0:
        return len(s1)
    prev = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        curr = [i + 1]
        for j, c2 in enumerate(s2):
            cost = 0 if c1 == c2 else 1
            curr.append(min(curr[j] + 1, prev[j + 1] + 1, prev[j] + cost))
        prev = curr
    return prev[-1]


def normalized_similarity(s1: str, s2: str) -> float:
    dist = levenshtein(s1, s2)
    return 1.0 - (dist / max(len(s1), len(s2), 1))


def keyboard_adjacency_score(s1: str, s2: str) -> float:
    if len(s1) != len(s2):
        return 0.0
    matches: float = 0.0
    for c1, c2 in zip(s1, s2, strict=False):
        if c1 == c2:
            matches += 1.0
        elif c2 in KEYBOARD_NEIGHBORS.get(c1, []):
            matches += 0.6
    return matches / max(len(s1), 1)


def homograph_normalize(text: str) -> str:
    normalized = unicodedata.normalize('NFKC', text)
    return normalized


def is_idn(domain: str) -> bool:
    try:
        domain.encode('ascii')
        return False
    except UnicodeEncodeError:
        return True


def brand_similarity(brand: str, domain: str) -> dict[str, Any]:
    brand_lower = brand.lower()
    domain_clean = domain.lower().split('.')[0] if '.' in domain else domain.lower()

    lev_sim = round(normalized_similarity(brand_lower, domain_clean), 3)
    kb_score = round(keyboard_adjacency_score(brand_lower, domain_clean), 3)
    is_idn_val = is_idn(domain)
    has_hyphen = '-' in domain
    has_prefix = domain_clean.startswith(brand_lower) and domain_clean != brand_lower
    has_suffix = domain_clean.endswith(brand_lower) and domain_clean != brand_lower
    homograph_detected = homograph_normalize(domain) != domain
    char_sub = brand_lower.translate(HOMOGRAPH_TABLE) == domain_clean.translate(HOMOGRAPH_TABLE)

    detection_methods = []
    if lev_sim > 0.85 and lev_sim < 1.0:
        detection_methods.append("typosquatting")
    if kb_score > 0.5:
        detection_methods.append("keyboard_proximity")
    if is_idn_val:
        detection_methods.append("idn")
    if homograph_detected:
        detection_methods.append("homograph")
    if char_sub:
        detection_methods.append("character_substitution")
    if has_hyphen:
        detection_methods.append("hyphen_abuse")
    if has_prefix:
        detection_methods.append("brand_prefix")
    if has_suffix:
        detection_methods.append("brand_suffix")
    if domain_clean in (brand_lower + 's', brand_lower + 'ing', brand_lower + 'ed'):
        detection_methods.append("added_characters")
    if brand_lower.startswith(domain_clean) and len(brand_lower) - len(domain_clean) == 1:
        detection_methods.append("missing_characters")

    similarity_score = max(lev_sim, kb_score)
    if char_sub or homograph_detected:
        similarity_score = max(similarity_score, 0.95)

    return {
        "brand": brand, "domain": domain, "domain_clean": domain_clean,
        "levenshtein_similarity": lev_sim,
        "keyboard_adjacency": kb_score,
        "similarity_score": round(similarity_score, 3),
        "detection_methods": detection_methods or ["unknown"],
        "is_idn": is_idn_val, "has_hyphen": has_hyphen,
        "homograph_detected": homograph_detected,
        "char_substitution": char_sub,
    }
