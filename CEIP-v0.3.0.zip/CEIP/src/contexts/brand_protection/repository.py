"""Brand protection repository."""
# ruff: noqa: E501

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.brand_protection.models import BrandCorrelation, BrandDomain, BrandEvidence


class BrandRepository:
    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def clear_brand(self, brand: str) -> None:
        domains = (await self._db.execute(
            select(BrandDomain).where(BrandDomain.brand == brand)
        )).scalars().all()
        for d in domains:
            for ev in (await self._db.execute(
                select(BrandEvidence).where(BrandEvidence.domain_id == str(d.id))
            )).scalars().all():
                await self._db.delete(ev)
            for corr in (await self._db.execute(
                select(BrandCorrelation).where(BrandCorrelation.domain_id == str(d.id))
            )).scalars().all():
                await self._db.delete(corr)
            await self._db.delete(d)
        await self._db.flush()

    async def add_domain(self, d: BrandDomain) -> None:
        self._db.add(d)
        await self._db.flush()

    async def add_evidence(self, e: BrandEvidence) -> None:
        self._db.add(e)

    async def add_correlation(self, c: BrandCorrelation) -> None:
        self._db.add(c)

    async def get_domains(self, brand: str) -> list[BrandDomain]:
        r = await self._db.execute(
            select(BrandDomain).where(BrandDomain.brand == brand).order_by(BrandDomain.risk_score.desc())
        )
        return list(r.scalars().all())

    async def flush(self) -> None:
        await self._db.flush()
