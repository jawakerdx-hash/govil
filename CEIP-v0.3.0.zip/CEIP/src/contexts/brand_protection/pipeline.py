"""Detection pipeline — runs all algorithms and aggregates results."""

from __future__ import annotations

from typing import Any

from .algorithms.base import DetectionResult
from .algorithms.registry import AlgorithmRegistry


class DetectionPipeline:
    """Orchestrates detection algorithms via AlgorithmRegistry.

    BrandService uses this pipeline instead of calling algorithms directly.
    """

    def __init__(self, registry: AlgorithmRegistry | None = None) -> None:
        self._registry = registry or AlgorithmRegistry.with_defaults()

    def run(self, brand: str, artifact: str) -> list[DetectionResult]:
        """Run all registered algorithms against a brand/artifact pair."""
        return self._registry.detect_all(brand, artifact)

    def aggregate(self, results: list[DetectionResult]) -> dict[str, Any]:
        """Aggregate detection results into summary statistics."""
        detected = [r for r in results if r.detected]
        confs = [r.confidence for r in detected] if detected else [0.0]
        return {
            "total_algorithms": len(results),
            "algorithms_detected": len(detected),
            "detected_names": [r.algorithm for r in detected],
            "avg_confidence": round(sum(confs) / len(confs), 3) if confs else 0.0,
            "max_confidence": round(max(confs), 3) if confs else 0.0,
            "results": results,
        }

    @property
    def algorithm_count(self) -> int:
        return len(self._registry.list())
