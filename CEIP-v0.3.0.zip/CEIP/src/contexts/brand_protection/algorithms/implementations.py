"""Detection algorithm implementations — 11 deterministic algorithms."""

from __future__ import annotations

import unicodedata

from ..similarity import KEYBOARD_NEIGHBORS, normalized_similarity
from .base import DetectionAlgorithm, DetectionResult

EXECUTIVE = ["ceo", "cto", "cfo", "admin", "root", "owner", "founder", "executive"]
AUTH = ["login", "signin", "auth", "password", "otp", "verify", "credential"]
AUTH.extend(["2fa", "mfa", "secure", "token"])
FINANCIAL = ["pay", "payment", "invoice", "billing", "bank", "wallet", "transfer"]
FINANCIAL.extend(["checkout", "donate", "refund", "subscription"])


def _get_base(domain: str) -> str:
    d = domain.lower().split("/")[0]
    if d.startswith("www."):
        d = d[4:]
    parts = d.split(".")
    if len(parts) > 1:
        return parts[-2]
    return parts[0]


def _jw(s1: str, s2: str) -> float:
    if not s1 or not s2:
        return 0.0
    if s1 == s2:
        return 1.0
    len1, len2 = len(s1), len(s2)
    max_dist = max(len1, len2) // 2 - 1
    if max_dist < 0:
        max_dist = 0
    s1_matches = [False] * len1
    s2_matches = [False] * len2
    matches = 0
    for i in range(len1):
        start = max(0, i - max_dist)
        end = min(i + max_dist + 1, len2)
        for j in range(start, end):
            if s2_matches[j] or s1[i] != s2[j]:
                continue
            s1_matches[i] = s2_matches[j] = True
            matches += 1
            break
    if matches == 0:
        return 0.0
    transpositions = k = 0
    for i in range(len1):
        if not s1_matches[i]:
            continue
        while not s2_matches[k]:
            k += 1
        if s1[i] != s2[k]:
            transpositions += 1
        k += 1
    transpositions //= 2
    jaro = (matches / len1 + matches / len2 + (matches - transpositions) / matches) / 3
    prefix = 0
    for i in range(min(len1, len2, 4)):
        if s1[i] == s2[i]:
            prefix += 1
        else:
            break
    return jaro + prefix * 0.1 * (1 - jaro)


class LevenshteinAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "levenshtein"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        score = normalized_similarity(b, a)
        return DetectionResult(
            algorithm=self.name, detected=score > 0.85, confidence=score,
            evidence={"brand_base": b, "artifact_base": a, "similarity": score},
            explanation=f"Levenshtein similarity '{b}' vs '{a}': {score:.4f}",
        )


class JaroWinklerAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "jaro_winkler"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        score = _jw(b, a)
        return DetectionResult(
            algorithm=self.name, detected=score > 0.85, confidence=score,
            evidence={"brand_base": b, "artifact_base": a, "jw_score": score},
            explanation=f"Jaro-Winkler '{b}' vs '{a}': {score:.4f}",
        )


class HomographAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "homograph"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        a = _get_base(artifact)
        normalized = unicodedata.normalize("NFKC", a)
        detected = normalized != a
        return DetectionResult(
            algorithm=self.name, detected=detected, confidence=1.0 if detected else 0.0,
            evidence={"original": a, "normalized": normalized},
            explanation=(
                f"Homograph: '{a}' normalizes to '{normalized}'"
                if detected else "No homograph detected"
            ),
        )


class KeyboardAdjacencyAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "keyboard_adjacency"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        subs = 0
        if len(b) == len(a):
            for c1, c2 in zip(b, a, strict=False):
                if c1 != c2 and c2 in KEYBOARD_NEIGHBORS.get(c1, []):
                    subs += 1
        detected = subs >= 2
        return DetectionResult(
            algorithm=self.name, detected=detected,
            confidence=subs / len(b) if len(b) > 0 else 0.0,
            evidence={"brand_base": b, "artifact_base": a, "substitutions": subs},
            explanation=f"Keyboard adjacency: {subs} substitutions between '{b}' and '{a}'",
        )


class CharacterOmissionAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "character_omission"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        idx = -1
        for i in range(len(b)):
            if b[:i] + b[i + 1 :] == a:
                idx = i
                break
        return DetectionResult(
            algorithm=self.name, detected=idx != -1, confidence=1.0 if idx != -1 else 0.0,
            evidence={"brand_base": b, "artifact_base": a, "omitted_index": idx},
            explanation=(
                f"Character omission: removing '{b[idx]}' at {idx} from '{b}' = '{a}'"
                if idx != -1 else "No character omission match"
            ),
        )


class CharacterDuplicationAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "character_duplication"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        idx = -1
        for i in range(len(b)):
            if b[: i + 1] + b[i + 1 :] == a:
                idx = i
                break
        return DetectionResult(
            algorithm=self.name, detected=idx != -1, confidence=1.0 if idx != -1 else 0.0,
            evidence={"brand_base": b, "artifact_base": a, "dup_index": idx},
            explanation=(
                f"Character duplication: dup '{b[idx]}' at {idx} in '{b}' = '{a}'"
                if idx != -1 else "No character duplication match"
            ),
        )


class CharacterTranspositionAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "character_transposition"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        idx = -1
        if len(b) == len(a) and len(b) >= 2:
            for i in range(len(b) - 1):
                if b[:i] + b[i + 1] + b[i] + b[i + 2 :] == a:
                    idx = i
                    break
        return DetectionResult(
            algorithm=self.name, detected=idx != -1, confidence=1.0 if idx != -1 else 0.0,
            evidence={"brand_base": b, "artifact_base": a, "swap_index": idx},
            explanation=(
                f"Transposition: swap {idx},{idx + 1} in '{b}' = '{a}'"
                if idx != -1 else "No transposition match"
            ),
        )


class PrefixAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "prefix"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        prefixes = ["secure", "my", "get", "the", "login", "www", "portal", "api"]
        matched = None
        for p in prefixes:
            if a.startswith(p) and a[len(p) :] == b:
                matched = p
                break
        return DetectionResult(
            algorithm=self.name, detected=matched is not None,
            confidence=1.0 if matched else 0.0,
            evidence={"brand_base": b, "artifact_base": a, "prefix": matched},
            explanation=(
                f"Prefix '{matched}' + '{b}' = '{a}'"
                if matched else "No prefix match"
            ),
        )


class SuffixAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "suffix"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b, a = _get_base(brand), _get_base(artifact)
        suffixes = ["login", "app", "online", "tech", "security", "support"]
        matched = None
        for s in suffixes:
            if a.endswith(s) and a[: -len(s)] == b:
                matched = s
                break
        return DetectionResult(
            algorithm=self.name, detected=matched is not None,
            confidence=1.0 if matched else 0.0,
            evidence={"brand_base": b, "artifact_base": a, "suffix": matched},
            explanation=(
                f"Suffix '{b}' + '{matched}' = '{a}'"
                if matched else "No suffix match"
            ),
        )


class HyphenAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "hyphen"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        a = _get_base(artifact)
        count = a.count("-")
        return DetectionResult(
            algorithm=self.name, detected=count > 0,
            confidence=min(count / 3.0, 1.0),
            evidence={"artifact_base": a, "hyphen_count": count},
            explanation=(
                f"Hyphen abuse: {count} hyphens in '{a}'"
                if count > 0 else "No hyphens"
            ),
        )


class SubdomainAlgorithm(DetectionAlgorithm):
    @property
    def name(self) -> str:
        return "subdomain"

    def detect(self, brand: str, artifact: str) -> DetectionResult:
        b = _get_base(brand)
        d = artifact.lower().split("/")[0]
        if d.startswith("www."):
            d = d[4:]
        parts = d.split(".")
        detected = len(parts) > 2 and b in parts[:-2]
        return DetectionResult(
            algorithm=self.name, detected=detected,
            confidence=1.0 if detected else 0.0,
            evidence={"brand_base": b, "domain_parts": parts},
            explanation=(
                f"Subdomain abuse: '{b}' in '{d}'"
                if detected else "No subdomain abuse"
            ),
        )


ALL_ALGORITHMS = [
    LevenshteinAlgorithm(),
    JaroWinklerAlgorithm(),
    HomographAlgorithm(),
    KeyboardAdjacencyAlgorithm(),
    CharacterOmissionAlgorithm(),
    CharacterDuplicationAlgorithm(),
    CharacterTranspositionAlgorithm(),
    PrefixAlgorithm(),
    SuffixAlgorithm(),
    HyphenAlgorithm(),
    SubdomainAlgorithm(),
]


# ---------------------------------------------------------------------------
# Standalone helpers (used by service.py for backward compat)
# ---------------------------------------------------------------------------


def detect_keywords(domain: str) -> dict[str, list[str]]:
    """Match executive, auth, and financial keywords in a domain."""
    d = domain.lower()
    return {
        "executive": [kw for kw in EXECUTIVE if kw in d],
        "auth": [kw for kw in AUTH if kw in d],
        "financial": [kw for kw in FINANCIAL if kw in d],
    }


def classify_domain(brand: str, domain: str, results: dict) -> str:
    """Return exactly one classification per candidate domain."""
    jw = results.get("jaro_winkler", 0.0)
    homograph = results.get("homograph_check", {})
    keywords = results.get("detect_keywords", {})

    if homograph.get("is_homograph") or homograph.get("has_idn"):
        return "IDN" if homograph.get("has_idn") else "Homograph"
    if isinstance(jw, dict):
        jw = jw.get("confidence", 0.0) if isinstance(jw, dict) else 0.0
    jw_val = float(jw) if isinstance(jw, (int, float)) else 0.0
    if jw_val < 0.7 and not any(keywords.values()):
        return "Low_Similarity"
    if (
        results.get("character_omission", {}).get("detected")
        or results.get("character_duplication", {}).get("detected")
        or results.get("character_transposition", {}).get("detected")
    ):
        return "Typosquatting"
    if (
        results.get("prefix", {}).get("detected")
        or results.get("suffix", {}).get("detected")
    ):
        return "Brand_Abuse"
    if results.get("subdomain", {}).get("detected"):
        return "Suspicious_Registration"
    if any(keywords.get("auth", [])) or any(keywords.get("financial", [])):
        return "Potential_Phishing"
    if jw_val >= 0.85:
        return "Lookalike"
    return "Suspicious_Registration"
