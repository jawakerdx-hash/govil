"""Detection algorithm abstract interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class DetectionResult:
    """Output from a single detection algorithm."""

    algorithm: str
    detected: bool
    confidence: float
    evidence: dict[str, Any] = field(default_factory=dict)
    explanation: str = ""


class DetectionAlgorithm(ABC):
    """Abstract interface for brand impersonation detection.

    Every algorithm produces a DetectionResult with whether
    impersonation was detected, confidence, evidence, and explanation.
    """

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def detect(self, brand: str, artifact: str) -> DetectionResult: ...

    def confidence(self, result: DetectionResult) -> float:
        return result.confidence

    def explain(self, result: DetectionResult) -> str:
        return result.explanation
