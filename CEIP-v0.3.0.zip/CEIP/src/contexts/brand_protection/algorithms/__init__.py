"""Detection algorithms subpackage."""

from .base import DetectionAlgorithm, DetectionResult
from .implementations import ALL_ALGORITHMS, classify_domain, detect_keywords
from .registry import AlgorithmRegistry

__all__ = [
    "ALL_ALGORITHMS", "AlgorithmRegistry",
    "DetectionAlgorithm", "DetectionResult",
    "classify_domain", "detect_keywords",
]
