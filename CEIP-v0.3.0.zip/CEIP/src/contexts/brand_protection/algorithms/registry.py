"""Algorithm registry for brand impersonation detection."""

from __future__ import annotations

from .base import DetectionAlgorithm, DetectionResult


class AlgorithmRegistry:
    """Registry of pluggable detection algorithms."""

    def __init__(self) -> None:
        self._algos: dict[str, DetectionAlgorithm] = {}

    def register(self, algo: DetectionAlgorithm) -> None:
        self._algos[algo.name] = algo

    def get(self, name: str) -> DetectionAlgorithm:
        if name not in self._algos:
            raise KeyError(
                f"Algorithm '{name}' not registered. Available: {self.list()}"
            )
        return self._algos[name]

    def list(self) -> list[str]:
        return sorted(self._algos)

    def detect_all(self, brand: str, artifact: str) -> list[DetectionResult]:
        return [algo.detect(brand, artifact) for algo in self._algos.values()]

    @classmethod
    def with_defaults(cls) -> AlgorithmRegistry:
        from .implementations import ALL_ALGORITHMS

        registry = cls()
        for algo in ALL_ALGORITHMS:
            registry.register(algo)
        return registry
