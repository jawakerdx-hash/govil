"""Internal brand artifact relationship graph — lightweight in-memory."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class BrandNode:
    node_type: str  # ProtectedTarget, Artifact, Campaign, Evidence, Finding
    identifier: str
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class BrandEdge:
    from_node: str
    to_node: str
    edge_type: str  # belongs_to, references, imitates, supports, part_of
    confidence: float = 0.5
    evidence: str = ""


class BrandGraph:
    """Lightweight in-memory graph of brand protection entities."""

    def __init__(self, domain: str = "") -> None:
        self.domain = domain
        self.nodes: dict[str, BrandNode] = {}
        self.edges: list[BrandEdge] = []

    def add_node(
        self, identifier: str, node_type: str, data: dict[str, Any] | None = None
    ) -> BrandNode:
        node = BrandNode(node_type=node_type, identifier=identifier, data=data or {})
        self.nodes[identifier] = node
        return node

    def add_edge(
        self, from_node: str, to_node: str, edge_type: str,
        confidence: float = 0.5, evidence: str = "",
    ) -> None:
        self.edges.append(BrandEdge(
            from_node=from_node, to_node=to_node,
            edge_type=edge_type, confidence=confidence, evidence=evidence,
        ))

    def get_node(self, identifier: str) -> BrandNode | None:
        return self.nodes.get(identifier)

    def get_edges_for(self, identifier: str) -> list[BrandEdge]:
        return [e for e in self.edges if e.from_node == identifier or e.to_node == identifier]

    def to_dict(self) -> dict[str, Any]:
        return {
            "domain": self.domain,
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "nodes": [{"id": k, "type": v.node_type} for k, v in self.nodes.items()],
            "edges": [
                {"from": e.from_node, "to": e.to_node, "type": e.edge_type}
                for e in self.edges
            ],
        }
