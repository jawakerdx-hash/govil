"""Default classification rules for brand abuse detection."""

from __future__ import annotations

from typing import Any

from .classification import ClassificationResult, ClassificationRule


class TyposquattingRule(ClassificationRule):
    @property
    def name(self) -> str:
        return "typosquatting"

    def evaluate(
        self, brand: str, artifact: str,
        detection_results: dict[str, Any], keywords: dict[str, list[str]],
    ) -> ClassificationResult | None:
        typo_algos = [
            "character_omission", "character_duplication",
            "character_transposition", "keyboard_adjacency",
        ]
        detected_count = sum(
            1 for a in typo_algos
            if detection_results.get(a, {}).get("detected", False)
        )
        lev = detection_results.get("levenshtein", {})
        if lev.get("detected") and lev.get("confidence", 0) > 0.85:
            detected_count += 1
        if detected_count == 0:
            return None
        conf = min(0.80 + (detected_count - 1) * 0.075, 0.95)
        return ClassificationResult(
            classification="Typosquatting", confidence=conf,
            explanation=f"Typosquatting: {detected_count} algorithms triggered",
        )


class HomographRule(ClassificationRule):
    @property
    def name(self) -> str:
        return "homograph"

    def evaluate(
        self, brand: str, artifact: str,
        detection_results: dict[str, Any], keywords: dict[str, list[str]],
    ) -> ClassificationResult | None:
        if detection_results.get("homograph", {}).get("detected"):
            return ClassificationResult(
                classification="Homograph", confidence=0.95,
                explanation="Homograph or IDN characters detected",
            )
        return None


class ExecutiveImpersonationRule(ClassificationRule):
    @property
    def name(self) -> str:
        return "executive_impersonation"

    def evaluate(
        self, brand: str, artifact: str,
        detection_results: dict[str, Any], keywords: dict[str, list[str]],
    ) -> ClassificationResult | None:
        matches = keywords.get("executive", [])
        if matches:
            return ClassificationResult(
                classification="Executive_Impersonation", confidence=0.85,
                explanation=f"Executive keywords: {', '.join(matches)}",
            )
        return None


class CredentialHarvestingRule(ClassificationRule):
    @property
    def name(self) -> str:
        return "credential_harvesting"

    def evaluate(
        self, brand: str, artifact: str,
        detection_results: dict[str, Any], keywords: dict[str, list[str]],
    ) -> ClassificationResult | None:
        matches = keywords.get("auth", [])
        if matches:
            return ClassificationResult(
                classification="Credential_Harvesting", confidence=0.9,
                explanation=f"Auth keywords: {', '.join(matches)}",
            )
        return None


class BrandAbuseRule(ClassificationRule):
    @property
    def name(self) -> str:
        return "brand_abuse"

    def evaluate(
        self, brand: str, artifact: str,
        detection_results: dict[str, Any], keywords: dict[str, list[str]],
    ) -> ClassificationResult | None:
        prefix = detection_results.get("prefix", {}).get("detected")
        suffix = detection_results.get("suffix", {}).get("detected")
        if prefix or suffix:
            return ClassificationResult(
                classification="Brand_Abuse", confidence=0.75,
                explanation="Brand abuse via prefix/suffix modification",
            )
        return None


class FinancialFraudRule(ClassificationRule):
    @property
    def name(self) -> str:
        return "financial_fraud"

    def evaluate(
        self, brand: str, artifact: str,
        detection_results: dict[str, Any], keywords: dict[str, list[str]],
    ) -> ClassificationResult | None:
        matches = keywords.get("financial", [])
        if matches:
            return ClassificationResult(
                classification="Financial_Fraud", confidence=0.9,
                explanation=f"Financial keywords: {', '.join(matches)}",
            )
        return None


DEFAULT_RULES = [
    TyposquattingRule(),
    HomographRule(),
    ExecutiveImpersonationRule(),
    CredentialHarvestingRule(),
    BrandAbuseRule(),
    FinancialFraudRule(),
]
