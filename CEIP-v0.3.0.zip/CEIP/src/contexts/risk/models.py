"""Risk ORM models — scores and explainable factors."""

from __future__ import annotations

import uuid

from sqlalchemy import Float, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class RiskScore(UUIDMixin, TimestampMixin, Base):
    """A unified risk score for an asset or cluster."""

    __tablename__ = "risk_scores"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    asset_identifier: Mapped[str] = mapped_column(String(512), nullable=False)
    asset_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # domain, ip, service, cluster
    score: Mapped[float] = mapped_column(Float, default=0.0)
    level: Mapped[str] = mapped_column(
        String(16), nullable=False
    )  # LOW, MEDIUM, HIGH, CRITICAL
    vuln_weight: Mapped[float] = mapped_column(Float, default=0.0)
    threat_weight: Mapped[float] = mapped_column(Float, default=0.0)
    exposure_weight: Mapped[float] = mapped_column(Float, default=0.0)
    importance_weight: Mapped[float] = mapped_column(Float, default=0.0)
    factors_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class RiskFactor(UUIDMixin, Base):
    """An individual contributing factor to a risk score."""

    __tablename__ = "risk_factors"

    score_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("risk_scores.id", ondelete="CASCADE"), nullable=False, index=True
    )
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    asset_identifier: Mapped[str] = mapped_column(String(512), nullable=False)
    category: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # vulnerability, threat, exposure, importance
    factor_name: Mapped[str] = mapped_column(String(255), nullable=False)
    contribution: Mapped[float] = mapped_column(Float, default=0.0)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
