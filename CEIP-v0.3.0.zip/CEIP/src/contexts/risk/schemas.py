"""Pydantic schemas for risk API."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class RiskFactorResponse(BaseModel):
    """A single contributing factor."""

    id: UUID
    category: str
    factor_name: str
    contribution: float
    detail: str | None = None

    model_config = {"from_attributes": True}


class RiskScoreResponse(BaseModel):
    """A risk score for an asset."""

    id: UUID
    asset_identifier: str
    asset_type: str
    score: float
    level: str
    vuln_weight: float = 0
    threat_weight: float = 0
    exposure_weight: float = 0
    importance_weight: float = 0
    factors: list[RiskFactorResponse] = []

    model_config = {"from_attributes": True}


class RiskResponse(BaseModel):
    """Complete risk assessment for a domain."""

    domain: str
    overall_risk_level: str
    overall_score: float
    scores: list[RiskScoreResponse] = []
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    top_risks: list[str] = []
    summary: str = ""
