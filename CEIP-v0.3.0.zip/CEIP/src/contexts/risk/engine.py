"""Deterministic risk scoring engine.

Unified score from four weighted dimensions:
  1. Vulnerability (40%) — CVEs, misconfigs, severity
  2. Threat (30%) — IOC matches, malicious indicators
  3. Exposure (20%) — public IP, missing headers, open ports
  4. Importance (10%) — cluster membership, central services
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.correlation.models import AssetCluster
from src.contexts.discovery.repository import DiscoveryRepository
from src.contexts.risk.models import RiskFactor, RiskScore
from src.contexts.threat.models import ThreatMatch
from src.contexts.vulnerability.models import SecurityFinding

# Scoring weights
W_VULN = 0.40
W_THREAT = 0.30
W_EXPOSURE = 0.20
W_IMPORTANCE = 0.10

# Severity multipliers
VULN_MULT: dict[str, float] = {
    "critical": 1.0, "high": 0.75, "medium": 0.50, "low": 0.25,
}
THREAT_MULT: dict[str, float] = {
    "malicious": 1.0, "suspicious": 0.60, "clean": 0.0,
}


def _score_to_level(score: float) -> str:
    if score >= 76:
        return "CRITICAL"
    if score >= 51:
        return "HIGH"
    if score >= 26:
        return "MEDIUM"
    return "LOW"


class RiskEngine:
    """Compute and persist risk scores for all assets in a domain."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._discovery_repo = DiscoveryRepository(db)

    async def assess(self, domain: str) -> dict[str, Any]:
        """Run risk assessment and return structured results."""
        domain = domain.lower().strip()

        # Load all data
        data = await self._load_domain_data(domain)
        if data["job"] is None:
            return {"domain": domain, "overall_risk_level": "LOW",
                    "overall_score": 0, "scores": [],
                    "summary": f"No discovery data for {domain}"}

        scores: list[dict[str, Any]] = []

        # Score each service/host
        for svc in data["services"]:
            score = self._score_asset(
                host=svc.host,
                asset_type="service",
                findings=data["findings"],
                threats=data["threats"],
                is_public=data["is_public"],
                has_hsts=data["has_hsts"],
                has_csp=data["has_csp"],
                cluster_sizes=data["cluster_sizes"],
            )
            scores.append(score)

        # Score each IP
        for ip_addr in data["ips"]:
            score = self._score_asset(
                host=ip_addr,
                asset_type="ip",
                findings=data["findings"],
                threats=data["threats"],
                is_public=data["is_public"],
                has_hsts=True,
                has_csp=True,
                cluster_sizes=data["cluster_sizes"],
            )
            scores.append(score)

        # Aggregate: overall score = max individual score
        overall = max((s["score"] for s in scores), default=0)
        level = _score_to_level(overall)

        # Top risks
        scores.sort(key=lambda s: s["score"], reverse=True)
        top = [f"{s['asset_identifier']} ({s['asset_type']}) = {s['score']:.0f}"
               for s in scores[:5] if s["score"] > 0]

        # Persist
        await self._persist(domain, scores)

        # Counts
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for s in scores:
            lvl = s["level"]
            if lvl in counts:
                counts[lvl] += 1

        return {
            "domain": domain,
            "overall_risk_level": level,
            "overall_score": round(overall, 1),
            "scores": scores,
            "critical_count": counts["CRITICAL"],
            "high_count": counts["HIGH"],
            "medium_count": counts["MEDIUM"],
            "low_count": counts["LOW"],
            "top_risks": top,
            "summary": (
                f"Overall: {level} ({overall:.0f}/100). "
                f"{len(scores)} assets scored. "
                f"{counts['CRITICAL']} critical, {counts['HIGH']} high, "
                f"{counts['MEDIUM']} medium, {counts['LOW']} low."
            ),
        }

    # ------------------------------------------------------------------
    # Scoring logic
    # ------------------------------------------------------------------

    def _score_asset(
        self,
        *,
        host: str,
        asset_type: str,
        findings: list[SecurityFinding],
        threats: list[ThreatMatch],
        is_public: bool,
        has_hsts: bool,
        has_csp: bool,
        cluster_sizes: dict[str, int],
    ) -> dict[str, Any]:
        """Compute a unified 0-100 risk score for one asset."""
        factors: list[dict[str, Any]] = []

        # 1. Vulnerability weight (0-100 scaled to 40%)
        vuln_score = 0.0
        for f in findings:
            if f.affected_asset and host == f.affected_asset:
                mult = VULN_MULT.get(f.severity, 0.25)
                contribution = 100 * mult * W_VULN
                vuln_score += contribution
                factors.append({
                    "category": "vulnerability",
                    "factor_name": f.cve_id or f.finding_type,
                    "contribution": round(contribution, 1),
                    "detail": f.title[:200],
                })
        vuln_score = min(vuln_score, 40)

        # 2. Threat weight (0-100 scaled to 30%)
        threat_score = 0.0
        for t in threats:
            if t.matched_asset and host == t.matched_asset:
                mult = THREAT_MULT.get(t.severity, 0.3)
                contribution = 100 * mult * W_THREAT
                threat_score += contribution
                factors.append({
                    "category": "threat",
                    "factor_name": t.threat_category or "ioc_match",
                    "contribution": round(contribution, 1),
                    "detail": f"Matched {t.match_type}: {t.matched_asset}",
                })
        threat_score = min(threat_score, 30)

        # 3. Exposure weight (0-100 scaled to 20%)
        exposure_score = 0.0
        if is_public:
            contribution = 100 * 0.6 * W_EXPOSURE
            exposure_score += contribution
            factors.append({
                "category": "exposure",
                "factor_name": "public_ip",
                "contribution": round(contribution, 1),
                "detail": "Asset is internet-facing",
            })
        if not has_hsts:
            contribution = 100 * 0.3 * W_EXPOSURE
            exposure_score += contribution
            factors.append({
                "category": "exposure",
                "factor_name": "missing_hsts",
                "contribution": round(contribution, 1),
                "detail": "HSTS header not set",
            })
        if not has_csp:
            contribution = 100 * 0.2 * W_EXPOSURE
            exposure_score += contribution
            factors.append({
                "category": "exposure",
                "factor_name": "missing_csp",
                "contribution": round(contribution, 1),
                "detail": "Content-Security-Policy not set",
            })
        exposure_score = min(exposure_score, 20)

        # 4. Importance weight (0-100 scaled to 10%)
        importance_score = 0.0
        cluster_size = cluster_sizes.get(host, 1)
        if cluster_size > 1:
            contribution = min(100 * (cluster_size / 10) * W_IMPORTANCE, 10)
            importance_score += contribution
            factors.append({
                "category": "importance",
                "factor_name": "cluster_size",
                "contribution": round(contribution, 1),
                "detail": f"Member of cluster with {cluster_size} assets",
            })
        importance_score = min(importance_score, 10)

        total = round(vuln_score + threat_score + exposure_score + importance_score, 1)
        level = _score_to_level(total)

        return {
            "asset_identifier": host,
            "asset_type": asset_type,
            "score": total,
            "level": level,
            "vuln_weight": round(vuln_score, 1),
            "threat_weight": round(threat_score, 1),
            "exposure_weight": round(exposure_score, 1),
            "importance_weight": round(importance_score, 1),
            "factors": factors,
        }

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------

    async def _load_domain_data(self, domain: str) -> dict[str, Any]:
        """Load all relevant data for a domain from existing contexts."""
        job = await self._discovery_repo.get_latest_done(domain)

        if job is None:
            return {"job": None}

        # Findings
        find_result = await self._db.execute(
            select(SecurityFinding).where(SecurityFinding.domain == domain)
        )
        findings = find_result.scalars().all()

        # Threats
        threat_result = await self._db.execute(
            select(ThreatMatch).where(ThreatMatch.domain == domain)
        )
        threats = threat_result.scalars().all()

        # Clusters
        cluster_result = await self._db.execute(
            select(AssetCluster).where(AssetCluster.domain == domain)
        )
        clusters = cluster_result.scalars().all()

        # Is public?
        is_public = any(
            r.record_type in ("A", "AAAA") for r in job.dns_records
        ) if job.dns_records else False

        # Security headers
        has_hsts = False
        has_csp = False
        for svc in job.services:
            if svc.headers_json:
                try:
                    hdrs = json.loads(svc.headers_json)
                    if "strict-transport-security" in hdrs:
                        has_hsts = True
                    if "content-security-policy" in hdrs:
                        has_csp = True
                except (json.JSONDecodeError, TypeError):
                    pass

        # IPs
        ips: list[str] = []
        for r in job.dns_records:
            if r.record_type in ("A", "AAAA"):
                ips.append(r.value)

        # Cluster sizes
        cluster_sizes: dict[str, int] = {}
        for c in clusters:
            if c.members_json:
                try:
                    members = json.loads(c.members_json)
                    for m in members:
                        cluster_sizes[str(m)] = max(
                            cluster_sizes.get(str(m), 0), c.member_count
                        )
                except (json.JSONDecodeError, TypeError):
                    pass

        # Services list
        services = list(job.services)

        return {
            "job": job,
            "findings": findings,
            "threats": threats,
            "clusters": clusters,
            "is_public": is_public,
            "has_hsts": has_hsts,
            "has_csp": has_csp,
            "ips": ips,
            "services": services,
            "cluster_sizes": cluster_sizes,
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    async def _persist(
        self, domain: str, scores: list[dict[str, Any]]
    ) -> None:
        """Store risk scores and factors."""
        # Clear old
        old_scores = await self._db.execute(
            select(RiskScore).where(RiskScore.domain == domain)
        )
        for row in old_scores.scalars().all():
            await self._db.delete(row)

        for s in scores:
            score_row = RiskScore(
                domain=domain,
                asset_identifier=s["asset_identifier"],
                asset_type=s["asset_type"],
                score=s["score"],
                level=s["level"],
                vuln_weight=s["vuln_weight"],
                threat_weight=s["threat_weight"],
                exposure_weight=s["exposure_weight"],
                importance_weight=s["importance_weight"],
                factors_json=json.dumps(s["factors"]),
            )
            self._db.add(score_row)
            await self._db.flush()  # flush once to get score_row.id

            for f in s["factors"]:
                self._db.add(RiskFactor(
                    score_id=score_row.id,
                    domain=domain,
                    asset_identifier=s["asset_identifier"],
                    category=f["category"],
                    factor_name=f["factor_name"],
                    contribution=f["contribution"],
                    detail=f.get("detail"),
                ))

        await self._db.flush()
