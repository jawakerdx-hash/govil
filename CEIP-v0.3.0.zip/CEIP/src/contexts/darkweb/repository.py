"""Dark web intelligence repository."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .models import (
    DarkWebCorrelation,
    DarkWebEvidence,
    DarkWebFinding,
    DarkWebIncident,
    DarkWebTarget,
)


class DarkWebRepository:
    """Persistence layer for dark web intelligence."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def clear_domain(self, domain: str) -> None:
        findings = (
            await self._db.execute(
                select(DarkWebFinding).where(DarkWebFinding.domain == domain)
            )
        ).scalars().all()
        for f in findings:
            for ev in (
                await self._db.execute(
                    select(DarkWebEvidence).where(
                        DarkWebEvidence.finding_id == str(f.id)
                    )
                )
            ).scalars().all():
                await self._db.delete(ev)
            for corr in (
                await self._db.execute(
                    select(DarkWebCorrelation).where(
                        DarkWebCorrelation.finding_id == str(f.id)
                    )
                )
            ).scalars().all():
                await self._db.delete(corr)
            await self._db.delete(f)
        targets = (
            await self._db.execute(
                select(DarkWebTarget).where(DarkWebTarget.domain == domain)
            )
        ).scalars().all()
        for t in targets:
            await self._db.delete(t)
        await self._db.flush()

    async def get_target(self, domain: str) -> DarkWebTarget | None:
        r = await self._db.execute(
            select(DarkWebTarget).where(DarkWebTarget.domain == domain)
        )
        return r.scalar_one_or_none()

    async def add_target(self, target: DarkWebTarget) -> None:
        self._db.add(target)
        await self._db.flush()

    async def add_finding(self, finding: DarkWebFinding) -> None:
        self._db.add(finding)

    async def add_evidence(self, evidence: DarkWebEvidence) -> None:
        self._db.add(evidence)

    async def add_correlation(self, correlation: DarkWebCorrelation) -> None:
        self._db.add(correlation)

    async def add_incident(self, incident: DarkWebIncident) -> None:
        self._db.add(incident)

    async def get_findings(self, domain: str) -> list[DarkWebFinding]:
        r = await self._db.execute(
            select(DarkWebFinding)
            .where(DarkWebFinding.domain == domain)
            .order_by(DarkWebFinding.risk_score.desc())
        )
        return list(r.scalars().all())

    async def flush(self) -> None:
        await self._db.flush()
