"""Normalization — converts provider-specific output to standard format."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from typing import Any

from .exposure_types import ExposureTypeInfo
from .providers.base import DarkWebSignal


class NormalizedDarkWebEvidence:
    """Provider-agnostic normalized evidence."""

    def __init__(
        self,
        provider: str,
        source: str,
        artifact_type: str,
        artifact_value: str,
        severity: str,
        confidence: float,
        raw_data: dict[str, Any] | None = None,
        normalized_data: dict[str, Any] | None = None,
        collected_at: datetime | None = None,
    ) -> None:
        self.provider = provider
        self.source = source
        self.artifact_type = artifact_type
        self.artifact_value = artifact_value
        self.severity = severity
        self.confidence = confidence
        self.raw_data = raw_data or {}
        self.normalized_data = normalized_data or {}
        self.collected_at = collected_at or datetime.now(UTC)
        self.content_hash = self._compute_hash()

    def _compute_hash(self) -> str:
        payload = json.dumps({
            "provider": self.provider, "source": self.source,
            "artifact_type": self.artifact_type, "artifact_value": self.artifact_value,
        }, sort_keys=True)
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    @classmethod
    def from_signal(cls, signal: DarkWebSignal, provider_name: str) -> NormalizedDarkWebEvidence:
        info = ExposureTypeInfo.from_type(signal.finding_type)
        return cls(
            provider=provider_name,
            source=signal.source_reference or provider_name,
            artifact_type=signal.finding_type,
            artifact_value=signal.domain,
            severity=signal.severity or info.severity,
            confidence=signal.confidence,
            raw_data={
                "title": signal.title, "description": signal.description,
                "email": signal.email, "username": signal.username,
            },
            normalized_data={
                "finding_type": signal.finding_type,
                "category": info.category,
                "base_confidence": info.base_confidence,
            },
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider, "source": self.source,
            "artifact_type": self.artifact_type, "artifact_value": self.artifact_value,
            "severity": self.severity, "confidence": self.confidence,
            "content_hash": self.content_hash,
            "collected_at": self.collected_at.isoformat(),
        }
