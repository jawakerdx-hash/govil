"""Confidence model — strict formula only, no guessing."""

from __future__ import annotations

from typing import Any


class DarkWebConfidence:
    """Deterministic confidence scoring.

    confidence = provider_trust * 0.25 + evidence_strength * 0.30
               + correlation_strength * 0.20 + source_diversity * 0.15
               + freshness_score * 0.10

    All inputs normalized 0-1 before calculation.
    """

    @staticmethod
    def calculate(
        provider_trust: float | None = None,
        provider_confidence: float | None = None,
        evidence_strength: float | None = None,
        evidence_count: int = 1,
        correlation_strength: float | None = None,
        correlation_count: int = 0,
        source_diversity: float | None = None,
        source_count: int = 1,
        freshness_score: float | None = None,
    ) -> dict[str, Any]:
        # Normalize all inputs to 0-1
        pt = min(1.0, max(0.0, (provider_trust or provider_confidence or 0.5)))
        es = min(1.0, max(0.0, (evidence_strength or min(1.0, evidence_count * 0.2))))
        cs = min(1.0, max(0.0, (correlation_strength or min(1.0, correlation_count * 0.25))))
        sd = min(1.0, max(0.0, (source_diversity or min(1.0, source_count * 0.2))))
        fs = min(1.0, max(0.1, (freshness_score or 0.5)))

        confidence = round(
            pt * 0.25 + es * 0.30 + cs * 0.20 + sd * 0.15 + fs * 0.10, 4
        )

        if confidence >= 0.8:
            level = "HIGH"
        elif confidence >= 0.5:
            level = "MEDIUM"
        else:
            level = "LOW"

        return {
            "overall_confidence": confidence,
            "confidence_level": level,
            "provider_trust": round(pt, 3),
            "evidence_strength": round(es, 3),
            "correlation_strength": round(cs, 3),
            "source_diversity": round(sd, 3),
            "freshness_score": round(fs, 3),
            "explanation": (
                f"Confidence {level} ({confidence:.2f}): "
                f"PT={pt:.2f} ES={es:.2f} CS={cs:.2f} SD={sd:.2f} FS={fs:.2f}"
            ),
        }
