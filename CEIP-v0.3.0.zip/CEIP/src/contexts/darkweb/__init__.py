"""Dark web intelligence bounded context."""

from .confidence import DarkWebConfidence
from .correlation import CorrelationLink, CorrelationResult, correlate_finding
from .entity_resolution import CanonicalEntity, EntityResolver
from .exposure_types import EXPOSURE_CATEGORIES, EXPOSURE_TYPE_LIST, ExposureTypeInfo
from .models import (
    DarkWebCorrelation,
    DarkWebEvidence,
    DarkWebFinding,
    DarkWebIncident,
    DarkWebSource,
    DarkWebTarget,
)
from .normalization import NormalizedDarkWebEvidence
from .pipeline import DarkWebPipeline
from .providers.base import DarkWebProvider, DarkWebSignal
from .providers.local_provider import LocalDarkWebProvider
from .registry import DarkWebProviderRegistry
from .risk_policy import DarkWebRiskPolicy

__all__ = [
    "CanonicalEntity",
    "CorrelationLink",
    "CorrelationResult",
    "DarkWebConfidence",
    "DarkWebCorrelation",
    "DarkWebEvidence",
    "DarkWebFinding",
    "DarkWebIncident",
    "DarkWebPipeline",
    "DarkWebProvider",
    "DarkWebProviderRegistry",
    "DarkWebRiskPolicy",
    "DarkWebSignal",
    "DarkWebSource",
    "DarkWebTarget",
    "EntityResolver",
    "EXPOSURE_CATEGORIES",
    "EXPOSURE_TYPE_LIST",
    "ExposureTypeInfo",
    "LocalDarkWebProvider",
    "NormalizedDarkWebEvidence",
    "correlate_finding",
]
