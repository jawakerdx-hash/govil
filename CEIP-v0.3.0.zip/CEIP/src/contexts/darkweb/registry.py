"""Provider registry for dark web data sources."""

from __future__ import annotations

from .providers.base import DarkWebProvider
from .providers.local_provider import LocalDarkWebProvider


class DarkWebProviderRegistry:
    """Registry of pluggable dark web intelligence providers."""

    def __init__(self) -> None:
        self._providers: dict[str, DarkWebProvider] = {}

    def register(self, provider: DarkWebProvider) -> None:
        self._providers[provider.name] = provider

    def get(self, name: str) -> DarkWebProvider:
        if name not in self._providers:
            raise KeyError(
                f"Provider '{name}' not registered. "
                f"Available: {', '.join(sorted(self._providers))}"
            )
        return self._providers[name]

    def list(self) -> list[str]:
        return sorted(self._providers)

    @classmethod
    def with_defaults(cls) -> DarkWebProviderRegistry:
        reg = cls()
        reg.register(LocalDarkWebProvider())
        return reg
