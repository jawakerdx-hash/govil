"""Dark web intelligence service — collection, scoring, correlation."""

from __future__ import annotations

import json
from typing import Any

from .models import DarkWebCorrelation, DarkWebEvidence, DarkWebFinding, DarkWebTarget
from .providers.base import DarkWebProvider
from .providers.local_provider import LocalDarkWebProvider
from .repository import DarkWebRepository
from .risk_policy import DarkWebRiskPolicy


class DarkWebService:
    """Orchestrates dark web intelligence collection and risk scoring."""

    def __init__(
        self,
        repo: DarkWebRepository,
        provider: DarkWebProvider | None = None,
        risk_policy: DarkWebRiskPolicy | None = None,
    ) -> None:
        self._repo = repo
        self._provider = provider or LocalDarkWebProvider()
        self._risk_policy = risk_policy or DarkWebRiskPolicy()

    async def scan(self, domain: str) -> dict[str, Any]:
        """Collect dark web signals, score, and persist."""
        domain = domain.lower().strip()
        await self._repo.clear_domain(domain)

        signals = await self._provider.collect(domain)
        results: list[dict[str, Any]] = []

        # Upsert target
        target = await self._repo.get_target(domain)
        if target is None:
            target = DarkWebTarget(domain=domain)
            await self._repo.add_target(target)

        for sig in signals:
            # Score
            risk = self._risk_policy.assess(
                finding_type=sig.finding_type,
                email=sig.email,
                username=sig.username,
                confidence=sig.confidence,
            )

            # Persist finding
            finding = DarkWebFinding(
                target_id=str(target.id),
                domain=domain,
                finding_type=sig.finding_type,
                provider=self._provider.name,
                confidence=sig.confidence,
                severity=risk["risk_level"],
                risk_score=risk["risk_score"],
                source_reference=sig.source_reference,
                evidence_json=json.dumps({
                    "title": sig.title,
                    "description": sig.description,
                    "email": sig.email,
                    "username": sig.username,
                    "metadata": sig.metadata,
                }),
            )
            await self._repo.add_finding(finding)
            await self._repo.flush()

            # Evidence
            ev = DarkWebEvidence(
                finding_id=str(finding.id),
                evidence_type=sig.finding_type,
                title=sig.title,
                description=sig.description,
                source=f"darkweb.{self._provider.name}",
            )
            await self._repo.add_evidence(ev)

            # Correlation — link to identity exposure
            if sig.email:
                corr = DarkWebCorrelation(
                    finding_id=str(finding.id),
                    related_asset=sig.email,
                    relation_type="matches_identity",
                    confidence=sig.confidence,
                    evidence=f"Email {sig.email} linked to dark web finding",
                )
                await self._repo.add_correlation(corr)

            results.append({
                "finding_type": sig.finding_type,
                "title": sig.title,
                "severity": risk["risk_level"],
                "risk_score": risk["risk_score"],
                "confidence": sig.confidence,
                "email": sig.email,
                "username": sig.username,
            })

        await self._repo.flush()

        # Summary
        levels = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for r in results:
            lvl = r["severity"]
            if lvl in levels:
                levels[lvl] += 1

        credential_count = sum(
            1 for r in results
            if r["finding_type"] in ("Credential_Exposure", "Password_Leak",
                                      "Email_Breach", "Username_Breach")
        )
        executive_count = sum(
            1 for r in results
            if any(p in (r.get("email", "") + r.get("username", "")).lower()
                   for p in ("admin", "root", "ceo", "cto", "cfo"))
        )

        top_risk = max(results, key=lambda r: r["risk_score"]) if results else {"risk_score": 0}

        return {
            "domain": domain,
            "total_findings": len(results),
            "highest_severity": (
                "CRITICAL" if levels["CRITICAL"] > 0
                else "HIGH" if levels["HIGH"] > 0
                else "MEDIUM" if levels["MEDIUM"] > 0
                else "LOW"
            ),
            "critical": levels["CRITICAL"],
            "high": levels["HIGH"],
            "medium": levels["MEDIUM"],
            "low": levels["LOW"],
            "credential_exposures": credential_count,
            "executive_mentions": executive_count,
            "leaked_assets": len(results),
            "risk_contribution": top_risk["risk_score"],
            "findings": [
                {
                    "id": f.id,
                    "finding_type": f.finding_type,
                    "domain": f.domain,
                    "severity": f.severity,
                    "risk_score": f.risk_score,
                    "confidence": f.confidence,
                    "source_reference": f.source_reference,
                }
                for f in (await self._repo.get_findings(domain))
            ],
            "recommendations": self._recommendations(results),
            "summary": (
                f"{len(results)} dark web findings for '{domain}': "
                f"{credential_count} credential, {executive_count} executive, "
                f"max severity {top_risk.get('severity', 'LOW')}"
            ),
        }

    @staticmethod
    def _recommendations(results: list[dict[str, Any]]) -> list[str]:
        recs: list[str] = []
        types = {r["finding_type"] for r in results}
        if "Credential_Exposure" in types or "Password_Leak" in types:
            recs.append("Rotate exposed credentials immediately")
            recs.append("Enable MFA for all accounts with exposed credentials")
        if "Email_Breach" in types:
            recs.append("Monitor affected email accounts for suspicious activity")
        if "API_Key_Exposure" in types:
            recs.append("Revoke and rotate all exposed API keys")
        if not recs:
            recs.append("Continue monitoring dark web intelligence sources")
        return recs
