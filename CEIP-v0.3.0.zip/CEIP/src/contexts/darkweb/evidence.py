"""Normalized dark web evidence model."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .providers.base import DarkWebSignal


@dataclass
class NormalizedEvidence:
    """Provider-agnostic normalized evidence from any dark web source."""

    finding_type: str
    domain: str
    title: str
    description: str = ""
    confidence: float = 0.5
    severity: str = "LOW"
    source_reference: str = ""
    email: str = ""
    username: str = ""
    provider: str = "local"
    metadata: dict = field(default_factory=dict)

    @classmethod
    def from_signal(cls, signal: DarkWebSignal, provider_name: str) -> NormalizedEvidence:
        """Create normalized evidence from a provider signal."""

        return cls(
            finding_type=signal.finding_type,
            domain=signal.domain,
            title=signal.title,
            description=signal.description,
            confidence=signal.confidence,
            severity=signal.severity,
            source_reference=signal.source_reference,
            email=signal.email,
            username=signal.username,
            provider=provider_name,
            metadata=signal.metadata,
        )
