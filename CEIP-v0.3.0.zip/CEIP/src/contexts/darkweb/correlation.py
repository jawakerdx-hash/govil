"""Structured correlation — links dark web findings to other CEIP contexts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class CorrelationLink:
    """A structured link between a dark web finding and another CEIP context."""

    # identity_exposure, brand_protection, threat_intel, discovery, attack_path, risk, monitoring
    context: str
    asset: str
    relation: str
    confidence: float
    evidence: str = ""


@dataclass
class CorrelationResult:
    finding_id: str
    domain: str
    links: list[CorrelationLink] = field(default_factory=list)
    total_links: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "finding_id": self.finding_id,
            "domain": self.domain,
            "total_links": self.total_links,
            "links": [
                {"context": link.context, "asset": link.asset, "relation": link.relation,
                 "confidence": link.confidence, "evidence": link.evidence}
                for link in self.links
            ],
        }


def correlate_finding(
    domain: str, email: str = "", username: str = "", finding_type: str = ""
) -> CorrelationResult:
    """Produce structured correlation links for a dark web finding.

    Never free-form text. Every link references a specific context.
    """
    result = CorrelationResult(finding_id="", domain=domain)
    links: list[CorrelationLink] = []

    if email:
        links.append(CorrelationLink(
            context="identity_exposure", asset=email, relation="matches_identity",
            confidence=0.75, evidence=f"Email {email} linked to {finding_type}",
        ))
    if username:
        links.append(CorrelationLink(
            context="identity_exposure", asset=username, relation="matches_username",
            confidence=0.7, evidence=f"Username {username} linked to {finding_type}",
        ))

    finding_lower = finding_type.lower()
    if "credential" in finding_lower or "password" in finding_lower:
        links.append(CorrelationLink(
            context="brand_protection", asset=domain, relation="credential_risk",
            confidence=0.7, evidence=f"Credential exposure affects brand {domain}",
        ))
    if "api" in finding_lower or "cloud" in finding_lower:
        links.append(CorrelationLink(
            context="attack_path", asset=domain, relation="infrastructure_risk",
            confidence=0.8, evidence=f"Secret exposure may enable attack paths against {domain}",
        ))

    links.append(CorrelationLink(
        context="security_rating", asset=domain, relation="impacts_rating",
        confidence=0.6, evidence=f"Dark web finding contributes to {domain} rating",
    ))

    result.links = links
    result.total_links = len(links)
    return result
