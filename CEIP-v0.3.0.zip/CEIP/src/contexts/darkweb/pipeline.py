"""Strict dark web intelligence pipeline — no step may be skipped."""

from __future__ import annotations

from typing import Any

from .confidence import DarkWebConfidence
from .correlation import correlate_finding
from .entity_resolution import EntityResolver
from .normalization import NormalizedDarkWebEvidence
from .providers.base import DarkWebProvider
from .risk_policy import DarkWebRiskPolicy

REQUIRED_FIELDS = [
    "entity", "exposure_type", "correlation_cluster",
    "confidence_score", "risk_score", "evidence_sources",
]


class DarkWebPipeline:
    """Provider → Ingestion → Normalization → Dedup → Entity Resolution
    → Correlation → Risk Scoring → Confidence → Output"""

    def __init__(self, provider: DarkWebProvider) -> None:
        self._provider = provider
        self._resolver = EntityResolver()
        self._risk = DarkWebRiskPolicy()
        self._confidence = DarkWebConfidence()

    async def run(self, domain: str) -> dict[str, Any]:
        # 1. Provider ingestion
        signals = await self._provider.collect(domain)
        if not signals:
            return {"status": "NO_SIGNALS", "domain": domain}

        # 2. Normalization
        evidence_list = [
            NormalizedDarkWebEvidence.from_signal(s, self._provider.name)
            for s in signals
        ]

        # 3. Deduplication + Entity Resolution
        entity_result = self._resolver.resolve(evidence_list)
        if "error" in entity_result:
            return {"status": "REJECTED", "reason": entity_result["error"]}

        # 4. Correlation
        clusters = []
        for entity in entity_result["entities"]:
            corr = correlate_finding(
                domain=domain,
                email=entity["normalized_value"] if entity["entity_type"] == "email" else "",
                username=entity["normalized_value"] if entity["entity_type"] != "email" else "",
            )
            clusters.append({
                "cluster_id": entity["entity_cluster"],
                "correlation_type": "entity",
                "entities": [entity["canonical_entity_id"]],
                "sources": entity["sources"],
                "strength_score": round(entity["confidence"] * 100),
            })
            # Add hybrid correlation links
            for link in corr.links:
                clusters.append({
                    "cluster_id": entity["entity_cluster"],
                    "correlation_type": "hybrid",
                    "entities": [entity["canonical_entity_id"], link.asset],
                    "sources": [link.context],
                    "strength_score": round(link.confidence * 100),
                })

        # 5. Risk + Confidence scoring
        outputs = []
        for entity in entity_result["entities"]:
            risk = self._risk.assess(
                finding_type=entity["entity_type"],
                email=entity["normalized_value"],
                confidence=entity["confidence"],
            )
            conf = self._confidence.calculate(
                provider_confidence=entity["confidence"],
                evidence_count=entity["source_count"],
                correlation_count=len(clusters),
                source_diversity=len(entity["sources"]),
            )

            output = {
                "entity": entity["canonical_entity_id"],
                "exposure_type": entity["entity_type"],
                "correlation_cluster": entity["entity_cluster"],
                "confidence_score": round(conf["overall_confidence"] * 100, 1),
                "risk_score": risk["risk_score"],
                "evidence_sources": entity["sources"],
            }

            # 6. Schema validation
            if not all(k in output for k in REQUIRED_FIELDS):
                return {"status": "REJECTED_INCOMPLETE_SCHEMA", "missing": [
                    k for k in REQUIRED_FIELDS if k not in output
                ]}

            outputs.append(output)

        return {
            "status": "COMPLETE",
            "domain": domain,
            "pipeline_version": "2.0",
            "total_signals": len(signals),
            "total_entities": entity_result["total_entities"],
            "total_clusters": len(set(c["cluster_id"] for c in clusters)),
            "outputs": outputs,
            "clusters": clusters,
        }
