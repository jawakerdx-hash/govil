"""Local dark web provider — returns empty results when no real provider is configured."""

from __future__ import annotations

from .base import DarkWebProvider, DarkWebSignal


class LocalDarkWebProvider(DarkWebProvider):
    """Default provider. Returns empty results — no fabricated data.

    To get real dark web intelligence, configure a real provider
    (e.g. Recorded Future, Digital Shadows, SpyCloud) and register it.
    """

    @property
    def name(self) -> str:
        return "local"

    async def collect(self, domain: str) -> list[DarkWebSignal]:
        return []

    async def search_domain(self, domain: str) -> list[DarkWebSignal]:
        return []

    async def search_email(self, email: str) -> list[DarkWebSignal]:
        return []

    async def search_username(self, username: str) -> list[DarkWebSignal]:
        return []

    async def search_organization(self, org: str) -> list[DarkWebSignal]:
        return []
