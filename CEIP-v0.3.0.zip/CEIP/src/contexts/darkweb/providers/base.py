"""Dark web intelligence provider abstraction."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class DarkWebSignal:
    """A single dark web intelligence signal."""

    finding_type: str
    domain: str
    title: str
    description: str = ""
    confidence: float = 0.5
    severity: str = "LOW"
    source_reference: str = ""
    email: str = ""
    username: str = ""
    metadata: dict = field(default_factory=dict)


class DarkWebProvider(ABC):
    """Abstract interface for dark web intelligence providers."""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    async def collect(self, domain: str) -> list[DarkWebSignal]: ...

    @abstractmethod
    async def search_domain(self, domain: str) -> list[DarkWebSignal]: ...

    @abstractmethod
    async def search_email(self, email: str) -> list[DarkWebSignal]: ...

    @abstractmethod
    async def search_username(self, username: str) -> list[DarkWebSignal]: ...

    @abstractmethod
    async def search_organization(self, org: str) -> list[DarkWebSignal]: ...
