"""Supported dark web exposure types with metadata."""
# ruff: noqa: E501

from __future__ import annotations

from dataclasses import dataclass

EXPOSURE_CATEGORIES: dict[str, dict[str, float | str]] = {
    "Credential_Leak": {"severity": "HIGH", "base_confidence": 0.7, "category": "credential"},
    "Email_Breach": {"severity": "MEDIUM", "base_confidence": 0.6, "category": "identity"},
    "Password_Exposure": {"severity": "HIGH", "base_confidence": 0.8, "category": "credential"},
    "Username_Exposure": {"severity": "LOW", "base_confidence": 0.5, "category": "identity"},
    "API_Key_Exposure": {"severity": "CRITICAL", "base_confidence": 0.9, "category": "secret"},
    "Cloud_Credential_Exposure": {"severity": "CRITICAL", "base_confidence": 0.9, "category": "secret"},
    "Source_Code_Leak": {"severity": "HIGH", "base_confidence": 0.7, "category": "data"},
    "Database_Dump": {"severity": "CRITICAL", "base_confidence": 0.85, "category": "data"},
    "Internal_Document": {"severity": "MEDIUM", "base_confidence": 0.6, "category": "data"},
    "Employee_Identity": {"severity": "MEDIUM", "base_confidence": 0.6, "category": "identity"},
    "Executive_Identity": {"severity": "HIGH", "base_confidence": 0.75, "category": "identity"},
    "Telegram_Mention": {"severity": "LOW", "base_confidence": 0.4, "category": "mention"},
    "Paste_Site_Mention": {"severity": "LOW", "base_confidence": 0.4, "category": "mention"},
    "Marketplace_Mention": {"severity": "MEDIUM", "base_confidence": 0.5, "category": "mention"},
    "Forum_Mention": {"severity": "LOW", "base_confidence": 0.35, "category": "mention"},
    "Repository_Mention": {"severity": "MEDIUM", "base_confidence": 0.55, "category": "code"},
}

EXPOSURE_TYPE_LIST: list[str] = sorted(EXPOSURE_CATEGORIES.keys())


@dataclass
class ExposureTypeInfo:
    name: str
    severity: str
    base_confidence: float
    category: str

    @classmethod
    def from_type(cls, exposure_type: str) -> ExposureTypeInfo:
        meta = EXPOSURE_CATEGORIES.get(exposure_type, {})
        return cls(
            name=exposure_type,
            severity=str(meta.get("severity", "LOW")),
            base_confidence=float(meta.get("base_confidence", 0.3)),
            category=str(meta.get("category", "unknown")),
        )
