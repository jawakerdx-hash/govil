"""Dark web intelligence ORM models."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class DarkWebTarget(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "darkweb_targets"

    domain: Mapped[str] = mapped_column(String(255), index=True)
    org_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    severity: Mapped[str] = mapped_column(String(16), default="LOW")
    first_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_scanned: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="active")
    provider: Mapped[str] = mapped_column(String(64), default="local")
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class DarkWebFinding(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "darkweb_findings"

    target_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("darkweb_targets.id"), index=True
    )
    domain: Mapped[str] = mapped_column(String(255), index=True)
    finding_type: Mapped[str] = mapped_column(String(64), nullable=False)
    provider: Mapped[str] = mapped_column(String(64), default="local")
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    severity: Mapped[str] = mapped_column(String(16), default="LOW")
    risk_score: Mapped[float] = mapped_column(Float, default=0.0)
    source_reference: Mapped[str | None] = mapped_column(String(512), nullable=True)
    evidence_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    canonical_entity_id: Mapped[str | None] = mapped_column(String(16), nullable=True, index=True)
    normalized_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    correlation_cluster_id: Mapped[str | None] = mapped_column(String(12), nullable=True)
    source_trust_score: Mapped[float] = mapped_column(Float, default=0.5)
    first_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="active")


class DarkWebEvidence(UUIDMixin, Base):
    __tablename__ = "darkweb_evidence"

    finding_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("darkweb_findings.id"), index=True
    )
    evidence_type: Mapped[str] = mapped_column(String(32), nullable=False)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str] = mapped_column(String(128), default="darkweb_intel")
    collected_at: Mapped[datetime] = mapped_column(DateTime, default=func.now())


class DarkWebCorrelation(UUIDMixin, Base):
    __tablename__ = "darkweb_correlations"

    finding_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("darkweb_findings.id"), index=True
    )
    related_asset: Mapped[str] = mapped_column(String(512), nullable=False)
    relation_type: Mapped[str] = mapped_column(String(32), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)


class DarkWebIncident(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "darkweb_incidents"

    domain: Mapped[str] = mapped_column(String(255), index=True)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    incident_type: Mapped[str] = mapped_column(String(64), nullable=False)
    severity: Mapped[str] = mapped_column(String(16), default="LOW")
    source_count: Mapped[int] = mapped_column(Integer, default=1)
    first_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="open")
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class DarkWebSource(UUIDMixin, TimestampMixin, Base):
    """Registered dark web intelligence source."""

    __tablename__ = "darkweb_sources"

    source_name: Mapped[str] = mapped_column(String(128), unique=True)
    source_type: Mapped[str] = mapped_column(String(32), default="local")
    provider: Mapped[str] = mapped_column(String(64), default="local")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_collected: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finding_count: Mapped[int] = mapped_column(Integer, default=0)
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)
