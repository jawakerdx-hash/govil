"""Dark web risk policy — deterministic formula only."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

FINDING_TYPE_WEIGHTS: dict[str, float] = {
    "credential_leak": 1.5, "username_exposure": 1.1,
    "api_key_exposure": 1.6, "cloud_credential_exposure": 1.6,
    "source_code_leak": 1.4, "database_dump": 1.5,
    "internal_document": 1.2, "identity_exposure": 1.3,
    "telegram_mention": 1.0, "paste_site_mention": 0.8,
    "marketplace_mention": 1.0, "forum_mention": 0.9,
    "repository_mention": 1.1,
}

EXECUTIVE_PATTERNS = ("admin", "root", "ceo", "cto", "cfo", "executive", "founder")


@dataclass
class RiskFactor:
    name: str
    weight: float
    score: float
    contribution: float


class DarkWebRiskPolicy:
    """Deterministic risk scoring.

    risk_score = severity * asset_criticality * validity_probability
               * freshness_decay * correlation_multiplier
    """

    DEFAULT_WEIGHTS = {
        "finding_type": 0.35, "credential_relevance": 0.25,
        "source_count": 0.20, "exposure_freshness": 0.20,
    }

    def __init__(self, weights: dict[str, float] | None = None) -> None:
        self.weights = {**self.DEFAULT_WEIGHTS, **(weights or {})}

    def assess(
        self,
        finding_type: str = "",
        email: str = "",
        username: str = "",
        confidence: float = 0.5,
        source_count: int = 1,
    ) -> dict[str, Any]:
        # Severity from finding type weight
        ft_lower = finding_type.lower().replace(" ", "_")
        severity = 0.5
        for key, weight in FINDING_TYPE_WEIGHTS.items():
            if key in ft_lower or ft_lower in key:
                severity = min(1.0, weight / 2.0)
                break

        # Asset criticality — executive accounts matter more
        asset_criticality = 0.5
        combined = (email + username).lower()
        if any(p in combined for p in EXECUTIVE_PATTERNS):
            asset_criticality = 0.9
        elif email or username:
            asset_criticality = 0.6

        # Validity probability = confidence
        validity = min(1.0, max(0.1, confidence))

        # Freshness decay — default 0.9 (no real timestamps yet)
        freshness = 0.9

        # Correlation multiplier
        corr_mult = min(1.5, max(0.5, 1.0 + (source_count - 1) * 0.1))

        risk_score = round(
            severity * asset_criticality * validity * freshness * corr_mult * 100, 1
        )

        if risk_score >= 76:
            level = "CRITICAL"
        elif risk_score >= 51:
            level = "HIGH"
        elif risk_score >= 26:
            level = "MEDIUM"
        else:
            level = "LOW"

        return {
            "risk_score": risk_score,
            "risk_level": level,
            "severity": round(severity, 3),
            "asset_criticality": round(asset_criticality, 3),
            "validity_probability": round(validity, 3),
            "freshness_decay": round(freshness, 3),
            "correlation_multiplier": round(corr_mult, 3),
            "confidence": confidence,
        }
