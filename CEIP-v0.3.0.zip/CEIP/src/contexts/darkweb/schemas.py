"""Dark web intelligence Pydantic schemas."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class FindingResponse(BaseModel):
    id: UUID
    domain: str
    finding_type: str
    confidence: float
    severity: str
    risk_score: float
    source_reference: str | None = None
    model_config = {"from_attributes": True}


class ScanSummary(BaseModel):
    domain: str
    total_findings: int
    highest_severity: str
    critical: int
    high: int
    medium: int
    low: int
    credential_exposures: int
    executive_mentions: int
    findings: list[FindingResponse] = []
