"""Entity resolution — normalize, deduplicate, assign canonical IDs."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Any

from .normalization import NormalizedDarkWebEvidence


@dataclass
class CanonicalEntity:
    """A deduplicated entity with canonical ID and cluster assignment."""

    canonical_entity_id: str
    entity_type: str
    normalized_value: str
    entity_cluster: str = ""
    source_count: int = 1
    confidence: float = 0.5
    aliases: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)


class EntityResolver:
    """Deterministic entity resolution across dark web sources."""

    def __init__(self) -> None:
        self._entities: dict[str, CanonicalEntity] = {}

    def resolve(
        self, evidence_list: list[NormalizedDarkWebEvidence]
    ) -> dict[str, Any]:
        if not evidence_list:
            return {"error": "ENTITY_RESOLUTION_FAILED", "reason": "No evidence provided"}

        try:
            for ev in evidence_list:
                norm_val = self._normalize(ev.artifact_type, ev.artifact_value)
                entity_type = self._classify_type(ev.artifact_type)
                key = f"{entity_type}:{norm_val}"

                if key in self._entities:
                    existing = self._entities[key]
                    existing.source_count += 1
                    if ev.source not in existing.sources:
                        existing.sources.append(ev.source)
                    if ev.artifact_value not in existing.aliases:
                        existing.aliases.append(ev.artifact_value)
                    existing.confidence = max(existing.confidence, ev.confidence)
                else:
                    canonical_id = hashlib.sha256(
                        f"{entity_type}:{norm_val}".encode()
                    ).hexdigest()[:16]
                    cluster = self._cluster_key(entity_type, norm_val)
                    self._entities[key] = CanonicalEntity(
                        canonical_entity_id=canonical_id,
                        entity_type=entity_type,
                        normalized_value=norm_val,
                        entity_cluster=cluster,
                        source_count=1,
                        confidence=ev.confidence,
                        aliases=[ev.artifact_value],
                        sources=[ev.source],
                    )

            entities = list(self._entities.values())
            return {
                "total_entities": len(entities),
                "entities": [
                    {
                        "canonical_entity_id": e.canonical_entity_id,
                        "entity_type": e.entity_type,
                        "normalized_value": e.normalized_value,
                        "entity_cluster": e.entity_cluster,
                        "source_count": e.source_count,
                        "confidence": e.confidence,
                        "sources": e.sources,
                    }
                    for e in entities
                ],
            }
        except Exception as exc:
            return {"error": "ENTITY_RESOLUTION_FAILED", "reason": str(exc)}

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize(artifact_type: str, value: str) -> str:
        v = value.lower().strip()
        at = artifact_type.lower()
        if "email" in at or "credential" in at:
            v = v.split("@")[-1] if "@" in v else v
        return v

    @staticmethod
    def _classify_type(artifact_type: str) -> str:
        at = artifact_type.lower()
        if any(k in at for k in ("email", "credential", "password", "username")):
            return "email"
        if "api" in at:
            return "api_key"
        if "cloud" in at:
            return "cloud_key"
        if any(k in at for k in ("source_code", "database", "document")):
            return "data"
        return "domain"

    @staticmethod
    def _cluster_key(entity_type: str, value: str) -> str:
        return hashlib.sha256(
            f"cluster:{entity_type}:{value}".encode()
        ).hexdigest()[:12]
