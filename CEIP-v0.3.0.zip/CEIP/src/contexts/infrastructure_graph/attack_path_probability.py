"""Attack path probability enhancement — enriches deterministic paths.

Read-only. No new paths created. Only enriches existing validated paths.
"""

from __future__ import annotations

from typing import Any


class AttackPathProbability:
    """Extends deterministic attack paths with probabilistic scores.

    Does NOT create paths. Does NOT modify graph structure.
    """

    def enrich(
        self, attack_paths: list[dict[str, Any]], uncertainty: dict[str, Any]
    ) -> list[dict[str, Any]]:
        enriched = []
        for p in attack_paths:
            base = p.get("path_risk_score", 50)
            confidence = p.get("confidence", 50) / 100

            # Probability of exploitation
            freshness = uncertainty.get("data_freshness", 0.5)
            maturity = uncertainty.get("exploit_maturity", 0.3)
            prob_exploit = round(
                confidence * 0.4 + maturity * 0.35 + freshness * 0.25, 3
            )

            # Confidence interval
            ci_low = max(0.0, prob_exploit - 0.15)
            ci_high = min(1.0, prob_exploit + 0.15)

            enriched.append({
                **p,
                "base_deterministic_score": base,
                "probability_of_exploitation": prob_exploit,
                "success_probability": prob_exploit,
                "failure_probability": round(1.0 - prob_exploit, 3),
                "confidence_interval": {"low": round(ci_low, 3), "high": round(ci_high, 3)},
                "confidence_distribution": {
                    "mean": prob_exploit,
                    "variance": round((ci_high - ci_low) / 2, 3),
                },
                "uncertainty_factors": [
                    f"data_freshness={freshness:.2f}",
                    f"exploit_maturity={maturity:.2f}",
                    f"signal_strength={uncertainty.get('signal_strength', 0.5):.2f}",
                    f"mapping_reliability={uncertainty.get('mapping_reliability', 0.5):.2f}",
                ],
            })
        return enriched
