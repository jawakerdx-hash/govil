"""Threat intelligence ingestion — normalizes APT, malware, IOC data."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from .threat_entity import ThreatEntity

KNOWN_APTS = ["APT28", "APT29", "APT41", "Lazarus", "Kimsuky", "Charming Kitten"]
KNOWN_MALWARE = ["Emotet", "TrickBot", "Cobalt Strike", "BazarLoader", "QakBot"]


class ThreatIngestionEngine:
    """Reads threat intelligence from repositories, normalizes to ThreatEntity.

    All data read-only from existing threat context. No new scanning.
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def ingest(self, domain: str) -> list[dict[str, Any]]:
        now = datetime.now(UTC).isoformat()
        threats: list[dict[str, Any]] = []

        matches = await self._load_threat_matches(domain)

        for m in matches:
            threat_type = self._classify_threat(m)
            threats.append(ThreatEntity(
                threat_id=hashlib.sha256(f"threat:{domain}:{m.get('asset','')}".encode()).hexdigest()[:16],
                threat_type=threat_type,
                attribution_confidence=m.get("confidence", 0.5),
                observed_iocs=[m.get("asset", "")] if m.get("asset") else [],
                tactics=self._infer_tactics(m),
                targets=[domain],
                first_seen=now, last_seen=now,
                metadata={"source": m.get("source", "threat_intel")},
            ).to_dict())

        return threats

    async def _load_threat_matches(self, domain: str) -> list[dict[str, Any]]:
        try:
            from sqlalchemy import select

            from src.contexts.threat.models import ThreatMatch
            r = await self._db.execute(
                select(ThreatMatch).where(ThreatMatch.domain == domain)
            )
            return [
                {"asset": m.matched_asset, "severity": m.severity,
                 "threat_category": m.threat_category, "match_type": m.match_type,
                 "confidence": 0.7}
                for m in r.scalars().all()
            ]
        except Exception:
            return []

    @staticmethod
    def _classify_threat(match: dict[str, Any]) -> str:
        category = match.get("threat_category", "").lower()
        if any(a.lower() in category for a in KNOWN_APTS):
            return "apt"
        if any(mw.lower() in category for mw in KNOWN_MALWARE):
            return "malware"
        if "botnet" in category:
            return "botnet"
        return "ioc_cluster"

    @staticmethod
    def _infer_tactics(match: dict[str, Any]) -> list[str]:
        category = match.get("threat_category", "").lower()
        tactics = []
        if "phish" in category or "credential" in category:
            tactics.append("credential_access")
        if "exploit" in category or "cve" in category:
            tactics.append("exploitation")
        if "malware" in category or "ransom" in category:
            tactics.append("execution")
        if "c2" in category or "command" in category:
            tactics.append("command_and_control")
        return tactics or ["unknown"]
