"""Uncertainty Engine — evaluates data freshness, CVE maturity, signal ambiguity.

All scores 0-1. Read-only on existing data. No structural changes.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

CVE_MATURITY = {
    "weaponized": 0.95, "poc_available": 0.75, "exploit_public": 0.60,
    "theoretical": 0.30, "unknown": 0.20,
}


class UncertaintyEngine:
    """Evaluates uncertainty factors for probabilistic risk enhancement.

    Factors: data_freshness, exploit_maturity, signal_strength, mapping_reliability.
    Each returns 0-1 where higher = less uncertainty (more confidence).
    """

    def evaluate(
        self,
        vuln_nodes: list[dict[str, Any]],
        attack_paths: list[dict[str, Any]],
        cross_mappings: list[dict[str, Any]],
    ) -> dict[str, Any]:
        return {
            "data_freshness": self._freshness_score(vuln_nodes),
            "exploit_maturity": self._exploit_maturity(vuln_nodes),
            "signal_strength": self._signal_strength(attack_paths),
            "mapping_reliability": self._mapping_reliability(cross_mappings),
        }

    @staticmethod
    def _freshness_score(vuln_nodes: list[dict[str, Any]]) -> float:
        if not vuln_nodes:
            return 0.5
        now = datetime.now(UTC)
        scores = []
        for v in vuln_nodes:
            last = v.get("last_seen", "")
            if last:
                try:
                    days = (now - datetime.fromisoformat(last)).days
                    s = max(0.1, 1.0 - days / 365)  # 1 year → 0
                    scores.append(s)
                except (ValueError, TypeError):
                    scores.append(0.5)
        return round(sum(scores) / len(scores), 3) if scores else 0.5

    @staticmethod
    def _exploit_maturity(vuln_nodes: list[dict[str, Any]]) -> float:
        if not vuln_nodes:
            return 0.3
        scores = []
        for v in vuln_nodes:
            maturity = v.get("metadata", {}).get("exploit_maturity", "unknown")
            scores.append(CVE_MATURITY.get(maturity, 0.2))
        return round(sum(scores) / len(scores), 3)

    @staticmethod
    def _signal_strength(attack_paths: list[dict[str, Any]]) -> float:
        if not attack_paths:
            return 0.3
        strengths = [p.get("confidence", 50) / 100 for p in attack_paths]
        return round(sum(strengths) / len(strengths), 3)

    @staticmethod
    def _mapping_reliability(cross_mappings: list[dict[str, Any]]) -> float:
        if not cross_mappings:
            return 0.3
        rels = [m.get("confidence_score", 50) / 100 for m in cross_mappings]
        return round(sum(rels) / len(rels), 3)
