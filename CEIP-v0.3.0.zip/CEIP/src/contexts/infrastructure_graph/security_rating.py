"""M24 - External Security Rating Engine. Product layer on M20-M23.

Reads intelligence pipeline output, produces 0-100 rating.
Fully deterministic, explainable, auditable. No black-box scoring.
"""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any

GRADE_SCALE = {
    (90, 100): ("A", "Excellent security posture"),
    (75, 89): ("B", "Good security posture with minor gaps"),
    (60, 74): ("C", "Adequate security, notable improvements needed"),
    (40, 59): ("D", "Below average, significant gaps"),
    (0, 39): ("E", "Critical security deficiencies"),
}

DEFAULT_WEIGHTS = {
    "attack_surface": 0.20, "vulnerability": 0.20,
    "exposure": 0.15, "identity_risk": 0.10,
    "threat_activity": 0.15, "cloud_risk": 0.10,
    "dark_web": 0.10,
}


class SecurityRatingEngine:
    """Transforms CEIP intelligence into an enterprise security rating.

    Consumes M20-M23 outputs. Never modifies underlying layers.
    """

    def __init__(self, weights: dict[str, float] | None = None) -> None:
        self._weights = {**DEFAULT_WEIGHTS, **(weights or {})}
        # Validate weights sum to 1.0
        total = sum(self._weights.values())
        if abs(total - 1.0) > 0.01:
            # Normalize
            self._weights = {k: v / total for k, v in self._weights.items()}

    def rate(self, pipeline_output: dict[str, Any]) -> dict[str, Any]:
        """Compute external security rating from pipeline output."""

        # Extract data from pipeline layers
        infra = pipeline_output.get("infrastructure_graph", {})
        vuln_graph = pipeline_output.get("vulnerability_graph", {})
        intel_graph = pipeline_output.get("intelligence_graph", {})
        attack_paths = pipeline_output.get("attack_feasibility_paths", [])
        prob_layer = pipeline_output.get("probabilistic_layer", {})
        threat_intel = pipeline_output.get("threat_intelligence", {})

        # 1. Attack Surface Score
        attack_surface = self._score_attack_surface(infra)

        # 2. Vulnerability Score
        vulnerability = self._score_vulnerability(vuln_graph, attack_paths)

        # 3. Exposure Score
        exposure = self._score_exposure(infra, intel_graph)

        # 4. Identity Risk Score
        identity = self._score_identity(intel_graph)

        # 5. Threat Activity Score
        threat = self._score_threat(threat_intel)

        # 6. Cloud & Infrastructure Risk
        cloud = self._score_cloud(infra)

        # 7. Dark Web Risk
        darkweb = self._score_darkweb(intel_graph, threat_intel)

        # Compute dimensions
        dimensions = {
            "attack_surface_score": attack_surface,
            "vulnerability_score": vulnerability,
            "exposure_score": exposure,
            "identity_risk_score": identity,
            "threat_activity_score": threat,
            "cloud_risk_score": cloud,
            "dark_web_risk_score": darkweb,
        }

        # M22 probabilistic amplifier (0.8-1.2)
        risk_dist = prob_layer.get("risk_distribution", {})
        confidence = risk_dist.get("mean", 0.5)
        amplifier = 0.8 + confidence * 0.4  # 0.8-1.2

        # Weighted final score
        overall = sum(
            dimensions[k] * self._weights.get(k, 0.1) for k in dimensions
        )
        overall = round(min(100, max(0, overall * amplifier)), 1)

        # Grade
        grade, description = "E", "Critical deficiencies"
        for (lo, hi), (g, d) in GRADE_SCALE.items():
            if lo <= overall <= hi:
                grade, description = g, d
                break

        # Risk level
        if overall >= 75:
            risk_level = "low"
        elif overall >= 50:
            risk_level = "medium"
        elif overall >= 30:
            risk_level = "high"
        else:
            risk_level = "critical"

        # Key drivers (lowest dimensions)
        sorted_dims = sorted(dimensions.items(), key=lambda x: x[1])
        key_drivers = [
            {"dimension": k, "score": v, "impact": "negative" if v < 50 else "positive"}
            for k, v in sorted_dims[:3]
        ]

        # Trend (from probability comparison)
        det_base = pipeline_output.get("unified_risk_score", 50)
        trend = "stable"
        if overall > det_base + 5:
            trend = "improving"
        elif overall < det_base - 5:
            trend = "worsening"

        return {
            "organization": "",  # populated by caller
            "external_security_rating": {
                "overall_score": overall,
                "grade": grade,
                "risk_level": risk_level,
                "dimension_scores": {
                    k: {
                        "value": v,
                        "top_factors": self._top_factors(k, pipeline_output),
                        "evidence": self._evidence_for(k, pipeline_output),
                    }
                    for k, v in dimensions.items()
                },
                "key_drivers": key_drivers,
                "risk_explanation": (
                    f"Overall score {overall}/100 ({grade}). {description}. "
                    f"Top weaknesses: {', '.join(d['dimension'] for d in key_drivers if d['impact'] == 'negative')}. "
                    f"Confidence amplifier: {amplifier:.2f}"
                ),
                "trend": trend,
            },
        }

    # ------------------------------------------------------------------
    # Dimension scorers — deterministic, evidence-backed
    # ------------------------------------------------------------------

    @staticmethod
    def _score_attack_surface(infra: dict) -> float:
        nodes = infra.get("nodes", [])
        if not nodes:
            return 50
        svc_count = sum(1 for n in nodes if n.get("node_type") == "service")
        score = max(20, 100 - svc_count * 3)
        return round(min(100, score), 1)

    @staticmethod
    def _score_vulnerability(vuln_graph: dict, attack_paths: list) -> float:
        nodes = vuln_graph.get("nodes", [])
        if not nodes:
            return 50
        sev_map = {"critical": 95, "high": 75, "medium": 50, "low": 25}
        sevs = [sev_map.get(n.get("severity", "low"), 25) for n in nodes]
        base = sum(sevs) / len(sevs) if sevs else 50
        # Attack path penalty
        path_penalty = min(20, len(attack_paths) * 5)
        return round(max(10, base - path_penalty), 1)

    @staticmethod
    def _score_exposure(infra: dict, intel_graph: dict) -> float:
        signals = intel_graph.get("nodes", [])
        infra_nodes = infra.get("nodes", [])
        exposed = sum(1 for n in infra_nodes if n.get("metadata", {}).get("risk_surface_score", 0) > 50)
        score = max(15, 100 - exposed * 5 - len(signals) * 3)
        return round(min(100, score), 1)

    @staticmethod
    def _score_identity(intel_graph: dict) -> float:
        nodes = intel_graph.get("nodes", [])
        if not nodes:
            return 70
        identities = sum(1 for n in nodes if n.get("node_type") == "identity_entity")
        score = max(20, 100 - identities * 10)
        return round(min(100, score), 1)

    @staticmethod
    def _score_threat(threat_intel: dict) -> float:
        campaigns = threat_intel.get("active_campaigns", [])
        profiles = threat_intel.get("adversary_profiles", [])
        iocs = threat_intel.get("ioc_clusters", [])
        penalty = len(campaigns) * 10 + len(profiles) * 8 + len(iocs) * 3
        return round(max(10, 100 - penalty), 1)

    @staticmethod
    def _score_cloud(infra: dict) -> float:
        nodes = infra.get("nodes", [])
        cloud = sum(1 for n in nodes if n.get("node_type") == "cloud_resource")
        score = max(30, 100 - cloud * 5)
        return round(min(100, score), 1)

    @staticmethod
    def _score_darkweb(intel_graph: dict, threat_intel: dict) -> float:
        nodes = intel_graph.get("nodes", [])
        darkweb_signals = sum(1 for n in nodes if n.get("node_type") == "darkweb_signal")
        score = max(10, 100 - darkweb_signals * 8)
        return round(min(100, score), 1)

    # ------------------------------------------------------------------
    # Explainability
    # ------------------------------------------------------------------

    @staticmethod
    def _top_factors(dimension: str, output: dict) -> list[str]:
        factors = {
            "attack_surface": ["exposed_services", "open_ports", "public_ips"],
            "vulnerability": ["cve_severity", "exploit_availability", "patch_lag"],
            "exposure": ["misconfigurations", "public_leaks", "sensitive_signals"],
            "identity_risk": ["email_exposure", "credential_leaks", "identity_correlation"],
            "threat_activity": ["active_campaigns", "apt_targeting", "ioc_proximity"],
            "cloud_risk": ["misconfigured_cloud", "exposed_storage", "cloud_attack_surface"],
            "dark_web": ["leaked_credentials", "mentions", "marketplace_signals"],
        }
        return factors.get(dimension, ["unknown"])

    @staticmethod
    def _evidence_for(dimension: str, output: dict) -> list[str]:
        evidence = []
        if dimension == "attack_surface":
            infra = output.get("infrastructure_graph", {})
            evidence.append(f"{len(infra.get('nodes', []))} infrastructure nodes")
        if dimension == "vulnerability":
            vuln = output.get("vulnerability_graph", {})
            evidence.append(f"{len(vuln.get('nodes', []))} vulnerability nodes")
        if dimension == "threat_activity":
            ti = output.get("threat_intelligence", {})
            evidence.append(f"{len(ti.get('active_campaigns', []))} active campaigns")
        return evidence
