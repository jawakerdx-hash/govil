"""M27 — Brand Protection & Dark Web Expansion Engine.

Consumes M20-M26 pipeline output. Correlates existing brand/darkweb/identity
data into structured intelligence views. Read-only. Never invents data.
"""

from __future__ import annotations

from typing import Any


class BrandDarkWebExpansion:
    """Expands CEIP into external brand + identity + dark web intelligence.

    All data from existing contexts. Only correlation + enrichment.
    """

    BRAND_ABUSE_PATTERNS = ("typosquatting", "homograph", "lookalike", "brand_abuse")
    DARKWEB_SIGNAL_TYPES = (
        "credential_leak", "api_key_exposure", "database_dump",
        "source_code_leak", "telegram_mention", "paste_site_mention",
        "forum_mention", "marketplace_mention",
    )

    def expand(self, pipeline_output: dict[str, Any]) -> dict[str, Any]:
        threat_intel = pipeline_output.get("threat_intelligence", {})
        intel_graph = pipeline_output.get("intelligence_graph", {})
        infra = pipeline_output.get("infrastructure_graph", {})
        mappings = pipeline_output.get("cross_graph_mappings", [])
        prob_layer = pipeline_output.get("probabilistic_layer", {})

        return {
            "brand_intelligence": self._build_brand_intel(infra, threat_intel, mappings),
            "dark_web_intelligence": self._build_darkweb_intel(intel_graph, threat_intel),
            "identity_intelligence": self._build_identity_intel(intel_graph, prob_layer),
            "threat_linkage": self._build_threat_linkage(threat_intel, mappings, infra),
            "risk_expansion_summary": self._build_summary(intel_graph, threat_intel, infra),
        }

    # ------------------------------------------------------------------
    # Brand Intelligence
    # ------------------------------------------------------------------

    def _build_brand_intel(self, infra: dict, threat: dict, mappings: list) -> dict:
        nodes = infra.get("nodes", [])
        impersonation = []
        phishing = []
        lookalike = []

        for n in nodes:
            meta = n.get("metadata", {})
            signals = meta.get("exposure_signals", [])
            if any(s in self.BRAND_ABUSE_PATTERNS for s in signals):
                impersonation.append({
                    "asset_id": n.get("node_id", ""),
                    "value": n.get("value", ""),
                    "signals": signals,
                    "risk": meta.get("risk_surface_score", 50),
                })
            if "admin_panel" in signals or "api_endpoint" in signals:
                phishing.append({
                    "asset_id": n.get("node_id", ""),
                    "value": n.get("value", ""),
                    "type": "potential_phishing_infrastructure",
                })

        # Lookalike domains from clustering
        clusters = infra.get("clusters", [])
        for c in clusters:
            members = c.get("member_nodes", [])
            if len(members) >= 2:
                lookalike.append({
                    "cluster_id": c.get("cluster_id", ""),
                    "type": c.get("cluster_type", "unknown"),
                    "members": members,
                })

        # Threat-linked brand abuse
        campaigns = threat.get("active_campaigns", [])
        for camp in campaigns:
            if any(p in str(camp.get("attack_phases", [])) for p in ("credential", "phish")):
                impersonation.append({
                    "campaign_id": camp.get("campaign_id", ""),
                    "threat_type": "campaign_linked_impersonation",
                    "confidence": camp.get("confidence_score", 0.5),
                })

        return {
            "impersonation_assets": impersonation,
            "phishing_infrastructure": phishing,
            "lookalike_domains": lookalike,
        }

    # ------------------------------------------------------------------
    # Dark Web Intelligence
    # ------------------------------------------------------------------

    def _build_darkweb_intel(self, intel_graph: dict, threat: dict) -> dict:
        nodes = intel_graph.get("nodes", [])
        leak_clusters = []
        exposed_creds = []
        breach_sources = []

        for n in nodes:
            ntype = n.get("node_type", "")
            meta = n.get("metadata", {})
            signal_type = meta.get("entity_type", ntype)

            if signal_type in ("credential_entity", "identity_entity"):
                exposed_creds.append({
                    "entity_id": n.get("node_id", ""),
                    "type": signal_type,
                    "value": n.get("value", "")[:50],  # Truncate for safety
                    "confidence": meta.get("confidence", 0.5),
                })

            if signal_type in ("exposure_event", "darkweb_signal"):
                leak_clusters.append({
                    "cluster_id": n.get("node_id", ""),
                    "signals": meta.get("sources", []),
                    "severity": "HIGH" if meta.get("confidence", 0) > 0.7 else "MEDIUM",
                })

        # Breach data sources from threat campaigns
        campaigns = threat.get("active_campaigns", [])
        for camp in campaigns:
            if any(s in str(camp).lower() for s in ("breach", "leak", "dump", "exposure")):
                breach_sources.append({
                    "campaign_id": camp.get("campaign_id", ""),
                    "type": "breach_campaign",
                    "confidence": camp.get("confidence_score", 0.5),
                })

        return {
            "leak_clusters": leak_clusters,
            "exposed_credentials": exposed_creds[:20],
            "data_breach_sources": breach_sources,
        }

    # ------------------------------------------------------------------
    # Identity Intelligence
    # ------------------------------------------------------------------

    def _build_identity_intel(self, intel_graph: dict, prob_layer: dict) -> dict:
        nodes = intel_graph.get("nodes", [])
        exposed = []
        clusters = []
        reuse_risks = []

        identity_nodes = [
            n for n in nodes
            if n.get("node_type") in ("identity_entity", "credential_entity")
        ]

        for n in identity_nodes:
            exposed.append({
                "entity_id": n.get("node_id", ""),
                "value": n.get("value", "")[:50],
                "type": n.get("node_type", ""),
            })

        # Identity clusters from groups
        grouped: dict[str, list[str]] = {}
        for n in identity_nodes:
            val = n.get("value", "")[:20]
            if val:
                grouped.setdefault(val[:10], []).append(n.get("node_id", ""))

        for key, members in grouped.items():
            if len(members) >= 2:
                clusters.append({
                    "cluster_key": key,
                    "members": members,
                    "exposure_severity": "HIGH" if len(members) > 3 else "MEDIUM",
                })

        # Credential reuse probability from M22
        risk_dist = prob_layer.get("risk_distribution", {})
        reuse_prob = risk_dist.get("mean", 0.5)
        reuse_risks.append({
            "risk_type": "credential_reuse",
            "probability": round(reuse_prob, 3),
            "affected_entities": len(identity_nodes),
        })

        return {
            "exposed_individuals": exposed[:20],
            "identity_clusters": clusters[:10],
            "credential_reuse_risk": reuse_risks,
        }

    # ------------------------------------------------------------------
    # Threat Linkage
    # ------------------------------------------------------------------

    def _build_threat_linkage(self, threat: dict, mappings: list, infra: dict) -> dict:
        campaign_maps = []
        infra_links = []

        for camp in threat.get("active_campaigns", []):
            for target in camp.get("targeted_assets", []):
                campaign_maps.append({
                    "campaign_id": camp.get("campaign_id", ""),
                    "target": target,
                    "confidence": camp.get("confidence_score", 0.5),
                })

        infra_nodes = infra.get("nodes", [])
        for m in mappings[:20]:
            src = m.get("source_node_id", "")
            tgt = m.get("target_node_id", "")
            src_node = next((n for n in infra_nodes if n.get("node_id") == src), {})
            infra_links.append({
                "source": src,
                "target": tgt,
                "mapping_type": m.get("mapping_type", ""),
                "source_value": src_node.get("value", ""),
                "confidence": m.get("confidence_score", 50),
            })

        return {
            "campaign_mappings": campaign_maps,
            "infrastructure_links": infra_links,
        }

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def _build_summary(self, intel_graph: dict, threat: dict, infra: dict) -> dict:
        findings = []
        new_risks = []

        intel_nodes = intel_graph.get("nodes", [])
        identity_count = sum(
            1 for n in intel_nodes
            if n.get("node_type") in ("identity_entity", "credential_entity")
        )
        if identity_count > 0:
            findings.append(f"{identity_count} identity/credential entities exposed")
            new_risks.append("Identity exposure risk identified")

        campaigns = threat.get("active_campaigns", [])
        if campaigns:
            findings.append(f"{len(campaigns)} active threat campaigns")
            new_risks.append("Active campaign targeting detected")

        infra_nodes = infra.get("nodes", [])
        svc_count = sum(1 for n in infra_nodes if n.get("node_type") == "service")
        if svc_count > 5:
            new_risks.append(f"Large attack surface: {svc_count} exposed services")

        return {
            "key_findings": [{"finding": f} for f in findings],
            "new_risks_identified": [{"risk": r} for r in new_risks],
        }
