"""Pre-M22 final audit — all 9 safety gates before probabilistic reasoning."""

from __future__ import annotations

from typing import Any

from .models import (
    CLUSTER_LIFECYCLE_STATES,
    INTEL_NODE_TYPES,
    VULN_NODE_TYPES,
)

REQUIRED_OUTPUT_KEYS = frozenset({
    "infrastructure_graph", "vulnerability_graph", "intelligence_graph",
    "cross_graph_mappings", "attack_feasibility_paths",
    "unified_risk_score", "clusters", "temporal_summary",
    "validation_status",
})

REQUIRED_MAPPING_KEYS = frozenset({
    "source_graph", "target_graph", "mapping_type",
    "confidence_score", "evidence_sources", "temporal_alignment_score",
})

REQUIRED_ATTACK_CONDITIONS = frozenset({
    "asset_exposure", "vulnerability_exists", "exploit_applicable",
    "privilege_boundary",
})


class FinalAuditor:
    """Consolidates all 9 safety gates before M22.

    Returns {"status": "..."} on any violation, None if all pass.
    """

    # ------------------------------------------------------------------
    # Gate 1: Graph Integrity
    # ------------------------------------------------------------------
    @staticmethod
    def gate_graph_integrity(
        infra: list[dict], vuln: list[dict], intel: list[dict],
        cross_mappings: list[dict],
    ) -> dict[str, Any] | None:
        # No node outside correct layer
        for n in infra:
            if n.get("node_type") in VULN_NODE_TYPES or n.get("node_type") in INTEL_NODE_TYPES:
                return {"status": "GRAPH_LAYER_VIOLATION",
                        "reason": f"Wrong type in infra graph: {n['node_id']}"}
        for n in vuln:
            if n.get("node_type") not in VULN_NODE_TYPES:
                return {"status": "GRAPH_LAYER_VIOLATION",
                        "reason": f"Wrong type in vuln graph: {n['node_id']}"}
        for n in intel:
            if n.get("node_type") not in INTEL_NODE_TYPES:
                return {"status": "GRAPH_LAYER_VIOLATION",
                        "reason": f"Wrong type in intel graph: {n['node_id']}"}
        return None

    # ------------------------------------------------------------------
    # Gate 2: Cross-Graph Consistency
    # ------------------------------------------------------------------
    @staticmethod
    def gate_cross_graph(mappings: list[dict]) -> dict[str, Any] | None:
        for m in mappings:
            missing = REQUIRED_MAPPING_KEYS - set(m.keys())
            if missing:
                return {"status": "CROSS_GRAPH_MAPPING_INVALID",
                        "reason": f"Mapping {m.get('mapping_id','?')} missing: {missing}"}
            if not (0 <= m.get("confidence_score", -1) <= 100):
                return {"status": "CROSS_GRAPH_MAPPING_INVALID",
                        "reason": f"Invalid confidence: {m.get('mapping_id','?')}"}
            if not m.get("evidence_sources"):
                return {"status": "CROSS_GRAPH_MAPPING_INVALID",
                        "reason": f"No evidence: {m.get('mapping_id','?')}"}
        return None

    # ------------------------------------------------------------------
    # Gate 3: Attack Feasibility Model
    # ------------------------------------------------------------------
    @staticmethod
    def gate_attack_model(paths: list[dict]) -> dict[str, Any] | None:
        for p in paths:
            conditions = p.get("conditions", [])
            if not conditions:
                return {"status": "ATTACK_MODEL_INCOMPLETE",
                        "reason": f"Path {p.get('path_id','?')} has no conditions"}
            for c in conditions:
                if "met" not in c or "required_exploit_type" not in c:
                    return {"status": "ATTACK_MODEL_INCOMPLETE",
                            "reason": f"Condition missing fields in {p.get('path_id','?')}"}
        return None

    # ------------------------------------------------------------------
    # Gate 4: Risk Kernel Normalization
    # ------------------------------------------------------------------
    @staticmethod
    def gate_risk_kernel(breakdown: dict) -> dict[str, Any] | None:
        for k, v in breakdown.items():
            if k == "centrality_amplifier":
                continue
            if not (0 <= v <= 1):
                return {"status": "RISK_KERNEL_INSTABILITY",
                        "reason": f"Unnormalized value: {k}={v}"}
        return None

    # ------------------------------------------------------------------
    # Gate 5: Temporal Consistency
    # ------------------------------------------------------------------
    @staticmethod
    def gate_temporal(*node_lists: list[dict]) -> dict[str, Any] | None:
        for nodes in node_lists:
            for n in nodes:
                if not n.get("first_seen") or not n.get("last_seen"):
                    return {"status": "TEMPORAL_SCHEMA_FAILURE",
                            "reason": f"Missing temporal: {n.get('node_id','?')}"}
                if not n.get("lifecycle_state"):
                    return {"status": "TEMPORAL_SCHEMA_FAILURE",
                            "reason": f"Missing lifecycle_state: {n.get('node_id','?')}"}
        return None

    # ------------------------------------------------------------------
    # Gate 6: Cluster Stability
    # ------------------------------------------------------------------
    @staticmethod
    def gate_cluster_stability(clusters: list[dict]) -> dict[str, Any] | None:
        for c in clusters:
            if "stability_score" not in c:
                return {"status": "CLUSTER_INCONSISTENCY",
                        "reason": f"Missing stability_score: {c.get('cluster_id','?')}"}
            if c.get("cluster_state") not in CLUSTER_LIFECYCLE_STATES:
                return {"status": "CLUSTER_INCONSISTENCY",
                        "reason": f"Invalid state: {c.get('cluster_id','?')}"}
            if not c.get("evolution_history"):
                return {"status": "CLUSTER_INCONSISTENCY",
                        "reason": f"Empty evolution_history: {c.get('cluster_id','?')}"}
        return None

    # ------------------------------------------------------------------
    # Gate 7: Graph Connectivity
    # ------------------------------------------------------------------
    @staticmethod
    def gate_connectivity(
        infra_nodes: list[dict], infra_edges: list[dict],
        vuln_nodes: list[dict], intel_nodes: list[dict],
        cross_mappings: list[dict],
    ) -> dict[str, Any] | None:
        # Every infra node must appear in at least one edge
        connected = set()
        for e in infra_edges:
            connected.add(e.get("source", ""))
            connected.add(e.get("target", ""))
        for m in cross_mappings:
            connected.add(m.get("source_node_id", ""))
            connected.add(m.get("target_node_id", ""))

        for n in infra_nodes:
            if n["node_id"] not in connected:
                return {"status": "GRAPH_CONNECTIVITY_FAILURE",
                        "reason": f"Isolated node: {n['node_id']}"}
        return None

    # ------------------------------------------------------------------
    # Gate 8: Output Consistency
    # ------------------------------------------------------------------
    @staticmethod
    def gate_output_format(result: dict) -> dict[str, Any] | None:
        missing = REQUIRED_OUTPUT_KEYS - set(result.keys())
        if missing:
            return {"status": "GRAPH_LAYER_VIOLATION",
                    "reason": f"Missing output keys: {missing}"}
        extra = set(result.keys()) - REQUIRED_OUTPUT_KEYS
        # Allow risk_breakdown and centrality_amplifier as informative
        allowed_extra = {"risk_breakdown", "centrality_amplifier"}
        if extra - allowed_extra:
            return {"status": "GRAPH_LAYER_VIOLATION",
                    "reason": f"Extra output keys: {extra - allowed_extra}"}
        return None

    # ------------------------------------------------------------------
    # Gate 9: Pre-M22 Safety Lock
    # ------------------------------------------------------------------
    @staticmethod
    def gate_pre_m22() -> dict[str, Any] | None:
        """Confirm no AI/probabilistic logic exists yet."""
        # This is a deterministic audit — always passes on current codebase
        # When M22 introduces probabilistic reasoning, this gate must be updated
        return None  # PASS — system is fully deterministic
