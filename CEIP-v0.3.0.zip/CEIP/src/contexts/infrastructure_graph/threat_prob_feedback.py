"""Threat-enhanced probabilistic feedback — enriches M22 without modifying it.

Adds: threat_presence_factor, campaign_activity_multiplier, adversary_relevance_score.
These ONLY influence the probabilistic layer, NOT deterministic risk.
"""

from __future__ import annotations

from typing import Any


class ThreatProbabilisticFeedback:
    """Enhances M22 probabilistic layer with threat intelligence.

    Read-only on M22. Adds threat-derived factors to probability estimates.
    """

    def compute(
        self,
        threats: list[dict[str, Any]],
        campaigns: list[dict[str, Any]],
        adversary_profiles: list[dict[str, Any]],
        probabilistic_layer: dict[str, Any],
    ) -> dict[str, Any]:
        # 1. Threat presence factor — how many active threats
        threat_presence = min(1.0, len(threats) * 0.1)

        # 2. Campaign activity multiplier — active campaigns amplify risk
        campaign_mult = 1.0
        if campaigns:
            campaign_conf = sum(c.get("confidence_score", 0.5) for c in campaigns) / len(campaigns)
            campaign_mult = 1.0 + campaign_conf * 0.3  # max 1.3x

        # 3. Adversary relevance — APT attribution confidence
        adversary_relevance = 0.0
        if adversary_profiles:
            adversary_relevance = sum(
                a.get("confidence", 0.5) for a in adversary_profiles
            ) / len(adversary_profiles)

        # Get existing probabilistic risk from M22
        risk_dist = probabilistic_layer.get("risk_distribution", {})
        existing_prob = risk_dist.get("probabilistic_enhanced", 50) / 100

        # Enhance with threat factors (only affects probabilistic, not deterministic)
        enhanced_prob = min(1.0, existing_prob * (1.0 + threat_presence * 0.2) * campaign_mult)
        if adversary_relevance > 0.5:
            enhanced_prob = min(1.0, enhanced_prob * (1.0 + adversary_relevance * 0.15))

        return {
            "threat_presence_factor": round(threat_presence, 3),
            "campaign_activity_multiplier": round(campaign_mult, 3),
            "adversary_relevance_score": round(adversary_relevance, 3),
            "threat_enhanced_probability": round(enhanced_prob * 100, 1),
            "active_threat_count": len(threats),
            "active_campaign_count": len(campaigns),
        }
