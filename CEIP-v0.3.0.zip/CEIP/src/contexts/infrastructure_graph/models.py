"""Strict 3-layer graph model — no mixed semantics."""
# ruff: noqa: E501

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# Graph layer types — NEVER mixed across graphs
# ---------------------------------------------------------------------------

INFRA_NODE_TYPES = frozenset({
    "organization", "asset", "domain", "subdomain", "ip_address",
    "cidr_block", "cloud_resource", "service", "load_balancer",
    "vpn_gateway", "storage_bucket", "dns_server", "mail_server",
})

VULN_NODE_TYPES = frozenset({
    "cve", "misconfiguration", "weak_crypto", "exposed_service_vuln",
})

INTEL_NODE_TYPES = frozenset({
    "credential_entity", "identity_entity", "exposure_event",
    "threat_indicator", "darkweb_signal",
})

CLUSTER_LIFECYCLE_STATES = frozenset({
    "created", "expanding", "stable", "splitting", "merging", "decaying", "dissolved",
})

CROSS_GRAPH_EDGE_TYPES = frozenset({
    "asset_has_vulnerability",      # infra → vuln
    "vulnerability_exploits_asset",  # vuln → infra
    "intelligence_indicates_asset",  # intel → infra
    "intelligence_indicates_vuln",   # intel → vuln
})


@dataclass
class GraphNode:
    node_id: str
    canonical_entity_id: str
    node_type: str
    graph_layer: str  # "infrastructure", "vulnerability", "intelligence"
    value: str = ""
    first_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    lifecycle_state: str = "active"
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate_layer(self) -> str | None:
        """Return error if node_type doesn't match graph_layer."""
        if self.graph_layer == "infrastructure" and self.node_type not in INFRA_NODE_TYPES:
            return f"Node {self.node_id}: type '{self.node_type}' not in INFRA_NODE_TYPES"
        if self.graph_layer == "vulnerability" and self.node_type not in VULN_NODE_TYPES:
            return f"Node {self.node_id}: type '{self.node_type}' not in VULN_NODE_TYPES"
        if self.graph_layer == "intelligence" and self.node_type not in INTEL_NODE_TYPES:
            return f"Node {self.node_id}: type '{self.node_type}' not in INTEL_NODE_TYPES"
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id, "canonical_entity_id": self.canonical_entity_id,
            "node_type": self.node_type, "graph_layer": self.graph_layer,
            "value": self.value, "first_seen": self.first_seen,
            "last_seen": self.last_seen, "lifecycle_state": self.lifecycle_state,
            "metadata": self.metadata,
        }


@dataclass
class GraphEdge:
    edge_id: str
    source_node_id: str
    target_node_id: str
    edge_type: str
    graph_layer: str = ""  # intra-graph or "cross_graph"
    strength_score: float = 50.0
    confidence_score: float = 50.0
    evidence_sources: list[str] = field(default_factory=list)
    first_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    temporal_weight: float = 1.0
    lifecycle_state: str = "active"

    def to_dict(self) -> dict[str, Any]:
        return {
            "edge_id": self.edge_id, "source": self.source_node_id,
            "target": self.target_node_id, "edge_type": self.edge_type,
            "graph_layer": self.graph_layer,
            "strength_score": self.strength_score,
            "confidence_score": self.confidence_score,
            "evidence_sources": self.evidence_sources,
            "first_seen": self.first_seen, "last_seen": self.last_seen,
            "temporal_weight": self.temporal_weight,
            "lifecycle_state": self.lifecycle_state,
        }


@dataclass
class CrossGraphMapping:
    mapping_id: str
    source_graph: str
    target_graph: str
    source_node_id: str
    target_node_id: str
    mapping_type: str  # from CROSS_GRAPH_EDGE_TYPES
    confidence_score: float = 50.0
    evidence_sources: list[str] = field(default_factory=list)
    temporal_alignment_score: float = 0.5

    def validate(self) -> str | None:
        if self.mapping_type not in CROSS_GRAPH_EDGE_TYPES:
            return f"Invalid mapping_type: {self.mapping_type}"
        if self.confidence_score < 0 or self.confidence_score > 100:
            return f"Invalid confidence_score: {self.confidence_score}"
        if not self.evidence_sources:
            return "Missing evidence_sources"
        if self.temporal_alignment_score < 0 or self.temporal_alignment_score > 1:
            return "Invalid temporal_alignment_score"
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "mapping_id": self.mapping_id,
            "source_graph": self.source_graph,
            "target_graph": self.target_graph,
            "source_node_id": self.source_node_id,
            "target_node_id": self.target_node_id,
            "mapping_type": self.mapping_type,
            "confidence_score": self.confidence_score,
            "evidence_sources": self.evidence_sources,
            "temporal_alignment_score": self.temporal_alignment_score,
        }


@dataclass
class InfrastructureCluster:
    cluster_id: str
    cluster_type: str  # cloud, hosting, hybrid, unknown
    member_nodes: list[str] = field(default_factory=list)
    centrality_score: float = 0.0
    exposure_density_score: float = 0.0
    cluster_state: str = "created"
    stability_score: float = 1.0
    evolution_history: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "cluster_id": self.cluster_id, "cluster_type": self.cluster_type,
            "member_nodes": self.member_nodes,
            "centrality_score": self.centrality_score,
            "exposure_density_score": self.exposure_density_score,
            "cluster_state": self.cluster_state,
            "stability_score": self.stability_score,
            "evolution_history": self.evolution_history,
        }


@dataclass
class AttackFeasibilityPath:
    path_id: str
    conditions: list[dict[str, Any]] = field(default_factory=list)
    path_risk_score: float = 0.0
    confidence: float = 50.0
    evidence_chain: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "path_id": self.path_id,
            "conditions": self.conditions,
            "path_risk_score": self.path_risk_score,
            "confidence": self.confidence,
            "evidence_chain": self.evidence_chain,
        }
