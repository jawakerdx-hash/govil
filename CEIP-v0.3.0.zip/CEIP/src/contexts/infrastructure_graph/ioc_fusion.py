"""IOC graph fusion — maps IOCs to existing entities only, no new nodes."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any


class IOCFusionEngine:
    """Maps IOCs to existing graph entities.

    IOC MUST NOT create new nodes. Maps to assets, vulns, or intel.
    Unresolved IOCs marked, never injected.
    """

    def fuse(
        self, threats: list[dict[str, Any]],
        infra_nodes: list[dict[str, Any]], vuln_nodes: list[dict[str, Any]],
        intel_nodes: list[dict[str, Any]],
    ) -> dict[str, Any]:
        asset_values = {n.get("value", "").lower(): n["node_id"] for n in infra_nodes if n.get("value")}
        vuln_values = {n.get("node_id", "").lower(): n.get("node_type", "") for n in vuln_nodes}
        ioc_clusters: list[dict[str, Any]] = []
        unresolved: list[dict[str, Any]] = []

        for threat in threats:
            for ioc in threat.get("observed_iocs", []):
                ioc_lower = ioc.lower().strip()
                matched = None
                match_type = ""

                if ioc_lower in asset_values:
                    matched = asset_values[ioc_lower]
                    match_type = "asset"
                elif any(ioc_lower in vk or vk in ioc_lower for vk in vuln_values):
                    match_type = "vulnerability"
                    matched = next((vk for vk in vuln_values if ioc_lower in vk or vk in ioc_lower), None)
                elif any(ioc_lower in n.get("value", "").lower() for n in intel_nodes):
                    match_type = "intelligence_signal"
                    matched = next((n["node_id"] for n in intel_nodes if ioc_lower in n.get("value", "").lower()), None)

                if matched:
                    ioc_clusters.append({
                        "ioc": ioc, "threat_id": threat["threat_id"],
                        "matched_entity": matched, "match_type": match_type,
                        "status": "resolved",
                    })
                else:
                    unresolved.append({
                        "ioc": ioc, "threat_id": threat["threat_id"],
                        "status": "unresolved_ioc",
                    })

        return {
            "ioc_clusters": ioc_clusters,
            "unresolved_iocs": unresolved,
            "total_resolved": len(ioc_clusters),
            "total_unresolved": len(unresolved),
        }
