"""Unified risk engine — M20 + M21 combined scoring.

risk_score = asset_exposure + vulnerability_severity + exploitability_score
           + graph_centrality + attack_path_probability + temporal_exposure_factor

All values normalized 0–1 before calculation.
"""

from __future__ import annotations

from typing import Any


class UnifiedRiskEngine:
    """Computes unified risk across M20 graph + M21 vulnerabilities."""

    def compute(
        self,
        nodes: list[dict[str, Any]],
        vuln_nodes: list[dict[str, Any]],
        attack_paths: list[dict[str, Any]],
    ) -> dict[str, Any]:
        # 1. Asset exposure (from risk_centrality)
        asset_exposure = self._avg(nodes, "risk_centrality")

        # 2. Vulnerability severity (normalized)
        sevs = {"critical": 1.0, "high": 0.75, "medium": 0.5, "low": 0.25}
        vuln_severity = 0.0
        if vuln_nodes:
            vuln_severity = sum(
                sevs.get(v.get("severity", "low"), 0.25) for v in vuln_nodes
            ) / len(vuln_nodes)

        # 3. Exploitability
        exploitability = 0.0
        if vuln_nodes:
            exploitability = sum(
                v.get("exploitability_score", 0) / 100 for v in vuln_nodes
            ) / len(vuln_nodes)

        # 4. Graph centrality
        centrality = self._avg(nodes, "risk_centrality")

        # 5. Attack path probability
        path_prob = 0.0
        if attack_paths:
            path_prob = sum(
                p.get("path_risk_score", 0) / 100 for p in attack_paths
            ) / len(attack_paths)

        # 6. Temporal exposure factor
        temporal = 0.9  # default, decayed only if very old

        # Normalize all
        asset_exp_n = min(1.0, asset_exposure)
        vuln_sev_n = min(1.0, vuln_severity)
        exploit_n = min(1.0, exploitability)
        central_n = min(1.0, centrality)
        path_n = min(1.0, path_prob)
        temp_n = min(1.0, temporal)

        # Weighted composite
        risk_score = round((
            asset_exp_n * 0.20 + vuln_sev_n * 0.25 + exploit_n * 0.20
            + central_n * 0.15 + path_n * 0.15 + temp_n * 0.05
        ) * 100, 1)

        return {
            "global_risk_score": risk_score,
            "risk_level": (
                "CRITICAL" if risk_score >= 76 else "HIGH" if risk_score >= 51
                else "MEDIUM" if risk_score >= 26 else "LOW"
            ),
            "breakdown": {
                "asset_exposure": round(asset_exp_n, 3),
                "vulnerability_severity": round(vuln_sev_n, 3),
                "exploitability": round(exploit_n, 3),
                "graph_centrality": round(central_n, 3),
                "attack_path_probability": round(path_n, 3),
                "temporal_exposure": round(temp_n, 3),
            },
        }

    @staticmethod
    def _avg(nodes: list[dict[str, Any]], key: str) -> float:
        if not nodes:
            return 0.0
        return sum(n.get(key, 0) for n in nodes) / len(nodes)
