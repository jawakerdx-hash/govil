"""Unified M20+M21 3-graph engine — strictly layered architecture."""
# ruff: noqa: E501

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from .adversary_behavior import AdversaryBehaviorEngine
from .attack_feasibility import AttackFeasibilityReasoner
from .brand_darkweb_expansion import BrandDarkWebExpansion
from .campaign_fusion import CampaignFusionEngine
from .centrality import CentralityScorer
from .cluster_engine import ClusterEngine
from .cluster_lifecycle import ClusterLifecycleManager
from .cross_graph import CrossGraphMappingLayer
from .dashboard_engine import DashboardEngine
from .final_audit import FinalAuditor
from .ioc_fusion import IOCFusionEngine
from .models import GraphEdge, GraphNode, InfrastructureCluster
from .probabilistic_threat_model import ProbabilisticThreatModel
from .reports_engine import ReportsEngine
from .risk_kernel import UnifiedRiskKernel
from .security_analyst import SecurityAnalyst
from .security_rating import SecurityRatingEngine
from .temporal_layer import TemporalLayerEngine
from .threat_correlation import ThreatCorrelationEngine
from .threat_ingestion import ThreatIngestionEngine
from .threat_prob_feedback import ThreatProbabilisticFeedback
from .validation import GraphValidator


class InfrastructureGraphEngine:
    """3-layer intelligence engine: Infrastructure | Vulnerability | Intelligence.

    Pipeline: Gather → Separate into 3 graphs → Cross-graph mapping
    → Attack feasibility → Clustering → Centrality → Temporal → Unified Risk → Validate → Output
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._cross = CrossGraphMappingLayer()
        self._attack = AttackFeasibilityReasoner()
        self._cluster = ClusterEngine()
        self._lifecycle = ClusterLifecycleManager()
        self._centrality = CentralityScorer()
        self._temporal = TemporalLayerEngine()
        self._risk = UnifiedRiskKernel()
        self._validator = GraphValidator()
        self._auditor = FinalAuditor()
        self._ptm = ProbabilisticThreatModel()
        self._threat_ingest = ThreatIngestionEngine(db)
        self._threat_corr: ThreatCorrelationEngine | None = None
        self._adversary = AdversaryBehaviorEngine()
        self._campaign = CampaignFusionEngine()
        self._ioc = IOCFusionEngine()
        self._threat_feedback = ThreatProbabilisticFeedback()
        self._rating_engine = SecurityRatingEngine()
        self._analyst = SecurityAnalyst()
        self._dashboard = DashboardEngine()
        self._brand_expansion = BrandDarkWebExpansion()
        self._reports = ReportsEngine()

    async def build(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        now = datetime.now(UTC).isoformat()

        # 1. Gather all data
        infra_raw = await self._gather_assets(domain)
        vuln_raw = await self._gather_vulns(domain)
        intel_raw = await self._gather_intel(domain)

        # 2. Build 3 separate graphs
        infra_nodes = self._build_nodes(infra_raw, "infrastructure", now)
        vuln_nodes = self._build_nodes(vuln_raw, "vulnerability", now)
        intel_nodes = self._build_nodes(intel_raw, "intelligence", now)

        # 3. Cross-graph mapping (controlled only)
        for vn in vuln_nodes:
            for an in infra_nodes:
                if an.get("value") and vn.get("description", "").lower().find(an["value"][:8]) >= 0:
                    self._cross.map_asset_to_vuln(an["node_id"], vn["node_id"], confidence=70,
                                                   evidence=["vuln_to_asset_match"])

        for en in intel_nodes:
            for an in infra_nodes[:10]:
                self._cross.map_intel_to_asset(en["node_id"], an["node_id"], confidence=40,
                                                evidence=["intel_asset_proximity"])

        # Validate mappings
        cross_err = self._cross.validate_all()
        if cross_err:
            return cross_err

        # 4. Attack feasibility paths
        attack_paths = self._attack.compute(vuln_nodes, infra_nodes, self._cross.to_list())

        # 5. Infrastructure clustering
        clusters = self._cluster.cluster(infra_nodes)
        clusters = self._lifecycle.process(
            [InfrastructureCluster(
                cluster_id=c.cluster_id, cluster_type=c.cluster_type,
                member_nodes=c.member_nodes, centrality_score=c.centrality_score,
                exposure_density_score=c.exposure_density_score,
            ) for c in clusters]
        )

        # 6. Intra-graph edges (infra only)
        infra_edges = self._build_infra_edges(infra_nodes, now)

        # 7. Centrality (infra only)
        infra_nodes = self._centrality.compute(infra_nodes, infra_edges)

        # 8. Per-graph temporal processing
        infra_nodes, _ = self._temporal.process_nodes(infra_nodes)
        vuln_nodes, _ = self._temporal.process_nodes(vuln_nodes)
        intel_nodes, _ = self._temporal.process_nodes(intel_nodes)

        # 9. Unified deterministic risk
        risk = self._risk.compute(
            infra_nodes, vuln_nodes,
            [c.to_dict() for c in clusters], attack_paths,
        )

        # ---- M22: Probabilistic Threat Model (read-only overlay) ----
        prob_result = self._ptm.analyze(
            risk, attack_paths, vuln_nodes, self._cross.to_list(),
        )
        if prob_result.get("status") == "M22_ARCHITECTURE_VIOLATION":
            return prob_result

        # ---- M23: Threat Intelligence Fusion (read-only overlay) ----
        self._threat_corr = ThreatCorrelationEngine(self._cross)
        threats = await self._threat_ingest.ingest(domain)
        threat_links, unresolved = self._threat_corr.correlate(
            threats, infra_nodes, vuln_nodes, intel_nodes,
        )
        profiles = self._adversary.build_profiles(threats, infra_nodes, vuln_nodes)
        campaigns = self._campaign.fuse(threats, domain)
        ioc_result = self._ioc.fuse(threats, infra_nodes, vuln_nodes, intel_nodes)
        threat_prob = self._threat_feedback.compute(
            threats, campaigns, profiles,
            prob_result.get("probabilistic_layer", {}),
        )

        threat_intel = {
            "active_campaigns": campaigns,
            "adversary_profiles": profiles,
            "ioc_clusters": ioc_result["ioc_clusters"],
            "unresolved_iocs": ioc_result["unresolved_iocs"],
            "threat_graph_links": threat_links,
            "campaign_risk_overlays": [threat_prob],
        }

        # M23 safety check
        if unresolved and not ioc_result["ioc_clusters"]:
            pass  # Unresolved IOCs are OK — marked, not injected

        # 10. Architecture validation
        result = {
            "infrastructure_graph": {"nodes": infra_nodes, "edges": infra_edges, "clusters": [c.to_dict() for c in clusters]},
            "vulnerability_graph": {"nodes": vuln_nodes},
            "intelligence_graph": {"nodes": intel_nodes},
            "cross_graph_mappings": self._cross.to_list(),
            "attack_feasibility_paths": attack_paths,
            "unified_risk_score": risk["global_risk_score"],
            "risk_breakdown": risk["breakdown"],
            "centrality_amplifier": risk["centrality_amplifier"],
            "probabilistic_layer": prob_result.get("probabilistic_layer", {}),
            "threat_intelligence": threat_intel,
            "clusters": [c.to_dict() for c in clusters],
            "temporal_summary": {
                "infra_nodes": len(infra_nodes), "vuln_nodes": len(vuln_nodes),
                "intel_nodes": len(intel_nodes), "cross_mappings": len(self._cross.to_list()),
                "attack_paths": len(attack_paths),
            },
            "validation_status": "PASS",
        }

        out_err = self._validator.validate_output(result)
        if out_err:
            return out_err

        arch_err = self._validator.validate_graphs(
            infra_nodes, vuln_nodes, intel_nodes, self._cross.to_list(),
        )
        if arch_err:
            return arch_err

        # ---- PRE-M22 FINAL AUDIT (9 gates) ----
        audit = self._run_final_audit(
            infra_nodes, infra_edges, vuln_nodes, intel_nodes,
            self._cross.to_list(), attack_paths, result,
            [c.to_dict() for c in clusters],
        )
        if audit:
            return audit

        # ---- M24: External Security Rating (product layer) ----
        rating = self._rating_engine.rate(result)
        result["external_security_rating"] = rating["external_security_rating"]

        # ---- M25: AI Security Analyst (read-only reasoning) ----
        analysis = self._analyst.analyze(result)
        if analysis.get("status") == "M24_SCHEMA_CORRUPTION_DETECTED":
            result["security_analysis"] = {"error": analysis["reason"]}
        else:
            result["security_analysis"] = analysis.get("security_analysis", {})
            result["analysis_metadata"] = analysis.get("analysis_metadata", {})

        # ---- M26: Executive + SOC Dashboards (presentation layer) ----
        dashboards = self._dashboard.build(result)
        result["executive_dashboard"] = dashboards["executive_dashboard"]
        result["soc_dashboard"] = dashboards["soc_dashboard"]
        result["insights"] = dashboards["insights"]

        # ---- M27: Brand + Dark Web + Identity Expansion ----
        expansion = self._brand_expansion.expand(result)
        result["brand_intelligence"] = expansion["brand_intelligence"]
        result["dark_web_intelligence"] = expansion["dark_web_intelligence"]
        result["identity_intelligence"] = expansion["identity_intelligence"]
        result["threat_linkage"] = expansion["threat_linkage"]
        result["risk_expansion_summary"] = expansion["risk_expansion_summary"]

        # ---- M28: Enterprise Reports Engine ----
        reports = self._reports.generate(result, domain)
        result["executive_report"] = reports["executive_report"]
        result["technical_report"] = reports["technical_report"]
        result["compliance_report"] = reports["compliance_report"]
        result["report_metadata"] = reports["report_metadata"]

        # Final output with standardized format
        result["validation_status"] = "PASS"
        return result

    def _run_final_audit(
        self, infra_n: list, infra_e: list, vuln_n: list, intel_n: list,
        mappings: list, paths: list, result: dict, clusters: list,
    ) -> dict | None:
        """Run all 9 pre-M22 safety gates."""
        gates = [
            ("G1_GRAPH_LAYER", self._auditor.gate_graph_integrity(infra_n, vuln_n, intel_n, mappings)),
            ("G2_CROSS_GRAPH", self._auditor.gate_cross_graph(mappings)),
            ("G3_ATTACK_MODEL", self._auditor.gate_attack_model(paths)),
            ("G4_RISK_KERNEL", self._auditor.gate_risk_kernel(result.get("risk_breakdown", {}))),
            ("G5_TEMPORAL", self._auditor.gate_temporal(infra_n, vuln_n, intel_n)),
            ("G6_CLUSTER", self._auditor.gate_cluster_stability(clusters)),
            ("G7_CONNECTIVITY", self._auditor.gate_connectivity(infra_n, infra_e, vuln_n, intel_n, mappings)),
            ("G8_OUTPUT", self._auditor.gate_output_format(result)),
            ("G9_PRE_M22", self._auditor.gate_pre_m22()),
        ]
        for name, violation in gates:
            if violation:
                violation["gate"] = name
                return violation
        return None

    # ------------------------------------------------------------------
    # Node builders
    # ------------------------------------------------------------------

    def _build_nodes(self, raw: list[dict[str, Any]], layer: str, now: str) -> list[dict[str, Any]]:
        return [
            GraphNode(
                node_id=r.get("node_id", hashlib.sha256(f"{layer}:{r.get('value','')}".encode()).hexdigest()[:16]),
                canonical_entity_id=r.get("canonical_entity_id", ""),
                node_type=r.get("node_type", "asset"), graph_layer=layer,
                value=r.get("value", ""), first_seen=now, last_seen=now,
                metadata=r.get("metadata", {}),
            ).to_dict()
            for r in raw
        ]

    def _build_infra_edges(self, nodes: list[dict[str, Any]], now: str) -> list[dict[str, Any]]:
        edges: list[dict[str, Any]] = []
        for n in nodes:
            org = n.get("canonical_entity_id", "")
            if org:
                edges.append(GraphEdge(
                    edge_id=hashlib.sha256(f"belongs:{n['node_id']}:{org}".encode()).hexdigest()[:16],
                    source_node_id=n["node_id"], target_node_id=org,
                    edge_type="belongs_to", graph_layer="infrastructure",
                    evidence_sources=["entity_linking"], first_seen=now, last_seen=now,
                ).to_dict())
        return edges

    # ------------------------------------------------------------------
    # Data gathering (repository reads only)
    # ------------------------------------------------------------------

    async def _gather_assets(self, domain: str) -> list[dict[str, Any]]:
        try:
            from sqlalchemy import select

            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(select(DiscoveryJob).where(
                DiscoveryJob.domain == domain, DiscoveryJob.status == "done").limit(1))
            job = r.scalar_one_or_none()
            if job:
                return [{"node_id": hashlib.sha256(f"srv:{s.host}".encode()).hexdigest()[:16],
                         "canonical_entity_id": hashlib.sha256(f"entity:{domain}".encode()).hexdigest()[:16],
                         "node_type": "service", "value": s.host,
                         "metadata": {"risk_surface_score": 50}}
                        for s in (job.services if hasattr(job, "services") else [])]
        except Exception:
            pass
        return []

    async def _gather_vulns(self, domain: str) -> list[dict[str, Any]]:
        try:
            from sqlalchemy import select

            from src.contexts.vulnerability.models import SecurityFinding
            r = await self._db.execute(select(SecurityFinding).where(SecurityFinding.domain == domain))
            return [{"node_id": hashlib.sha256(f"vuln:{f.cve_id or f.title}:{domain}".encode()).hexdigest()[:16],
                     "canonical_entity_id": hashlib.sha256(f"entity:{domain}".encode()).hexdigest()[:16],
                     "node_type": "cve" if f.cve_id else "misconfiguration",
                     "value": f.cve_id or f.title, "metadata": {"severity": f.severity, "exploitability_score": 50}}
                    for f in r.scalars().all()]
        except Exception:
            return []

    async def _gather_intel(self, domain: str) -> list[dict[str, Any]]:
        try:
            from sqlalchemy import select

            from src.contexts.darkweb.models import DarkWebFinding
            r = await self._db.execute(select(DarkWebFinding).where(DarkWebFinding.domain == domain))
            return [{"node_id": f.canonical_entity_id or hashlib.sha256(f"intel:{f.domain}:{f.finding_type}".encode()).hexdigest()[:16],
                     "canonical_entity_id": f.canonical_entity_id or "",
                     "node_type": "darkweb_signal", "value": f.domain}
                    for f in r.scalars().all()]
        except Exception:
            return []
