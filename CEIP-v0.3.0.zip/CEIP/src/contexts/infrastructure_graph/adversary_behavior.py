"""Adversary behavior modeling — infrastructure patterns, preferred vulns, chain analysis."""

from __future__ import annotations

import hashlib
from typing import Any

from .threat_entity import AdversaryProfile


class AdversaryBehaviorEngine:
    """Builds behavioral profiles from threat entities and graph data.

    Identifies HOW attackers behave across infrastructure — not just indicators.
    """

    def build_profiles(
        self, threats: list[dict[str, Any]],
        infra_nodes: list[dict[str, Any]], vuln_nodes: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        profiles: list[dict[str, Any]] = []
        vuln_types = {n.get("node_type", "") for n in vuln_nodes}

        for threat in threats:
            if threat.get("threat_type") != "apt":
                continue

            # Infrastructure patterns from tactics
            tactics = threat.get("tactics", [])
            infra_patterns = []
            if "credential_access" in tactics:
                infra_patterns.append("credential_theft")
            if "exploitation" in tactics:
                infra_patterns.append("vulnerability_scanning")
            if "command_and_control" in tactics:
                infra_patterns.append("c2_infrastructure")

            # Preferred vulnerabilities
            preferred = [t for t in vuln_types if t in ("cve", "misconfiguration")]

            # Infrastructure reuse score (deterministic from IOC count)
            ioc_count = len(threat.get("observed_iocs", []))
            reuse_score = min(1.0, ioc_count * 0.1)

            profiles.append(AdversaryProfile(
                profile_id=hashlib.sha256(
                    f"profile:{threat['threat_id']}".encode()
                ).hexdigest()[:16],
                threat_id=threat["threat_id"],
                known_infrastructure_patterns=infra_patterns,
                preferred_vulnerabilities=preferred,
                attack_chain_patterns=tactics,
                infrastructure_reuse_score=round(reuse_score, 3),
                campaign_overlap_clusters=[],
                confidence=threat.get("attribution_confidence", 0.5),
            ).to_dict())

        return profiles
