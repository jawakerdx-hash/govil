"""M28 - Enterprise Reports Engine. Read-only on M20-M27.

Generates: Executive, Technical, Compliance (PCI/ISO/NIST/CIS).
Every finding includes lineage (origin_module + transformation_path).
Deduplication enforced across report types.
Schema validation on output.
"""
# ruff: noqa: E501

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any


class ReportsEngine:
    """Enterprise cyber risk reporting with full lineage + audit trail."""

    REQUIRED_COMPLIANCE_FIELDS = frozenset({
        "control_id", "description", "mapped_evidence_source", "severity_level",
        "origin_module", "transformation_path",
    })

    def generate(self, pipeline_output: dict[str, Any], org_name: str = "") -> dict[str, Any]:
        rating = pipeline_output.get("external_security_rating", {})
        analysis = pipeline_output.get("security_analysis", {})
        executive_dash = pipeline_output.get("executive_dashboard", {})
        soc_dash = pipeline_output.get("soc_dashboard", {})
        threat_intel = pipeline_output.get("threat_intelligence", {})
        infra = pipeline_output.get("infrastructure_graph", {})
        vuln_graph = pipeline_output.get("vulnerability_graph", {})
        intel_graph = pipeline_output.get("intelligence_graph", {})
        darkweb = pipeline_output.get("dark_web_intelligence", {})

        result = {
            "executive_report": self._build_executive(rating, analysis, executive_dash, darkweb),
            "technical_report": self._build_technical(vuln_graph, infra, threat_intel, intel_graph, soc_dash),
            "compliance_report": self._build_compliance(vuln_graph),
            "report_metadata": {
                "generated_from_modules": ["M20", "M21", "M22", "M23", "M24", "M25", "M26", "M27"],
                "report_integrity": "verified",
                "confidence_score": self._confidence(rating),
                "organization": org_name,
                "generated_at": datetime.now(UTC).isoformat(),
            },
        }

        err = self._validate(result)
        if err:
            return err
        return result

    # ------------------------------------------------------------------
    # Executive Report (CEO Level — business only, zero technical detail)
    # ------------------------------------------------------------------

    def _build_executive(self, rating: dict, analysis: dict, dash: dict, darkweb: dict) -> dict:
        dims = rating.get("dimension_scores", {})
        sorted_dims = sorted(dims.items(), key=lambda x: x[1].get("value", 50))

        return {
            "security_score": rating.get("overall_score", 50),
            "risk_grade": rating.get("grade", "C"),
            "business_summary": analysis.get("posture_summary", ""),
            "top_risks": [
                self._lineage("M24", "pipeline->rating->executive_report", {
                    "dimension": k,
                    "score": v.get("value", 50),
                    "risk_level": (
                        "CRITICAL" if v.get("value", 50) < 30
                        else "HIGH" if v.get("value", 50) < 50 else "MEDIUM"
                    ),
                })
                for k, v in sorted_dims[:5]
            ],
            "trend_analysis": (
                f"Security posture is {rating.get('trend', 'stable')}. "
                f"Overall score: {rating.get('overall_score', 50)}/100 "
                f"({rating.get('grade', 'C')})."
            ),
            "brand_exposure": dash.get("brand_exposure_summary", ""),
            "dark_web_exposure": dash.get("dark_web_exposure_summary", ""),
        }

    # ------------------------------------------------------------------
    # Technical Report (SOC Level — actionable, no business summary)
    # ------------------------------------------------------------------

    def _build_technical(self, vuln: dict, infra: dict, threat: dict,
                         intel: dict, soc: dict) -> dict:
        vuln_nodes = vuln.get("nodes", [])
        intel_nodes = intel.get("nodes", [])
        infra_nodes = infra.get("nodes", [])

        return {
            "critical_findings": self._dedup_by_key(
                [
                    self._lineage("M21", "graph->vuln->technical_report", {
                        "type": "vulnerability",
                        "severity": n.get("severity", "LOW").upper(),
                        "description": f"Vulnerability: {n.get('vuln_id', n.get('node_id', ''))}",
                        "priority": "P1" if n.get("severity", "low") in ("critical", "CRITICAL") else "P2",
                    })
                    for n in vuln_nodes
                    if n.get("severity", "low") in ("critical", "high", "CRITICAL", "HIGH")
                ][:10],
                key_fn=lambda f: f.get("description", ""),
            ),
            "attack_surface_summary": (
                f"{len(infra_nodes)} infrastructure nodes, "
                f"{sum(1 for n in infra_nodes if n.get('node_type') == 'service')} exposed services"
            ),
            "threat_campaigns": [
                self._lineage("M23", "threat->fusion->technical_report", {
                    "campaign_id": c.get("campaign_id", ""),
                    "confidence": c.get("confidence_score", 0.5),
                    "phases": c.get("attack_phases", []),
                })
                for c in threat.get("active_campaigns", [])[:5]
            ],
            "infrastructure_exposure": [
                self._lineage("M20", "infra_graph->technical_report", {
                    "asset_id": n.get("node_id", ""),
                    "type": n.get("node_type", ""),
                    "value": n.get("value", ""),
                })
                for n in infra_nodes if n.get("node_type") == "service"
            ][:10],
            "identity_exposure": [
                self._lineage("M20+M27", "intel_graph->identity->technical_report", {
                    "entity_id": n.get("node_id", ""),
                    "type": n.get("node_type", ""),
                })
                for n in intel_nodes
                if n.get("node_type") in ("identity_entity", "credential_entity")
            ][:10],
            "attack_paths": [],
            "misconfiguration_summary": (
                f"{sum(1 for n in vuln_nodes if n.get('severity', '') in ('medium', 'MEDIUM'))} "
                f"medium-severity findings across "
                f"{sum(1 for n in infra_nodes if n.get('node_type') == 'service')} services"
            ),
        }

    # ------------------------------------------------------------------
    # Compliance Report — separated by framework, fully mapped
    # ------------------------------------------------------------------

    def _build_compliance(self, vuln: dict) -> dict:
        vuln_nodes = vuln.get("nodes", [])
        critical_vulns = [n for n in vuln_nodes if n.get("severity", "low") in ("critical", "high", "CRITICAL", "HIGH")]

        frameworks = {
            "pci_dss": ("PCI-6.1", "M21"),
            "iso_27001": ("A.12.6.1", "M21"),
            "nist_csf": ("DE.CM-8", "M21"),
            "cis_controls": ("CIS-7.1", "M21"),
        }

        result: dict[str, list[dict]] = {}
        for fw_key, (control_id, origin) in frameworks.items():
            if critical_vulns:
                result[fw_key] = [
                    self._build_compliance_finding(control_id, n, origin)
                    for n in critical_vulns[:5]
                ]
            else:
                result[fw_key] = [{
                    "control_id": control_id,
                    "description": "No critical findings identified",
                    "mapped_evidence_source": f"{origin}-VulnerabilityGraph",
                    "severity_level": "P4",
                    "origin_module": "M24",
                    "transformation_path": "rating->compliance_report",
                }]
        return result

    def _build_compliance_finding(self, control_id: str, vuln: dict, origin: str) -> dict:
        return self._lineage(origin, "vuln_graph->compliance_report", {
            "control_id": control_id,
            "description": f"Vulnerability: {vuln.get('vuln_id', vuln.get('node_id', ''))}",
            "mapped_evidence_source": f"{origin}-VulnerabilityGraph",
            "severity_level": "P1" if vuln.get("severity", "low") in ("critical", "CRITICAL") else "P2",
        })

    # ------------------------------------------------------------------
    # Lineage tracking — required for auditability
    # ------------------------------------------------------------------

    @staticmethod
    def _lineage(origin_module: str, transformation_path: str, finding: dict) -> dict:
        """Stamp every finding with origin and transformation path."""
        finding["origin_module"] = origin_module
        finding["transformation_path"] = transformation_path
        return finding

    # ------------------------------------------------------------------
    # Deduplication
    # ------------------------------------------------------------------

    @staticmethod
    def _dedup_by_key(items: list[dict], key_fn) -> list[dict]:
        """Single finding, multiple references — no duplication."""
        seen: set[str] = set()
        result: list[dict] = []
        for item in items:
            k = key_fn(item)
            if k not in seen:
                seen.add(k)
                result.append(item)
        return result

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    TRUNCATED_TOKENS = ("Nfinding", "Ncontrol", "Nvuln", ",,", "  ")

    def _validate(self, result: dict) -> dict | None:
        import json
        try:
            raw = json.dumps(result)
        except (TypeError, ValueError):
            return {"status": "M28_SCHEMA_CORRUPTION_DETECTED", "reason": "Invalid JSON"}

        # Truncation check
        for token in self.TRUNCATED_TOKENS:
            if token in raw:
                return {"status": "M28_SCHEMA_CORRUPTION_DETECTED", "reason": f"Truncated token: {token}"}

        # Compliance schema check
        compliance = result.get("compliance_report", {})
        for fw in ("pci_dss", "iso_27001", "nist_csf", "cis_controls"):
            for finding in compliance.get(fw, []):
                missing = self.REQUIRED_COMPLIANCE_FIELDS - set(finding.keys())
                if missing:
                    return {"status": "M28_COMPLIANCE_SCHEMA_VIOLATION",
                            "reason": f"Missing in {fw}: {missing}"}

        # Lineage check
        for section_key in ("executive_report", "technical_report"):
            section = result.get(section_key, {})
            for key, val in section.items():
                if isinstance(val, list):
                    for item in val:
                        if isinstance(item, dict) and "origin_module" not in item:
                            return {"status": "M28_LINEAGE_MISSING",
                                    "reason": f"Missing lineage in {section_key}.{key}"}

        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _confidence(rating: dict) -> float:
        dims = rating.get("dimension_scores", {})
        if not dims:
            return 0.5
        vals = [v.get("value", 50) for v in dims.values()]
        return round((100 - (max(vals) - min(vals))) / 100, 2)
