"""Attack path reasoning — graph traversal for multi-hop exploit chains."""

from __future__ import annotations

from typing import Any

from .models import AttackPath

MAX_HOPS = 5
MIN_CONFIDENCE = 30.0


class AttackPathReasoner:
    """Computes attack paths using ONLY graph structure.

    Multi-hop traversal allowed. No hallucinated paths.
    Every path must include: asset → vulnerability → impact node.
    """

    def compute(
        self, nodes: list[dict[str, Any]], edges: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        # Build adjacency
        adj: dict[str, list[tuple[str, dict[str, Any]]]] = {}
        for e in edges:
            s, t = e["source"], e["target"]
            adj.setdefault(s, []).append((t, e))
            adj.setdefault(t, []).append((s, e))

        # Find vulnerability nodes
        vuln_nodes = [n for n in nodes if n.get("node_type") == "vulnerability_node"]
        asset_nodes = {n["node_id"]: n for n in nodes if n.get("node_type") in (
            "service", "domain", "subdomain", "ip_address", "cloud_resource", "asset",
        )}

        paths: list[dict[str, Any]] = []

        for vuln in vuln_nodes:
            vuln_id = vuln["node_id"]
            # Find assets connected to this vulnerability
            connected_assets = [
                (neighbor, edge)
                for neighbor, edge in adj.get(vuln_id, [])
                if neighbor in asset_nodes
            ]

            for asset_id, edge in connected_assets:
                # BFS for impact nodes
                chain = self._find_impact_chain(asset_id, vuln_id, adj, asset_nodes, nodes)
                if chain:
                    risk = self._compute_path_risk(vuln, edge, chain)
                    paths.append(AttackPath(
                        path=[asset_id, vuln_id] + chain[:3],
                        exploit_chain=[edge.get("edge_type", "")],
                        path_risk_score=risk,
                        confidence=edge.get("confidence_score", 50),
                        evidence_chain=edge.get("evidence_sources", []),
                    ).to_dict())

        return sorted(paths, key=lambda p: p["path_risk_score"], reverse=True)[:10]

    def _find_impact_chain(
        self, start: str, vuln_id: str,
        adj: dict[str, list[tuple[str, dict[str, Any]]]],
        asset_nodes: dict[str, dict[str, Any]],
        all_nodes: list[dict[str, Any]],
    ) -> list[str]:
        """BFS from asset through vulnerability to find impact nodes."""
        visited: set[str] = {start, vuln_id}
        queue: list[tuple[str, list[str]]] = [(start, [])]

        for _ in range(MAX_HOPS):
            next_queue: list[tuple[str, list[str]]] = []
            for current, path in queue:
                for neighbor, _edge in adj.get(current, []):
                    if neighbor in visited:
                        continue
                    visited.add(neighbor)
                    new_path = path + [neighbor]
                    # Check if this is an impact node
                    node = next((n for n in all_nodes if n["node_id"] == neighbor), {})
                    if node.get("node_type") in ("infrastructure_cluster", "organization",
                                                  "credential_entity", "exposure_event"):
                        return new_path
                    next_queue.append((neighbor, new_path))
            queue = next_queue
        return []

    @staticmethod
    def _compute_path_risk(
        vuln: dict[str, Any], edge: dict[str, Any], chain: list[str]
    ) -> float:
        sev = vuln.get("exploitability_score", 50)
        strength = edge.get("strength_score", 50)
        hops = len(chain)
        hop_penalty = max(0.5, 1.0 - hops * 0.1)
        return round((sev * 0.5 + strength * 0.3 + 30 * hop_penalty * 0.2), 1)
