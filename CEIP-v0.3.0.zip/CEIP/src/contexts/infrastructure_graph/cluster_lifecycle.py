"""Cluster lifecycle management — strict state transitions."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from .models import InfrastructureCluster

VALID_TRANSITIONS = {
    "created": {"expanding", "stable"},
    "expanding": {"stable", "splitting"},
    "stable": {"expanding", "decaying", "merging"},
    "splitting": {"stable", "decaying"},
    "merging": {"stable", "expanding"},
    "decaying": {"stable", "created"},
}


class ClusterLifecycleManager:
    """Manages cluster state transitions with stability scoring."""

    def process(
        self, clusters: list[InfrastructureCluster],
        previous_clusters: list[dict[str, Any]] | None = None,
    ) -> list[InfrastructureCluster]:
        prev_map = {}
        if previous_clusters:
            prev_map = {p.get("cluster_id", ""): p for p in previous_clusters}

        for cluster in clusters:
            prev = prev_map.get(cluster.cluster_id)
            if prev:
                prev_size = len(prev.get("member_nodes", []))
                curr_size = len(cluster.member_nodes)

                if curr_size > prev_size * 1.3:
                    cluster.cluster_state = "expanding"
                    cluster.stability_score = max(0.3, cluster.stability_score - 0.1)
                elif curr_size < prev_size * 0.3:
                    cluster.cluster_state = "dissolved"
                    cluster.stability_score = 0.0
                elif curr_size < prev_size * 0.7:
                    cluster.cluster_state = "decaying"
                    cluster.stability_score = max(0.1, cluster.stability_score - 0.2)
                else:
                    cluster.cluster_state = "stable"
                    cluster.stability_score = min(1.0, cluster.stability_score + 0.05)

                cluster.evolution_history.append({
                    "timestamp": datetime.now(UTC).isoformat(),
                    "state": cluster.cluster_state,
                    "size": curr_size,
                    "stability": cluster.stability_score,
                })
            else:
                cluster.cluster_state = "created"
                cluster.stability_score = 0.8
                cluster.evolution_history.append({
                    "timestamp": datetime.now(UTC).isoformat(),
                    "state": "created",
                    "size": len(cluster.member_nodes),
                    "stability": 0.8,
                })

        return clusters
