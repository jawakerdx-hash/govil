"""Campaign fusion engine — clusters threats into campaign objects."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import Any

from .threat_entity import CampaignObject


class CampaignFusionEngine:
    """Clusters related threats into CampaignObjects.

    Deterministic grouping by target overlap + temporal proximity.
    """

    def fuse(
        self, threats: list[dict[str, Any]], domain: str,
    ) -> list[dict[str, Any]]:
        if not threats:
            return []

        now = datetime.now(UTC).isoformat()
        campaigns: list[dict[str, Any]] = []

        # Group by target
        grouped: dict[str, list[dict[str, Any]]] = {}
        for t in threats:
            for target in t.get("targets", [domain]):
                grouped.setdefault(target, []).append(t)

        for target, group in grouped.items():
            if len(group) >= 1:
                threat_ids = [t["threat_id"] for t in group]
                attack_phases = []
                for t in group:
                    attack_phases.extend(t.get("tactics", []))
                phases = list(dict.fromkeys(attack_phases))[:5]

                conf = sum(t.get("attribution_confidence", 0.5) for t in group) / len(group)

                campaigns.append(CampaignObject(
                    campaign_id=hashlib.sha256(
                        f"campaign:{target}:{len(group)}".encode()
                    ).hexdigest()[:16],
                    related_threats=threat_ids,
                    targeted_assets=[target],
                    attack_phases=phases or ["reconnaissance"],
                    confidence_score=round(conf, 3),
                    temporal_span={"start": now, "end": now},
                ).to_dict())

        return campaigns
