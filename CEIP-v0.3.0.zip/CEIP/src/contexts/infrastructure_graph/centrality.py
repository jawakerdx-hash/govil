"""Centrality scoring — degree, exposure, and risk centrality per node."""

from __future__ import annotations

from typing import Any


class CentralityScorer:
    """Computes node centrality across three dimensions."""

    @staticmethod
    def compute(
        nodes: list[dict[str, Any]], edges: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        adj: dict[str, list[str]] = {}
        for e in edges:
            s, t = e["source"], e["target"]
            adj.setdefault(s, []).append(t)
            adj.setdefault(t, []).append(s)

        total = max(len(nodes), 1)

        for node in nodes:
            nid = node["node_id"]
            deg = len(adj.get(nid, []))
            node["degree_centrality"] = round(deg / total, 4)

            exposure = sum(
                1 for e in edges
                if e.get("edge_type") == "exposed_in"
                and (e["source"] == nid or e["target"] == nid)
            )
            node["exposure_centrality"] = round(exposure / max(total, 1), 4)

            risk = node["degree_centrality"] * 0.4 + node["exposure_centrality"] * 0.6
            node["risk_centrality"] = round(risk, 4)

        return nodes
