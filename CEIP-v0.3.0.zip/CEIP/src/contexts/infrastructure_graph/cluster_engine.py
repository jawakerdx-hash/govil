"""Infrastructure cluster engine — groups nodes by shared infrastructure."""

from __future__ import annotations

import hashlib
from typing import Any

from .models import InfrastructureCluster


class ClusterEngine:
    """Groups nodes into infrastructure clusters based on shared properties.

    Clustering dimensions: IP ranges, ASN, hosting, TLS, DNS, CDN/WAF.
    """

    def cluster(self, nodes: list[dict[str, Any]]) -> list[InfrastructureCluster]:
        clusters: dict[str, InfrastructureCluster] = {}

        for node in nodes:
            meta = node.get("metadata", {})
            cluster_key = self._derive_cluster_key(node, meta)

            if cluster_key in clusters:
                clusters[cluster_key].member_nodes.append(node["node_id"])
            else:
                ctype = self._classify_cluster_type(meta)
                clusters[cluster_key] = InfrastructureCluster(
                    cluster_id=hashlib.sha256(
                        f"cluster:{cluster_key}".encode()
                    ).hexdigest()[:12],
                    cluster_type=ctype,
                    member_nodes=[node["node_id"]],
                )

        # Compute centrality and density
        result = list(clusters.values())
        total = len(result)
        for c in result:
            c.centrality_score = round(len(c.member_nodes) / max(total, 1), 3)
            c.exposure_density_score = min(1.0, len(c.member_nodes) * 0.1)

        return result

    @staticmethod
    def _derive_cluster_key(node: dict[str, Any], meta: dict[str, Any]) -> str:
        parts: list[str] = []
        if meta.get("asn"):
            parts.append(f"asn:{meta['asn']}")
        if meta.get("hosting_provider"):
            parts.append(f"host:{meta['hosting_provider'].lower()}")
        if meta.get("cloud_provider"):
            parts.append(f"cloud:{meta['cloud_provider'].lower()}")
        if meta.get("cdn_detected"):
            parts.append(f"cdn:{meta['cdn_detected'].lower()}")
        if meta.get("waf_detected"):
            parts.append(f"waf:{meta['waf_detected'].lower()}")
        if not parts:
            parts.append(f"type:{node.get('node_type', 'unknown')}")
        return "|".join(sorted(parts))

    @staticmethod
    def _classify_cluster_type(meta: dict[str, Any]) -> str:
        if meta.get("cloud_provider"):
            return "cloud"
        if meta.get("hosting_provider"):
            return "hosting"
        if meta.get("cdn_detected") and meta.get("waf_detected"):
            return "hybrid"
        return "unknown"
