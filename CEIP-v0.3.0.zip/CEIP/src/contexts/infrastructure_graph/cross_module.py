"""Cross-module correlation — links M18 dark web entities to M19 assets."""
# ruff: noqa: E501

from __future__ import annotations

import hashlib
from typing import Any

from .models import GraphEdge


class CrossModuleCorrelator:
    """Links M19 assets to M18 dark web entities via deterministic rules."""

    def correlate(
        self, m19_assets: list[dict[str, Any]], m18_entities: list[dict[str, Any]]
    ) -> tuple[list[GraphEdge], list[dict[str, Any]]]:
        edges: list[GraphEdge] = []
        insights: list[dict[str, Any]] = []

        for asset in m19_assets:
            asset_id = asset.get("asset_id", "")
            asset_type = asset.get("asset_type", "")
            domain = asset.get("organization_entity", "")

            for entity in m18_entities:
                entity_id = entity.get("canonical_entity_id", "")
                entity_type = entity.get("entity_type", "")

                # Leaked credentials → matching domain
                if entity_type == "email" and entity.get("normalized_value", ""):
                    if domain and domain in entity.get("normalized_value", ""):
                        edges.append(self._make_edge(asset_id, entity_id, "indicates_exposure_of",
                                                     strength=85, evidence=["credential_domain_match"]))
                        insights.append({"type": "credential_to_domain",
                                         "asset": asset_id, "entity": entity_id,
                                         "description": f"Leaked credentials match domain {domain}"})

                # Exposed API key → cloud resource
                if entity_type == "api_key" and asset_type == "cloud_resource":
                    edges.append(self._make_edge(entity_id, asset_id, "related_to",
                                                 strength=60, evidence=["api_cloud_proximity"]))
                    insights.append({"type": "api_to_cloud",
                                     "asset": asset_id, "entity": entity_id,
                                     "description": "Exposed API key near cloud resource"})

                # Dark web mention → organization
                if entity_type in ("data", "domain") and asset_type in ("root_domain", "subdomain"):
                    edges.append(self._make_edge(entity_id, asset_id, "observed_with",
                                                 strength=50, evidence=["darkweb_asset_proximity"]))
                    insights.append({"type": "darkweb_to_asset",
                                     "asset": asset_id, "entity": entity_id,
                                     "description": "Dark web entity observed near asset"})

        return edges, insights

    @staticmethod
    def _make_edge(source: str, target: str, etype: str,
                   strength: float = 50, evidence: list[str] | None = None) -> GraphEdge:
        return GraphEdge(
            edge_id=hashlib.sha256(f"{source}:{target}:{etype}".encode()).hexdigest()[:16],
            source_node_id=source, target_node_id=target, edge_type=etype,
            strength_score=strength, confidence_score=strength * 0.85,
            evidence_sources=evidence or [],
        )
