"""Probabilistic Threat Model — sits ABOVE deterministic core, never replaces it.

Read-only on M20+M21. Enhances interpretation without structural changes.
"""

from __future__ import annotations

from typing import Any

from .attack_path_probability import AttackPathProbability
from .uncertainty_engine import UncertaintyEngine


class ProbabilisticThreatModel:
    """Controlled probabilistic overlay on deterministic cyber reasoning.

    Rules:
    - Does NOT modify graph structure, nodes, or edges
    - Does NOT modify deterministic risk kernel outputs
    - Only reads outputs and enhances interpretation
    - Returns M22_ARCHITECTURE_VIOLATION on any violation
    """

    DETECTED_VIOLATION = "M22_ARCHITECTURE_VIOLATION"
    CONFIDENCE_WEIGHT_MIN = 0.7
    CONFIDENCE_WEIGHT_MAX = 1.3

    def __init__(self) -> None:
        self._uncertainty = UncertaintyEngine()
        self._path_prob = AttackPathProbability()

    def analyze(
        self,
        deterministic_risk: dict[str, Any],
        attack_paths: list[dict[str, Any]],
        vuln_nodes: list[dict[str, Any]],
        cross_mappings: list[dict[str, Any]],
    ) -> dict[str, Any]:
        # Safety check — verify deterministic base exists
        if not deterministic_risk:
            return {"status": self.DETECTED_VIOLATION,
                    "reason": "Missing deterministic risk base"}

        base_score = deterministic_risk.get("global_risk_score", 50)

        # 1. Compute uncertainty factors
        uncertainty = self._uncertainty.evaluate(vuln_nodes, attack_paths, cross_mappings)

        # 2. Enrich attack paths with probability
        enriched_paths = self._path_prob.enrich(attack_paths, uncertainty)

        # 3. Compute probability-enhanced risk
        prob_exploit = sum(
            p.get("probability_of_exploitation", 0.5) for p in enriched_paths
        ) / max(len(enriched_paths), 1) if enriched_paths else 0.5

        # Confidence weight bounded [0.7, 1.3]
        avg_mapping_conf = sum(
            m.get("confidence_score", 50) for m in cross_mappings
        ) / max(len(cross_mappings), 1) / 100 if cross_mappings else 0.5
        confidence_weight = max(
            self.CONFIDENCE_WEIGHT_MIN,
            min(self.CONFIDENCE_WEIGHT_MAX, avg_mapping_conf * 1.5),
        )

        # final_risk = deterministic_risk × probability_of_exploitation × confidence_weight
        final_risk = round(base_score * max(0.1, prob_exploit) * confidence_weight, 1)
        final_risk = min(100.0, final_risk)

        # Risk distribution
        all_probs = [p.get("probability_of_exploitation", 0.5) for p in enriched_paths]
        mean_prob = sum(all_probs) / max(len(all_probs), 1) if all_probs else 0.5
        variance = round(
            sum((p - mean_prob) ** 2 for p in all_probs) / max(len(all_probs), 1), 4
        ) if all_probs else 0.0

        return {
            "probabilistic_layer": {
                "attack_paths_probability": enriched_paths,
                "risk_distribution": {
                    "deterministic_base": base_score,
                    "probabilistic_enhanced": final_risk,
                    "mean": round(mean_prob * 100, 1),
                    "variance": variance,
                },
                "uncertainty_analysis": uncertainty,
                "confidence_model": {
                    "confidence_weight": round(confidence_weight, 3),
                    "bounded_range": [self.CONFIDENCE_WEIGHT_MIN, self.CONFIDENCE_WEIGHT_MAX],
                    "mapping_confidence_avg": round(avg_mapping_conf, 3),
                },
            },
            "status": "M22_PROBABILISTIC_COMPLETE",
        }
