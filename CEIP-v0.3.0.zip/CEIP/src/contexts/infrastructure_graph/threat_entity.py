"""Threat intelligence entity models — APT, malware, campaigns, IOCs."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class ThreatEntity:
    """Normalized threat intelligence entity."""
    threat_id: str
    threat_type: str  # apt, malware, campaign, botnet, ioc_cluster
    attribution_confidence: float = 0.5
    observed_iocs: list[str] = field(default_factory=list)
    tactics: list[str] = field(default_factory=list)
    targets: list[str] = field(default_factory=list)
    first_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "threat_id": self.threat_id,
            "threat_type": self.threat_type,
            "attribution_confidence": self.attribution_confidence,
            "observed_iocs": self.observed_iocs,
            "tactics": self.tactics,
            "targets": self.targets,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "metadata": self.metadata,
        }


@dataclass
class AdversaryProfile:
    """Behavioral profile of an adversary group."""
    profile_id: str
    threat_id: str
    known_infrastructure_patterns: list[str] = field(default_factory=list)
    preferred_vulnerabilities: list[str] = field(default_factory=list)
    attack_chain_patterns: list[str] = field(default_factory=list)
    infrastructure_reuse_score: float = 0.0
    campaign_overlap_clusters: list[str] = field(default_factory=list)
    confidence: float = 0.5

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "threat_id": self.threat_id,
            "known_infrastructure_patterns": self.known_infrastructure_patterns,
            "preferred_vulnerabilities": self.preferred_vulnerabilities,
            "attack_chain_patterns": self.attack_chain_patterns,
            "infrastructure_reuse_score": self.infrastructure_reuse_score,
            "campaign_overlap_clusters": self.campaign_overlap_clusters,
            "confidence": self.confidence,
        }


@dataclass
class CampaignObject:
    """Clustered threat campaign."""
    campaign_id: str
    related_threats: list[str] = field(default_factory=list)
    targeted_assets: list[str] = field(default_factory=list)
    attack_phases: list[str] = field(default_factory=list)
    confidence_score: float = 0.5
    temporal_span: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "campaign_id": self.campaign_id,
            "related_threats": self.related_threats,
            "targeted_assets": self.targeted_assets,
            "attack_phases": self.attack_phases,
            "confidence_score": self.confidence_score,
            "temporal_span": self.temporal_span,
        }
