"""Schema normalization — ensures M18 and M19 canonical models align."""

from __future__ import annotations

from typing import Any


class SchemaNormalizer:
    """Validates and normalizes cross-module entity schemas."""

    M18_REQUIRED = {"canonical_entity_id", "entity_type", "normalized_value"}
    M19_REQUIRED = {"asset_id", "canonical_entity_id", "asset_type", "value"}

    @classmethod
    def validate_alignment(
        cls, m18_entities: list[dict[str, Any]], m19_assets: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """Return NORMALIZATION_CONFLICT if schemas mismatch, else None."""

        for e in m18_entities:
            if not cls.M18_REQUIRED.issubset(e.keys()):
                return {
                    "status": "NORMALIZATION_CONFLICT_M18_M19",
                    "reason": f"M18 entity missing fields: {cls.M18_REQUIRED - set(e.keys())}",
                    "entity": e.get("canonical_entity_id", "?"),
                }

        for a in m19_assets:
            if not cls.M19_REQUIRED.issubset(a.keys()):
                return {
                    "status": "NORMALIZATION_CONFLICT_M18_M19",
                    "reason": f"M19 asset missing fields: {cls.M19_REQUIRED - set(a.keys())}",
                    "asset": a.get("asset_id", "?"),
                }

        return None

    @classmethod
    def normalize_entity_id(cls, source: str, value: str) -> str:
        """Generate deterministic canonical entity ID."""
        import hashlib
        return hashlib.sha256(f"{source}:{value}".encode()).hexdigest()[:16]
