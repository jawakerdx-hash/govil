"""Graph validation — CEIP_ARCHITECTURE_VIOLATION on any rule break."""

from __future__ import annotations

from typing import Any

from .models import INTEL_NODE_TYPES, VULN_NODE_TYPES


class GraphValidator:
    """Strict architecture validation. Returns CEIP_ARCHITECTURE_VIOLATION on failure."""

    @staticmethod
    def validate_graphs(
        infra_nodes: list[dict[str, Any]],
        vuln_nodes: list[dict[str, Any]],
        intel_nodes: list[dict[str, Any]],
        cross_mappings: list[dict[str, Any]],
    ) -> dict[str, Any] | None:
        # 1. No mixed node types in wrong graph
        for n in infra_nodes:
            if n.get("node_type") in VULN_NODE_TYPES or n.get("node_type") in INTEL_NODE_TYPES:
                return {"status": "CEIP_ARCHITECTURE_VIOLATION",
                        "reason": f"Vuln/intel type in infrastructure graph: {n['node_id']}"}
        for n in vuln_nodes:
            if n.get("node_type") not in VULN_NODE_TYPES:
                return {"status": "CEIP_ARCHITECTURE_VIOLATION",
                        "reason": f"Non-vuln type in vulnerability graph: {n['node_id']}"}
        for n in intel_nodes:
            if n.get("node_type") not in INTEL_NODE_TYPES:
                return {"status": "CEIP_ARCHITECTURE_VIOLATION",
                        "reason": f"Non-intel type in intelligence graph: {n['node_id']}"}

        # 2. No missing temporal data
        for nodes in (infra_nodes, vuln_nodes, intel_nodes):
            for n in nodes:
                if not n.get("first_seen") or not n.get("last_seen"):
                    return {"status": "CEIP_ARCHITECTURE_VIOLATION",
                            "reason": f"Missing temporal data: {n['node_id']}"}

        # 3. No cross-graph direct edges (must go through mappings)
        # This is validated in CrossGraphMappingLayer.validate_all()

        # 4. No mappings without evidence
        for m in cross_mappings:
            if not m.get("evidence_sources"):
                return {"status": "CEIP_ARCHITECTURE_VIOLATION",
                        "reason": f"Mapping without evidence: {m.get('mapping_id', '?')}"}
            if not m.get("temporal_alignment_score"):
                return {"status": "CEIP_ARCHITECTURE_VIOLATION",
                        "reason": f"Mapping missing temporal alignment: {m.get('mapping_id', '?')}"}

        return None

    @staticmethod
    def validate_output(result: dict[str, Any]) -> dict[str, Any] | None:
        required = {"infrastructure_graph", "vulnerability_graph",
                    "intelligence_graph", "cross_graph_mappings",
                    "attack_feasibility_paths", "unified_risk_score"}
        missing = required - set(result.keys())
        if missing:
            return {"status": "CEIP_ARCHITECTURE_VIOLATION",
                    "reason": f"Missing required keys: {missing}"}
        return None
