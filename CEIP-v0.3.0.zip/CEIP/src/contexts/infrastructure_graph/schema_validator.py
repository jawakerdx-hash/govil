"""M24 schema validator — detects corruption before AI reasoning."""

from __future__ import annotations

from typing import Any

REQUIRED_DIMENSIONS = frozenset({
    "attack_surface_score", "vulnerability_score", "exposure_score",
    "identity_risk_score", "threat_activity_score", "cloud_risk_score",
    "dark_web_risk_score",
})

REQUIRED_RATING_KEYS = frozenset({
    "overall_score", "grade", "risk_level", "dimension_scores",
    "key_drivers", "risk_explanation", "trend",
})


class SchemaValidator:
    """Validates M24 output schema integrity before M25 reasoning."""

    TRUNCATED_PATTERNS = ("Clo", "pyt", "adversary_re", "threat_pr", ",,")

    @classmethod
    def validate(cls, rating_data: dict[str, Any]) -> dict[str, Any] | None:
        """Return M24_SCHEMA_CORRUPTION_DETECTED if issues found, else None."""
        esr = rating_data.get("external_security_rating", {})

        # Check required keys
        missing = REQUIRED_RATING_KEYS - set(esr.keys())
        if missing:
            return {"status": "M24_SCHEMA_CORRUPTION_DETECTED",
                    "reason": f"Missing rating keys: {missing}"}

        # Check dimensions
        dims = esr.get("dimension_scores", {})
        dim_missing = REQUIRED_DIMENSIONS - set(dims.keys())
        if dim_missing:
            return {"status": "M24_SCHEMA_CORRUPTION_DETECTED",
                    "reason": f"Missing dimensions: {dim_missing}"}

        # Check for truncated fields
        for key, val in _flatten_dict(esr):
            val_str = str(val)
            if not val_str or val_str.strip() in ("", ",", ",,"):
                return {"status": "M24_SCHEMA_CORRUPTION_DETECTED",
                        "reason": f"Empty/truncated field: {key}"}
            for pattern in cls.TRUNCATED_PATTERNS:
                if pattern in val_str and len(val_str) < 20:
                    return {"status": "M24_SCHEMA_CORRUPTION_DETECTED",
                            "reason": f"Truncated field '{key}' contains '{pattern}'"}

        # Validate overall_score range
        score = esr.get("overall_score", -1)
        if not (0 <= score <= 100):
            return {"status": "M24_SCHEMA_CORRUPTION_DETECTED",
                    "reason": f"Invalid overall_score: {score}"}

        return None


def _flatten_dict(d: dict, prefix: str = "") -> list[tuple[str, Any]]:
    result: list[tuple[str, Any]] = []
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            result.extend(_flatten_dict(v, key))
        else:
            result.append((key, v))
    return result
