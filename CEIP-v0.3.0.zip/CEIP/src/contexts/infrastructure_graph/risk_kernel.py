"""Unified Risk Kernel — strictly normalized, centrality as amplifier only.

risk = (exposure * w1 + vuln_severity * w2 + exploitability * w3
       + cluster_propagation * w4 + temporal_decay * w5) * centrality_amplifier

ALL inputs normalized 0-1 before calculation.
Centrality amplifies AFTER base risk, never as independent input.
"""

from __future__ import annotations

from typing import Any


class UnifiedRiskKernel:
    """Strict risk model. No raw sums without normalization."""

    WEIGHTS = {
        "exposure": 0.25, "vulnerability_severity": 0.25,
        "exploitability": 0.20, "cluster_propagation": 0.15,
        "temporal_decay": 0.15,
    }

    SEVERITY_NORM = {"critical": 1.0, "high": 0.75, "medium": 0.5, "low": 0.25}

    def compute(
        self,
        asset_nodes: list[dict[str, Any]],
        vuln_nodes: list[dict[str, Any]],
        clusters: list[dict[str, Any]],
        attack_paths: list[dict[str, Any]],
    ) -> dict[str, Any]:
        # 1. Exposure factor (from asset risk_surface_score)
        exposure = self._avg_metric(asset_nodes, "risk_surface_score") / 100

        # 2. Vulnerability severity
        vuln_sev = 0.0
        if vuln_nodes:
            vuln_sev = sum(
                self.SEVERITY_NORM.get(v.get("severity", "low"), 0.25)
                for v in vuln_nodes
            ) / len(vuln_nodes)

        # 3. Exploitability (from attack paths)
        exploit = 0.0
        if attack_paths:
            exploit = sum(
                p.get("path_risk_score", 0) / 100 for p in attack_paths
            ) / len(attack_paths)

        # 4. Cluster propagation
        cluster_prop = 0.0
        if clusters:
            cluster_prop = sum(
                c.get("exposure_density_score", 0) for c in clusters
            ) / len(clusters)

        # 5. Temporal decay
        temporal = 0.9

        # Normalize all
        vals = {
            "exposure": min(1.0, max(0.0, exposure)),
            "vulnerability_severity": min(1.0, max(0.0, vuln_sev)),
            "exploitability": min(1.0, max(0.0, exploit)),
            "cluster_propagation": min(1.0, max(0.0, cluster_prop)),
            "temporal_decay": min(1.0, max(0.0, temporal)),
        }

        # Base risk (weighted sum, all normalized)
        base = sum(vals[k] * self.WEIGHTS[k] for k in self.WEIGHTS)

        # Centrality as AMPLIFIER only (never independent input)
        centrality = self._avg_metric(asset_nodes, "risk_centrality")
        centrality_amp = 1.0 + min(0.5, centrality * 0.5)  # max 1.5x amplification

        risk_score = round(base * centrality_amp * 100, 1)

        return {
            "global_risk_score": risk_score,
            "risk_level": (
                "CRITICAL" if risk_score >= 76 else "HIGH" if risk_score >= 51
                else "MEDIUM" if risk_score >= 26 else "LOW"
            ),
            "breakdown": {k: round(v, 3) for k, v in vals.items()},
            "centrality_amplifier": round(centrality_amp, 3),
        }

    @staticmethod
    def _avg_metric(nodes: list[dict[str, Any]], key: str) -> float:
        if not nodes:
            return 0.0
        return sum(n.get(key, 0) for n in nodes) / len(nodes)
