# ruff: noqa: E501
"""M26 — Executive + SOC Dashboard Engine. Pure presentation layer.

Consumes M20-M25 outputs. No recalculation. No data modification.
Transforms structured intelligence into visual dashboard views.
"""

from __future__ import annotations

from typing import Any


class DashboardEngine:
    """Transforms CEIP pipeline output into executive + SOC dashboards.

    Read-only. Groups, summarizes, and prioritizes. Never invents data.
    """

    def build(self, pipeline_output: dict[str, Any]) -> dict[str, Any]:
        rating = pipeline_output.get("external_security_rating", {})
        analysis = pipeline_output.get("security_analysis", {})
        threat_intel = pipeline_output.get("threat_intelligence", {})
        prob_layer = pipeline_output.get("probabilistic_layer", {})
        infra = pipeline_output.get("infrastructure_graph", {})
        vuln_graph = pipeline_output.get("vulnerability_graph", {})

        result = {
            "executive_dashboard": self._build_executive(rating, analysis, threat_intel),
            "soc_dashboard": self._build_soc(rating, threat_intel, infra, vuln_graph, prob_layer, pipeline_output),
            "insights": self._build_insights(rating, analysis, threat_intel),
        }

        # Validate M26 output
        err = self._validate(result)
        if err:
            return err
        return result

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    TRUNCATED_TOKENS = ("p", "cybe", "vulnera", "visualizatidata")

    def _validate(self, result: dict) -> dict | None:
        """Check for truncation, broken fields, merged arrays."""
        import json
        try:
            json.dumps(result)
        except (TypeError, ValueError):
            return {"status": "M26_SCHEMA_CORRUPTION_DETECTED", "reason": "Invalid JSON"}

        exec_dash = result.get("executive_dashboard", {})
        soc_dash = result.get("soc_dashboard", {})

        # Check exec required fields
        for key in ("security_score", "risk_grade", "trend", "business_summary", "top_risks"):
            if key not in exec_dash:
                return {"status": "M26_SCHEMA_CORRUPTION_DETECTED", "reason": f"Missing exec field: {key}"}

        # Check SOC required fields
        soc_keys = ("critical_vulnerabilities", "active_threat_campaigns", "exposed_assets",
                    "attack_paths", "identity_exposure", "real_time_alerts")
        for key in soc_keys:
            if key not in soc_dash:
                return {"status": "M26_SCHEMA_CORRUPTION_DETECTED", "reason": f"Missing SOC field: {key}"}
            if not isinstance(soc_dash[key], list):
                return {"status": "M26_SCHEMA_CORRUPTION_DETECTED", "reason": f"SOC field '{key}' must be array"}

        # Check for truncated tokens
        all_str = json.dumps(result)
        for token in self.TRUNCATED_TOKENS:
            if token in all_str and len(token) < 5:
                return {"status": "M26_SCHEMA_CORRUPTION_DETECTED", "reason": f"Truncated token: {token}"}

        return None

    # ------------------------------------------------------------------
    # Executive Dashboard (CEO View)
    # ------------------------------------------------------------------

    def _build_executive(self, rating: dict, analysis: dict, threat: dict) -> dict:
        score = rating.get("overall_score", 50)
        grade = rating.get("grade", "C")
        trend = rating.get("trend", "stable")
        posture = analysis.get("posture_summary", "")

        # Top 5 business risks from key drivers
        drivers = analysis.get("key_risk_drivers", [])
        top_risks = [
            {
                "rank": i + 1,
                "risk": d.get("dimension", "unknown"),
                "score": d.get("score", 50),
                "impact": "HIGH" if d.get("score", 50) < 40 else "MEDIUM" if d.get("score", 50) < 60 else "LOW",
                "layers": d.get("affected_layers", []),
            }
            for i, d in enumerate(drivers[:5])
        ]

        # Brand exposure from threats
        campaigns = threat.get("active_campaigns", [])
        brand_exposure = "No brand-specific threats detected"
        if campaigns:
            brand_exposure = f"{len(campaigns)} active threat campaigns may affect brand reputation"

        # Dark web summary (high-level)
        darkweb_signals = len(threat.get("ioc_clusters", []))
        darkweb_summary = "No dark web exposure detected"
        if darkweb_signals > 0:
            darkweb_summary = f"{darkweb_signals} dark web signals identified"

        return {
            "security_score": score,
            "risk_grade": grade,
            "trend": trend,
            "business_summary": posture,
            "top_risks": top_risks,
            "brand_exposure_summary": brand_exposure,
            "dark_web_exposure_summary": darkweb_summary,
        }

    # ------------------------------------------------------------------
    # SOC Dashboard (Operational View)
    # ------------------------------------------------------------------

    def _build_soc(self, rating: dict, threat: dict, infra: dict,
                   vuln_graph: dict, prob: dict, pipeline_output: dict) -> dict:
        dims = rating.get("dimension_scores", {})

        # Critical vulnerabilities (P1 only — score < 40)
        critical_vulns = [
            {
                "dimension": k,
                "score": v.get("value", 50),
                "priority": "P1",
                "evidence": v.get("evidence", []),
            }
            for k, v in dims.items()
            if v.get("value", 50) < 40
        ]

        # Active threat campaigns
        active_threats = [
            {
                "campaign_id": c.get("campaign_id", "unknown"),
                "confidence": c.get("confidence_score", 0.5),
                "phases": c.get("attack_phases", []),
            }
            for c in threat.get("active_campaigns", [])
        ]

        # Exposed assets (from infra graph)
        infra_nodes = infra.get("nodes", [])
        exposed = [
            {
                "asset_id": n.get("node_id", ""),
                "type": n.get("node_type", ""),
                "value": n.get("value", ""),
                "risk_surface": n.get("metadata", {}).get("risk_surface_score", 50),
            }
            for n in infra_nodes
            if n.get("node_type") == "service"
        ][:10]

        # Attack paths
        attack_paths = [
            {
                "path_id": p.get("path_id", ""),
                "risk": p.get("path_risk_score", 50),
                "confidence": p.get("confidence", 50),
                "conditions_met": sum(1 for c in p.get("conditions", []) if c.get("met")),
            }
            for p in pipeline_output.get("attack_feasibility_paths", [])[:5]
        ] if "attack_feasibility_paths" in pipeline_output else []

        # Identity exposure
        intel_nodes = pipeline_output.get("intelligence_graph", {}).get("nodes", [])
        identity_exposure = [
            {
                "entity_id": n.get("node_id", ""),
                "type": n.get("node_type", ""),
                "value": n.get("value", ""),
            }
            for n in intel_nodes
            if n.get("node_type") in ("identity_entity", "credential_entity")
        ][:10]

        # Real-time risk alerts (derived from probability layer)
        risk_dist = prob.get("risk_distribution", {})
        prob_enhanced = risk_dist.get("probabilistic_enhanced", 50)
        alerts = []
        if prob_enhanced > 75:
            alerts.append("CRITICAL: High probability of exploitation detected")
        if len(active_threats) > 3:
            alerts.append("WARNING: Multiple active threat campaigns")
        if len(critical_vulns) > 3:
            alerts.append("WARNING: Multiple critical vulnerability dimensions")
        if not alerts:
            alerts.append("No critical alerts at this time")

        return {
            "critical_vulnerabilities": critical_vulns,
            "active_threat_campaigns": active_threats,
            "exposed_assets": exposed,
            "attack_paths": attack_paths,
            "identity_exposure": identity_exposure,
            "real_time_alerts": alerts,
        }

    # ------------------------------------------------------------------
    # Insights
    # ------------------------------------------------------------------

    def _build_insights(self, rating: dict, analysis: dict, threat: dict) -> dict:
        drivers = analysis.get("key_risk_drivers", [])
        key_findings = [
            {
                "finding": f"Weak {d.get('dimension', 'unknown')} score: {d.get('score', 50)}/100",
                "severity": "HIGH" if d.get("score", 50) < 40 else "MEDIUM",
            }
            for d in drivers[:3]
        ]

        # Recommended actions from mitigation plan
        mitigations = analysis.get("mitigation_plan", [])
        actions = [
            {
                "action": m.get("strategy", ""),
                "priority": m.get("priority", "P4"),
                "impact": m.get("estimated_impact", "unknown"),
            }
            for m in mitigations[:4]
        ]

        campaigns = threat.get("active_campaigns", [])
        if campaigns:
            key_findings.append({
                "finding": f"{len(campaigns)} active threat campaigns targeting organization",
                "severity": "HIGH",
            })

        return {
            "key_findings": key_findings,
            "recommended_actions": actions,
        }
