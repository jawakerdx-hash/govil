"""Cross-graph mapping layer — controlled linking between separated graphs."""

from __future__ import annotations

import hashlib
from typing import Any

from .models import CrossGraphMapping


class CrossGraphMappingLayer:
    """Controlled cross-graph linking. No direct edges between graphs allowed."""

    def __init__(self) -> None:
        self._mappings: list[CrossGraphMapping] = []

    def map_asset_to_vuln(
        self, asset_id: str, vuln_id: str,
        confidence: float = 50.0, evidence: list[str] | None = None,
    ) -> CrossGraphMapping:
        mapping = CrossGraphMapping(
            mapping_id=hashlib.sha256(
                f"cross:infra:vuln:{asset_id}:{vuln_id}".encode()
            ).hexdigest()[:16],
            source_graph="infrastructure", target_graph="vulnerability",
            source_node_id=asset_id, target_node_id=vuln_id,
            mapping_type="asset_has_vulnerability",
            confidence_score=confidence,
            evidence_sources=evidence or [],
            temporal_alignment_score=0.5,
        )
        self._mappings.append(mapping)
        return mapping

    def map_intel_to_asset(
        self, intel_id: str, asset_id: str,
        confidence: float = 50.0, evidence: list[str] | None = None,
    ) -> CrossGraphMapping:
        mapping = CrossGraphMapping(
            mapping_id=hashlib.sha256(
                f"cross:intel:asset:{intel_id}:{asset_id}".encode()
            ).hexdigest()[:16],
            source_graph="intelligence", target_graph="infrastructure",
            source_node_id=intel_id, target_node_id=asset_id,
            mapping_type="intelligence_indicates_asset",
            confidence_score=confidence,
            evidence_sources=evidence or [],
            temporal_alignment_score=0.5,
        )
        self._mappings.append(mapping)
        return mapping

    def validate_all(self) -> dict[str, Any] | None:
        for m in self._mappings:
            err = m.validate()
            if err:
                return {
                    "status": "CEIP_ARCHITECTURE_VIOLATION",
                    "reason": f"Mapping {m.mapping_id}: {err}",
                }
        return None

    def to_list(self) -> list[dict[str, Any]]:
        return [m.to_dict() for m in self._mappings]
