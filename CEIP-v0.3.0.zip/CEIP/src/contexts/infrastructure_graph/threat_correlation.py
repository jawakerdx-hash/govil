"""Threat correlation — maps threats to graph entities via CrossGraphMappingLayer."""

from __future__ import annotations

import hashlib
from typing import Any

from .cross_graph import CrossGraphMappingLayer


class ThreatCorrelationEngine:
    """Maps ThreatEntities to existing graph entities.

    All mappings go through CrossGraphMappingLayer.
    No direct graph modifications.
    IOC must map to existing assets/vulns/intel. Unresolved → marked.
    """

    def __init__(self, cross_graph: CrossGraphMappingLayer) -> None:
        self._cross = cross_graph
        self._unresolved_iocs: list[dict[str, Any]] = []

    def correlate(
        self, threats: list[dict[str, Any]],
        infra_nodes: list[dict[str, Any]], vuln_nodes: list[dict[str, Any]],
        intel_nodes: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Return (threat_links, unresolved_iocs)."""
        links: list[dict[str, Any]] = []
        asset_map = {n.get("value", ""): n for n in infra_nodes}
        vuln_map = {n.get("vuln_id", n.get("node_id", "")): n for n in vuln_nodes}

        for threat in threats:
            for ioc in threat.get("observed_iocs", []):
                mapped = False
                # Try asset match
                if ioc in asset_map:
                    self._cross.map_intel_to_asset(
                        threat["threat_id"], asset_map[ioc]["node_id"],
                        confidence=70, evidence=[f"ioc_match:{ioc}"],
                    )
                    mapped = True
                # Try vulnerability match
                for vkey, vnode in vuln_map.items():
                    if ioc.lower() in vkey.lower() or vkey.lower() in ioc.lower():
                        self._cross.map_asset_to_vuln(
                            threat["threat_id"], vnode["node_id"],
                            confidence=60, evidence=[f"threat_vuln:{ioc}"],
                        )
                        mapped = True
                        break
                if not mapped:
                    self._unresolved_iocs.append({
                        "ioc": ioc, "threat_id": threat["threat_id"],
                        "status": "unresolved_ioc",
                    })

        # Validate all cross-graph mappings
        err = self._cross.validate_all()
        if err:
            return [], self._unresolved_iocs  # Return unresolved, don't break

        links = [
            {
                "link_id": hashlib.sha256(
                    f"tlink:{t['threat_id']}:{t.get('threat_type','')}".encode()
                ).hexdigest()[:16],
                "threat_id": t["threat_id"],
                "threat_type": t["threat_type"],
                "attack_association_strength": round(t.get("attribution_confidence", 0.5) * 100),
            }
            for t in threats
        ]

        return links, self._unresolved_iocs
