"""Per-graph temporal decay — separate decay rates per graph layer."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

DECAY_CONFIG = {
    "infrastructure": {"threshold_days": 120, "rate": 0.90, "floor": 0.4},
    "vulnerability": {"threshold_days": 60, "rate": 0.80, "floor": 0.2},
    "intelligence": {"threshold_days": 45, "rate": 0.75, "floor": 0.15},
}


class TemporalLayerEngine:
    """Applies per-graph temporal decay. Infrastructure decays slowest,
    intelligence decays fastest."""

    def process_nodes(
        self, nodes: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        now = datetime.now(UTC)
        decayed_count = 0

        for node in nodes:
            layer = node.get("graph_layer", "infrastructure")
            config = DECAY_CONFIG.get(layer, DECAY_CONFIG["infrastructure"])

            last_seen = node.get("last_seen", "")
            if last_seen:
                try:
                    last_dt = datetime.fromisoformat(last_seen)
                    days_old = (now - last_dt).days
                    if days_old > config["threshold_days"]:
                        old_state = node.get("lifecycle_state", "active")
                        node["lifecycle_state"] = "decaying" if days_old < 365 else "archived"
                        if old_state != node["lifecycle_state"]:
                            decayed_count += 1
                except (ValueError, TypeError):
                    pass

        return nodes, {
            "decayed_nodes": decayed_count,
            "total_nodes": len(nodes),
            "decay_configs": DECAY_CONFIG,
        }

    def process_edges(
        self, edges: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        now = datetime.now(UTC)
        decayed = 0
        reinforced = 0

        for edge in edges:
            layer = edge.get("graph_layer", "infrastructure")
            config = DECAY_CONFIG.get(layer, DECAY_CONFIG["infrastructure"])

            last_seen = edge.get("last_seen", "")
            if last_seen:
                try:
                    last_dt = datetime.fromisoformat(last_seen)
                    days_old = (now - last_dt).days
                    if days_old > config["threshold_days"]:
                        edge["temporal_weight"] = max(
                            config["floor"],
                            edge.get("temporal_weight", 1.0) * config["rate"],
                        )
                        edge["strength_score"] = max(
                            10, edge.get("strength_score", 50) * config["rate"],
                        )
                        edge["lifecycle_state"] = "decaying"
                        decayed += 1
                    elif days_old < 30:
                        edge["temporal_weight"] = min(2.0, edge.get("temporal_weight", 1.0) * 1.1)
                        reinforced += 1
                except (ValueError, TypeError):
                    pass

        return edges, {"decayed_edges": decayed, "reinforced_edges": reinforced}
