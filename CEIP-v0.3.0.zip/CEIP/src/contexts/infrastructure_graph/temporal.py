"""Temporal intelligence — edge decay, reinforcement, lifecycle tracking."""
# ruff: noqa: E501

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any


class TemporalEngine:
    """Tracks edge evolution over time.

    Rules: old edges decay unless reinforced, new evidence strengthens,
    inactivity reduces confidence.
    """

    DECAY_THRESHOLD_DAYS = 90
    DECAY_RATE = 0.85
    REINFORCEMENT_BOOST = 1.2
    DECAY_FLOOR = 0.3

    def process(
        self, edges: list[dict[str, Any]], existing_edges: list[dict[str, Any]] | None = None
    ) -> dict[str, Any]:
        now = datetime.now(UTC)
        new_links: list[str] = []
        strengthened: list[str] = []
        decayed: list[str] = []

        existing_map = {}
        if existing_edges:
            for e in existing_edges:
                existing_map[e.get("edge_id", "")] = e

        for edge in edges:
            eid = edge.get("edge_id", "")
            if eid in existing_map:
                # Existing edge — reinforce
                prev = existing_map[eid]
                edge["temporal_weight"] = min(2.0, prev.get("temporal_weight", 1.0) * self.REINFORCEMENT_BOOST)
                edge["strength_score"] = min(100, edge.get("strength_score", 50) * 1.1)
                strengthened.append(eid)
            else:
                # New edge
                edge["temporal_weight"] = 1.0
                new_links.append(eid)

            # Check for decay
            last_seen = edge.get("last_seen", "")
            if last_seen:
                try:
                    last_dt = datetime.fromisoformat(last_seen)
                    days_old = (now - last_dt).days
                    if days_old > self.DECAY_THRESHOLD_DAYS:
                        edge["temporal_weight"] = max(
                            self.DECAY_FLOOR,
                            edge.get("temporal_weight", 1.0) * self.DECAY_RATE,
                        )
                        edge["strength_score"] = max(10, edge.get("strength_score", 50) * self.DECAY_RATE)
                        decayed.append(eid)
                except (ValueError, TypeError):
                    pass

        return {
            "new_links": new_links,
            "strengthened_links": strengthened,
            "decayed_links": decayed,
            "new_count": len(new_links),
            "strengthened_count": len(strengthened),
            "decayed_count": len(decayed),
        }
