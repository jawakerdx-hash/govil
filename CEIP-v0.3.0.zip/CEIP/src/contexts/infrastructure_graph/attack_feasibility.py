"""Attack feasibility reasoning — condition-based, no raw graph traversal."""

from __future__ import annotations

import hashlib
from typing import Any

from .models import AttackFeasibilityPath


class AttackFeasibilityReasoner:
    """Condition-based attack path reasoning.

    Each path must satisfy: asset exposure, vulnerability existence,
    exploit applicability, and privilege boundary conditions.
    No generic multi-hop graph traversal.
    """

    MAX_PATHS = 10

    def compute(
        self, vuln_nodes: list[dict[str, Any]], asset_nodes: list[dict[str, Any]],
        cross_mappings: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        paths: list[dict[str, Any]] = []
        asset_map = {a["node_id"]: a for a in asset_nodes}

        for vuln in vuln_nodes[:20]:
            related = [
                m for m in cross_mappings
                if m.get("target_node_id") == vuln["node_id"]
                and m.get("mapping_type") == "asset_has_vulnerability"
            ]
            for mapping in related:
                asset_id = mapping["source_node_id"]
                asset = asset_map.get(asset_id, {})
                conditions = self._build_conditions(asset, vuln)

                if all(c["met"] for c in conditions):
                    risk = round(
                        sum(c.get("success_probability", 0.5) for c in conditions)
                        / len(conditions) * 100, 1
                    )
                    paths.append(AttackFeasibilityPath(
                        path_id=hashlib.sha256(
                            f"attack:{asset_id}:{vuln['node_id']}".encode()
                        ).hexdigest()[:16],
                        conditions=conditions,
                        path_risk_score=risk,
                        confidence=mapping.get("confidence_score", 50),
                        evidence_chain=mapping.get("evidence_sources", []),
                    ).to_dict())

        return sorted(paths, key=lambda p: p["path_risk_score"], reverse=True)[:self.MAX_PATHS]

    @staticmethod
    def _build_conditions(
        asset: dict[str, Any], vuln: dict[str, Any]
    ) -> list[dict[str, Any]]:
        meta = asset.get("metadata", {})
        exposure = meta.get("risk_surface_score", 50)

        return [
            {
                "condition": "asset_exposure",
                "met": exposure > 30,
                "value": exposure,
                "required_exploit_type": "network_access",
            },
            {
                "condition": "vulnerability_exists",
                "met": True,
                "value": vuln.get("severity", "low"),
                "required_exploit_type": "vulnerability_exploit",
            },
            {
                "condition": "exploit_applicable",
                "met": vuln.get("exploitability_score", 50) > 25,
                "value": vuln.get("exploitability_score", 50),
                "required_exploit_type": "exploit_chain",
                "dependency_validation": vuln.get("exploitability_score", 50) > 25,
                "success_probability": round(vuln.get("exploitability_score", 50) / 100, 3),
            },
            {
                "condition": "privilege_boundary",
                "met": True,
                "value": "network_to_app",
                "required_exploit_type": "privilege_escalation",
            },
        ]
