# ruff: noqa: E501
"""M25 — AI Security Analyst. Read-only reasoning on M20-M24 outputs.

Deterministic structure, evidence-based, non-hallucinatory.
Never modifies scores, graphs, or underlying data.
"""

from __future__ import annotations

from typing import Any

from .schema_validator import SchemaValidator


class SecurityAnalyst:
    """Cyber Security Reasoning Analyst Engine.

    Transforms structured intelligence into explanations, causal reasoning,
    attack narratives, risk justification, and mitigation strategies.
    """

    def analyze(self, pipeline_output: dict[str, Any]) -> dict[str, Any]:
        # 1. Schema validation (M24 integrity check)
        schema_err = SchemaValidator.validate(pipeline_output)
        if schema_err:
            return schema_err

        rating = pipeline_output.get("external_security_rating", {})
        threat_intel = pipeline_output.get("threat_intelligence", {})
        prob_layer = pipeline_output.get("probabilistic_layer", {})
        infra = pipeline_output.get("infrastructure_graph", {})
        vuln_graph = pipeline_output.get("vulnerability_graph", {})

        # A. Security Posture Summary
        posture = self._build_posture(rating)

        # B. Key Risk Drivers
        drivers = self._build_drivers(rating, infra, vuln_graph, threat_intel)

        # C. Attacker Perspective
        attacker_view = self._build_attacker_view(infra, vuln_graph, threat_intel, prob_layer)

        # D. Threat Context
        threat_context = self._build_threat_context(threat_intel)

        # E. Risk Explanation
        risk_explanation = self._build_risk_explanation(rating)

        # F. Mitigation Plan
        mitigations = self._build_mitigations(rating, infra, vuln_graph)

        # Confidence: based on data completeness
        data_sources = ["M24", "M23", "M22"]
        available = sum(1 for src in data_sources if self._has_data(src, pipeline_output))
        confidence = round(available / len(data_sources), 2)

        # Reasoning depth
        total_signals = (
            len(infra.get("nodes", [])) + len(vuln_graph.get("nodes", []))
            + len(threat_intel.get("active_campaigns", []))
        )
        depth = "high" if total_signals > 20 else "medium" if total_signals > 5 else "low"

        return {
            "organization": "",
            "security_analysis": {
                "posture_summary": posture,
                "key_risk_drivers": drivers,
                "attacker_perspective": attacker_view,
                "threat_context": threat_context,
                "risk_explanation": risk_explanation,
                "mitigation_plan": mitigations,
            },
            "analysis_metadata": {
                "data_sources_used": [s for s in data_sources if self._has_data(s, pipeline_output)],
                "confidence_level": confidence,
                "reasoning_depth": depth,
            },
        }

    # ------------------------------------------------------------------
    # Analysis builders
    # ------------------------------------------------------------------

    @staticmethod
    def _build_posture(rating: dict) -> str:
        score = rating.get("overall_score", 50)
        grade = rating.get("grade", "C")
        level = rating.get("risk_level", "medium")
        trend = rating.get("trend", "stable")

        if score >= 75:
            base = f"The organization maintains a strong security posture with an overall score of {score}/100 (Grade {grade})."
        elif score >= 50:
            base = f"The organization has an adequate security posture scoring {score}/100 (Grade {grade}), with notable areas requiring attention."
        else:
            base = f"The organization faces significant security challenges scoring {score}/100 (Grade {grade}), requiring urgent remediation."

        base += f" Risk level is {level.upper()}. Trend is {trend}."
        return base

    @staticmethod
    def _build_drivers(rating: dict, infra: dict, vuln: dict, threat: dict) -> list[dict]:
        drivers = []
        dims = rating.get("dimension_scores", {})
        sorted_dims = sorted(dims.items(), key=lambda x: x[1].get("value", 50))

        for dim_name, dim_data in sorted_dims[:5]:
            drivers.append({
                "dimension": dim_name,
                "score": dim_data.get("value", 50),
                "affected_layers": SecurityAnalyst._map_layers(dim_name),
                "evidence": dim_data.get("evidence", []),
            })
        return drivers

    @staticmethod
    def _build_attacker_view(infra: dict, vuln: dict, threat: dict, prob: dict) -> str:
        nodes = infra.get("nodes", [])
        vulns = vuln.get("nodes", [])
        campaigns = threat.get("active_campaigns", [])

        services = [n for n in nodes if n.get("node_type") == "service"]
        entry_points = [s.get("value", "") for s in services[:3]]

        parts = ["If I were an attacker targeting this organization:"]

        if entry_points:
            parts.append(f"Entry points: {', '.join(entry_points)}")
        else:
            parts.append("Entry points: No exposed services identified")

        if vulns:
            parts.append(f"Exploitable vulnerabilities: {len(vulns)} detected across infrastructure")
        else:
            parts.append("Exploitable vulnerabilities: No CVEs mapped")

        if campaigns:
            parts.append(f"Active threat campaigns: {len(campaigns)} targeting this organization")
        else:
            parts.append("Active threat campaigns: None detected")

        risk_dist = prob.get("risk_distribution", {})
        enhanced = risk_dist.get("probabilistic_enhanced", 50)
        parts.append(f"Probabilistic exploit likelihood: {enhanced:.0f}/100")

        return ". ".join(parts) + "."

    @staticmethod
    def _build_threat_context(threat: dict) -> list[dict]:
        context = []
        for campaign in threat.get("active_campaigns", [])[:3]:
            context.append({
                "campaign": campaign.get("campaign_id", "unknown"),
                "confidence": campaign.get("confidence_score", 0.5),
                "phases": campaign.get("attack_phases", []),
                "relevance": "The organization appears in threat intelligence as a target of this campaign",
            })
        for profile in threat.get("adversary_profiles", [])[:2]:
            context.append({
                "adversary": profile.get("threat_id", "unknown"),
                "patterns": profile.get("known_infrastructure_patterns", []),
                "confidence": profile.get("confidence", 0.5),
                "relevance": "Adversary profile matches organizational attack surface patterns",
            })
        return context

    @staticmethod
    def _build_risk_explanation(rating: dict) -> str:
        score = rating.get("overall_score", 50)
        grade = rating.get("grade", "C")
        dims = rating.get("dimension_scores", {})
        dim_entries = [(k, v.get("value", 50)) for k, v in dims.items()]
        dim_entries.sort(key=lambda x: x[1])

        strongest = dim_entries[-1] if dim_entries else ("unknown", 50)
        weakest = dim_entries[0] if dim_entries else ("unknown", 50)

        return (
            f"The overall security rating of {score}/100 ({grade}) is primarily driven by "
            f"strong performance in {strongest[0]} ({strongest[1]}/100) and "
            f"weak performance in {weakest[0]} ({weakest[1]}/100). "
            f"Addressing the weakest dimension would yield the largest score improvement."
        )

    @staticmethod
    def _build_mitigations(rating: dict, infra: dict, vuln: dict) -> list[dict]:
        mitigations = []
        dims = rating.get("dimension_scores", {})
        sorted_dims = sorted(dims.items(), key=lambda x: x[1].get("value", 50))

        priorities = ["P1", "P2", "P3", "P4"]
        for i, (dim_name, dim_data) in enumerate(sorted_dims[:4]):
            if dim_data.get("value", 50) >= 70:
                continue
            mitigations.append({
                "dimension": dim_name,
                "priority": priorities[min(i, 3)],
                "strategy": SecurityAnalyst._mitigation_for(dim_name),
                "estimated_impact": f"+{min(20, (70 - dim_data.get('value', 50)) // 2)} points",
                "affected_layer": SecurityAnalyst._map_layers(dim_name),
            })
        return mitigations

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _has_data(source: str, output: dict) -> bool:
        if source == "M24":
            return "external_security_rating" in output
        if source == "M23":
            return bool(output.get("threat_intelligence", {}).get("active_campaigns"))
        if source == "M22":
            return "probabilistic_layer" in output
        return False

    @staticmethod
    def _map_layers(dimension: str) -> list[str]:
        mapping = {
            "attack_surface_score": ["infrastructure", "discovery"],
            "vulnerability_score": ["vulnerability", "attack_paths"],
            "exposure_score": ["infrastructure", "intelligence"],
            "identity_risk_score": ["intelligence", "identity"],
            "threat_activity_score": ["threat_intelligence", "campaigns"],
            "cloud_risk_score": ["infrastructure", "cloud"],
            "dark_web_risk_score": ["intelligence", "darkweb"],
        }
        return mapping.get(dimension, ["unknown"])

    @staticmethod
    def _mitigation_for(dimension: str) -> str:
        strategies = {
            "attack_surface_score": "Reduce exposed services; implement additional network segmentation",
            "vulnerability_score": "Patch critical CVEs immediately; establish regular scanning cadence",
            "exposure_score": "Address misconfigurations; review public-facing asset inventory",
            "identity_risk_score": "Enable MFA across all accounts; monitor credential leak sources",
            "threat_activity_score": "Deploy threat-informed defenses; enhance threat intelligence feeds",
            "cloud_risk_score": "Harden cloud configurations; review IAM policies and storage permissions",
            "dark_web_risk_score": "Rotate exposed credentials; increase dark web monitoring frequency",
        }
        return strategies.get(dimension, "Review and improve security controls")
