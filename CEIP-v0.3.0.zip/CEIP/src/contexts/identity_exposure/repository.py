"""Repository layer — all database access for identity exposure."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.identity_exposure.models import (
    ExposureEvidence,
    IdentityCorrelation,
    IdentityExposure,
)


class IdentityExposureRepository:
    """Data access for identity exposure context. Service never touches SQL directly."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def clear_domain(self, domain: str) -> None:
        """Remove all exposure data for a domain."""
        rows = (
            await self._db.execute(
                select(IdentityExposure).where(IdentityExposure.domain == domain)
            )
        ).scalars().all()
        for exp in rows:
            await self._delete_children(exp.id)
            await self._db.delete(exp)
        await self._db.flush()

    async def _delete_children(self, exposure_id: object) -> None:
        for model in (IdentityCorrelation, ExposureEvidence):
            rows = (
                await self._db.execute(
                    select(model).where(model.exposure_id == exposure_id)
                )
            ).scalars().all()
            for row in rows:
                await self._db.delete(row)

    async def add_exposure(self, exposure: IdentityExposure) -> None:
        self._db.add(exposure)
        await self._db.flush()

    async def add_evidence(self, evidence: ExposureEvidence) -> None:
        self._db.add(evidence)

    async def add_correlation(self, correlation: IdentityCorrelation) -> None:
        self._db.add(correlation)

    async def flush(self) -> None:
        await self._db.flush()
