"""Pydantic schemas for identity exposure API."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class IdentityScanRequest(BaseModel):
    domain: str = Field(min_length=3, max_length=255)


class EvidenceResponse(BaseModel):
    id: UUID
    provider: str
    evidence_type: str
    title: str
    description: str | None = None
    url: str | None = None
    collected_at: datetime

    model_config = {"from_attributes": True}


class CorrelationResponse(BaseModel):
    id: UUID
    identity_value: str
    related_asset: str
    relation_type: str
    confidence: float

    model_config = {"from_attributes": True}


class ExposureResponse(BaseModel):
    id: UUID
    identity_type: str
    value: str
    source: str
    confidence: float
    severity: str
    first_seen: datetime
    last_seen: datetime
    status: str
    metadata_json: str | None = None

    model_config = {"from_attributes": True}


class IdentitySummaryResponse(BaseModel):
    domain: str
    total_exposures: int = 0
    emails_found: int = 0
    employees_found: int = 0
    executives_found: int = 0
    admins_found: int = 0
    repositories_found: int = 0
    secrets_found: int = 0
    exposure_score: int = 0
    risk_contribution: int = 0
    severity_counts: dict[str, int] = Field(default_factory=lambda: {
        "CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0,
    })
    top_findings: list[str] = Field(default_factory=list)
    exposures: list[ExposureResponse] = Field(default_factory=list)
    correlations: list[CorrelationResponse] = Field(default_factory=list)
    evidence: list[EvidenceResponse] = Field(default_factory=list)
    summary: str = ""
