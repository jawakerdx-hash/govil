"""Risk policy — configurable weighting strategy for identity exposure scoring.

Replaces the static RISK_WEIGHTS dict with a strategy that can be
swapped per customer, industry, or compliance framework.
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class RiskPolicy(ABC):
    """Abstract strategy for computing identity exposure risk contribution."""

    @abstractmethod
    def weight_for(self, identity_type: str) -> int:
        """Return the risk contribution weight for an identity type."""
        ...

    @abstractmethod
    def score(self, identity_type: str, confidence: float) -> int:
        """Compute a weighted score from identity type and confidence."""
        ...


class DefaultIdentityRiskPolicy(RiskPolicy):
    """Standard risk weights suitable for most organizations."""

    _weights: dict[str, int] = {
        "EMAIL": 5,
        "USERNAME": 3,
        "EMPLOYEE": 5,
        "ADMIN": 10,
        "EXECUTIVE": 15,
        "PUBLIC_REPOSITORY": 20,
        "PUBLIC_SECRET": 35,
        "BREACH_REFERENCE": 10,
    }

    def weight_for(self, identity_type: str) -> int:
        return self._weights.get(identity_type, 0)

    def score(self, identity_type: str, confidence: float) -> int:
        return int(confidence * self.weight_for(identity_type))
