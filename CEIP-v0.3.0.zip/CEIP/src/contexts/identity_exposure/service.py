"""Identity exposure service — collect, correlate, assess risk."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from src.config import Settings
from src.contexts.identity_exposure.evidence import NormalizedEvidence
from src.contexts.identity_exposure.models import (
    ExposureEvidence,
    IdentityCorrelation,
    IdentityExposure,
)
from src.contexts.identity_exposure.providers.base import IdentityProvider
from src.contexts.identity_exposure.registry import ProviderRegistry
from src.contexts.identity_exposure.repository import IdentityExposureRepository
from src.contexts.identity_exposure.risk_policy import DefaultIdentityRiskPolicy, RiskPolicy


class IdentityExposureService:
    """Orchestrate identity exposure collection, correlation, and risk assessment.

    All dependencies injected — no direct instantiation of providers,
    repositories, or policies.
    """

    def __init__(
        self,
        repo: IdentityExposureRepository,
        provider: IdentityProvider | None = None,
        settings: Settings | None = None,
        risk_policy: RiskPolicy | None = None,
    ) -> None:
        self._repo = repo
        self._provider = provider or ProviderRegistry.resolve(settings or Settings())
        self._policy = risk_policy or DefaultIdentityRiskPolicy()

    async def scan(self, domain: str) -> dict[str, Any]:
        """Run identity exposure scan for a domain."""
        domain = domain.lower().strip()
        await self._repo.clear_domain(domain)

        results = await self._provider.collect(domain)
        exposures: list[dict[str, Any]] = []
        correlations: list[dict[str, Any]] = []
        evidence_list: list[dict[str, Any]] = []

        for r in results:
            now = datetime.now(UTC)
            exp = IdentityExposure(
                domain=domain, identity_type=r.identity_type, value=r.value,
                source=r.source, confidence=r.confidence, severity=r.severity,
                first_seen=now, last_seen=now, status="active",
                metadata_json=json.dumps(r.metadata) if r.metadata else None,
            )
            await self._repo.add_exposure(exp)

            exposures.append({
                "id": exp.id, "identity_type": exp.identity_type,
                "value": exp.value, "source": exp.source,
                "confidence": exp.confidence, "severity": exp.severity,
                "first_seen": exp.first_seen, "last_seen": exp.last_seen,
                "status": exp.status, "metadata_json": exp.metadata_json,
            })

            # Normalized evidence
            norm = NormalizedEvidence(
                provider=r.source,
                evidence_type="breach" if "breach" in r.evidence_title.lower() else "search_result",
                title=r.evidence_title,
                description=r.evidence_description,
                source_url=r.evidence_url,
                raw_data={"identity_type": r.identity_type, "value": r.value},
                normalized_data={"severity": r.severity, "confidence": r.confidence},
            )
            ev = ExposureEvidence(
                exposure_id=exp.id, provider=norm.provider,
                evidence_type=norm.evidence_type, title=norm.title,
                description=norm.description, url=norm.source_url,
                collected_at=now,
            )
            await self._repo.add_evidence(ev)
            evidence_list.append({
                "id": ev.id, "provider": ev.provider, "evidence_type": ev.evidence_type,
                "title": ev.title, "description": ev.description,
                "url": ev.url, "collected_at": ev.collected_at,
            })

            # Correlation
            corr = IdentityCorrelation(
                exposure_id=exp.id, identity_value=r.value,
                related_asset=domain, relation_type="belongs_to",
                confidence=r.confidence,
            )
            await self._repo.add_correlation(corr)
            correlations.append({
                "id": corr.id, "identity_value": corr.identity_value,
                "related_asset": corr.related_asset,
                "relation_type": corr.relation_type, "confidence": corr.confidence,
            })

        await self._repo.flush()

        return self._build_summary(domain, exposures, correlations, evidence_list)

    # ------------------------------------------------------------------

    def _build_summary(
        self,
        domain: str,
        exposures: list[dict[str, Any]],
        correlations: list[dict[str, Any]],
        evidence_list: list[dict[str, Any]],
    ) -> dict[str, Any]:
        counts = {
            "emails": sum(1 for e in exposures if e["identity_type"] == "EMAIL"),
            "employees": sum(
                1 for e in exposures if e["identity_type"] in ("EMPLOYEE", "USERNAME")
            ),
            "executives": sum(1 for e in exposures if e["identity_type"] == "EXECUTIVE"),
            "admins": sum(1 for e in exposures if e["identity_type"] == "ADMIN"),
            "repos": sum(1 for e in exposures if e["identity_type"] == "PUBLIC_REPOSITORY"),
            "secrets": sum(1 for e in exposures if e["identity_type"] == "PUBLIC_SECRET"),
        }
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        exposure_score = 0
        risk_contribution = 0

        for e in exposures:
            sev = e["severity"]
            if sev in severity_counts:
                severity_counts[sev] += 1
            risk_contribution += self._policy.weight_for(e["identity_type"])
            exposure_score += self._policy.score(
                e["identity_type"], float(e["confidence"])
            )

        sorted_exposures = sorted(
            exposures,
            key=lambda x: self._policy.score(
                str(x["identity_type"]), float(x["confidence"])
            ),
            reverse=True,
        )
        top_findings = [
            f"[{e['severity']}] {e['identity_type']}: {str(e['value'])[:60]}"
            for e in sorted_exposures[:5]
        ]

        return {
            "domain": domain,
            "total_exposures": len(exposures),
            "emails_found": counts["emails"],
            "employees_found": counts["employees"],
            "executives_found": counts["executives"],
            "admins_found": counts["admins"],
            "repositories_found": counts["repos"],
            "secrets_found": counts["secrets"],
            "exposure_score": exposure_score,
            "risk_contribution": risk_contribution,
            "severity_counts": severity_counts,
            "top_findings": top_findings,
            "exposures": exposures,
            "correlations": correlations,
            "evidence": evidence_list,
            "summary": (
                f"{len(exposures)} identity exposures: "
                f"{counts['emails']} emails, {counts['employees']} employees, "
                f"{counts['executives']} executives, {counts['admins']} admins, "
                f"{counts['repos']} repos, {counts['secrets']} secrets. "
                f"Score: {exposure_score} (risk contribution: {risk_contribution})"
            ),
        }
