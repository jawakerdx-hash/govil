"""Identity exposure ORM models."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class IdentityExposure(UUIDMixin, TimestampMixin, Base):
    """A publicly exposed identity related to an organization."""

    __tablename__ = "identity_exposures"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    identity_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # EMAIL, USERNAME, EMPLOYEE, ADMIN, EXECUTIVE, PUBLIC_SECRET, REPOSITORY, BREACH
    value: Mapped[str] = mapped_column(String(512), nullable=False)
    source: Mapped[str] = mapped_column(String(128), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    severity: Mapped[str] = mapped_column(
        String(16), nullable=False
    )  # LOW, MEDIUM, HIGH, CRITICAL
    first_seen: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now()
    )
    last_seen: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now(), onupdate=func.now()
    )
    status: Mapped[str] = mapped_column(String(20), default="active")
    metadata_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class ExposureEvidence(UUIDMixin, Base):
    """Supporting evidence for an identity exposure."""

    __tablename__ = "exposure_evidence"

    exposure_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("identity_exposures.id", ondelete="CASCADE"), nullable=False, index=True
    )
    provider: Mapped[str] = mapped_column(String(64), nullable=False)
    evidence_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # breach, leak, repository, search_result
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    url: Mapped[str | None] = mapped_column(Text, nullable=True)
    collected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now()
    )


class IdentityCorrelation(UUIDMixin, Base):
    """Correlation between an identity exposure and a known asset."""

    __tablename__ = "identity_correlations"

    exposure_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("identity_exposures.id", ondelete="CASCADE"), nullable=False, index=True
    )
    identity_value: Mapped[str] = mapped_column(String(512), nullable=False)
    related_asset: Mapped[str] = mapped_column(String(512), nullable=False)
    relation_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # belongs_to, mentions, references, resolves_to
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
