"""Normalized evidence model — provider-agnostic evidence representation."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class NormalizedEvidence:
    """Provider-agnostic evidence. Every provider normalizes into this format."""

    provider: str
    evidence_type: str  # breach, leak, repository, search_result
    title: str
    description: str | None = None
    source_url: str | None = None
    collected_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    raw_data: dict[str, Any] = field(default_factory=dict)
    normalized_data: dict[str, Any] = field(default_factory=dict)

    @property
    def content_hash(self) -> str:
        """Deterministic hash of the evidence content for deduplication."""
        payload = f"{self.provider}|{self.evidence_type}|{self.title}"
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    def to_json(self) -> str:
        return json.dumps({
            "provider": self.provider,
            "evidence_type": self.evidence_type,
            "title": self.title,
            "source_url": self.source_url,
            "collected_at": self.collected_at,
            "normalized_data": self.normalized_data,
            "content_hash": self.content_hash,
        })
