"""Provider abstraction for identity exposure intelligence."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class IdentityResult:
    """A single identity exposure result from a provider."""

    identity_type: str  # EMAIL, USERNAME, EMPLOYEE, ADMIN, etc.
    value: str          # The actual email, username, etc.
    source: str         # Provider name
    confidence: float   # 0.0 - 1.0
    severity: str       # LOW, MEDIUM, HIGH, CRITICAL
    evidence_title: str = ""
    evidence_description: str | None = None
    evidence_url: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)


class IdentityProvider(ABC):
    """Abstract provider for identity exposure intelligence.

    Implementations can connect to HaveIBeenPwned, DeHashed, GitHub, etc.
    """

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    async def collect(self, domain: str) -> list[IdentityResult]: ...

    @abstractmethod
    async def search_email(self, email: str) -> list[IdentityResult]: ...

    @abstractmethod
    async def search_username(self, username: str) -> list[IdentityResult]: ...

    @abstractmethod
    async def search_domain(self, domain: str) -> list[IdentityResult]: ...
