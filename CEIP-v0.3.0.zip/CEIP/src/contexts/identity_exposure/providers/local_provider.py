"""Local identity provider — returns empty results when no real provider is configured."""

from __future__ import annotations

from src.contexts.identity_exposure.providers.base import IdentityProvider, IdentityResult


class LocalIdentityProvider(IdentityProvider):
    """Default provider. Returns empty results — no fabricated data.

    To get real identity exposure intelligence, configure a real provider
    (e.g. HaveIBeenPwned API, Dehashed, SpyCloud) and register it.
    """

    @property
    def name(self) -> str:
        return "local"

    async def collect(self, domain: str) -> list[IdentityResult]:
        return []

    async def search_email(self, email: str) -> list[IdentityResult]:
        return []

    async def search_username(self, username: str) -> list[IdentityResult]:
        return []

    async def search_domain(self, domain: str) -> list[IdentityResult]:
        return []
