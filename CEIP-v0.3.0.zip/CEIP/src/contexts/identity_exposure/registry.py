"""Provider registry — resolves identity providers through configuration."""

from __future__ import annotations

from src.config import Settings
from src.contexts.identity_exposure.providers.base import IdentityProvider
from src.contexts.identity_exposure.providers.local_provider import LocalIdentityProvider


class ProviderRegistry:
    """Resolves the configured IdentityProvider without the service knowing which one.

    Adding a new provider (HaveIBeenPwned, DeHashed, etc.) means:
        1. Implement IdentityProvider
        2. Add one line here
        3. Zero changes to IdentityExposureService
    """

    _providers: dict[str, type[IdentityProvider]] = {
        "local": LocalIdentityProvider,
    }

    @classmethod
    def register(cls, name: str, provider_cls: type[IdentityProvider]) -> None:
        """Register a new provider implementation at runtime."""
        cls._providers[name] = provider_cls

    @classmethod
    def resolve(cls, settings: Settings) -> IdentityProvider:
        """Return the configured provider instance.

        Provider selection via IDENTITY_PROVIDER env var or .env setting.
        Defaults to 'local'.
        """
        provider_name = getattr(settings, "identity_provider", "local") or "local"
        provider_cls = cls._providers.get(provider_name)
        if provider_cls is None:
            raise ValueError(
                f"Unknown identity provider: {provider_name}. "
                f"Available: {', '.join(cls._providers)}"
            )
        return provider_cls()
