"""Investigation Pydantic schemas — request/response validation."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Phase configuration
# ---------------------------------------------------------------------------


class PhaseConfig(BaseModel):
    """Configuration for a single investigation phase."""
    phase_number: int = Field(ge=1, le=19)
    enabled: bool = True
    skip_on_failure: bool = False  # if True, skip phase when any job fails


class InvestigationConfig(BaseModel):
    """Full investigation configuration."""
    phases: list[PhaseConfig] = Field(default_factory=list)
    max_parallel_jobs: int = Field(default=4, ge=1, le=16)
    job_timeout_seconds: int = Field(default=120, ge=10, le=600)
    max_retries: int = Field(default=3, ge=0, le=5)
    verify_evidence: bool = True
    generate_intelligence: bool = True


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class CreateInvestigationRequest(BaseModel):
    """Request to create a new investigation."""
    domain: str = Field(min_length=3, max_length=255)
    tenant_id: str = Field(default="default")
    priority: str = Field(default="MEDIUM", pattern="^(LOW|MEDIUM|HIGH|CRITICAL)$")
    start_immediately: bool = Field(default=True)
    config: InvestigationConfig | None = None


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class JobSummary(BaseModel):
    """Lightweight job status for list responses."""
    id: UUID
    phase: int
    job_type: str
    status: str
    attempt: int
    duration_ms: int | None = None
    error: str | None = None

    model_config = {"from_attributes": True}


class PhaseSummary(BaseModel):
    """Per-phase progress."""
    phase_number: int
    name: str
    status: str
    job_count: int
    completed_jobs: int
    failed_jobs: int
    started_at: datetime | None = None
    completed_at: datetime | None = None

    model_config = {"from_attributes": True}


class EvidenceItem(BaseModel):
    """A single piece of investigation evidence."""
    id: UUID
    evidence_type: str
    severity: str
    title: str
    description: str | None = None
    source_module: str
    entity_type: str
    entity_value: str
    confidence: float
    verified: bool

    model_config = {"from_attributes": True}


class TimelineEvent(BaseModel):
    """A single timeline event."""
    id: UUID
    phase: int | None = None
    event_type: str
    message: str
    sequence: int
    created_at: datetime

    model_config = {"from_attributes": True}


class InvestigationProgress(BaseModel):
    """Detailed progress breakdown."""
    investigation_id: UUID
    domain: str
    status: str
    current_phase: int
    progress_pct: float
    total_jobs: int
    completed_jobs: int
    failed_jobs: int
    running_jobs: int
    evidence_count: int
    asset_count: int
    finding_count: int
    risk_score: float
    risk_level: str
    phases: list[PhaseSummary] = Field(default_factory=list)


class InvestigationSummary(BaseModel):
    """Lightweight investigation for list responses."""
    id: UUID
    domain: str
    tenant_id: str
    status: str
    priority: str
    current_phase: int
    progress_pct: float
    risk_score: float
    risk_level: str
    evidence_count: int
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None

    model_config = {"from_attributes": True}


class InvestigationDetail(BaseModel):
    """Full investigation response including all child entities."""
    id: UUID
    domain: str
    tenant_id: str
    status: str
    priority: str
    current_phase: int
    progress_pct: float
    total_jobs: int
    completed_jobs: int
    failed_jobs: int
    running_jobs: int
    evidence_count: int
    asset_count: int
    finding_count: int
    risk_score: float
    risk_level: str
    intelligence_cases: int
    error_message: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    phases: list[PhaseSummary] = Field(default_factory=list)
    recent_timeline: list[TimelineEvent] = Field(default_factory=list)

    model_config = {"from_attributes": True}


class InvestigationReport(BaseModel):
    """Generated investigation report."""
    investigation_id: UUID
    domain: str
    generated_at: str
    risk_score: float
    risk_level: str
    asset_count: int
    finding_count: int
    evidence_count: int
    intelligence_cases: int
    attack_paths: list[dict] = Field(default_factory=list)
    executive_summary: str = ""
    sections: list[dict] = Field(default_factory=list)


class IntelligenceCaseResponse(BaseModel):
    """An intelligence case generated by the Security Intelligence Brain."""
    case_id: str
    title: str
    executive_summary: str
    risk_level: str
    confidence: float
    evidence: list[str] = Field(default_factory=list)
    affected_assets: list[str] = Field(default_factory=list)
    attack_path: list[str] = Field(default_factory=list)
    threat_context: str = ""
    business_impact: str = ""
    root_cause: str = ""
    recommendations: list[str] = Field(default_factory=list)
    priority: str = "MEDIUM"


class InvestigationListResponse(BaseModel):
    """Paginated list of investigations."""
    investigations: list[InvestigationSummary]
    total: int
    offset: int = 0
    limit: int = 50
