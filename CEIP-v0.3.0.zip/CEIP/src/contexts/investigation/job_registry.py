"""Job Registry — plugin system for investigation job types.

New job types are registered here without modifying the orchestrator.
Each JobDefinition describes a job type: what phase it belongs to,
what worker executes it, what evidence it produces.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# The 19 investigation phases (canonical names)
# ---------------------------------------------------------------------------

PHASE_NAMES: dict[int, str] = {
    1: "Target Validation",
    2: "Passive Discovery",
    3: "DNS Intelligence",
    4: "Certificate Intelligence",
    5: "Asset Discovery",
    6: "Technology Fingerprinting",
    7: "Port & Service Enumeration",
    8: "Endpoint Discovery",
    9: "JavaScript Analysis",
    10: "API Discovery",
    11: "Cloud Intelligence",
    12: "Threat Intelligence Enrichment",
    13: "Evidence Correlation",
    14: "Verification",
    15: "Risk Analysis",
    16: "Attack Path Generation",
    17: "Security Intelligence Cases",
    18: "Executive Report",
    19: "Continuous Monitoring Registration",
}


@dataclass
class JobDefinition:
    """Describes a single job type that can be executed within an investigation phase.

    Registration example::

        JobRegistry.register(JobDefinition(
            job_type="dns_resolution",
            phase=3,
            worker_class="src.contexts.investigation.workers.discovery.DNSResolutionWorker",
            description="Resolve all DNS record types for the target domain",
            produces_evidence=["asset"],
        ))
    """

    job_type: str
    phase: int  # 1-19
    worker_class: str  # fully qualified import path
    description: str = ""
    default_max_attempts: int = 3
    default_timeout_seconds: int = 120
    produces_evidence: list[str] = field(default_factory=list)  # evidence_type values
    required_input: list[str] = field(default_factory=list)  # input key names
    dependencies: list[str] = field(default_factory=list)  # job_type strings that must run first
    can_run_parallel: bool = True
    default_priority: int = 50  # 0 (highest) - 100 (lowest)


# ---------------------------------------------------------------------------
# Job Registry
# ---------------------------------------------------------------------------


class JobRegistry:
    """Central registry of all job types available for investigations.

    Thread-safe class-level registry. Workers are discovered by phase.
    New job types are added with ``JobRegistry.register()`` — no orchestrator changes needed.
    """

    _jobs: dict[str, JobDefinition] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    @classmethod
    def register(cls, definition: JobDefinition) -> None:
        """Register a job type. Overwrites if job_type already exists."""
        if definition.phase not in PHASE_NAMES:
            raise ValueError(
                f"Invalid phase {definition.phase}. Must be 1-19."
            )
        cls._jobs[definition.job_type] = definition

    @classmethod
    def register_many(cls, definitions: list[JobDefinition]) -> None:
        """Register multiple job types at once."""
        for d in definitions:
            cls.register(d)

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    @classmethod
    def get(cls, job_type: str) -> JobDefinition | None:
        """Get a job definition by type string."""
        return cls._jobs.get(job_type)

    @classmethod
    def get_phase_jobs(cls, phase: int) -> list[JobDefinition]:
        """Return all job definitions for a given phase, sorted by priority."""
        jobs = [j for j in cls._jobs.values() if j.phase == phase]
        return sorted(jobs, key=lambda j: j.default_priority)

    @classmethod
    def get_all(cls) -> dict[str, JobDefinition]:
        """Return all registered job definitions."""
        return dict(cls._jobs)

    @classmethod
    def phase_count(cls) -> dict[int, int]:
        """Return job count per phase."""
        counts: dict[int, int] = {}
        for j in cls._jobs.values():
            counts[j.phase] = counts.get(j.phase, 0) + 1
        return counts

    @classmethod
    def total_count(cls) -> int:
        """Total number of registered job types."""
        return len(cls._jobs)

    @classmethod
    def clear(cls) -> None:
        """Remove all registered jobs (useful for testing)."""
        cls._jobs.clear()


# ---------------------------------------------------------------------------
# Pre-register all 19 phases' job types
# ---------------------------------------------------------------------------

_BUILTIN_JOBS: list[JobDefinition] = [
    # ---- Phase 1: Target Validation ----
    JobDefinition(
        job_type="validate_target", phase=1,
        worker_class="src.contexts.investigation.workers.discovery.TargetValidationWorker",
        description="Validate target domain is resolvable and well-formed",
        produces_evidence=["asset"], can_run_parallel=False,
        default_priority=1,
    ),

    # ---- Phase 2: Passive Discovery ----
    JobDefinition(
        job_type="passive_discovery", phase=2,
        worker_class="src.contexts.investigation.workers.discovery.PassiveDiscoveryWorker",
        description="Discover subdomains via wordlist and passive sources",
        produces_evidence=["asset"],
    ),
    JobDefinition(
        job_type="subdomain_wordlist", phase=2,
        worker_class="src.contexts.investigation.workers.discovery.SubdomainWordlistWorker",
        description="Brute-force common subdomain names",
        produces_evidence=["asset"],
    ),

    # ---- Phase 3: DNS Intelligence ----
    JobDefinition(
        job_type="dns_resolution", phase=3,
        worker_class="src.contexts.investigation.workers.discovery.DNSResolutionWorker",
        description="Resolve DNS A, AAAA, NS, MX, TXT, SOA, CNAME records",
        produces_evidence=["asset"],
    ),
    JobDefinition(
        job_type="dns_zone_analysis", phase=3,
        worker_class="src.contexts.investigation.workers.discovery.DNSZoneAnalysisWorker",
        description="Analyze DNS zone configuration, SPF, DMARC, DKIM",
        produces_evidence=["finding"],
    ),

    # ---- Phase 4: Certificate Intelligence ----
    JobDefinition(
        job_type="certificate_transparency", phase=4,
        worker_class="src.contexts.investigation.workers.discovery.CertificateTransparencyWorker",
        description="Query crt.sh for certificate transparency logs",
        produces_evidence=["certificate"],
    ),
    JobDefinition(
        job_type="ssl_fingerprint", phase=4,
        worker_class="src.contexts.investigation.workers.discovery.SSLFingerprintWorker",
        description="Fingerprint SSL/TLS certificates on discovered hosts",
        produces_evidence=["certificate"],
    ),

    # ---- Phase 5: Asset Discovery ----
    JobDefinition(
        job_type="http_fingerprint", phase=5,
        worker_class="src.contexts.investigation.workers.discovery.HTTPFingerprintWorker",
        description="HTTP service fingerprinting — server, headers, status codes",
        produces_evidence=["service"],
    ),
    JobDefinition(
        job_type="ip_enrichment", phase=5,
        worker_class="src.contexts.investigation.workers.discovery.IPEnrichmentWorker",
        description="Enrich IPs with reverse DNS, ASN, organization",
        produces_evidence=["asset"],
    ),
    JobDefinition(
        job_type="cdn_detection", phase=5,
        worker_class="src.contexts.investigation.workers.tech.CDNDetectionWorker",
        description="Detect CDN, WAF, and reverse-proxy presence",
        produces_evidence=["technology"],
    ),

    # ---- Phase 6: Technology Fingerprinting ----
    JobDefinition(
        job_type="tech_stack_detect", phase=6,
        worker_class="src.contexts.investigation.workers.tech.TechStackDetectWorker",
        description="Detect full technology stack using 12-detector engine",
        produces_evidence=["technology"],
    ),
    JobDefinition(
        job_type="framework_detect", phase=6,
        worker_class="src.contexts.investigation.workers.tech.FrameworkDetectWorker",
        description="Identify web frameworks (React, Vue, Django, Rails, etc.)",
        produces_evidence=["technology"],
    ),
    JobDefinition(
        job_type="cms_detect", phase=6,
        worker_class="src.contexts.investigation.workers.tech.CMSDetectWorker",
        description="Detect CMS platforms (WordPress, Drupal, Shopify, etc.)",
        produces_evidence=["technology"],
    ),

    # ---- Phase 7: Port & Service Enumeration ----
    JobDefinition(
        job_type="port_scan", phase=7,
        worker_class="src.contexts.investigation.workers.enumeration.PortScanWorker",
        description="Scan common ports on discovered hosts",
        produces_evidence=["service"],
    ),
    JobDefinition(
        job_type="service_banner_grab", phase=7,
        worker_class="src.contexts.investigation.workers.enumeration.ServiceBannerWorker",
        description="Grab service banners from open ports",
        produces_evidence=["service"],
    ),

    # ---- Phase 8: Endpoint Discovery ----
    JobDefinition(
        job_type="path_fuzzing", phase=8,
        worker_class="src.contexts.investigation.workers.enumeration.PathFuzzingWorker",
        description="Discover common paths and endpoints on HTTP services",
        produces_evidence=["endpoint"],
    ),
    JobDefinition(
        job_type="directory_enum", phase=8,
        worker_class="src.contexts.investigation.workers.enumeration.DirectoryEnumWorker",
        description="Enumerate directories for sensitive content",
        produces_evidence=["endpoint"],
    ),

    # ---- Phase 9: JavaScript Analysis ----
    JobDefinition(
        job_type="js_extraction", phase=9,
        worker_class="src.contexts.investigation.workers.enumeration.JSExtractionWorker",
        description="Extract and analyze JavaScript files for endpoints and secrets",
        produces_evidence=["endpoint", "finding"],
    ),
    JobDefinition(
        job_type="api_endpoint_discovery", phase=9,
        worker_class="src.contexts.investigation.workers.enumeration.APIEndpointWorker",
        description="Discover API endpoints from JavaScript source maps",
        produces_evidence=["endpoint"],
    ),

    # ---- Phase 10: API Discovery ----
    JobDefinition(
        job_type="api_schema_detection", phase=10,
        worker_class="src.contexts.investigation.workers.enumeration.APISchemaWorker",
        description="Detect API schemas (OpenAPI, GraphQL, gRPC)",
        produces_evidence=["endpoint"],
    ),
    JobDefinition(
        job_type="openapi_discovery", phase=10,
        worker_class="src.contexts.investigation.workers.enumeration.OpenAPIDiscoveryWorker",
        description="Discover OpenAPI/Swagger specifications",
        produces_evidence=["endpoint"],
    ),

    # ---- Phase 11: Cloud Intelligence ----
    JobDefinition(
        job_type="cloud_provider_detect", phase=11,
        worker_class="src.contexts.investigation.workers.enumeration.CloudProviderWorker",
        description="Detect cloud provider (AWS, GCP, Azure) from headers and IPs",
        produces_evidence=["technology"],
    ),
    JobDefinition(
        job_type="storage_bucket_enum", phase=11,
        worker_class="src.contexts.investigation.workers.enumeration.StorageBucketWorker",
        description="Enumerate cloud storage buckets for the domain",
        produces_evidence=["finding"],
    ),

    # ---- Phase 12: Threat Intelligence Enrichment ----
    JobDefinition(
        job_type="ioc_matching", phase=12,
        worker_class="src.contexts.investigation.workers.intel.IOCMatchingWorker",
        description="Match discovered IPs and domains against IOC dataset",
        produces_evidence=["threat"],
    ),
    JobDefinition(
        job_type="threat_feed_check", phase=12,
        worker_class="src.contexts.investigation.workers.intel.ThreatFeedWorker",
        description="Check threat intelligence feeds for known indicators",
        produces_evidence=["threat"],
    ),
    JobDefinition(
        job_type="dark_web_query", phase=12,
        worker_class="src.contexts.investigation.workers.intel.DarkWebQueryWorker",
        description="Query dark web intelligence for domain exposure",
        produces_evidence=["exposure"],
    ),

    # ---- Phase 13: Evidence Correlation ----
    JobDefinition(
        job_type="relationship_building", phase=13,
        worker_class="src.contexts.investigation.workers.intel.RelationshipBuildingWorker",
        description="Build asset relationships from discovery data",
        produces_evidence=["relationship"],
    ),
    JobDefinition(
        job_type="cluster_analysis", phase=13,
        worker_class="src.contexts.investigation.workers.intel.ClusterAnalysisWorker",
        description="Group assets into clusters by shared properties",
        produces_evidence=["relationship"],
    ),
    JobDefinition(
        job_type="entity_linking", phase=13,
        worker_class="src.contexts.investigation.workers.intel.EntityLinkingWorker",
        description="Link entities across discovery, vulnerability, and threat data",
        produces_evidence=["relationship"],
    ),

    # ---- Phase 14: Verification ----
    JobDefinition(
        job_type="evidence_verification", phase=14,
        worker_class="src.contexts.investigation.workers.intel.EvidenceVerificationWorker",
        description="Run 8-stage verification pipeline on all collected evidence",
        produces_evidence=["finding"],
        can_run_parallel=False,
    ),

    # ---- Phase 15: Risk Analysis ----
    JobDefinition(
        job_type="per_asset_scoring", phase=15,
        worker_class="src.contexts.investigation.workers.analysis.PerAssetScoringWorker",
        description="Compute risk scores for every discovered asset",
        produces_evidence=["finding"],
    ),
    JobDefinition(
        job_type="business_risk", phase=15,
        worker_class="src.contexts.investigation.workers.analysis.BusinessRiskWorker",
        description="Assess business-level risk from asset scores",
        produces_evidence=["finding"],
    ),
    JobDefinition(
        job_type="exposure_scoring", phase=15,
        worker_class="src.contexts.investigation.workers.analysis.ExposureScoringWorker",
        description="Compute exposure scores for internet-facing assets",
        produces_evidence=["finding"],
    ),

    # ---- Phase 16: Attack Path Generation ----
    JobDefinition(
        job_type="path_rule_evaluation", phase=16,
        worker_class="src.contexts.investigation.workers.analysis.AttackPathRuleWorker",
        description="Evaluate deterministic attack path rules against evidence",
        produces_evidence=["finding"],
    ),
    JobDefinition(
        job_type="kill_chain_mapping", phase=16,
        worker_class="src.contexts.investigation.workers.analysis.KillChainMappingWorker",
        description="Map attack paths to MITRE-style kill chain stages",
        produces_evidence=["finding"],
    ),
    JobDefinition(
        job_type="graph_building", phase=16,
        worker_class="src.contexts.investigation.workers.analysis.GraphBuildingWorker",
        description="Build attack graph from evidence nodes and edges",
        produces_evidence=["relationship"],
    ),

    # ---- Phase 17: Security Intelligence Cases ----
    JobDefinition(
        job_type="intelligence_case_building", phase=17,
        worker_class="src.contexts.investigation.workers.analysis.IntelligenceCaseWorker",
        description="Build intelligence cases from correlated evidence",
        produces_evidence=["finding"],
        can_run_parallel=False,
    ),

    # ---- Phase 18: Executive Report ----
    JobDefinition(
        job_type="executive_report_generation", phase=18,
        worker_class="src.contexts.investigation.workers.reporting.ExecutiveReportWorker",
        description="Generate executive-level report",
        produces_evidence=["finding"],
        can_run_parallel=False,
    ),

    # ---- Phase 19: Continuous Monitoring Registration ----
    JobDefinition(
        job_type="monitor_registration", phase=19,
        worker_class="src.contexts.investigation.workers.reporting.MonitorRegistrationWorker",
        description="Register domain for continuous monitoring",
        produces_evidence=["asset"],
        can_run_parallel=False,
    ),
]

# Auto-register all built-in jobs
JobRegistry.register_many(_BUILTIN_JOBS)
