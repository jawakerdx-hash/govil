"""Investigation Orchestrator — schedules phases, manages dependencies, retries, resumes."""

from __future__ import annotations

import json
import time
import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.contexts.investigation.job_registry import PHASE_NAMES, JobRegistry
from src.contexts.investigation.models import (
    Investigation,
    InvestigationEvidence,
    InvestigationJob,
    InvestigationPhase,
    InvestigationTimeline,
)
from src.foundation.event_bus import EventBus


def _utcnow() -> datetime:
    return datetime.now(UTC)


class InvestigationOrchestrator:
    """Core engine: schedules, manages dependencies, retries, resumes investigations.

    Usage::

        orch = InvestigationOrchestrator(db, event_bus)
        inv = await orch.create_investigation("example.com")
        await orch.start(inv.id)
    """

    def __init__(
        self,
        db: AsyncSession,
        event_bus: EventBus | None = None,
        worker_pool: Any | None = None,
    ) -> None:
        self._db = db
        self._event_bus = event_bus or EventBus()
        self._worker_pool = worker_pool

    # ------------------------------------------------------------------
    # Create & Configure
    # ------------------------------------------------------------------

    async def create_investigation(
        self,
        domain: str,
        tenant_id: str = "default",
        priority: str = "MEDIUM",
        phases: list[int] | None = None,
        config: dict[str, Any] | None = None,
    ) -> Investigation:
        """Create a new investigation with all phases and jobs."""
        domain = domain.lower().strip()

        # Determine which phases to include
        phase_numbers = phases or sorted(PHASE_NAMES.keys())
        total_jobs = 0

        # Create the investigation
        inv = Investigation(
            domain=domain,
            tenant_id=tenant_id,
            priority=priority,
            status="pending",
            current_phase=0,
            config_json=json.dumps(config or {}),
        )
        self._db.add(inv)
        await self._db.flush()

        # Create phases and their jobs
        for phase_num in phase_numbers:
            phase_name = PHASE_NAMES.get(phase_num, f"Phase {phase_num}")
            job_defs = JobRegistry.get_phase_jobs(phase_num)

            phase = InvestigationPhase(
                investigation_id=inv.id,
                phase_number=phase_num,
                name=phase_name,
                job_count=len(job_defs),
            )
            self._db.add(phase)
            await self._db.flush()

            # Create jobs for this phase
            for jdef in job_defs:
                job = InvestigationJob(
                    investigation_id=inv.id,
                    phase=phase_num,
                    job_type=jdef.job_type,
                    worker=jdef.worker_class,
                    priority=jdef.default_priority,
                    max_attempts=jdef.default_max_attempts,
                    input_json=json.dumps({"domain": domain}),
                    dependencies_json=json.dumps(jdef.dependencies) if jdef.dependencies else None,
                )
                self._db.add(job)
                total_jobs += 1

            await self._db.flush()

        inv.total_jobs = total_jobs

        # Emit creation event
        await self._emit_event(inv, "investigation_created", {
            "domain": domain, "tenant_id": tenant_id,
            "total_jobs": total_jobs, "phases": len(phase_numbers),
        })
        await self._add_timeline(inv, "investigation_created",
                                 f"Investigation created for {domain}", phase=None)

        await self._db.commit()

        # Eager-load relationships before session closes
        result = await self._db.execute(
            select(Investigation)
            .options(
                selectinload(Investigation.phases),
                selectinload(Investigation.jobs),
                selectinload(Investigation.timeline_events),
                selectinload(Investigation.evidence_items),
            )
            .where(Investigation.id == inv.id)
        )
        return result.scalar_one()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self, investigation_id: uuid.UUID) -> Investigation:
        """Begin executing an investigation. Enforces concurrency limits."""
        inv = await self._load_investigation(investigation_id)
        if inv is None:
            raise ValueError(f"Investigation {investigation_id} not found")

        # Concurrency control
        from src.foundation.stability import concurrency_guard
        if not concurrency_guard.can_start(inv.tenant_id):
            raise RuntimeError(
                f"Concurrency limit reached for tenant {inv.tenant_id}. "
                f"Max {concurrency_guard._limits.max_per_tenant} concurrent scans."
            )
        concurrency_guard.register(inv.tenant_id, str(inv.id))

        # Observability — start trace
        from src.foundation.observability import scan_tracer, audit_logger
        trace_id = scan_tracer.start_trace(str(inv.id))
        audit_logger.record("scan_started", str(inv.id),
                            f"Scan started for {inv.domain}", trace_id=trace_id)

        inv.status = "running"
        inv.started_at = _utcnow()

        # Start phase 1
        await self._advance_phase(inv, 1)

        # If we have a worker pool, dispatch phase 1 jobs
        if self._worker_pool:
            await self._dispatch_phase_jobs(inv, 1)

        await self._emit_event(inv, "investigation_started", {
            "domain": inv.domain,
            "total_phases": await self._count_phases(inv.id),
            "total_jobs": inv.total_jobs,
        })
        await self._add_timeline(inv, "investigation_started",
                                 f"Investigation started for {inv.domain}", phase=1)

        await self._db.commit()

        # Re-load for clean return
        result = await self._db.execute(
            select(Investigation)
            .options(
                selectinload(Investigation.phases),
                selectinload(Investigation.jobs),
                selectinload(Investigation.timeline_events),
                selectinload(Investigation.evidence_items),
            )
            .where(Investigation.id == inv.id)
        )
        loaded = result.scalar_one()

        # Dispatch phase 1 jobs in background (separate session via asyncio.create_task)
        import asyncio as _asyncio
        _asyncio.create_task(self._execute_phase_jobs_bg(inv.id, 1))

        return loaded

    async def pause(self, investigation_id: uuid.UUID) -> Investigation:
        """Pause a running investigation."""
        inv = await self._load_investigation(investigation_id)
        if inv is None:
            raise ValueError(f"Investigation {investigation_id} not found")

        inv.status = "paused"
        await self._emit_event(inv, "investigation_paused")
        await self._add_timeline(inv, "investigation_paused",
                                 "Investigation paused", phase=inv.current_phase)
        await self._db.flush()
        return inv

    async def resume(self, investigation_id: uuid.UUID) -> Investigation:
        """Resume a paused investigation from its current phase."""
        inv = await self._load_investigation(investigation_id)
        if inv is None:
            raise ValueError(f"Investigation {investigation_id} not found")

        inv.status = "running"

        # Re-dispatch failed/pending jobs in the current phase
        if self._worker_pool:
            await self._dispatch_phase_jobs(inv, inv.current_phase)

        await self._emit_event(inv, "investigation_resumed",
                               {"current_phase": inv.current_phase})
        await self._add_timeline(inv, "investigation_resumed",
                                 f"Investigation resumed at phase {inv.current_phase}",
                                 phase=inv.current_phase)
        await self._db.commit()
        return inv

    async def cancel(self, investigation_id: uuid.UUID) -> Investigation:
        """Cancel an investigation gracefully."""
        inv = await self._load_investigation(investigation_id)
        if inv is None:
            raise ValueError(f"Investigation {investigation_id} not found")

        inv.status = "cancelled"
        inv.completed_at = _utcnow()

        # Cancel all running/pending jobs
        for phase in inv.phases:
            if phase.status in ("running", "pending"):
                phase.status = "failed"
            for job in phase.jobs:
                if job.status in ("pending", "running", "retrying"):
                    job.status = "cancelled"

        await self._emit_event(inv, "investigation_cancelled")
        await self._add_timeline(inv, "investigation_cancelled",
                                 "Investigation cancelled", phase=inv.current_phase)
        await self._db.flush()
        return inv

    # ------------------------------------------------------------------
    # Job handling
    # ------------------------------------------------------------------

    async def handle_job_completion(
        self,
        job_id: uuid.UUID,
        evidence_items: list[dict[str, Any]],
        output: dict[str, Any] | None = None,
        duration_ms: int | None = None,
    ) -> InvestigationJob | None:
        """Called when a worker completes a job. Persists evidence, updates progress."""
        job = await self._load_job(job_id)
        if job is None:
            return None

        # Mark job completed
        job.status = "completed"
        job.completed_at = _utcnow()
        job.duration_ms = duration_ms
        job.output_json = json.dumps(output or {})

        # Persist evidence items
        for ev_data in evidence_items:
            evidence = InvestigationEvidence(
                investigation_id=job.investigation_id,
                job_id=job.id,
                evidence_type=ev_data.get("evidence_type", "asset"),
                severity=ev_data.get("severity", "INFO"),
                title=ev_data.get("title", "Evidence"),
                description=ev_data.get("description"),
                source_module=ev_data.get("source_module", job.job_type),
                entity_type=ev_data.get("entity_type", "unknown"),
                entity_value=ev_data.get("entity_value", ""),
                data_json=json.dumps(ev_data.get("data", {})),
                confidence=ev_data.get("confidence", 0.5),
            )
            self._db.add(evidence)

        # Update investigation counters
        inv = await self._load_investigation(job.investigation_id)
        if inv:
            inv.completed_jobs += 1
            inv.running_jobs = max(0, inv.running_jobs - 1)
            inv.evidence_count += len(evidence_items)

            # Count asset/finding evidence types
            for ev_data in evidence_items:
                if ev_data.get("evidence_type") == "asset":
                    inv.asset_count += 1
                elif ev_data.get("evidence_type") == "finding":
                    inv.finding_count += 1

            # Update progress
            if inv.total_jobs > 0:
                inv.progress_pct = round(inv.completed_jobs / inv.total_jobs * 100, 1)

        # Update phase counters
        phase = await self._load_phase_by_number(inv.id, job.phase) if inv else None
        if phase:
            phase.completed_jobs += 1

        await self._emit_event(inv, "job_completed", {
            "job_id": str(job.id), "job_type": job.job_type,
            "evidence_count": len(evidence_items), "duration_ms": duration_ms,
        })
        await self._add_timeline(inv, "job_completed",
                                 f"Job {job.job_type} completed ({len(evidence_items)} evidence, {duration_ms}ms)",
                                 phase=job.phase, job_id=job.id)

        # Check if phase is complete
        if inv and phase and phase.completed_jobs >= phase.job_count:
            await self._complete_phase(inv, phase)

        await self._db.commit()
        return job

    async def handle_job_failure(
        self,
        job_id: uuid.UUID,
        error: Exception | str,
    ) -> InvestigationJob | None:
        """Called when a worker fails a job. Determines retry/skip."""
        job = await self._load_job(job_id)
        if job is None:
            return None

        error_str = str(error)

        # Determine if retryable
        is_terminal = any(
            kw in error_str.lower()
            for kw in ("permission denied", "invalid configuration", "not found")
        )

        if is_terminal or job.attempt >= job.max_attempts:
            # Terminal failure or max retries exhausted
            job.status = "failed"
            job.error_json = json.dumps({"error": error_str, "attempt": job.attempt})

            inv = await self._load_investigation(job.investigation_id)
            if inv:
                inv.failed_jobs += 1
                inv.running_jobs = max(0, inv.running_jobs - 1)

                await self._emit_event(inv, "job_failed", {
                    "job_id": str(job.id), "job_type": job.job_type,
                    "error": error_str, "attempt": job.attempt,
                })
                await self._add_timeline(inv, "job_failed",
                                         f"Job {job.job_type} failed: {error_str}",
                                         phase=job.phase, job_id=job.id)

            # Update phase
            phase = await self._load_phase_by_number(inv.id, job.phase) if inv else None
            if phase:
                phase.failed_jobs += 1
                # Phase can still complete with failures
                if (phase.completed_jobs + phase.failed_jobs) >= phase.job_count:
                    await self._complete_phase(inv, phase)
        else:
            # Retryable — schedule retry with exponential backoff
            job.status = "retrying"
            job.attempt += 1
            backoff = 2 ** job.attempt  # 2s, 4s, 8s, ...
            job.retry_at = datetime.fromtimestamp(
                time.time() + backoff, tz=UTC,
            )

            inv = await self._load_investigation(job.investigation_id)
            if inv:
                await self._emit_event(inv, "job_retrying", {
                    "job_id": str(job.id), "job_type": job.job_type,
                    "attempt": job.attempt, "max_attempts": job.max_attempts,
                    "backoff_seconds": backoff,
                })
                await self._add_timeline(inv, "job_retrying",
                                         f"Job {job.job_type} retry {job.attempt}/{job.max_attempts} in {backoff}s",
                                         phase=job.phase, job_id=job.id)

        await self._db.commit()
        return job

    # ------------------------------------------------------------------
    # Progress & Query
    # ------------------------------------------------------------------

    async def get_progress(self, investigation_id: uuid.UUID) -> dict[str, Any]:
        """Get detailed investigation progress."""
        inv = await self._load_investigation(investigation_id)
        if inv is None:
            return {"error": "Not found"}

        phases_data = []
        for phase in sorted(inv.phases, key=lambda p: p.phase_number):
            phases_data.append({
                "phase_number": phase.phase_number,
                "name": phase.name,
                "status": phase.status,
                "job_count": phase.job_count,
                "completed_jobs": phase.completed_jobs,
                "failed_jobs": phase.failed_jobs,
                "started_at": phase.started_at.isoformat() if phase.started_at else None,
                "completed_at": phase.completed_at.isoformat() if phase.completed_at else None,
            })

        return {
            "investigation_id": str(inv.id),
            "domain": inv.domain,
            "status": inv.status,
            "current_phase": inv.current_phase,
            "progress_pct": inv.progress_pct,
            "total_jobs": inv.total_jobs,
            "completed_jobs": inv.completed_jobs,
            "failed_jobs": inv.failed_jobs,
            "running_jobs": inv.running_jobs,
            "evidence_count": inv.evidence_count,
            "asset_count": inv.asset_count,
            "finding_count": inv.finding_count,
            "risk_score": inv.risk_score,
            "risk_level": inv.risk_level,
            "phases": phases_data,
        }

    async def get_evidence(
        self, investigation_id: uuid.UUID, evidence_type: str | None = None,
    ) -> list[InvestigationEvidence]:
        """Get all evidence for an investigation."""
        query = select(InvestigationEvidence).where(
            InvestigationEvidence.investigation_id == investigation_id,
        )
        if evidence_type:
            query = query.where(InvestigationEvidence.evidence_type == evidence_type)
        query = query.order_by(InvestigationEvidence.created_at.desc())

        result = await self._db.execute(query)
        return list(result.scalars().all())

    async def get_timeline(
        self, investigation_id: uuid.UUID, limit: int = 100,
    ) -> list[InvestigationTimeline]:
        """Get timeline events."""
        result = await self._db.execute(
            select(InvestigationTimeline)
            .where(InvestigationTimeline.investigation_id == investigation_id)
            .order_by(InvestigationTimeline.sequence.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_jobs(
        self, investigation_id: uuid.UUID, phase: int | None = None,
    ) -> list[InvestigationJob]:
        """Get all jobs for an investigation, optionally filtered by phase."""
        query = select(InvestigationJob).where(
            InvestigationJob.investigation_id == investigation_id,
        )
        if phase is not None:
            query = query.where(InvestigationJob.phase == phase)
        query = query.order_by(InvestigationJob.created_at)

        result = await self._db.execute(query)
        return list(result.scalars().all())

    async def list_investigations(
        self, tenant_id: str = "default", status: str | None = None,
        limit: int = 50, offset: int = 0,
    ) -> list[Investigation]:
        """List investigations."""
        query = select(Investigation).where(
            Investigation.tenant_id == tenant_id,
        )
        if status:
            query = query.where(Investigation.status == status)
        query = query.order_by(Investigation.created_at.desc()).offset(offset).limit(limit)

        result = await self._db.execute(query)
        return list(result.scalars().all())

    # ------------------------------------------------------------------
    # Internal — Phase management
    # ------------------------------------------------------------------

    async def _advance_phase(self, inv: Investigation, phase_num: int) -> None:
        """Mark a phase as running and update investigation state."""
        inv.current_phase = phase_num

        phase = await self._load_phase_by_number(inv.id, phase_num)
        if phase:
            phase.status = "running"
            phase.started_at = _utcnow()

            await self._emit_event(inv, "phase_started", {
                "phase": phase_num, "phase_name": phase.name,
                "job_count": phase.job_count,
            })
            await self._add_timeline(inv, "phase_started",
                                     f"Phase {phase_num} started: {phase.name}",
                                     phase=phase_num)

    async def _complete_phase(self, inv: Investigation, phase: InvestigationPhase) -> None:
        """Mark a phase as completed and advance to the next phase. Prevents duplicate dispatch."""
        if phase.status in ("completed", "completed_with_errors"):
            return  # Already completed — skip duplicate

        phase.status = "completed" if phase.failed_jobs == 0 else "completed_with_errors"
        phase.completed_at = _utcnow()
        await self._db.commit()

        await self._emit_event(inv, "phase_completed", {
            "phase": phase.phase_number,
            "phase_name": phase.name,
            "status": phase.status,
            "completed_jobs": phase.completed_jobs,
            "failed_jobs": phase.failed_jobs,
        })
        await self._add_timeline(inv, "phase_completed",
                                 f"Phase {phase.phase_number} completed: {phase.name} "
                                 f"({phase.completed_jobs}/{phase.job_count} jobs, "
                                 f"{phase.failed_jobs} failed)",
                                 phase=phase.phase_number)

        # Advance to next phase — only if not already dispatched
        next_phase_num = phase.phase_number + 1
        next_name = PHASE_NAMES.get(next_phase_num)

        if next_name:
            next_phase = await self._load_phase_by_number(inv.id, next_phase_num)
            if next_phase and next_phase.status == "pending":
                await self._advance_phase(inv, next_phase_num)
                import asyncio as _asyncio
                _asyncio.create_task(self._execute_phase_jobs_bg(inv.id, next_phase_num))
        else:
            # All 19 phases complete
            await self._complete_investigation(inv)

    async def _complete_investigation(self, inv: Investigation) -> None:
        """Mark investigation as completed ONLY if all phases are done."""
        # Verify all phases are actually complete
        all_phases = sorted(inv.phases, key=lambda p: p.phase_number)
        for p in all_phases:
            if p.status not in ("completed", "completed_with_errors", "skipped"):
                return  # Not all phases done — don't complete yet

        if inv.status == "completed":
            return  # Already completed

        inv.status = "completed"
        inv.completed_at = _utcnow()
        inv.progress_pct = 100.0

        await self._emit_event(inv, "investigation_completed", {
            "domain": inv.domain,
            "total_jobs": inv.total_jobs,
            "completed_jobs": inv.completed_jobs,
            "failed_jobs": inv.failed_jobs,
            "evidence_count": inv.evidence_count,
            "asset_count": inv.asset_count,
            "finding_count": inv.finding_count,
            "risk_score": inv.risk_score,
            "risk_level": inv.risk_level,
        })
        await self._add_timeline(inv, "investigation_completed",
                                 f"Investigation completed for {inv.domain}: "
                                 f"{inv.completed_jobs}/{inv.total_jobs} jobs, "
                                 f"{inv.evidence_count} evidence, "
                                 f"{inv.finding_count} findings")

        # Integrity check — verify no fake data
        from src.foundation.integrity import integrity_guard
        try:
            integrity_guard.validate_scan_completion({
                "phases": [{"status": p.status, "phase_number": p.phase_number,
                            "completed_jobs": p.completed_jobs}
                           for p in inv.phases],
                "evidence_count": inv.evidence_count,
            })
        except Exception:
            pass  # Log but don't block completion

        # Observability — finalize trace
        from src.foundation.observability import audit_logger
        audit_logger.record("scan_completed", str(inv.id),
                            f"Scan completed: {inv.evidence_count} evidence, "
                            f"{inv.finding_count} findings")

        # Memory cleanup
        from src.foundation.stability import concurrency_guard, memory_guard
        concurrency_guard.release(inv.tenant_id, str(inv.id))
        memory_guard.cleanup_scan(str(inv.id), self._event_bus)

        await self._db.commit()

    async def _dispatch_phase_jobs(self, inv: Investigation, phase_num: int) -> None:
        """Send all pending jobs for a phase to the worker pool."""
        jobs = await self.get_jobs(inv.id, phase=phase_num)
        for job in jobs:
            if job.status == "pending":
                job.status = "running"
                job.started_at = _utcnow()
                inv.running_jobs += 1

                await self._emit_event(inv, "job_started", {
                    "job_id": str(job.id), "job_type": job.job_type,
                    "phase": phase_num,
                })
                await self._add_timeline(inv, "job_started",
                                         f"Job {job.job_type} started",
                                         phase=phase_num, job_id=job.id)

                await self._db.flush()

                if self._worker_pool:
                    await self._worker_pool.enqueue({
                        "job_id": str(job.id),
                        "investigation_id": str(inv.id),
                        "worker_class": job.worker,
                        "params": json.loads(job.input_json or "{}"),
                    })

    # ------------------------------------------------------------------
    # Internal — Data loading
    # ------------------------------------------------------------------

    async def _load_investigation(self, inv_id: uuid.UUID) -> Investigation | None:
        result = await self._db.execute(
            select(Investigation)
            .options(
                selectinload(Investigation.phases),
                selectinload(Investigation.jobs),
                selectinload(Investigation.evidence_items),
                selectinload(Investigation.timeline_events),
            )
            .where(Investigation.id == inv_id)
        )
        return result.scalar_one_or_none()

    async def _load_job(self, job_id: uuid.UUID) -> InvestigationJob | None:
        result = await self._db.execute(
            select(InvestigationJob).where(InvestigationJob.id == job_id)
        )
        return result.scalar_one_or_none()

    async def _load_phase_by_number(
        self, inv_id: uuid.UUID, phase_num: int,
    ) -> InvestigationPhase | None:
        result = await self._db.execute(
            select(InvestigationPhase).where(
                InvestigationPhase.investigation_id == inv_id,
                InvestigationPhase.phase_number == phase_num,
            )
        )
        return result.scalar_one_or_none()

    # ------------------------------------------------------------------
    # Internal — Background phase execution (OWN session, no conflicts)
    # ------------------------------------------------------------------

    async def _execute_phase_jobs_bg(
        self, inv_id: uuid.UUID, phase_num: int,
    ) -> None:
        """Execute all pending jobs in a phase using its OWN DB session.
        Runs via asyncio.create_task — completely independent of the request session.
        """
        import importlib as _importlib
        import traceback as _traceback
        from src.config import Settings
        from src.foundation.database import create_engine, create_session_factory

        try:
            settings = Settings()
            engine = create_engine(settings)
            factory = create_session_factory(engine)
            async with factory() as bg_db:
                orch = InvestigationOrchestrator(bg_db, self._event_bus)

                jobs = await orch.get_jobs(inv_id, phase=phase_num)
                for job in jobs:
                    if job.status not in ("pending", "retrying"):
                        continue

                    job.status = "running"
                    job.started_at = _utcnow()

                    inv = await orch._load_investigation(inv_id)
                    if inv:
                        inv.running_jobs += 1
                    await bg_db.commit()

                    await orch._emit_event(inv, "job_started", {
                        "job_id": str(job.id), "job_type": job.job_type, "phase": phase_num,
                    })

                    try:
                        module_path, class_name = job.worker.rsplit(".", 1)
                        module = _importlib.import_module(module_path)
                        worker_cls = getattr(module, class_name)
                        worker = worker_cls(bg_db)
                        params = json.loads(job.input_json or "{}")
                        evidence = await worker.execute(
                            investigation_id=str(inv_id),
                            job_id=str(job.id),
                            domain=(inv.domain if inv else ""),
                            params=params,
                        )
                        await orch.handle_job_completion(job.id, evidence)
                    except Exception as exc:
                        print(f"[BG WORKER ERROR] Job {job.job_type}: {exc}", flush=True)
                        _traceback.print_exc()
                        await orch.handle_job_failure(job.id, exc)

                # Advance to next phase
                inv = await orch._load_investigation(inv_id)
                phase = await orch._load_phase_by_number(inv_id, phase_num) if inv else None
                if inv and phase and phase.completed_jobs >= phase.job_count:
                    await orch._complete_phase(inv, phase)

                # Check completion
                inv = await orch._load_investigation(inv_id)
                # Phase completion handles advancement — don't prematurely complete
        except Exception as exc:
            print(f"[BG PHASE EXECUTOR ERROR] Phase {phase_num}: {exc}", flush=True)
            _traceback.print_exc()

    # ------------------------------------------------------------------
    # Internal — Inline phase execution (no worker pool)
    # ------------------------------------------------------------------

    async def _execute_phase_jobs_inline(
        self, inv: Investigation, phase_num: int,
    ) -> None:
        """Execute all pending jobs in a phase inline via create_task.
        Used when no Redis worker pool is available.
        Each job calls its real worker class and produces real evidence.
        """
        import importlib as _importlib

        jobs = await self.get_jobs(inv.id, phase=phase_num)
        for job in jobs:
            if job.status not in ("pending", "retrying"):
                continue

            job.status = "running"
            job.started_at = _utcnow()
            inv.running_jobs += 1
            await self._db.flush()

            await self._emit_event(inv, "job_started", {
                "job_id": str(job.id),
                "job_type": job.job_type,
                "phase": phase_num,
            })

            try:
                # Resolve and execute the worker
                module_path, class_name = job.worker.rsplit(".", 1)
                module = _importlib.import_module(module_path)
                worker_cls = getattr(module, class_name)
                worker = worker_cls(self._db)

                params = json.loads(job.input_json or "{}")
                evidence = await worker.execute(
                    investigation_id=str(inv.id),
                    job_id=str(job.id),
                    domain=inv.domain,
                    params=params,
                )

                # Let orchestrator handle completion
                await self.handle_job_completion(
                    job.id, evidence,
                    duration_ms=None,
                )
            except Exception as exc:
                await self.handle_job_failure(job.id, exc)

        # Check if phase is complete — advance to next
        phase = await self._load_phase_by_number(inv.id, phase_num)
        if phase and phase.completed_jobs >= phase.job_count:
            await self._complete_phase(inv, phase)

        # Phase completion chain handles advancement — no premature completion needed

    async def _count_phases(self, inv_id: uuid.UUID) -> int:
        result = await self._db.execute(
            select(InvestigationPhase).where(
                InvestigationPhase.investigation_id == inv_id,
            )
        )
        return len(list(result.scalars().all()))

    # ------------------------------------------------------------------
    # Internal — Events & Timeline
    # ------------------------------------------------------------------

    async def _emit_event(
        self, inv: Investigation, event_type: str, data: dict[str, Any] | None = None,
    ) -> None:
        """Emit an investigation event to the event bus."""
        channel = f"investigation:{inv.id}"
        payload = {
            "type": event_type,
            "investigation_id": str(inv.id),
            "domain": inv.domain,
            "timestamp": int(time.time() * 1000),
            **(data or {}),
        }
        try:
            await self._event_bus.publish(channel, payload)
        except Exception:
            pass  # Event bus failures are non-fatal

    async def _add_timeline(
        self,
        inv: Investigation,
        event_type: str,
        message: str,
        phase: int | None = None,
        job_id: uuid.UUID | None = None,
    ) -> None:
        """Add a timeline entry."""
        # Get next sequence number
        result = await self._db.execute(
            select(InvestigationTimeline)
            .where(InvestigationTimeline.investigation_id == inv.id)
            .order_by(InvestigationTimeline.sequence.desc())
            .limit(1)
        )
        last = result.scalar_one_or_none()
        next_seq = (last.sequence + 1) if last else 1

        entry = InvestigationTimeline(
            investigation_id=inv.id,
            phase=phase,
            job_id=job_id,
            event_type=event_type,
            message=message,
            sequence=next_seq,
        )
        self._db.add(entry)
