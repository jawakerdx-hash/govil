"""Investigation workers — one per job type, all wrapping existing CEIP services."""
