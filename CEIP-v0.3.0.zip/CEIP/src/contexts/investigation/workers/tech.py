"""Phase 6 workers — Technology Fingerprinting."""

from __future__ import annotations

from typing import Any

from .base import BaseWorker


class TechStackDetectWorker(BaseWorker):
    """Phase 6: Run full 12-detector technology fingerprinting engine."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio

        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)

        headers = fp.headers or {}
        body = params.get("body", "")

        from src.foundation.tech_intelligence import TechIntelligenceEngine

        engine = TechIntelligenceEngine()
        profile = await engine.analyze(
            url=f"https://{domain}",
            headers=headers,
            body=body,
            tls_info={},
        )

        evidence = []
        for sig in profile.tech_stack:
            evidence.append({
                "evidence_type": "technology", "severity": "INFO",
                "title": f"Technology: {sig.name} ({sig.category})",
                "description": f"Confidence: {sig.confidence:.0%}, Evidence: {sig.evidence}",
                "source_module": "M6-TechFingerprint", "entity_type": "technology",
                "entity_value": sig.name,
                "data": {
                    "category": sig.category, "name": sig.name,
                    "version": sig.version, "confidence": sig.confidence,
                    "evidence": sig.evidence,
                },
                "confidence": sig.confidence,
            })

        # Risk indicators
        for ri in profile.risk_indicators:
            evidence.append({
                "evidence_type": "finding", "severity": "MEDIUM",
                "title": f"Tech risk: {ri}",
                "source_module": "M6-TechFingerprint", "entity_type": "technology",
                "entity_value": domain,
                "data": {"risk_indicator": ri},
                "confidence": 0.8,
            })

        evidence.append({
            "evidence_type": "technology", "severity": "INFO",
            "title": f"Technology profile for {domain}: {len(profile.tech_stack)} signals, "
                     f"{len(profile.risk_indicators)} risks",
            "source_module": "M6-TechFingerprint", "entity_type": "domain",
            "entity_value": domain,
            "data": {
                "signal_count": len(profile.tech_stack),
                "risk_count": len(profile.risk_indicators),
                "categories": list({s.category for s in profile.tech_stack}),
            },
            "confidence": profile.confidence,
        })

        if not evidence:
            evidence.append({
                "evidence_type": "technology", "severity": "INFO",
                "title": f"No technologies identified for {domain}",
                "source_module": "M6-TechFingerprint", "entity_type": "domain",
                "entity_value": domain,
                "data": {},
                "confidence": 0.3,
            })

        return evidence


class FrameworkDetectWorker(BaseWorker):
    """Phase 6: Identify web frameworks (React, Vue, Django, Rails, etc.)."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio

        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)

        headers = fp.headers or {}
        evidence = []

        # Framework detection via headers and common patterns
        pb = str(headers.get("X-Powered-By", "")).lower()
        server = str(headers.get("Server", "")).lower()

        framework_signatures = {
            "next.js": ("Next.js", "Next.js framework detected"),
            "react": ("React", "React library detected"),
            "vue": ("Vue.js", "Vue.js framework detected"),
            "django": ("Django", "Django framework detected"),
            "rails": ("Ruby on Rails", "Rails framework detected"),
            "laravel": ("Laravel", "Laravel framework detected"),
            "spring": ("Spring Boot", "Spring Boot detected"),
            "express": ("Express.js", "Express.js detected"),
            "flask": ("Flask", "Flask framework detected"),
        }

        for keyword, (name, desc) in framework_signatures.items():
            if keyword in pb or keyword in server:
                evidence.append({
                    "evidence_type": "technology", "severity": "INFO",
                    "title": f"Framework: {name}",
                    "description": desc,
                    "source_module": "M6-FrameworkDetect", "entity_type": "technology",
                    "entity_value": name,
                    "data": {"framework": name, "keyword": keyword},
                    "confidence": 0.8,
                })

        if not evidence:
            evidence.append({
                "evidence_type": "technology", "severity": "INFO",
                "title": f"No specific framework identified for {domain}",
                "source_module": "M6-FrameworkDetect", "entity_type": "domain",
                "entity_value": domain,
                "data": {},
                "confidence": 0.2,
            })

        return evidence


class CMSDetectWorker(BaseWorker):
    """Phase 6: Detect CMS platforms (WordPress, Drupal, Shopify, etc.)."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio

        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)

        evidence = []

        cms_signatures = {
            "wp-content": ("WordPress", "WordPress content path detected"),
            "wp-admin": ("WordPress", "WordPress admin path"),
            "sites/default": ("Drupal", "Drupal default path"),
            "joomla": ("Joomla", "Joomla CMS detected"),
            "shopify": ("Shopify", "Shopify e-commerce platform"),
            "magento": ("Magento", "Magento e-commerce"),
        }

        # Check headers
        headers = {k.lower(): v for k, v in (fp.headers or {}).items()}
        generator = headers.get("x-generator", "")

        for keyword, (name, desc) in cms_signatures.items():
            if keyword in generator.lower() or keyword in str(fp.server or "").lower():
                evidence.append({
                    "evidence_type": "technology", "severity": "INFO",
                    "title": f"CMS: {name}",
                    "description": desc,
                    "source_module": "M6-CMSDetect", "entity_type": "technology",
                    "entity_value": name,
                    "data": {"cms": name},
                    "confidence": 0.85,
                })

        if not evidence:
            evidence.append({
                "evidence_type": "technology", "severity": "INFO",
                "title": f"No CMS detected for {domain}",
                "source_module": "M6-CMSDetect", "entity_type": "domain",
                "entity_value": domain,
                "data": {},
                "confidence": 0.2,
            })

        return evidence


class CDNDetectionWorker(BaseWorker):
    """Phase 5: Detect CDN, WAF, and reverse-proxy presence."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio

        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)

        headers = {k.lower(): v for k, v in (fp.headers or {}).items()}
        server = str(fp.server or "").lower()
        evidence = []

        cdn_signatures = {
            "cloudflare": ("Cloudflare", "Cloudflare CDN"),
            "akamai": ("Akamai", "Akamai CDN"),
            "fastly": ("Fastly", "Fastly CDN"),
            "cloudfront": ("AWS CloudFront", "AWS CloudFront CDN"),
        }

        for keyword, (name, desc) in cdn_signatures.items():
            in_server = keyword in server
            in_headers = any(keyword in str(v).lower() for v in headers.values())
            if in_server or in_headers:
                evidence.append({
                    "evidence_type": "technology", "severity": "INFO",
                    "title": f"CDN Detected: {name}",
                    "description": desc,
                    "source_module": "M5-CDNDetection", "entity_type": "technology",
                    "entity_value": name,
                    "data": {"cdn": name, "detected_in": "server" if in_server else "headers"},
                    "confidence": 0.9,
                })

        # WAF detection
        waf_headers = {
            "x-sucuri-id": "Sucuri WAF",
            "x-amzn-requestid": "AWS WAF",
            "x-waf-server": "Generic WAF",
        }
        for header, waf_name in waf_headers.items():
            if header in headers:
                evidence.append({
                    "evidence_type": "technology", "severity": "INFO",
                    "title": f"WAF Detected: {waf_name}",
                    "description": f"Header: {header}",
                    "source_module": "M5-CDNDetection", "entity_type": "technology",
                    "entity_value": waf_name,
                    "data": {"waf": waf_name, "detected_in": header},
                    "confidence": 0.85,
                })

        if not evidence:
            evidence.append({
                "evidence_type": "technology", "severity": "INFO",
                "title": f"No CDN/WAF detected for {domain}",
                "source_module": "M5-CDNDetection", "entity_type": "domain",
                "entity_value": domain,
                "data": {},
                "confidence": 0.5,
            })

        return evidence
