"""Phase 1-5 workers — Target Validation, Passive Discovery, DNS, Certificates, Assets."""

from __future__ import annotations

import asyncio
from typing import Any

from .base import BaseWorker


class TargetValidationWorker(BaseWorker):
    """Phase 1: Validate target domain is resolvable and well-formed."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.resolver import resolve_dns

        loop = asyncio.get_running_loop()
        records = await loop.run_in_executor(None, resolve_dns, domain)

        has_a = any(r["record_type"] in ("A", "AAAA") for r in records)
        evidence = []

        if has_a:
            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"Domain {domain} is resolvable",
                "description": f"Found {len(records)} DNS records",
                "source_module": "M1-Validation", "entity_type": "domain",
                "entity_value": domain,
                "data": {"records_found": len(records), "has_ip": True},
                "confidence": 1.0,
            })
        else:
            evidence.append({
                "evidence_type": "finding", "severity": "HIGH",
                "title": f"Domain {domain} does not resolve",
                "description": "No A or AAAA records found",
                "source_module": "M1-Validation", "entity_type": "domain",
                "entity_value": domain,
                "data": {"records_found": len(records), "has_ip": False},
                "confidence": 1.0,
            })

        for r in records:
            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"DNS {r['record_type']}: {r['name']} -> {r['value']}",
                "source_module": "M1-Validation", "entity_type": "dns_record",
                "entity_value": f"{r['record_type']}:{r['value']}",
                "data": dict(r), "confidence": 0.95,
            })

        return evidence


class PassiveDiscoveryWorker(BaseWorker):
    """Phase 2: Discover subdomains via wordlist and passive sources."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.subdomains import discover_subdomains

        loop = asyncio.get_running_loop()
        subs = await loop.run_in_executor(None, discover_subdomains, domain)

        evidence = []
        for sub in subs:
            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"Subdomain discovered: {sub}",
                "source_module": "M2-PassiveDiscovery", "entity_type": "subdomain",
                "entity_value": sub,
                "data": {"subdomain": sub, "source": "brute"},
                "confidence": 0.8,
            })

        if not evidence:
            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"No subdomains found via passive discovery for {domain}",
                "source_module": "M2-PassiveDiscovery", "entity_type": "domain",
                "entity_value": domain,
                "data": {"subdomain_count": 0},
                "confidence": 0.5,
            })

        return evidence


class SubdomainWordlistWorker(BaseWorker):
    """Phase 2: Brute-force common subdomain names from wordlist."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:

        wordlist = params.get("wordlist", [
            "www", "mail", "api", "dev", "staging", "admin",
            "blog", "shop", "cdn", "app", "vpn", "git",
            "docs", "status", "monitor", "test", "portal",
        ])

        evidence = []
        for word in wordlist:
            sub = f"{word}.{domain}"
            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"Subdomain candidate: {sub}",
                "source_module": "M2-SubdomainWordlist", "entity_type": "subdomain",
                "entity_value": sub,
                "data": {"subdomain": sub, "word": word},
                "confidence": 0.3,
            })

        return evidence


class DNSResolutionWorker(BaseWorker):
    """Phase 3: Resolve all DNS record types for the target domain."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.resolver import resolve_dns

        loop = asyncio.get_running_loop()
        records = await loop.run_in_executor(None, resolve_dns, domain)

        evidence = []
        record_types_seen: set[str] = set()

        for r in records:
            rtype = r["record_type"]
            record_types_seen.add(rtype)
            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"DNS {rtype}: {r['name']} -> {r['value']}",
                "description": f"TTL: {r.get('ttl', 'N/A')}",
                "source_module": "M3-DNS", "entity_type": "dns_record",
                "entity_value": f"{r['name']}:{rtype}:{r['value']}",
                "data": dict(r),
                "confidence": 0.95,
            })

        evidence.append({
            "evidence_type": "asset", "severity": "INFO",
            "title": f"DNS summary for {domain}: {len(records)} records, "
                     f"{len(record_types_seen)} types ({', '.join(sorted(record_types_seen))})",
            "source_module": "M3-DNS", "entity_type": "domain",
            "entity_value": domain,
            "data": {"total_records": len(records), "types": sorted(record_types_seen)},
            "confidence": 1.0,
        })

        return evidence


class DNSZoneAnalysisWorker(BaseWorker):
    """Phase 3: Analyze DNS zone configuration, SPF, DMARC, DKIM."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.resolver import resolve_dns

        loop = asyncio.get_running_loop()
        records = await loop.run_in_executor(None, resolve_dns, domain)

        evidence = []

        # Check for SPF
        spf_records = [r for r in records if r["record_type"] == "TXT" and "v=spf1" in r["value"]]
        if spf_records:
            evidence.append({
                "evidence_type": "finding", "severity": "INFO",
                "title": f"SPF record configured for {domain}",
                "description": f"SPF: {spf_records[0]['value'][:200]}",
                "source_module": "M3-DNSZoneAnalysis", "entity_type": "dns_record",
                "entity_value": f"TXT:{spf_records[0]['value'][:100]}",
                "data": {"has_spf": True, "spf": spf_records[0]["value"]},
                "confidence": 0.9,
            })
        else:
            evidence.append({
                "evidence_type": "finding", "severity": "MEDIUM",
                "title": f"No SPF record for {domain} — email spoofing possible",
                "source_module": "M3-DNSZoneAnalysis", "entity_type": "domain",
                "entity_value": domain,
                "data": {"has_spf": False},
                "confidence": 0.95,
            })

        # Check for DMARC
        dmarc_records = [
            r for r in records
            if r["record_type"] == "TXT" and "_dmarc" in r["name"]
        ]
        if dmarc_records:
            evidence.append({
                "evidence_type": "finding", "severity": "INFO",
                "title": f"DMARC record configured for {domain}",
                "description": f"DMARC: {dmarc_records[0]['value'][:200]}",
                "source_module": "M3-DNSZoneAnalysis", "entity_type": "dns_record",
                "entity_value": f"TXT:{dmarc_records[0]['value'][:100]}",
                "data": {"has_dmarc": True},
                "confidence": 0.9,
            })
        else:
            evidence.append({
                "evidence_type": "finding", "severity": "MEDIUM",
                "title": f"No DMARC record for {domain}",
                "source_module": "M3-DNSZoneAnalysis", "entity_type": "domain",
                "entity_value": domain,
                "data": {"has_dmarc": False},
                "confidence": 0.95,
            })

        return evidence


class CertificateTransparencyWorker(BaseWorker):
    """Phase 4: Query crt.sh for certificate transparency logs."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.subdomains import discover_crtsh

        ct_subs = await discover_crtsh(domain)

        evidence = []
        for sub in ct_subs:
            evidence.append({
                "evidence_type": "certificate", "severity": "INFO",
                "title": f"Certificate Transparency: {sub}",
                "source_module": "M4-CertificateTransparency",
                "entity_type": "subdomain", "entity_value": sub,
                "data": {"subdomain": sub, "source": "crtsh"},
                "confidence": 0.85,
            })

        evidence.append({
            "evidence_type": "certificate", "severity": "INFO",
            "title": f"CRT.sh: {len(ct_subs)} subdomains in certificate transparency logs for {domain}",
            "source_module": "M4-CertificateTransparency", "entity_type": "domain",
            "entity_value": domain,
            "data": {"count": len(ct_subs), "subdomains": ct_subs},
            "confidence": 1.0,
        })

        return evidence


class SSLFingerprintWorker(BaseWorker):
    """Phase 4: Fingerprint SSL/TLS certificates on discovered hosts."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.fingerprint import fingerprint_ssl

        loop = asyncio.get_running_loop()
        cert = await loop.run_in_executor(None, fingerprint_ssl, domain)

        evidence = []
        if cert.subject:
            evidence.append({
                "evidence_type": "certificate", "severity": "INFO",
                "title": f"SSL Certificate: {cert.subject}",
                "description": f"Issuer: {cert.issuer or 'unknown'}",
                "source_module": "M4-SSLFingerprint", "entity_type": "certificate",
                "entity_value": cert.subject or domain,
                "data": {
                    "subject": cert.subject, "issuer": cert.issuer,
                    "not_before": cert.not_before, "not_after": cert.not_after,
                    "sans": cert.sans,
                },
                "confidence": 0.9,
            })

            # Flag short-lived or expired certs
            if cert.not_after:
                evidence.append({
                    "evidence_type": "finding",
                    "severity": "INFO",
                    "title": f"Certificate expires: {cert.not_after}",
                    "source_module": "M4-SSLFingerprint",
                    "entity_type": "certificate",
                    "entity_value": cert.subject or domain,
                    "data": {"not_after": cert.not_after},
                    "confidence": 0.9,
                })

        if cert.error:
            evidence.append({
                "evidence_type": "finding", "severity": "LOW",
                "title": f"SSL fingerprint error for {domain}: {cert.error}",
                "source_module": "M4-SSLFingerprint", "entity_type": "domain",
                "entity_value": domain,
                "data": {"error": cert.error},
                "confidence": 0.7,
            })

        if not evidence:
            evidence.append({
                "evidence_type": "certificate", "severity": "INFO",
                "title": f"No SSL certificate found for {domain}",
                "source_module": "M4-SSLFingerprint", "entity_type": "domain",
                "entity_value": domain,
                "data": {},
                "confidence": 0.5,
            })

        return evidence


class HTTPFingerprintWorker(BaseWorker):
    """Phase 5: HTTP service fingerprinting — server, headers, status codes."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)

        evidence = []

        if fp.server:
            evidence.append({
                "evidence_type": "service", "severity": "INFO",
                "title": f"HTTP service on {domain}: {fp.server}",
                "description": f"Status: {fp.status_code or 'N/A'}",
                "source_module": "M5-HTTPFingerprint", "entity_type": "service",
                "entity_value": f"{domain}:443",
                "data": {
                    "server": fp.server, "status_code": fp.status_code,
                    "headers": fp.headers,
                },
                "confidence": 0.9,
            })

        # Flag missing security headers
        if fp.headers:
            hdrs_lower = {k.lower(): v for k, v in (fp.headers or {}).items()}
            if "strict-transport-security" not in hdrs_lower:
                evidence.append({
                    "evidence_type": "finding", "severity": "MEDIUM",
                    "title": f"Missing HSTS header on {domain}",
                    "source_module": "M5-HTTPFingerprint", "entity_type": "service",
                    "entity_value": f"{domain}:443",
                    "data": {"missing_header": "Strict-Transport-Security"},
                    "confidence": 0.95,
                })
            if "content-security-policy" not in hdrs_lower:
                evidence.append({
                    "evidence_type": "finding", "severity": "LOW",
                    "title": f"Missing CSP header on {domain}",
                    "source_module": "M5-HTTPFingerprint", "entity_type": "service",
                    "entity_value": f"{domain}:443",
                    "data": {"missing_header": "Content-Security-Policy"},
                    "confidence": 0.95,
                })

        if fp.error and not fp.server:
            evidence.append({
                "evidence_type": "finding", "severity": "LOW",
                "title": f"HTTP probe failed for {domain}: {fp.error}",
                "source_module": "M5-HTTPFingerprint", "entity_type": "domain",
                "entity_value": domain,
                "data": {"error": fp.error},
                "confidence": 0.7,
            })

        if not evidence:
            evidence.append({
                "evidence_type": "service", "severity": "INFO",
                "title": f"No HTTP response from {domain}",
                "source_module": "M5-HTTPFingerprint", "entity_type": "domain",
                "entity_value": domain,
                "data": {},
                "confidence": 0.5,
            })

        return evidence


class IPEnrichmentWorker(BaseWorker):
    """Phase 5: Enrich IPs with reverse DNS, ASN, organization info."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.discovery.enrichment import enrich_ip
        from src.contexts.discovery.resolver import resolve_dns

        loop = asyncio.get_running_loop()
        records = await loop.run_in_executor(None, resolve_dns, domain)

        evidence = []
        ips = {r["value"] for r in records if r["record_type"] in ("A", "AAAA")}

        for ip_addr in sorted(ips):
            info = await loop.run_in_executor(None, enrich_ip, ip_addr)
            parts = []
            if info.reverse_dns:
                parts.append(f"PTR={info.reverse_dns}")
            if info.asn:
                parts.append(f"ASN={info.asn}")
            if info.asn_org:
                parts.append(f"Org={info.asn_org}")

            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"IP Enrichment: {ip_addr} ({' '.join(parts)})",
                "source_module": "M5-IPEnrichment", "entity_type": "ip",
                "entity_value": ip_addr,
                "data": {
                    "ip": ip_addr, "reverse_dns": info.reverse_dns,
                    "asn": info.asn, "asn_org": info.asn_org,
                },
                "confidence": 0.85,
            })

        if not evidence:
            evidence.append({
                "evidence_type": "asset", "severity": "INFO",
                "title": f"No IPs to enrich for {domain}",
                "source_module": "M5-IPEnrichment", "entity_type": "domain",
                "entity_value": domain,
                "data": {"ip_count": 0},
                "confidence": 0.5,
            })

        return evidence
