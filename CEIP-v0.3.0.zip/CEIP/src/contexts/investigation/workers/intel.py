"""Phase 12-14 workers — Threat Intel, Evidence Correlation, Verification."""

from __future__ import annotations

import asyncio
from typing import Any

from sqlalchemy import select

from .base import BaseWorker

# ---------------------------------------------------------------------------
# Phase 12: Threat Intelligence Enrichment
# ---------------------------------------------------------------------------


class IOCMatchingWorker(BaseWorker):
    """Phase 12: Match discovered IPs and domains against IOC dataset."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.threat.service import ThreatService

        svc = ThreatService(self.db)
        result = await svc.assess(domain)

        evidence = []
        for match in result.get("matches", []):
            evidence.append({
                "evidence_type": "threat",
                "severity": match["severity"].upper(),
                "title": f"IOC Match: {match['matched_asset']} — {match.get('threat_category', 'unknown')}",
                "description": match.get("evidence_json", ""),
                "source_module": "M12-IOCMatching",
                "entity_type": "threat_match",
                "entity_value": match["matched_asset"],
                "data": dict(match),
                "confidence": {
                    "high": 0.9, "medium": 0.7, "low": 0.4,
                }.get(match.get("confidence", "medium"), 0.5),
            })

        evidence.append({
            "evidence_type": "threat", "severity": "INFO",
            "title": result.get("summary", f"Threat assessment for {domain}"),
            "source_module": "M12-IOCMatching", "entity_type": "domain",
            "entity_value": domain,
            "data": {
                "matches_count": result.get("matches_count", 0),
                "malicious": result.get("malicious", 0),
                "suspicious": result.get("suspicious", 0),
            },
            "confidence": 0.9,
        })

        return evidence


class ThreatFeedWorker(BaseWorker):
    """Phase 12: Cross-reference discovered IPs against IOC dataset (real ThreatService)."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.threat.service import ThreatService

        svc = ThreatService(self.db)
        result = await svc.assess(domain)

        evidence = []
        for match in result.get("matches", []):
            evidence.append({
                "evidence_type": "threat",
                "severity": match.get("severity", "MEDIUM").upper(),
                "title": f"Threat feed match: {match['matched_asset']} ({match.get('threat_category', 'unknown')})",
                "source_module": "M12-ThreatFeed",
                "entity_type": "threat_match",
                "entity_value": match["matched_asset"],
                "data": dict(match),
                "confidence": {"high": 0.85, "medium": 0.65, "low": 0.4}.get(match.get("confidence", "medium"), 0.5),
            })

        evidence.append({
            "evidence_type": "threat", "severity": "INFO",
            "title": f"Threat feed: {len(evidence)} IOC matches for {domain}",
            "source_module": "M12-ThreatFeed", "entity_type": "domain",
            "entity_value": domain,
            "data": {"matches_count": len(evidence), "malicious": result.get("malicious", 0)},
            "confidence": 0.85,
        })

        if not evidence:
            evidence.append({
                "evidence_type": "threat", "severity": "INFO",
                "title": f"No threat intelligence matches for {domain}",
                "source_module": "M12-ThreatFeed", "entity_type": "domain",
                "entity_value": domain, "data": {},
                "confidence": 0.5,
            })

        return evidence


class DarkWebQueryWorker(BaseWorker):
    """Phase 12: Query dark web intelligence for domain exposure."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        try:
            from src.contexts.exposure.service import ExposureService

            svc = ExposureService(self.db)
            result = await svc.assess_darkweb(domain)

            evidence = []
            for item in result.get("dark_web_intel", []):
                evidence.append({
                    "evidence_type": "exposure",
                    "severity": item.get("severity", "LOW").upper(),
                    "title": f"Dark web: {item.get('title', 'Unknown signal')}",
                    "description": item.get("description", ""),
                    "source_module": "M12-DarkWeb",
                    "entity_type": "darkweb_signal",
                    "entity_value": item.get("intel_type", "signal"),
                    "data": dict(item),
                    "confidence": 0.6,
                })

            if not evidence:
                evidence.append({
                    "evidence_type": "exposure", "severity": "INFO",
                    "title": f"No dark web signals for {domain}",
                    "source_module": "M12-DarkWeb", "entity_type": "domain",
                    "entity_value": domain, "data": {}, "confidence": 0.4,
                })

            return evidence
        except Exception:
            return [{
                "evidence_type": "exposure", "severity": "INFO",
                "title": f"Dark web query skipped for {domain} (no provider configured)",
                "source_module": "M12-DarkWeb", "entity_type": "domain",
                "entity_value": domain, "data": {}, "confidence": 0.1,
            }]


# ---------------------------------------------------------------------------
# Phase 13: Evidence Correlation
# ---------------------------------------------------------------------------


class RelationshipBuildingWorker(BaseWorker):
    """Phase 13: Build asset relationships from discovery data using CorrelationService."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.correlation.service import CorrelationService

        svc = CorrelationService(self.db)
        result = await svc.correlate(domain)

        evidence = []
        for rel in result.get("relationships", []):
            evidence.append({
                "evidence_type": "relationship",
                "severity": "INFO",
                "title": f"{rel['source_value']} --[{rel['relationship']}]--> {rel['target_value']}",
                "source_module": "M13-RelationshipBuilding",
                "entity_type": "relationship",
                "entity_value": f"{rel['source_value']}:{rel['relationship']}:{rel['target_value']}",
                "data": dict(rel),
                "confidence": rel.get("confidence", 0.9),
            })

        evidence.append({
            "evidence_type": "relationship", "severity": "INFO",
            "title": result.get("summary", f"Correlation for {domain}"),
            "source_module": "M13-RelationshipBuilding", "entity_type": "domain",
            "entity_value": domain,
            "data": {
                "relationship_count": len(result.get("relationships", [])),
                "cluster_count": len(result.get("clusters", [])),
                "exposure_group_count": len(result.get("exposure_groups", [])),
            },
            "confidence": 1.0,
        })

        return evidence


class ClusterAnalysisWorker(BaseWorker):
    """Phase 13: Group assets into clusters by shared properties."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.correlation.service import CorrelationService

        svc = CorrelationService(self.db)
        result = await svc.correlate(domain)

        evidence = []
        for cluster in result.get("clusters", []):
            evidence.append({
                "evidence_type": "relationship",
                "severity": "INFO",
                "title": f"Cluster [{cluster['cluster_type']}]: {cluster['name'][:80]} "
                         f"({cluster['member_count']} members)",
                "source_module": "M13-ClusterAnalysis",
                "entity_type": "cluster",
                "entity_value": cluster["name"][:100],
                "data": dict(cluster),
                "confidence": 0.85,
            })

        return evidence


class EntityLinkingWorker(BaseWorker):
    """Phase 13: Link entities across discovery, vulnerability, and threat data."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        # Read findings and threats from DB to cross-reference
        evidence = []

        try:
            from src.contexts.vulnerability.models import SecurityFinding

            findings_r = await self.db.execute(
                select(SecurityFinding).where(SecurityFinding.domain == domain)
            )
            findings = findings_r.scalars().all()

            if findings:
                assets = {f.affected_asset for f in findings}
                evidence.append({
                    "evidence_type": "relationship", "severity": "INFO",
                    "title": f"Entity linking: {len(findings)} findings across "
                             f"{len(assets)} affected assets for {domain}",
                    "source_module": "M13-EntityLinking", "entity_type": "domain",
                    "entity_value": domain,
                    "data": {
                        "finding_count": len(findings),
                        "affected_assets": sorted(assets),
                    },
                    "confidence": 0.9,
                })
        except Exception:
            pass

        if not evidence:
            evidence.append({
                "evidence_type": "relationship", "severity": "INFO",
                "title": f"No cross-entity links found for {domain}",
                "source_module": "M13-EntityLinking", "entity_type": "domain",
                "entity_value": domain, "data": {}, "confidence": 0.3,
            })

        return evidence


# ---------------------------------------------------------------------------
# Phase 14: Verification
# ---------------------------------------------------------------------------


class EvidenceVerificationWorker(BaseWorker):
    """Phase 14: Run 8-stage verification pipeline on all collected evidence."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        # Load all evidence from the investigation
        from src.contexts.investigation.models import InvestigationEvidence
        from src.foundation.verification_engine import VerificationPipeline, EvidenceItem

        import uuid as _uuid
        inv_uuid = _uuid.UUID(investigation_id)
        result = await self.db.execute(
            select(InvestigationEvidence).where(
                InvestigationEvidence.investigation_id == inv_uuid,
            )
        )
        all_evidence = result.scalars().all()

        pipeline = VerificationPipeline()
        evidence = []

        for ev in all_evidence:
            finding = {
                "scan_id": investigation_id,
                "title": ev.title,
                "severity": ev.severity,
                "endpoint": ev.entity_value,
                "description": ev.description or "",
            }
            evidence_items = [
                EvidenceItem(
                    source=ev.source_module,
                    timestamp=ev.created_at.isoformat() if ev.created_at else "",
                    confidence=ev.confidence,
                    collector=ev.source_module,
                    stage="initial",
                )
            ]

            verified = await pipeline.verify(finding, evidence_items)
            evidence.append({
                "evidence_type": "finding", "severity": verified.verification_result,
                "title": f"Verified: {verified.title[:80]}",
                "description": verified.verification_notes,
                "source_module": "M14-Verification", "entity_type": ev.entity_type,
                "entity_value": ev.entity_value,
                "data": verified.to_dict(),
                "confidence": verified.overall_confidence,
            })

        evidence.append({
            "evidence_type": "finding", "severity": "INFO",
            "title": f"Verification complete: {len(all_evidence)} evidence items verified for {domain}",
            "source_module": "M14-Verification", "entity_type": "domain",
            "entity_value": domain,
            "data": {"total_verified": len(all_evidence)},
            "confidence": 1.0,
        })

        return evidence
