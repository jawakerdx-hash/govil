"""Phase 15-17 workers — Risk Analysis, Attack Path, Intelligence Cases."""

from __future__ import annotations

from typing import Any

from .base import BaseWorker

# ---------------------------------------------------------------------------
# Phase 15: Risk Analysis
# ---------------------------------------------------------------------------


class PerAssetScoringWorker(BaseWorker):
    """Phase 15: Compute risk scores for every discovered asset using RiskEngine."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.risk.engine import RiskEngine

        engine = RiskEngine(self.db)
        result = await engine.assess(domain)

        evidence = []
        for score in result.get("scores", []):
            evidence.append({
                "evidence_type": "finding",
                "severity": score["level"],
                "title": f"Risk: {score['asset_identifier']} ({score['asset_type']}) = {score['score']:.0f}/100",
                "description": (
                    f"V:{score['vuln_weight']:.0f} T:{score['threat_weight']:.0f} "
                    f"E:{score['exposure_weight']:.0f} I:{score['importance_weight']:.0f}"
                ),
                "source_module": "M15-RiskAnalysis",
                "entity_type": score["asset_type"],
                "entity_value": score["asset_identifier"],
                "data": dict(score),
                "confidence": 0.85,
            })

        evidence.append({
            "evidence_type": "finding",
            "severity": result.get("overall_risk_level", "LOW"),
            "title": result.get("summary", f"Risk assessment for {domain}"),
            "source_module": "M15-RiskAnalysis",
            "entity_type": "domain",
            "entity_value": domain,
            "data": {
                "overall_score": result.get("overall_score", 0),
                "overall_risk_level": result.get("overall_risk_level", "LOW"),
                "critical_count": result.get("critical_count", 0),
                "high_count": result.get("high_count", 0),
            },
            "confidence": 0.9,
        })

        return evidence


class BusinessRiskWorker(BaseWorker):
    """Phase 15: Assess business-level risk from asset scores."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.risk.engine import RiskEngine

        engine = RiskEngine(self.db)
        result = await engine.assess(domain)

        evidence = []
        for risk_item in result.get("top_risks", []):
            evidence.append({
                "evidence_type": "finding",
                "severity": "HIGH",
                "title": f"Business risk: {risk_item}",
                "source_module": "M15-BusinessRisk",
                "entity_type": "domain",
                "entity_value": domain,
                "data": {"risk": risk_item},
                "confidence": 0.8,
            })

        if not evidence:
            evidence.append({
                "evidence_type": "finding", "severity": "INFO",
                "title": f"Business risk assessment for {domain}: {result.get('overall_risk_level', 'LOW')}",
                "source_module": "M15-BusinessRisk", "entity_type": "domain",
                "entity_value": domain,
                "data": {"overall_level": result.get("overall_risk_level", "LOW")},
                "confidence": 0.8,
            })

        return evidence


class ExposureScoringWorker(BaseWorker):
    """Phase 15: Compute exposure scores for internet-facing assets."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.risk.engine import RiskEngine

        engine = RiskEngine(self.db)
        result = await engine.assess(domain)

        evidence = []
        for score in result.get("scores", []):
            if score.get("exposure_weight", 0) > 0:
                evidence.append({
                    "evidence_type": "finding",
                    "severity": "HIGH" if score["exposure_weight"] > 10 else "MEDIUM",
                    "title": f"Exposed asset: {score['asset_identifier']} "
                             f"(exposure={score['exposure_weight']:.1f})",
                    "source_module": "M15-ExposureScoring",
                    "entity_type": score["asset_type"],
                    "entity_value": score["asset_identifier"],
                    "data": {
                        "exposure_weight": score["exposure_weight"],
                        "asset_identifier": score["asset_identifier"],
                    },
                    "confidence": 0.85,
                })

        if not evidence:
            evidence.append({
                "evidence_type": "finding", "severity": "INFO",
                "title": f"No exposed assets identified for {domain}",
                "source_module": "M15-ExposureScoring", "entity_type": "domain",
                "entity_value": domain, "data": {}, "confidence": 0.5,
            })

        return evidence


# ---------------------------------------------------------------------------
# Phase 16: Attack Path Generation
# ---------------------------------------------------------------------------


class AttackPathRuleWorker(BaseWorker):
    """Phase 16: Evaluate deterministic attack path rules against evidence."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.attack_path.engine import AttackPathEngine

        engine = AttackPathEngine(self.db)
        result = await engine.assess(domain)

        evidence = []
        for path in result.get("paths", []):
            evidence.append({
                "evidence_type": "finding",
                "severity": path.get("level", "MEDIUM"),
                "title": f"Attack Path: {path['name'][:80]}",
                "description": (
                    f"Score: {path.get('risk_score', path.get('overall_score', 0)):.0f}, "
                    f"Jewels: {', '.join(path.get('crown_jewels_affected', []))}"
                ),
                "source_module": "M16-AttackPathRules",
                "entity_type": "attack_path",
                "entity_value": path["name"][:120],
                "data": dict(path),
                "confidence": path.get("confidence", 0.7),
            })

        evidence.append({
            "evidence_type": "finding", "severity": "INFO",
            "title": f"Attack path analysis: {result.get('path_count', 0)} paths, "
                     f"overall {result.get('overall_exposure', 'LOW')}",
            "source_module": "M16-AttackPathRules", "entity_type": "domain",
            "entity_value": domain,
            "data": {
                "path_count": result.get("path_count", 0),
                "overall_exposure": result.get("overall_exposure", "LOW"),
                "critical_paths": result.get("critical_paths", 0),
            },
            "confidence": 0.9,
        })

        return evidence


class KillChainMappingWorker(BaseWorker):
    """Phase 16: Map attack paths to MITRE-style kill chain stages."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.attack_path.engine import AttackPathEngine
        from src.contexts.attack_path.kill_chain import map_kill_chain

        engine = AttackPathEngine(self.db)
        result = await engine.assess(domain)

        evidence = []
        for path in result.get("paths", []):
            nodes = path.get("nodes", [])
            if nodes:
                chain = map_kill_chain(nodes)
                stages = chain.covered_stages()
                evidence.append({
                    "evidence_type": "finding", "severity": path.get("level", "MEDIUM"),
                    "title": f"Kill Chain: {chain.summary()[:120]}",
                    "description": f"Covered: {', '.join(stages)}. Missing: {', '.join(chain.missing_stages())}",
                    "source_module": "M16-KillChainMapping", "entity_type": "attack_path",
                    "entity_value": path["name"][:120],
                    "data": {
                        "stages": stages,
                        "missing": chain.missing_stages(),
                        "steps": [{"stage": s.stage, "node": s.node, "asset_type": s.asset_type}
                                  for s in chain.steps],
                    },
                    "confidence": 0.75,
                })

        return evidence or [{
            "evidence_type": "finding", "severity": "INFO",
            "title": f"No kill chain mapping for {domain}",
            "source_module": "M16-KillChainMapping", "entity_type": "domain",
            "entity_value": domain, "data": {}, "confidence": 0.3,
        }]


class GraphBuildingWorker(BaseWorker):
    """Phase 16: Build attack graph from evidence nodes and edges."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.attack_path.graph import GraphBuilder

        builder = GraphBuilder(self.db)
        graph = await builder.build(domain)

        evidence = [{
            "evidence_type": "relationship", "severity": "INFO",
            "title": f"Attack graph: {len(graph.nodes)} nodes, {len(graph.edges)} edges, "
                     f"{len(graph.crown_jewels)} crown jewels, {len(graph.blocked_paths)} blocked paths",
            "source_module": "M16-GraphBuilding", "entity_type": "domain",
            "entity_value": domain,
            "data": {
                "node_count": len(graph.nodes),
                "edge_count": len(graph.edges),
                "crown_jewels": graph.crown_jewels,
                "blocked_paths": graph.blocked_paths,
                "controls": [
                    {"name": c.name, "present": c.present}
                    for c in graph.controls
                ],
            },
            "confidence": 0.9,
        }]

        for node in graph.nodes:
            if node.crown_jewel:
                evidence.append({
                    "evidence_type": "finding", "severity": "HIGH",
                    "title": f"Crown Jewel: {node.asset} ({node.asset_type})",
                    "description": f"Criticality: {node.criticality}, Business: {node.business_value}",
                    "source_module": "M16-GraphBuilding", "entity_type": "asset",
                    "entity_value": node.asset,
                    "data": {"asset": node.asset, "asset_type": node.asset_type,
                             "crown_jewel": True, "internet_reachable": node.internet_reachable},
                    "confidence": 0.85,
                })

        return evidence


# ---------------------------------------------------------------------------
# Phase 17: Security Intelligence Cases
# ---------------------------------------------------------------------------


class IntelligenceCaseWorker(BaseWorker):
    """Phase 17: Build intelligence cases using the Security Intelligence Brain."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.intelligence.service import SecurityIntelligenceBrain

        sib = SecurityIntelligenceBrain(self.db)
        result = await sib.analyze(investigation_id, domain)

        evidence = []
        for case in result.get("cases", []):
            evidence.append({
                "evidence_type": "finding",
                "severity": case.get("risk_level", "MEDIUM"),
                "title": f"Intelligence Case: {case.get('title', '')[:80]}",
                "description": case.get("executive_summary", ""),
                "source_module": "M17-SIB",
                "entity_type": "intelligence_case",
                "entity_value": case.get("case_id", ""),
                "data": dict(case),
                "confidence": case.get("confidence", 0.7),
            })

        for chain in result.get("attack_chains", []):
            evidence.append({
                "evidence_type": "finding",
                "severity": chain.get("severity", "HIGH"),
                "title": f"Attack Chain: {chain.get('title', '')[:100]}",
                "source_module": "M17-SIB",
                "entity_type": "attack_chain",
                "entity_value": chain.get("chain_id", ""),
                "data": dict(chain),
                "confidence": chain.get("confidence", 0.7),
            })

        risk = result.get("risk_correlation", {})
        if risk:
            evidence.append({
                "evidence_type": "finding",
                "severity": risk.get("risk_level", "MEDIUM"),
                "title": (f"SIB Risk: Overall={risk.get('overall_score', 0):.2f}, "
                         f"Asset={risk.get('asset_risk', 0):.2f}"),
                "description": (
                    f"8-dim: Asset={risk.get('asset_risk', 0):.2f}, "
                    f"Business={risk.get('business_risk', 0):.2f}, "
                    f"Threat={risk.get('threat_risk', 0):.2f}"
                ),
                "source_module": "M17-SIB",
                "entity_type": "risk_correlation",
                "entity_value": domain,
                "data": dict(risk),
                "confidence": 0.85,
            })

        stats = result.get("stats", {})
        evidence.append({
            "evidence_type": "finding", "severity": "INFO",
            "title": (f"SIB complete: {len(result.get('cases', []))} cases, "
                     f"{len(result.get('attack_chains', []))} chains, "
                     f"{stats.get('graph_nodes', 0)} nodes for {domain}"),
            "source_module": "M17-SIB", "entity_type": "domain",
            "entity_value": domain,
            "data": stats,
            "confidence": 0.9,
        })

        return evidence
