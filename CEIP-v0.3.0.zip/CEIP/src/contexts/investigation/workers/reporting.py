"""Phase 18-19 workers — Report Generation and Monitoring Registration."""

from __future__ import annotations

from typing import Any

from .base import BaseWorker

# ---------------------------------------------------------------------------
# Phase 18: Executive Report
# ---------------------------------------------------------------------------


class ExecutiveReportWorker(BaseWorker):
    """Phase 18: Generate executive-level security report."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        from src.contexts.reporting.service import ReportingService

        svc = ReportingService(self.db)

        # Generate all report types
        for report_type in ["executive", "technical", "risk"]:
            try:
                await svc.generate(domain, report_type)
            except Exception:
                continue

        evidence = [{
            "evidence_type": "finding", "severity": "INFO",
            "title": f"Report generated for {domain}",
            "description": "Executive, technical, and risk reports generated",
            "source_module": "M18-Report", "entity_type": "domain",
            "entity_value": domain,
            "data": {
                "report_types": ["executive", "technical", "risk"],
                "generated": True,
            },
            "confidence": 1.0,
        }]

        # Load risk data for the report summary
        try:
            from src.contexts.risk.engine import RiskEngine
            engine = RiskEngine(self.db)
            risk_result = await engine.assess(domain)

            evidence.append({
                "evidence_type": "finding",
                "severity": risk_result.get("overall_risk_level", "LOW"),
                "title": f"Executive Summary: {domain} — "
                         f"Risk Score {risk_result.get('overall_score', 0)}/100 "
                         f"({risk_result.get('overall_risk_level', 'LOW')})",
                "description": risk_result.get("summary", ""),
                "source_module": "M18-Report",
                "entity_type": "domain",
                "entity_value": domain,
                "data": {
                    "risk_score": risk_result.get("overall_score", 0),
                    "risk_level": risk_result.get("overall_risk_level", "LOW"),
                    "critical_count": risk_result.get("critical_count", 0),
                    "high_count": risk_result.get("high_count", 0),
                },
                "confidence": 0.9,
            })
        except Exception:
            pass

        return evidence


# ---------------------------------------------------------------------------
# Phase 19: Continuous Monitoring Registration
# ---------------------------------------------------------------------------


class MonitorRegistrationWorker(BaseWorker):
    """Phase 19: Register domain for continuous monitoring."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        try:
            from src.contexts.monitoring.repository import MonitoringRepository
            from src.contexts.monitoring.service import MonitoringService

            repo = MonitoringRepository(self.db)
            svc = MonitoringService(self.db, repo)

            schedule = params.get("schedule", "weekly")
            job = await svc.start_job(domain, schedule)

            return [{
                "evidence_type": "asset", "severity": "INFO",
                "title": f"Monitoring registered for {domain} (schedule: {schedule})",
                "description": f"Job ID: {job.id}",
                "source_module": "M19-MonitorRegistration",
                "entity_type": "domain",
                "entity_value": domain,
                "data": {
                    "monitoring_job_id": str(job.id),
                    "schedule": schedule,
                    "enabled": job.enabled,
                },
                "confidence": 1.0,
            }]
        except Exception as exc:
            return [{
                "evidence_type": "asset", "severity": "INFO",
                "title": f"Monitoring registration failed for {domain}: {exc}",
                "source_module": "M19-MonitorRegistration",
                "entity_type": "domain",
                "entity_value": domain,
                "data": {"error": str(exc)},
                "confidence": 0.1,
            }]
