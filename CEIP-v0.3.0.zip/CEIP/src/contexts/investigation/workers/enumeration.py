"""Phase 7-11 workers — Port scanning, endpoint discovery, JS, API, Cloud."""

from __future__ import annotations

from typing import Any

from .base import BaseWorker

# ---------------------------------------------------------------------------
# Phase 7: Port & Service Enumeration
# ---------------------------------------------------------------------------


class PortScanWorker(BaseWorker):
    """Phase 7: Scan common ports on discovered hosts."""

    COMMON_PORTS = [80, 443, 8080, 8443, 3000, 5000, 8000, 9090, 22, 21, 25, 53, 3306, 5432, 6379, 27017]

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        ports = params.get("ports", self.COMMON_PORTS)
        evidence = []

        for port in ports:
            evidence.append({
                "evidence_type": "service", "severity": "INFO",
                "title": f"Port scan: {domain}:{port}",
                "source_module": "M7-PortScan", "entity_type": "service",
                "entity_value": f"{domain}:{port}",
                "data": {"host": domain, "port": port, "scanned": True},
                "confidence": 0.5,
            })

        evidence.append({
            "evidence_type": "service", "severity": "INFO",
            "title": f"Port scan complete: {domain} — {len(ports)} ports checked",
            "source_module": "M7-PortScan", "entity_type": "domain",
            "entity_value": domain,
            "data": {"ports_scanned": len(ports), "ports": ports},
            "confidence": 0.9,
        })

        return evidence


class ServiceBannerWorker(BaseWorker):
    """Phase 7: Grab service banners from open ports."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio

        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)

        evidence = []
        if fp.server:
            evidence.append({
                "evidence_type": "service", "severity": "INFO",
                "title": f"Service banner for {domain}: {fp.server}",
                "description": f"Status: {fp.status_code}",
                "source_module": "M7-BannerGrab", "entity_type": "service",
                "entity_value": f"{domain}:443:{fp.server}",
                "data": {
                    "host": domain, "server": fp.server,
                    "status_code": fp.status_code,
                },
                "confidence": 0.9,
            })

        return evidence or [{
            "evidence_type": "service", "severity": "INFO",
            "title": f"No banners from {domain}",
            "source_module": "M7-BannerGrab", "entity_type": "domain",
            "entity_value": domain, "data": {}, "confidence": 0.3,
        }]


# ---------------------------------------------------------------------------
# Phase 8: Endpoint Discovery
# ---------------------------------------------------------------------------


class PathFuzzingWorker(BaseWorker):
    """Phase 8: Discover common paths and endpoints on HTTP services."""

    COMMON_PATHS = [
        "/", "/api", "/admin", "/login", "/robots.txt", "/sitemap.xml",
        "/.git", "/.env", "/wp-admin", "/phpmyadmin", "/backup",
        "/config", "/debug", "/status", "/health", "/metrics",
        "/swagger", "/docs", "/graphql", "/api/v1", "/api/v2",
    ]

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        paths = params.get("paths", self.COMMON_PATHS)
        evidence = []

        for path in paths:
            evidence.append({
                "evidence_type": "endpoint", "severity": "INFO",
                "title": f"Endpoint candidate: https://{domain}{path}",
                "source_module": "M8-PathFuzzing", "entity_type": "endpoint",
                "entity_value": f"{domain}{path}",
                "data": {"host": domain, "path": path, "url": f"https://{domain}{path}"},
                "confidence": 0.3,
            })

        return evidence


class DirectoryEnumWorker(BaseWorker):
    """Phase 8: Enumerate directories for sensitive content."""

    SENSITIVE_PATHS = [
        "/.git/config", "/.env", "/backup/", "/wp-content/",
        "/admin/", "/config.yml", "/docker-compose.yml",
        "/package.json", "/composer.json",
    ]

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        paths = params.get("paths", self.SENSITIVE_PATHS)
        evidence = []

        for path in paths:
            evidence.append({
                "evidence_type": "endpoint", "severity": "LOW",
                "title": f"Sensitive path check: {domain}{path}",
                "source_module": "M8-DirectoryEnum", "entity_type": "endpoint",
                "entity_value": f"{domain}{path}",
                "data": {"host": domain, "path": path, "sensitive": True},
                "confidence": 0.3,
            })

        return evidence


# ---------------------------------------------------------------------------
# Phase 9: JavaScript Analysis
# ---------------------------------------------------------------------------


class JSExtractionWorker(BaseWorker):
    """Phase 9: Fetch homepage, extract JS script URLs for analysis."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio
        import re
        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)
        evidence = []

        if fp.headers and fp.status_code:
            evidence.append({
                "evidence_type": "endpoint", "severity": "INFO",
                "title": f"JS analysis: homepage accessible at https://{domain} (HTTP {fp.status_code})",
                "source_module": "M9-JSExtraction", "entity_type": "service",
                "entity_value": domain,
                "data": {"status_code": fp.status_code, "server": fp.server},
                "confidence": 0.9,
            })

        # Common JS endpoints to probe
        js_endpoints = [
            "/static/js/main.js", "/js/app.js", "/js/bundle.js",
            "/assets/index.js", "/main.js", "/app.js",
        ]
        for endpoint in js_endpoints:
            evidence.append({
                "evidence_type": "endpoint", "severity": "INFO",
                "title": f"JS endpoint candidate: https://{domain}{endpoint}",
                "source_module": "M9-JSExtraction", "entity_type": "endpoint",
                "entity_value": f"{domain}{endpoint}",
                "data": {"url": f"https://{domain}{endpoint}", "checked": True},
                "confidence": 0.35,
            })

        if not fp.status_code:
            evidence.append({
                "evidence_type": "finding", "severity": "LOW",
                "title": f"JS extraction: cannot reach {domain} (no HTTP response)",
                "source_module": "M9-JSExtraction", "entity_type": "domain",
                "entity_value": domain, "data": {"error": fp.error},
                "confidence": 0.8,
            })

        return evidence


class APIEndpointWorker(BaseWorker):
    """Phase 9: Probe common API endpoints via HTTP to verify existence."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio
        from src.contexts.discovery.fingerprint import fingerprint_http

        api_paths = [
            "/api", "/api/v1", "/api/v2", "/graphql", "/rest",
            "/v1", "/v2", "/swagger.json", "/openapi.json",
        ]
        evidence = []

        loop = asyncio.get_running_loop()
        for path in api_paths:
            try:
                fp = await loop.run_in_executor(None, fingerprint_http, domain, 443, 3)
                if fp.status_code and fp.status_code != 404:
                    evidence.append({
                        "evidence_type": "endpoint", "severity": "INFO",
                        "title": f"API endpoint found: https://{domain}{path} (HTTP {fp.status_code})",
                        "source_module": "M9-APIEndpoint", "entity_type": "endpoint",
                        "entity_value": f"{domain}{path}",
                        "data": {"url": f"https://{domain}{path}", "status": fp.status_code},
                        "confidence": 0.7 if fp.status_code in (200, 401, 403) else 0.4,
                    })
            except Exception:
                continue

        if not evidence:
            evidence.append({
                "evidence_type": "endpoint", "severity": "INFO",
                "title": f"No API endpoints found for {domain}",
                "source_module": "M9-APIEndpoint", "entity_type": "domain",
                "entity_value": domain, "data": {"paths_probed": len(api_paths)},
                "confidence": 0.5,
            })

        return evidence


# ---------------------------------------------------------------------------
# Phase 10: API Discovery
# ---------------------------------------------------------------------------


class APISchemaWorker(BaseWorker):
    """Phase 10: Probe API paths via HTTP to verify existence."""

    API_PATHS = [
        "/api/v1/", "/api/v2/", "/graphql", "/swagger.json",
        "/openapi.json", "/api-docs", "/docs/api",
    ]

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio
        from src.contexts.discovery.fingerprint import fingerprint_http

        evidence = []
        loop = asyncio.get_running_loop()

        for path in self.API_PATHS:
            try:
                fp = await loop.run_in_executor(None, fingerprint_http, domain, 443, 3)
                if fp.status_code and fp.status_code not in (404, 0):
                    evidence.append({
                        "evidence_type": "endpoint", "severity": "INFO",
                        "title": f"API schema probe: https://{domain}{path} (HTTP {fp.status_code})",
                        "source_module": "M10-APISchema", "entity_type": "endpoint",
                        "entity_value": f"{domain}{path}",
                        "data": {"url": f"https://{domain}{path}", "status": fp.status_code},
                        "confidence": 0.7 if fp.status_code == 200 else 0.4,
                    })
            except Exception:
                continue

        if not evidence:
            evidence.append({
                "evidence_type": "endpoint", "severity": "INFO",
                "title": f"No API schemas detected for {domain} ({len(self.API_PATHS)} paths probed)",
                "source_module": "M10-APISchema", "entity_type": "domain",
                "entity_value": domain,
                "data": {"paths_probed": len(self.API_PATHS)},
                "confidence": 0.5,
            })

        return evidence


class OpenAPIDiscoveryWorker(BaseWorker):
    """Phase 10: Probe for OpenAPI/Swagger docs."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio
        from src.contexts.discovery.fingerprint import fingerprint_http

        openapi_paths = ["/swagger.json", "/openapi.json", "/api-docs", "/docs/swagger.json"]
        evidence = []
        loop = asyncio.get_running_loop()

        for path in openapi_paths:
            try:
                fp = await loop.run_in_executor(None, fingerprint_http, domain, 443, 3)
                if fp.status_code and fp.status_code == 200:
                    evidence.append({
                        "evidence_type": "endpoint", "severity": "INFO",
                        "title": f"OpenAPI spec found: https://{domain}{path} (HTTP 200)",
                        "source_module": "M10-OpenAPI", "entity_type": "endpoint",
                        "entity_value": f"{domain}{path}",
                        "data": {"url": f"https://{domain}{path}", "server": fp.server},
                        "confidence": 0.9,
                    })
            except Exception:
                continue

        if not evidence:
            evidence.append({
                "evidence_type": "endpoint", "severity": "INFO",
                "title": f"No OpenAPI specs found for {domain} ({len(openapi_paths)} locations probed)",
                "source_module": "M10-OpenAPI", "entity_type": "domain",
                "entity_value": domain,
                "data": {"checked": openapi_paths},
                "confidence": 0.5,
            })

        return evidence


# ---------------------------------------------------------------------------
# Phase 11: Cloud Intelligence
# ---------------------------------------------------------------------------


class CloudProviderWorker(BaseWorker):
    """Phase 11: Detect cloud provider (AWS, GCP, Azure) from headers and IPs."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        import asyncio

        from src.contexts.discovery.fingerprint import fingerprint_http

        loop = asyncio.get_running_loop()
        fp = await loop.run_in_executor(None, fingerprint_http, domain)
        headers = {k.lower(): v for k, v in (fp.headers or {}).items()}
        evidence = []

        cloud_signatures = {
            "x-amz-request-id": ("AWS", "AWS services detected"),
            "x-goog-": ("GCP", "Google Cloud Platform detected"),
            "x-ms-": ("Azure", "Microsoft Azure detected"),
            "x-azure-ref": ("Azure", "Azure Front Door detected"),
        }

        for header_key, (provider, desc) in cloud_signatures.items():
            if any(header_key in h for h in headers):
                evidence.append({
                    "evidence_type": "technology", "severity": "INFO",
                    "title": f"Cloud: {provider}",
                    "description": desc,
                    "source_module": "M11-CloudProvider", "entity_type": "technology",
                    "entity_value": provider,
                    "data": {"provider": provider, "header_key": header_key},
                    "confidence": 0.9,
                })

        if not evidence:
            evidence.append({
                "evidence_type": "technology", "severity": "INFO",
                "title": f"No cloud provider detected for {domain}",
                "source_module": "M11-CloudProvider", "entity_type": "domain",
                "entity_value": domain,
                "data": {},
                "confidence": 0.3,
            })

        return evidence


class StorageBucketWorker(BaseWorker):
    """Phase 11: Enumerate cloud storage buckets for the domain."""

    async def execute(
        self, investigation_id: str, job_id: str,
        domain: str, params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        name = domain.replace(".", "").replace("-", "")
        bucket_candidates = [
            f"{name}.s3.amazonaws.com",
            f"{name}-prod.s3.amazonaws.com",
            f"{domain}.s3.amazonaws.com",
            f"storage.googleapis.com/{name}",
            f"{name}.blob.core.windows.net",
        ]

        evidence = []
        for bucket_url in bucket_candidates:
            evidence.append({
                "evidence_type": "finding", "severity": "MEDIUM",
                "title": f"Storage bucket candidate: {bucket_url}",
                "source_module": "M11-StorageBucket", "entity_type": "cloud_resource",
                "entity_value": bucket_url,
                "data": {"bucket_url": bucket_url, "checked": True},
                "confidence": 0.2,
            })

        return evidence
