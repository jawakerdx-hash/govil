"""Base worker — all investigation job workers inherit from this."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.investigation.models import InvestigationEvidence
from src.foundation.event_bus import EventBus


class BaseWorker(ABC):
    """Abstract base for all investigation job workers.

    Each worker wraps an existing CEIP service and converts
    its output into structured InvestigationEvidence.
    """

    def __init__(
        self,
        db: AsyncSession,
        event_bus: EventBus | None = None,
    ) -> None:
        self.db = db
        self.event_bus = event_bus

    @abstractmethod
    async def execute(
        self,
        investigation_id: str,
        job_id: str,
        domain: str,
        params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Execute the job and return evidence dicts.

        Returns a list of dicts with keys: evidence_type, severity,
        title, description, source_module, entity_type, entity_value,
        data, confidence.
        """
        ...

    def _to_evidence(
        self,
        investigation_id: str,
        job_id: str,
        evidence_type: str,
        severity: str,
        title: str,
        source_module: str,
        entity_type: str,
        entity_value: str,
        data: dict[str, Any] | None = None,
        description: str | None = None,
        confidence: float = 0.5,
    ) -> InvestigationEvidence:
        """Create an InvestigationEvidence row from worker output."""
        return InvestigationEvidence(
            investigation_id=investigation_id,
            job_id=job_id,
            evidence_type=evidence_type,
            severity=severity,
            title=title,
            description=description,
            source_module=source_module,
            entity_type=entity_type,
            entity_value=entity_value,
            data_json=json.dumps(data or {}, default=str),
            confidence=confidence,
        )

    @staticmethod
    def _severity_from_cvss(score: float) -> str:
        if score >= 9.0:
            return "CRITICAL"
        if score >= 7.0:
            return "HIGH"
        if score >= 4.0:
            return "MEDIUM"
        return "LOW"
