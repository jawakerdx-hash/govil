"""Evidence Pipeline — processes evidence through verification, correlation, risk, and intelligence."""

from __future__ import annotations

import json
import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.investigation.models import InvestigationEvidence
from src.foundation.event_bus import EventBus


class EvidenceCollector:
    """Collects raw job output and wraps it in InvestigationEvidence records."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def collect(
        self,
        investigation_id: uuid.UUID,
        job_id: uuid.UUID,
        evidence_items: list[dict[str, Any]],
    ) -> list[InvestigationEvidence]:
        """Persist evidence items from a completed job."""
        records = []
        for item in evidence_items:
            record = InvestigationEvidence(
                investigation_id=investigation_id,
                job_id=job_id,
                evidence_type=item.get("evidence_type", "asset"),
                severity=item.get("severity", "INFO"),
                title=item.get("title", "Untitled evidence"),
                description=item.get("description"),
                source_module=item.get("source_module", "unknown"),
                entity_type=item.get("entity_type", "unknown"),
                entity_value=item.get("entity_value", ""),
                data_json=json.dumps(item.get("data", {})),
                confidence=item.get("confidence", 0.5),
            )
            self._db.add(record)
            records.append(record)

        await self._db.flush()
        return records


class EvidenceCorrelator:
    """Links related evidence by entity, cross-references across jobs."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def correlate(self, investigation_id: uuid.UUID) -> dict[str, Any]:
        """Correlate all evidence in an investigation.

        Groups by entity_value, links related items, assigns correlation_ids.
        """
        result = await self._db.execute(
            select(InvestigationEvidence).where(
                InvestigationEvidence.investigation_id == investigation_id,
            ).order_by(InvestigationEvidence.created_at)
        )
        all_evidence = list(result.scalars().all())

        # Group by entity_value for cross-job correlation
        groups: dict[str, list[InvestigationEvidence]] = {}
        for ev in all_evidence:
            key = f"{ev.entity_type}:{ev.entity_value}"
            groups.setdefault(key, []).append(ev)

        # Assign correlation_ids to related evidence
        corr_count = 0
        for _key, items in groups.items():
            if len(items) > 1:
                corr_id = uuid.uuid4().hex[:16]
                for item in items:
                    item.correlation_id = corr_id
                corr_count += 1

        await self._db.flush()

        return {
            "total_evidence": len(all_evidence),
            "unique_entities": len(groups),
            "correlated_groups": corr_count,
            "multi_source_count": sum(1 for items in groups.values() if len(items) > 1),
            "evidence_types": {
                etype: sum(1 for ev in all_evidence if ev.evidence_type == etype)
                for etype in {ev.evidence_type for ev in all_evidence}
            },
        }


class EvidenceVerifier:
    """Runs the 8-stage verification pipeline on collected evidence."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def verify_all(self, investigation_id: uuid.UUID) -> dict[str, Any]:
        """Run verification on all unverified evidence."""
        from src.foundation.verification_engine import VerificationPipeline

        result = await self._db.execute(
            select(InvestigationEvidence).where(
                InvestigationEvidence.investigation_id == investigation_id,
                InvestigationEvidence.verified == False,  # noqa: E712
            )
        )
        unverified = list(result.scalars().all())

        pipeline = VerificationPipeline()
        verified_count = 0

        for ev in unverified:
            finding = {
                "scan_id": str(investigation_id),
                "title": ev.title,
                "severity": ev.severity,
                "endpoint": ev.entity_value,
                "description": ev.description or "",
            }
            evidence_items = [{
                "source": ev.source_module,
                "timestamp": ev.created_at.isoformat() if ev.created_at else "",
                "confidence": ev.confidence,
                "collector": ev.source_module,
                "stage": "initial",
            }]

            try:
                verified = await pipeline.verify(finding, evidence_items)
                ev.verified = True
                ev.confidence = max(ev.confidence, verified.overall_confidence)
                verified_count += 1
            except Exception:
                pass  # Individual verification failure is non-fatal

        await self._db.flush()

        return {
            "total_unverified": len(unverified),
            "verified_count": verified_count,
            "failed_count": len(unverified) - verified_count,
        }


class EvidencePipeline:
    """Complete evidence processing pipeline.

    Flow: Collect → Correlate → Verify → (Risk) → (Intelligence)

    Stages 1-3 run during phase 14 (Verification).
    Stages 4-5 (Risk, Intelligence) run in phases 15 and 17.
    """

    def __init__(self, db: AsyncSession, event_bus: EventBus | None = None) -> None:
        self._db = db
        self._event_bus = event_bus or EventBus()
        self.collector = EvidenceCollector(db)
        self.correlator = EvidenceCorrelator(db)
        self.verifier = EvidenceVerifier(db)

    async def process_phase_evidence(
        self, investigation_id: uuid.UUID,
    ) -> dict[str, Any]:
        """Run all evidence processing stages for an investigation."""

        # Stage 1-2: Correlate
        corr_result = await self.correlator.correlate(investigation_id)

        # Stage 3: Verify
        verify_result = await self.verifier.verify_all(investigation_id)

        # Emit event
        channel = f"investigation:{investigation_id}"
        await self._event_bus.publish(channel, {
            "type": "evidence_processing_complete",
            "investigation_id": str(investigation_id),
            "correlation": corr_result,
            "verification": verify_result,
        })

        return {
            "correlation": corr_result,
            "verification": verify_result,
        }
