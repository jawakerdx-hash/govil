"""Investigation context — production-grade investigation orchestration."""
