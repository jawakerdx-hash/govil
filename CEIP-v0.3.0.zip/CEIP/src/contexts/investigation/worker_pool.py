"""Redis-backed worker pool for horizontally scalable investigations.

Replaces the in-memory asyncio.Queue in task_queue.py.
Workers pull jobs from Redis, execute via registered handlers, and report results.
"""

from __future__ import annotations

import asyncio
import importlib
import json
import time
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import create_async_engine

from src.foundation.database import create_session_factory


class InvestigationWorkerPool:
    """Redis-backed pool. Each worker pulls jobs, executes, reports.

    In production, Redis is used. For dev, falls back to in-memory queue.
    """

    REDIS_QUEUE_KEY = "ceip:investigation:queue"
    REDIS_INFLIGHT_KEY = "ceip:investigation:inflight"

    def __init__(
        self,
        database_url: str,
        redis_url: str | None = None,
        worker_count: int = 4,
    ) -> None:
        self._database_url = database_url
        self._redis_url = redis_url
        self._worker_count = worker_count
        self._redis: Any = None  # redis.asyncio.Redis
        self._running = False
        self._workers: list[asyncio.Task] = []

        # In-memory fallback
        self._memory_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()

    async def start(self) -> None:
        """Start the worker pool."""
        self._running = True

        # Try Redis connection
        if self._redis_url:
            try:
                import redis.asyncio as aioredis
                self._redis = await aioredis.from_url(
                    self._redis_url, decode_responses=True,
                )
            except Exception:
                self._redis = None  # Fall back to in-memory

        # Start workers
        for i in range(self._worker_count):
            task = asyncio.create_task(self._worker_loop(i))
            self._workers.append(task)

    async def stop(self) -> None:
        """Stop all workers gracefully."""
        self._running = False
        for task in self._workers:
            task.cancel()
        self._workers.clear()

        if self._redis:
            await self._redis.close()

    async def enqueue(self, job_payload: dict[str, Any]) -> None:
        """Push a job to the queue."""
        payload_str = json.dumps(job_payload)

        if self._redis:
            await self._redis.rpush(self.REDIS_QUEUE_KEY, payload_str)
        else:
            await self._memory_queue.put(job_payload)

    async def _worker_loop(self, worker_id: int) -> None:
        """Main worker loop: pull job → execute → report."""
        while self._running:
            try:
                payload = await self._dequeue(timeout=1.0)
                if payload is None:
                    continue

                job_id = payload.get("job_id")
                worker_class_path = payload.get("worker_class", "")
                params = payload.get("params", {})

                if not worker_class_path:
                    continue

                # Resolve worker class
                worker_cls = self._resolve_worker(worker_class_path)
                if worker_cls is None:
                    continue

                # Execute job
                t0 = time.perf_counter()

                engine = create_async_engine(self._database_url, echo=False)
                factory = create_session_factory(engine)
                async with factory() as db:
                    try:
                        from src.contexts.investigation.orchestrator import (
                            InvestigationOrchestrator,
                        )

                        worker_instance = worker_cls(db)
                        evidence = await worker_instance.execute(
                            investigation_id=payload.get("investigation_id", ""),
                            job_id=job_id,
                            domain=params.get("domain", ""),
                            params=params,
                        )

                        duration_ms = int((time.perf_counter() - t0) * 1000)

                        # Report completion to orchestrator
                        orch = InvestigationOrchestrator(db)
                        await orch.handle_job_completion(
                            job_id=uuid.UUID(job_id),
                            evidence_items=evidence,
                            duration_ms=duration_ms,
                        )

                    except Exception as exc:
                        duration_ms = int((time.perf_counter() - t0) * 1000)
                        orch = InvestigationOrchestrator(db)
                        await orch.handle_job_failure(
                            job_id=uuid.UUID(job_id),
                            error=exc,
                        )
                await engine.dispose()

            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(0.5)

    async def _dequeue(self, timeout: float = 5.0) -> dict[str, Any] | None:
        """Pop a job from Redis or in-memory queue."""
        if self._redis:
            try:
                result = await self._redis.blpop(
                    self.REDIS_QUEUE_KEY, timeout=int(timeout),
                )
                if result:
                    _, payload_str = result
                    return json.loads(payload_str)
            except Exception:
                pass
            return None
        else:
            try:
                return await asyncio.wait_for(
                    self._memory_queue.get(), timeout=timeout,
                )
            except TimeoutError:
                return None

    @staticmethod
    def _resolve_worker(worker_class_path: str) -> Any | None:
        """Resolve a worker class by its fully qualified path."""
        try:
            module_path, class_name = worker_class_path.rsplit(".", 1)
            module = importlib.import_module(module_path)
            return getattr(module, class_name)
        except Exception:
            return None
