"""Investigation ORM models — Investigation, Job, Evidence, Timeline, Phase."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


def _utcnow() -> datetime:
    return datetime.now(UTC)


# ---------------------------------------------------------------------------
# Investigation — top-level entity for every scan / investigation
# ---------------------------------------------------------------------------


class Investigation(UUIDMixin, TimestampMixin, Base):
    """A structured security investigation against a target domain.

    Contains 1-19 phases, each with multiple independent jobs.
    Progress computed as completed_jobs / total_jobs.
    """

    __tablename__ = "investigations"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    tenant_id: Mapped[str] = mapped_column(
        String(64), default="default", nullable=False, index=True
    )
    status: Mapped[str] = mapped_column(
        String(20), default="pending", nullable=False
    )  # pending|validating|running|paused|completed|failed|cancelled
    priority: Mapped[str] = mapped_column(
        String(16), default="MEDIUM", nullable=False
    )  # LOW|MEDIUM|HIGH|CRITICAL

    # Phase tracking
    current_phase: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    progress_pct: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)

    # Job counters (recalculated on every job completion)
    total_jobs: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    completed_jobs: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failed_jobs: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    running_jobs: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Discovery counters
    evidence_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    asset_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    finding_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Risk snapshot (populated after Phase 15)
    risk_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    risk_level: Mapped[str] = mapped_column(
        String(16), default="LOW", nullable=False
    )
    intelligence_cases: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Timing
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Configuration (JSON blob for investigation-specific settings)
    config_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Relationships
    jobs: Mapped[list[InvestigationJob]] = relationship(
        back_populates="investigation", cascade="all, delete-orphan",
        order_by="InvestigationJob.created_at",
    )
    evidence_items: Mapped[list[InvestigationEvidence]] = relationship(
        back_populates="investigation", cascade="all, delete-orphan",
    )
    timeline_events: Mapped[list[InvestigationTimeline]] = relationship(
        back_populates="investigation", cascade="all, delete-orphan",
        order_by="InvestigationTimeline.sequence",
    )
    phases: Mapped[list[InvestigationPhase]] = relationship(
        back_populates="investigation", cascade="all, delete-orphan",
        order_by="InvestigationPhase.phase_number",
    )


# ---------------------------------------------------------------------------
# InvestigationJob — a single unit of work within a phase
# ---------------------------------------------------------------------------


class InvestigationJob(UUIDMixin, TimestampMixin, Base):
    """An independent, retryable, observable unit of work.

    Each job wraps a call to an existing CEIP service (DiscoveryService,
    VulnerabilityService, RiskEngine, etc.) and produces structured evidence.
    """

    __tablename__ = "investigation_jobs"

    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    phase: Mapped[int] = mapped_column(Integer, nullable=False)  # 1-19
    job_type: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True,
    )  # e.g. "dns_resolution", "http_fingerprint"
    worker: Mapped[str] = mapped_column(
        String(128), nullable=False,
    )  # fully-qualified worker class name

    # Lifecycle
    status: Mapped[str] = mapped_column(
        String(16), default="pending", nullable=False,
    )  # pending|running|completed|failed|skipped|cancelled|retrying
    priority: Mapped[int] = mapped_column(
        Integer, default=50, nullable=False,
    )  # 0 (highest) - 100 (lowest)

    # Retry
    attempt: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3, nullable=False)

    # Dependencies (JSON array of job_ids that must complete first)
    dependencies_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # I/O
    input_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    output_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Timing
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    retry_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )  # next retry time per exponential backoff

    # Audit log (JSON list of {"timestamp": "...", "level": "INFO", "message": "..."})
    logs_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Relationships
    investigation: Mapped[Investigation] = relationship(back_populates="jobs")
    evidence_items: Mapped[list[InvestigationEvidence]] = relationship(
        back_populates="job", cascade="all, delete-orphan",
    )


# ---------------------------------------------------------------------------
# InvestigationEvidence — structured output from every job
# ---------------------------------------------------------------------------


class InvestigationEvidence(UUIDMixin, TimestampMixin, Base):
    """Structured evidence produced by a job.

    Every job writes evidence — never directly to a report.
    Evidence flows through: Verification → Correlation → Risk → Intelligence.
    """

    __tablename__ = "investigation_evidence"

    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigation_jobs.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )

    # Classification
    evidence_type: Mapped[str] = mapped_column(
        String(32), nullable=False,
    )  # asset|technology|finding|threat|exposure|certificate|service|endpoint|relationship
    severity: Mapped[str] = mapped_column(
        String(16), default="INFO", nullable=False,
    )  # CRITICAL|HIGH|MEDIUM|LOW|INFO
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Provenance
    source_module: Mapped[str] = mapped_column(
        String(32), nullable=False,
    )  # e.g. "M3-DNS", "M4-HTTP", "M6-Vulnerability"

    # Entity reference
    entity_type: Mapped[str] = mapped_column(
        String(32), nullable=False,
    )  # domain|subdomain|ip|service|certificate|vulnerability|threat_match
    entity_value: Mapped[str] = mapped_column(String(512), nullable=False)

    # Payload
    data_json: Mapped[str] = mapped_column(Text, nullable=False)  # full structured payload
    confidence: Mapped[float] = mapped_column(Float, default=0.5, nullable=False)

    # Pipeline state
    verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    correlation_id: Mapped[str | None] = mapped_column(
        String(64), nullable=True, index=True,
    )  # links related evidence across jobs

    # Relationships
    investigation: Mapped[Investigation] = relationship(back_populates="evidence_items")
    job: Mapped[InvestigationJob] = relationship(back_populates="evidence_items")


# ---------------------------------------------------------------------------
# InvestigationTimeline — ordered event stream for live dashboards
# ---------------------------------------------------------------------------


class InvestigationTimeline(UUIDMixin, Base):
    """Time-ordered event stream. One row per significant event."""

    __tablename__ = "investigation_timeline"

    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    phase: Mapped[int | None] = mapped_column(Integer, nullable=True)
    job_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("investigation_jobs.id", ondelete="SET NULL"),
        nullable=True, index=True,
    )

    event_type: Mapped[str] = mapped_column(
        String(32), nullable=False,
    )  # phase_started|job_completed|evidence_collected|asset_discovered|...
    message: Mapped[str] = mapped_column(String(512), nullable=False)
    data_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False,
    )

    # Relationship
    investigation: Mapped[Investigation] = relationship(back_populates="timeline_events")


# ---------------------------------------------------------------------------
# InvestigationPhase — per-phase tracking within an investigation
# ---------------------------------------------------------------------------


class InvestigationPhase(UUIDMixin, Base):
    """Tracks execution state for each of the 19 investigation phases."""

    __tablename__ = "investigation_phases"

    investigation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("investigations.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    phase_number: Mapped[int] = mapped_column(Integer, nullable=False)  # 1-19
    name: Mapped[str] = mapped_column(
        String(64), nullable=False,
    )  # "Target Validation", "DNS Intelligence", ...
    status: Mapped[str] = mapped_column(
        String(20), default="pending", nullable=False,
    )  # pending|running|completed|failed|skipped|completed_with_errors
    job_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    completed_jobs: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    failed_jobs: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # Relationship
    investigation: Mapped[Investigation] = relationship(back_populates="phases")
