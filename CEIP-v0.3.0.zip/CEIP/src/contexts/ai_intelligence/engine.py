# ruff: noqa: E501  — system prompts and JSON schemas must stay intact
"""AI Analysis Engine — reasoning and verification over all tool/agent results.

This engine does NOT replace security tools. It sits BETWEEN tool execution
and the next decision point, analyzing findings and recommending actions.

Integration points:
1. After each CEIP.py pipeline phase → analyze findings
2. Inside AIOrchestrator → enhance intent classification + consensus
3. Autonomous loop → generate next investigation tasks
"""

from __future__ import annotations

import json
import time
from typing import Any

import structlog

from src.config import Settings

from .models import (
    ALLOWED_ACTIONS,
    ALLOWED_AGENTS,
    AIAnalysisInput,
    AIAnalysisOutput,
    EvidenceItem,
    FindingAssessment,
)
from .provider import AIProvider, AnthropicProvider

# ---------------------------------------------------------------------------
# System prompt — instructs the AI how to behave as a security analyst
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are the CEIP AI Intelligence Layer — a security analysis engine that reviews findings from automated security tools.

Your job is NOT to run scans. Tools produce evidence. You analyze, correlate, verify, and prioritize.

RULES:
1. Never hallucinate findings. Only reason about the evidence provided.
2. Flag probable false positives with clear reasoning.
3. Identify when multiple tools are reporting the same issue.
4. Identify missing evidence and recommend what to check next.
5. Recommend which existing tool/agent should investigate next.
6. Connect findings to attack paths and asset relationships.
7. Every recommendation must reference a tool or agent that actually exists.
8. Be conservative with severity upgrades — only escalate with strong evidence.
9. Output ONLY valid JSON. No markdown, no explanation outside the JSON.
10. Be CONCISE. Every reasoning and summary field must be under 100 characters unless truly needed.
11. Do NOT list the same finding multiple times. Deduplicate.

Available tools: discover, correlate, assess_vulnerability, check_threats, compute_risk, simulate_attack_path, scan_brand, check_email_security
Available agents: DiscoveryAgent, ThreatAnalyst, VulnerabilityAnalyst, DarkWebAnalyst, BrandProtectionAgent, IncidentInvestigator, ExecutiveAdvisor

Respond with this EXACT JSON structure:
{
  "finding_assessments": [
    {
      "finding_id": "string",
      "is_credible": true,
      "is_false_positive": false,
      "false_positive_probability": 0.0,
      "confidence": 0.85,
      "severity": "medium",
      "reasoning": "Why this assessment was made"
    }
  ],
  "correlation_results": [],
  "evidence_gaps": ["what is missing"],
  "related_findings": ["finding_id_1", "finding_id_2"],
  "recommended_next_actions": ["verify_finding", "assess_vulnerability"],
  "recommended_agent": "VulnerabilityAnalyst",
  "recommended_tool": "assess_vulnerability",
  "priority": "medium",
  "confidence": 0.85,
  "reasoning_summary": "Overall analysis summary in 1-2 sentences",
  "new_tasks": [
    {"target": "example.com", "action": "assess_vulnerability", "priority": "high", "reason": "Verify CVE-2024-4577"}
  ]
}
"""


class AIIntelligenceEngine:
    """AI reasoning layer that analyzes tool findings and generates next actions.

    Integrates into the autonomous loop:
    DISCOVER → COLLECT → AI ANALYSIS → CORRELATE → VERIFY → UPDATE GRAPH → NEW TASKS → LOOP
    """

    def __init__(
        self,
        settings: Settings | None = None,
        provider: AIProvider | None = None,
        logger: structlog.BoundLogger | None = None,
    ) -> None:
        self._settings = settings or Settings()
        self._log = logger or structlog.get_logger().bind(component="ai-intel-engine")
        self._provider = provider
        self._analysis_history: list[dict[str, Any]] = []
        self._finding_store: list[dict[str, Any]] = []

    @property
    def provider(self) -> AIProvider:
        """Lazy-init the provider so we respect the current settings."""
        if self._provider is None:
            import httpx

            self._provider = AnthropicProvider(
                self._settings,
                http_client=httpx.AsyncClient(
                    timeout=httpx.Timeout(self._settings.ai_timeout),
                ),
                logger=self._log,
            )
        return self._provider

    # ------------------------------------------------------------------
    # Main analysis entry point
    # ------------------------------------------------------------------

    async def analyze_phase(
        self,
        phase: str,
        evidence_items: list[EvidenceItem],
        *,
        previous_findings: list[dict[str, Any]] | None = None,
        related_findings: list[dict[str, Any]] | None = None,
        attack_path_context: list[dict[str, Any]] | None = None,
        investigation_history: list[dict[str, Any]] | None = None,
        asset_graph_summary: str = "",
        risk_summary: str = "",
        scan_target: str = "",
    ) -> AIAnalysisOutput:
        """Send a phase's findings to the AI for structured analysis.

        Returns an empty/default AIAnalysisOutput if AI is disabled or fails.
        The pipeline continues regardless.
        """
        t0 = time.perf_counter()

        # Build structured input
        ai_input = AIAnalysisInput(
            scan_target=scan_target,
            phase=phase,
            evidence_items=evidence_items,
            previous_findings=previous_findings or self._finding_store[-20:],
            related_findings=related_findings or [],
            attack_path_context=attack_path_context or [],
            investigation_history=investigation_history or self._analysis_history[-10:],
            asset_graph_summary=asset_graph_summary,
            risk_summary=risk_summary,
        )

        # Build the user prompt with all context
        user_prompt = self._build_prompt(ai_input)

        # Call AI
        raw_response = await self.provider.analyze(SYSTEM_PROMPT, user_prompt)

        if not raw_response:
            # AI unavailable — return empty output (pipeline continues)
            self._log.info(
                "ai_analysis_skipped",
                phase=phase,
                reason="ai_unavailable_or_disabled",
                duration_ms=round((time.perf_counter() - t0) * 1000, 1),
            )
            return AIAnalysisOutput(
                reasoning_summary=f"AI analysis skipped for {phase} (AI unavailable)",
                confidence=0.0,
            )

        # Parse and validate
        output = self._parse_output(raw_response, phase)

        # Store for history
        self._analysis_history.append({
            "phase": phase,
            "timestamp": time.time(),
            "findings_count": len(evidence_items),
            "output": output.to_dict(),
        })

        # Store findings
        for item in evidence_items:
            self._finding_store.append({
                "tool": item.tool_name,
                "agent": item.agent_name,
                "target": item.target,
                "type": item.finding_type,
                "severity": item.severity,
                "phase": phase,
            })

        duration_ms = round((time.perf_counter() - t0) * 1000, 1)
        self._log.info(
            "ai_analysis_complete",
            phase=phase,
            findings_analyzed=len(evidence_items),
            recommendations=len(output.recommended_next_actions),
            confidence=output.confidence,
            priority=output.priority,
            duration_ms=duration_ms,
            tokens_used=self.provider.tokens_used,
        )

        return output

    # ------------------------------------------------------------------
    # Quick check — single finding analysis (lightweight)
    # ------------------------------------------------------------------

    async def assess_finding(
        self,
        finding: EvidenceItem,
        *,
        context: str = "",
    ) -> FindingAssessment:
        """Quick AI assessment of a single finding. Used for real-time verification."""
        output = await self.analyze_phase(
            phase="single_finding",
            evidence_items=[finding],
            asset_graph_summary=context,
        )
        if output.finding_assessments:
            return output.finding_assessments[0]
        return FindingAssessment(
            finding_id=f"{finding.tool_name}:{finding.target}",
            confidence=0.5,
            reasoning="AI analysis unavailable — defaulting to manual review",
        )

    # ------------------------------------------------------------------
    # Task generation for the autonomous loop
    # ------------------------------------------------------------------

    def get_pending_tasks(self) -> list[dict[str, str]]:
        """Return all AI-recommended tasks that haven't been executed yet."""
        tasks: list[dict[str, str]] = []
        for entry in self._analysis_history[-5:]:
            output = entry.get("output", {})
            for task in output.get("new_tasks", []):
                tasks.append(task)
        return tasks

    def get_analysis_summary(self) -> str:
        """Human-readable summary of all AI analysis so far."""
        if not self._analysis_history:
            return "No AI analysis performed."
        parts = []
        for entry in self._analysis_history:
            phase = entry.get("phase", "?")
            output = entry.get("output", {})
            summary = output.get("reasoning_summary", "")
            if summary:
                parts.append(f"[{phase}] {summary}")
        return " | ".join(parts[-5:]) if parts else "Analysis completed."

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _build_prompt(self, inp: AIAnalysisInput) -> str:
        """Build a comprehensive prompt with all available context."""
        parts: list[str] = []

        parts.append(f"## Current Phase: {inp.phase}")
        parts.append(f"## Scan Target: {inp.scan_target}")
        parts.append("")

        # Evidence
        parts.append(f"## Evidence Items ({len(inp.evidence_items)} findings)")
        for i, item in enumerate(inp.evidence_items):
            parts.append(f"### Finding {i + 1}")
            parts.append(f"- Tool: {item.tool_name}")
            parts.append(f"- Agent: {item.agent_name}")
            parts.append(f"- Target: {item.target}")
            parts.append(f"- Type: {item.finding_type}")
            parts.append(f"- Severity: {item.severity}")
            parts.append(f"- Confidence: {item.confidence}")
            parts.append(f"- Result: {item.raw_result}")
            if item.raw_data:
                parts.append(f"- Data: {json.dumps(item.raw_data, default=str)[:500]}")
            parts.append("")

        # Previous findings
        if inp.previous_findings:
            parts.append(f"## Previous Findings ({len(inp.previous_findings)})")
            parts.append(json.dumps(inp.previous_findings[-10:], default=str)[:1500])
            parts.append("")

        # Attack path context
        if inp.attack_path_context:
            parts.append("## Attack Path Context")
            parts.append(json.dumps(inp.attack_path_context, default=str)[:1000])
            parts.append("")

        # Asset graph
        if inp.asset_graph_summary:
            parts.append(f"## Asset Graph: {inp.asset_graph_summary}")
            parts.append("")

        # Risk context
        if inp.risk_summary:
            parts.append(f"## Risk Context: {inp.risk_summary}")
            parts.append("")

        # Investigation history
        if inp.investigation_history:
            parts.append("## Investigation History")
            parts.append(json.dumps(inp.investigation_history[-5:], default=str)[:1000])
            parts.append("")

        parts.append("## Instructions")
        parts.append("Analyze the evidence above. Identify false positives, correlate related findings, identify evidence gaps, and recommend next actions. Output ONLY valid JSON.")

        return "\n".join(parts)

    def _parse_output(self, raw: dict[str, Any], phase: str) -> AIAnalysisOutput:
        """Parse and validate the AI's JSON response into a structured output.

        Sanitises: only allowed actions and agents pass through.
        """
        assessments = []
        for fa in raw.get("finding_assessments", []):
            if not isinstance(fa, dict):
                continue
            assessments.append(FindingAssessment(
                finding_id=str(fa.get("finding_id", ""))[:200],
                is_credible=bool(fa.get("is_credible", True)),
                is_false_positive=bool(fa.get("is_false_positive", False)),
                false_positive_probability=float(fa.get("false_positive_probability", 0)),
                confidence=float(fa.get("confidence", 0.5)),
                severity=str(fa.get("severity", "medium")),
                reasoning=str(fa.get("reasoning", ""))[:500],
            ))

        # Sanitise: only allow known actions
        raw_actions = raw.get("recommended_next_actions", [])
        if isinstance(raw_actions, str):
            raw_actions = [raw_actions]
        safe_actions = [
            a for a in raw_actions
            if isinstance(a, str) and a in ALLOWED_ACTIONS
        ]

        # Sanitise: only allow known agents
        agent = str(raw.get("recommended_agent", ""))
        if agent not in ALLOWED_AGENTS:
            agent = ""

        # Sanitise: only allow known tools
        tool = str(raw.get("recommended_tool", ""))
        if tool not in ALLOWED_ACTIONS:
            tool = ""

        # Sanitise: priority
        priority = str(raw.get("priority", "medium"))
        if priority not in ("critical", "high", "medium", "low"):
            priority = "medium"

        # Sanitise: new tasks
        new_tasks = []
        for t in raw.get("new_tasks", []):
            if not isinstance(t, dict):
                continue
            action = str(t.get("action", ""))
            if action in ALLOWED_ACTIONS:
                new_tasks.append({
                    "target": str(t.get("target", ""))[:200],
                    "action": action,
                    "priority": str(t.get("priority", "medium")),
                    "reason": str(t.get("reason", ""))[:300],
                })

        return AIAnalysisOutput(
            finding_assessments=assessments,
            correlation_results=raw.get("correlation_results", [])[:20],
            evidence_gaps=[str(g) for g in raw.get("evidence_gaps", [])][:10],
            related_findings=[str(f) for f in raw.get("related_findings", [])][:20],
            recommended_next_actions=safe_actions,
            recommended_agent=agent,
            recommended_tool=tool,
            priority=priority,
            confidence=float(raw.get("confidence", 0.5)),
            reasoning_summary=str(raw.get("reasoning_summary", ""))[:500],
            new_tasks=new_tasks[:5],
        )
