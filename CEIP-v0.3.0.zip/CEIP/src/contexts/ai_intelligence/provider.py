"""AI provider abstraction — configurable backend for the intelligence layer.

Supports Anthropic (Claude) by default. Switchable via Settings without
code changes: set ``AI_API_URL``, ``AI_API_KEY``, ``AI_MODEL`` in .env

Built-in: timeout handling, retry with exponential backoff, rate-limit
tracking, API-failure fallback, structured logging, and cost control.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from abc import ABC, abstractmethod
from typing import Any

import httpx
import structlog

from src.config import Settings


class AIProvider(ABC):
    """Abstract interface for an AI reasoning backend."""

    @abstractmethod
    async def analyze(self, system_prompt: str, user_prompt: str) -> dict[str, Any]:
        """Send structured analysis request and return parsed JSON response."""
        ...

    @property
    @abstractmethod
    def tokens_used(self) -> int:
        """Total tokens consumed in this session."""
        ...

    @property
    @abstractmethod
    def requests_made(self) -> int:
        """Total API requests made in this session."""
        ...


class AnthropicProvider(AIProvider):
    """Claude API provider with production-hardened reliability.

    Features:
    - Exponential backoff retry (3 attempts default)
    - Rate-limit tracking with automatic backpressure
    - Per-scan token budget enforcement
    - Graceful fallback on API failure
    - Structured JSON response parsing with validation
    - Request/response logging with truncated payloads
    """

    def __init__(
        self,
        settings: Settings,
        http_client: httpx.AsyncClient | None = None,
        logger: structlog.BoundLogger | None = None,
    ) -> None:
        self._settings = settings
        self._http = http_client or httpx.AsyncClient(
            timeout=httpx.Timeout(settings.ai_timeout),
        )
        self._log = logger or structlog.get_logger().bind(component="ai-intel")
        self._tokens_used = 0
        self._requests = 0
        self._request_times: list[float] = []  # sliding window for rate limiting
        self._api_key_hash = hashlib.sha256(
            settings.ai_api_key.encode()
        ).hexdigest()[:8] if settings.ai_api_key else "none"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def analyze(self, system_prompt: str, user_prompt: str) -> dict[str, Any]:
        """Send a structured analysis request to Claude and return parsed JSON.

        Returns an empty dict on any failure — the system continues without AI.
        """
        if not self._settings.ai_enabled or not self._settings.ai_api_key:
            return {}

        # Check budget
        budget = self._settings.ai_budget_per_scan
        if self._tokens_used >= budget:
            self._log.warning(
                "ai_budget_exceeded",
                tokens_used=self._tokens_used,
                budget=budget,
            )
            return {}

        # Rate limit check
        await self._rate_limit_wait()

        # Build request
        body = {
            "model": self._settings.ai_model,
            "max_tokens": self._settings.ai_max_tokens,
            "temperature": self._settings.ai_temperature,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        }
        headers = {
            "x-api-key": self._settings.ai_api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

        # Retry loop
        last_error = None
        for attempt in range(1, self._settings.ai_max_retries + 1):
            try:
                t0 = time.perf_counter()
                resp = await self._http.post(
                    self._settings.ai_api_url,
                    headers=headers,
                    json=body,
                )
                latency_ms = (time.perf_counter() - t0) * 1000
                self._requests += 1
                self._request_times.append(time.monotonic())

                result = self._parse_response(resp, latency_ms)
                return result

            except (TimeoutError, httpx.TimeoutException) as exc:
                last_error = f"timeout (attempt {attempt}/{self._settings.ai_max_retries})"
                self._log.warning("ai_timeout", attempt=attempt, error=str(exc))
                if attempt < self._settings.ai_max_retries:
                    await asyncio.sleep(2 ** attempt)

            except httpx.HTTPStatusError as exc:
                if exc.response.status_code == 429:
                    last_error = f"rate limited (attempt {attempt})"
                    self._log.warning("ai_rate_limited", attempt=attempt)
                    retry_after = int(exc.response.headers.get("retry-after", 5))
                    await asyncio.sleep(retry_after + attempt)
                elif exc.response.status_code in (401, 403):
                    self._log.error("ai_auth_failed", status=exc.response.status_code)
                    return {}  # Don't retry auth failures
                else:
                    last_error = f"HTTP {exc.response.status_code}"
                    if attempt < self._settings.ai_max_retries:
                        await asyncio.sleep(2 ** attempt)

            except Exception as exc:
                last_error = str(exc)[:100]
                self._log.warning("ai_call_failed", attempt=attempt, error=last_error)
                if attempt < self._settings.ai_max_retries:
                    await asyncio.sleep(2 ** attempt)

        self._log.error("ai_all_retries_exhausted", last_error=last_error)
        return {}

    @property
    def tokens_used(self) -> int:
        return self._tokens_used

    @property
    def requests_made(self) -> int:
        return self._requests

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _parse_response(self, resp: httpx.Response, latency_ms: float) -> dict[str, Any]:
        """Parse Claude's response, extracting structured JSON from the content."""
        if resp.status_code != 200:
            raise httpx.HTTPStatusError(
                f"AI API returned {resp.status_code}",
                request=resp.request,
                response=resp,
            )

        data = resp.json()
        usage = data.get("usage", {})
        prompt_tokens = usage.get("input_tokens", 0)
        completion_tokens = usage.get("output_tokens", 0)
        self._tokens_used += prompt_tokens + completion_tokens

        content_blocks = data.get("content", [])
        text = ""
        for block in content_blocks:
            if block.get("type") == "text":
                text += block.get("text", "")

        stop_reason = data.get("stop_reason", "unknown")

        self._log.info(
            "ai_call_complete",
            latency_ms=round(latency_ms, 1),
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens_used=self._tokens_used,
            model=data.get("model", "unknown"),
            api_key_hash=self._api_key_hash,
            stop_reason=stop_reason,
            response_length=len(text),
        )

        # Extract JSON from the response
        result = _extract_json(text)
        if not result:
            self._log.warning(
                "ai_json_extraction_failed",
                response_preview=text[:300],
                response_length=len(text),
            )
        return result

    async def _rate_limit_wait(self) -> None:
        """Enforce configurable RPM limit using a sliding window."""
        rpm = self._settings.ai_rate_limit_rpm
        now = time.monotonic()
        window_start = now - 60.0

        # Prune old entries
        self._request_times = [t for t in self._request_times if t > window_start]

        if len(self._request_times) >= rpm:
            # Wait until the oldest entry falls out of the window
            oldest = self._request_times[0]
            wait = oldest - window_start + 0.5
            if wait > 0:
                self._log.debug("ai_rate_limit_wait", wait_seconds=round(wait, 1))
                await asyncio.sleep(wait)

    async def close(self) -> None:
        await self._http.aclose()


# ---------------------------------------------------------------------------
# JSON extraction helper
# ---------------------------------------------------------------------------


def _extract_json(text: str) -> dict[str, Any]:
    """Extract a JSON object from Claude's response text.

    Handles: raw JSON, ```json blocks, ``` blocks, and bare JSON in text.
    """
    if not text:
        return {}

    import re

    # Strategy 1: Extract from ```json ... ``` or ``` ... ``` code blocks
    # First try tagged block, then untagged block
    for pattern in [
        r'```json\s*\n(.*?)```',   # ```json\n{...}\n```
        r'```\s*\n(\{.*?\})\s*\n```',  # ```\n{...}\n```
    ]:
        match = re.search(pattern, text, re.DOTALL)
        if match:
            try:
                parsed = json.loads(match.group(1).strip())
                if isinstance(parsed, dict):
                    return parsed
            except (json.JSONDecodeError, ValueError):
                continue

    # Strategy 2: Find the outermost JSON object using brace matching
    start = text.find("{")
    if start >= 0:
        depth = 0
        in_string = False
        escape = False
        for i in range(start, len(text)):
            ch = text[i]
            if escape:
                escape = False
                continue
            if ch == "\\" and in_string:
                escape = True
                continue
            if ch == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start:i + 1]
                    try:
                        parsed = json.loads(candidate)
                        if isinstance(parsed, dict):
                            return parsed
                    except (json.JSONDecodeError, ValueError):
                        pass
                    break

    return {}
