"""Structured I/O models for the AI Intelligence Layer.

Every AI call receives a structured ``AIAnalysisInput`` and MUST return
machine-readable JSON matching ``AIAnalysisOutput``. The response is
validated before any action is taken.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EvidenceItem:
    """A single piece of evidence from a tool or agent."""

    tool_name: str = ""
    agent_name: str = ""
    target: str = ""
    finding_type: str = ""  # cve | misconfig | threat_match | exposure | certificate | dns | ...
    severity: str = ""      # critical | high | medium | low | info
    raw_result: str = ""    # human-readable summary
    raw_data: dict[str, Any] = field(default_factory=dict)  # structured data
    confidence: float = 0.0


@dataclass
class AIAnalysisInput:
    """Full context sent to the AI for analysis."""

    scan_target: str = ""
    phase: str = ""  # discovery | correlation | vulnerability | threat | risk | attack_path | brand
    evidence_items: list[EvidenceItem] = field(default_factory=list)
    previous_findings: list[dict[str, Any]] = field(default_factory=list)
    related_findings: list[dict[str, Any]] = field(default_factory=list)
    attack_path_context: list[dict[str, Any]] = field(default_factory=list)
    investigation_history: list[dict[str, Any]] = field(default_factory=list)
    asset_graph_summary: str = ""
    risk_summary: str = ""


@dataclass
class FindingAssessment:
    """AI assessment of a single finding."""

    finding_id: str = ""
    is_credible: bool = True
    is_false_positive: bool = False
    false_positive_probability: float = 0.0
    confidence: float = 0.5
    severity: str = "medium"
    reasoning: str = ""


@dataclass
class AIAnalysisOutput:
    """Machine-readable AI response. Every field is required by the validator."""

    finding_assessments: list[FindingAssessment] = field(default_factory=list)
    correlation_results: list[dict[str, Any]] = field(default_factory=list)
    evidence_gaps: list[str] = field(default_factory=list)
    related_findings: list[str] = field(default_factory=list)
    recommended_next_actions: list[str] = field(default_factory=list)
    recommended_agent: str = ""
    recommended_tool: str = ""
    priority: str = "medium"  # critical | high | medium | low
    confidence: float = 0.5
    reasoning_summary: str = ""
    new_tasks: list[dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "finding_assessments": [
                {
                    "finding_id": fa.finding_id,
                    "is_credible": fa.is_credible,
                    "is_false_positive": fa.is_false_positive,
                    "false_positive_probability": fa.false_positive_probability,
                    "confidence": fa.confidence,
                    "severity": fa.severity,
                    "reasoning": fa.reasoning,
                }
                for fa in self.finding_assessments
            ],
            "correlation_results": self.correlation_results,
            "evidence_gaps": self.evidence_gaps,
            "related_findings": self.related_findings,
            "recommended_next_actions": self.recommended_next_actions,
            "recommended_agent": self.recommended_agent,
            "recommended_tool": self.recommended_tool,
            "priority": self.priority,
            "confidence": self.confidence,
            "reasoning_summary": self.reasoning_summary,
            "new_tasks": self.new_tasks,
        }


# Every action the AI can recommend must be in this allowlist.
# AI-recommended actions NOT in this list are rejected by the validator.
ALLOWED_ACTIONS: frozenset[str] = frozenset({
    "discover",
    "correlate",
    "assess_vulnerability",
    "check_threats",
    "compute_risk",
    "simulate_attack_path",
    "scan_brand",
    "check_email_security",
    "verify_finding",
    "re_run_with_options",
    "mark_false_positive",
    "escalate_finding",
    "add_to_graph",
    "generate_report",
    "monitor_continuous",
    "no_action",
})

ALLOWED_AGENTS: frozenset[str] = frozenset({
    "DiscoveryAgent",
    "ThreatAnalyst",
    "VulnerabilityAnalyst",
    "DarkWebAnalyst",
    "BrandProtectionAgent",
    "IncidentInvestigator",
    "ExecutiveAdvisor",
})
