"""M32 — AI Cognitive Orchestration Layer.

Read-only orchestration over M1-M31. 7 specialized enterprise agents.
"""

from .capability_matrix import CAPABILITY_MATRIX, check_permission
from .confidence_engine import ConfidenceEngine
from .consensus_engine import ConsensusEngine
from .evidence_validator import EvidenceValidator
from .intent_classifier import IntentClassifier
from .investigation_session import SessionStore
from .models import (
    AGENT_NAMES,
    INTENTS,
    AgentCapability,
    InvestigationSession,
    OrchestratorOutput,
)
from .orchestrator import AIOrchestrator
from .registry import AgentRegistry
from .routing import RoutingEngine
from .validation import OrchestratorValidator

__all__ = [
    "AGENT_NAMES", "AIOrchestrator",
    "AgentCapability", "AgentRegistry",
    "CAPABILITY_MATRIX",
    "ConfidenceEngine", "ConsensusEngine",
    "EvidenceValidator",
    "INTENTS",
    "IntentClassifier", "InvestigationSession",
    "OrchestratorOutput", "OrchestratorValidator",
    "RoutingEngine",
    "SessionStore",
    "check_permission",
]
