"""Confidence engine — deterministic scoring for orchestration outputs."""

from __future__ import annotations

from typing import Any


class ConfidenceEngine:
    """Deterministic confidence: agent_count + evidence_count + consensus_factor."""

    @staticmethod
    def compute(agent_count: int, evidence_count: int) -> dict[str, Any]:
        agent_factor = min(1.0, agent_count * 0.25)
        evidence_factor = min(1.0, evidence_count * 0.15)
        score = round(agent_factor * 0.6 + evidence_factor * 0.4, 3)

        if score >= 0.8:
            level = "HIGH"
        elif score >= 0.5:
            level = "MEDIUM"
        else:
            level = "LOW"

        return {
            "score": score,
            "level": level,
            "agent_count": agent_count,
            "evidence_count": evidence_count,
        }
