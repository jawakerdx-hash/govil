"""Intent classifier — deterministic mapping from request to intent."""
# ruff: noqa: E501

from __future__ import annotations

from .models import INTENTS

INTENT_KEYWORDS: dict[str, list[str]] = {
    "Asset_Discovery": ["discover", "asset", "infrastructure", "domain", "ip", "scan", "find"],
    "Threat_Investigation": ["threat", "campaign", "apt", "malware", "ioc", "attack"],
    "Vulnerability_Prioritization": ["vulnerabilit", "cve", "exploit", "patch", "weakness", "risk"],
    "Executive_Summary": ["executive", "summary", "report", "overview", "business", "ceo"],
    "Dark_Web": ["dark web", "leak", "credential", "breach", "exposure", "telegram"],
    "Identity_Exposure": ["identity", "email", "employee", "executive", "admin", "user"],
    "Brand_Abuse": ["brand", "impersonat", "typosquat", "phishing", "lookalike", "domain"],
    "Attack_Path": ["attack path", "chain", "kill chain", "lateral", "exploit path"],
    "Incident_Investigation": ["incident", "timeline", "investigate", "reconstruct", "breach"],
    "Compliance": ["compliance", "pci", "iso", "nist", "cis", "audit", "regulatory"],
    "General_Question": [],  # fallback
}


class IntentClassifier:
    """Deterministic intent classification from natural language request."""

    @staticmethod
    def classify(request: str) -> str:
        if not request or not request.strip():
            return "Unknown"

        request_lower = request.lower().strip()
        scores: dict[str, int] = {}

        for intent, keywords in INTENT_KEYWORDS.items():
            if intent == "General_Question":
                continue
            score = sum(1 for kw in keywords if kw in request_lower)
            if score > 0:
                scores[intent] = score

        if not scores:
            return "General_Question"

        best = max(scores, key=lambda k: scores[k])
        if scores[best] >= 1:
            return best
        return "General_Question"

    @classmethod
    def classify_or_unknown(cls, request: str) -> str:
        result = cls.classify(request)
        return result if result in INTENTS else "Unknown"
