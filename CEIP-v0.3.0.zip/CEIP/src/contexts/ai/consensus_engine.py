"""Consensus engine — merges multi-agent outputs, resolves conflicts."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any


class ConsensusEngine:
    """Collects outputs, removes duplicates, resolves conflicts, merges evidence."""

    @staticmethod
    def merge(results: list[dict[str, Any]]) -> dict[str, Any]:
        if not results:
            return {"analysis": "No agent results", "evidence": [], "confidence": 0.0}

        analyses = [r.get("analysis", "") for r in results]
        evidence = []
        for r in results:
            evidence.extend(r.get("evidence", []))

        # Deduplicate evidence
        unique_evidence = list(dict.fromkeys(evidence))

        # Resolve conflicts (deterministic: latest agent wins if conflict)
        confidences = [r.get("confidence", 0.5) for r in results]
        avg_conf = round(sum(confidences) / len(confidences), 3)

        return {
            "analysis": " | ".join(analyses),
            "evidence": unique_evidence,
            "confidence": avg_conf,
            "agent_count": len(results),
            "conflict_status": "CONSENSUS" if len(set(analyses)) <= 1 else "AGENT_CONSENSUS_CONFLICT",
        }
