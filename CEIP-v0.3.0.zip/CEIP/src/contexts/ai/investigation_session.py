"""Investigation session store — immutable after completion."""

from __future__ import annotations

from .models import InvestigationSession


class SessionStore:
    """Stores completed investigation sessions. Immutable after finalize()."""

    def __init__(self) -> None:
        self._sessions: dict[str, InvestigationSession] = {}

    def store(self, session: InvestigationSession) -> None:
        if not session.immutable:
            raise ValueError("Session must be finalized before storing")
        self._sessions[session.session_id] = session

    def get(self, session_id: str) -> InvestigationSession | None:
        return self._sessions.get(session_id)

    def list_by_tenant(self, tenant_id: str, limit: int = 20) -> list[dict]:
        return [
            s.to_dict()
            for s in self._sessions.values()
            if s.tenant_id == tenant_id
        ][-limit:]

    def count(self) -> int:
        return len(self._sessions)
