"""M32 AI Orchestrator — read-only, delegates to agents, never modifies state."""

from __future__ import annotations

import time
import uuid
from typing import Any

from .capability_matrix import check_permission
from .confidence_engine import ConfidenceEngine
from .consensus_engine import ConsensusEngine
from .evidence_validator import EvidenceValidator
from .intent_classifier import IntentClassifier
from .investigation_session import SessionStore
from .models import InvestigationSession, OrchestratorOutput
from .registry import AgentRegistry
from .routing import RoutingEngine
from .validation import OrchestratorValidator


class AIOrchestrator:
    """Read-only orchestration layer. Agents never communicate directly.

    Pipeline: Classify Intent -> Route Agents -> Execute -> Consensus -> Evidence -> Output.
    """

    def __init__(self) -> None:
        self._registry = AgentRegistry()
        self._classifier = IntentClassifier()
        self._consensus = ConsensusEngine()
        self._evidence = EvidenceValidator()
        self._confidence = ConfidenceEngine()
        self._sessions = SessionStore()
        self._validator = OrchestratorValidator()

    async def investigate(self, tenant_id: str, request: str,
                    user: str = "system") -> dict[str, Any]:
        """Orchestrate an investigation across specialized agents. Now async — agents call real services."""
        t0 = time.perf_counter()
        session_id = uuid.uuid4().hex[:12]

        # 1. Classify intent
        intent = self._classifier.classify(request)

        # 2. Route to agents
        routing = RoutingEngine.route(intent)
        agents = routing.get("agents", [])
        strategy = routing.get("strategy", "single")

        if not agents:
            return self._error(session_id, tenant_id, request,
                               "M32_ROUTING_FAILURE", f"No agents for intent '{intent}'", intent)

        # 3. Execute agents (single/parallel/sequential via registry)
        results = {}
        reasoning: list[str] = []
        evidence_items: list[str] = []
        modules_used: list[str] = []

        for agent_name in agents:
            agent = self._registry.get(agent_name)
            if agent is None:
                continue

            # Permission check — use agent's own first allowed module
            allowed = agent.allowed_modules()
            primary_module = allowed[0] if allowed else "M24"
            perm_err = check_permission(agent_name, primary_module, "investigation")
            if perm_err:
                return self._error(session_id, tenant_id, request,
                                   "M32_PERMISSION_DENIED", perm_err["reason"], intent)

            result = await agent.investigate(tenant_id, request)
            results[agent_name] = result
            reasoning.append(f"{agent_name}: analyzed {intent}")
            evidence_items.extend(result.get("evidence", []))
            modules_used.extend(agent.allowed_modules())

        # 4. Consensus + merge
        merged = self._consensus.merge(list(results.values()))

        # 5. Evidence validation
        evidence_err = self._evidence.validate(merged, evidence_items)
        if evidence_err:
            return evidence_err

        # 6. Confidence scoring
        conf = self._confidence.compute(len(agents), len(evidence_items))

        # 7. Build output
        duration_ms = (time.perf_counter() - t0) * 1000
        output = OrchestratorOutput(
            session_id=session_id, tenant_id=tenant_id, intent=intent,
            agents_used=agents, routing_strategy=strategy,
            reasoning_chain=reasoning, supporting_modules=modules_used,
            evidence_summary=evidence_items[:10],
            confidence_score=conf["score"],
            confidence_level=conf["level"],
            final_analysis=merged,
            analysis_metadata={
                "request": request, "user": user,
                "duration_ms": round(duration_ms, 1),
                "modules_called": modules_used,
            },
        )

        # 8. Store immutable session
        session = InvestigationSession(
            session_id=session_id, tenant_id=tenant_id, user=user,
            request=request, intent=intent, agents_used=agents,
            routing_strategy=strategy, reasoning_chain=reasoning,
            duration_ms=round(duration_ms, 1),
            confidence=conf["score"],
        )
        session.finalize()
        self._sessions.store(session)

        # 9. Validate output
        val_err = self._validator.check(output.to_dict())
        if val_err:
            return val_err

        return output.to_dict()

    @staticmethod
    def _error(session_id: str, tenant_id: str, request: str,
               error_type: str, reason: str, intent: str = "Unknown") -> dict:
        return {
            "session_id": session_id, "tenant_id": tenant_id,
            "intent": intent, "agents_used": [],
            "routing_strategy": "none",
            "reasoning_chain": [], "supporting_modules": [],
            "evidence_summary": [],
            "confidence_score": 0.0, "confidence_level": "NONE",
            "final_analysis": {"error": error_type, "reason": reason},
            "analysis_metadata": {"request": request, "status": "FAILED"},
        }
