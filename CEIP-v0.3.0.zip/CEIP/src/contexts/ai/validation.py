"""Orchestrator validation — detects loops, cycles, permission violations."""

from __future__ import annotations

from typing import Any


class OrchestratorValidator:
    """Validates orchestrator output for architecture violations."""

    REQUIRED_OUTPUT_KEYS = frozenset({
        "session_id", "tenant_id", "intent", "agents_used",
        "routing_strategy", "reasoning_chain", "supporting_modules",
        "evidence_summary", "confidence_score", "confidence_level",
        "final_analysis", "analysis_metadata",
    })

    @classmethod
    def check(cls, output: dict[str, Any]) -> dict | None:
        """Return error dict on violation, None if valid."""
        # Missing keys
        missing = cls.REQUIRED_OUTPUT_KEYS - set(output.keys())
        if missing:
            return {"status": "M32_ARCHITECTURE_VIOLATION",
                    "reason": f"Missing output keys: {missing}"}

        # Agent loop detection
        agents = output.get("agents_used", [])
        if len(agents) != len(set(agents)):
            return {"status": "M32_AGENT_LOOP",
                    "reason": "Duplicate agent execution detected"}

        # Missing confidence
        if output.get("confidence_score", -1) < 0:
            return {"status": "M32_EVIDENCE_MISSING",
                    "reason": "Confidence score missing or negative"}

        # Missing intent
        if not output.get("intent"):
            return {"status": "M32_ROUTING_FAILURE",
                    "reason": "No intent classified"}

        # Tenant required
        if not output.get("tenant_id"):
            return {"status": "M32_ARCHITECTURE_VIOLATION",
                    "reason": "Missing tenant_id"}

        return None
