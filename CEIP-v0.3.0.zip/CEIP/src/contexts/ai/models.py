"""M32 — AI Cognitive Orchestration Layer models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

INTENTS = [
    "Asset_Discovery", "Threat_Investigation", "Vulnerability_Prioritization",
    "Executive_Summary", "Dark_Web", "Identity_Exposure", "Brand_Abuse",
    "Attack_Path", "Incident_Investigation", "Compliance",
    "General_Question", "Unknown",
]

AGENT_NAMES = [
    "DiscoveryAgent", "ThreatAnalyst", "VulnerabilityAnalyst",
    "DarkWebAnalyst", "BrandProtectionAgent", "IncidentInvestigator",
    "ExecutiveAdvisor",
]


@dataclass
class AgentCapability:
    agent_name: str
    allowed_modules: list[str] = field(default_factory=list)
    allowed_queries: list[str] = field(default_factory=list)
    allowed_memory_access: bool = False


@dataclass
class InvestigationSession:
    session_id: str
    tenant_id: str
    user: str = ""
    request: str = ""
    intent: str = "Unknown"
    agents_used: list[str] = field(default_factory=list)
    routing_strategy: str = ""
    reasoning_chain: list[str] = field(default_factory=list)
    timestamps: dict[str, str] = field(default_factory=dict)
    duration_ms: float = 0.0
    confidence: float = 0.0
    memory_refs: list[str] = field(default_factory=list)
    graph_refs: list[str] = field(default_factory=list)
    immutable: bool = False

    def finalize(self) -> None:
        self.immutable = True
        self.timestamps["completed"] = datetime.now(UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id, "tenant_id": self.tenant_id,
            "intent": self.intent, "agents_used": self.agents_used,
            "routing_strategy": self.routing_strategy,
            "reasoning_chain": self.reasoning_chain,
            "duration_ms": self.duration_ms, "confidence": self.confidence,
        }


@dataclass
class OrchestratorOutput:
    session_id: str
    tenant_id: str
    intent: str
    agents_used: list[str] = field(default_factory=list)
    routing_strategy: str = ""
    reasoning_chain: list[str] = field(default_factory=list)
    supporting_modules: list[str] = field(default_factory=list)
    evidence_summary: list[str] = field(default_factory=list)
    confidence_score: float = 0.0
    confidence_level: str = "LOW"
    final_analysis: dict[str, Any] = field(default_factory=dict)
    analysis_metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id, "tenant_id": self.tenant_id,
            "intent": self.intent, "agents_used": self.agents_used,
            "routing_strategy": self.routing_strategy,
            "reasoning_chain": self.reasoning_chain,
            "supporting_modules": self.supporting_modules,
            "evidence_summary": self.evidence_summary,
            "confidence_score": self.confidence_score,
            "confidence_level": self.confidence_level,
            "final_analysis": self.final_analysis,
            "analysis_metadata": self.analysis_metadata,
        }
