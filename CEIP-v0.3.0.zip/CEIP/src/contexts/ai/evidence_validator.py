"""Evidence validator — every claim must reference M1-M31 sources."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any


class EvidenceValidator:
    """Validates that every agent claim is backed by evidence."""

    @staticmethod
    def validate(merged: dict[str, Any], evidence: list[str]) -> dict | None:
        """Return UNSUPPORTED_AGENT_CLAIM if evidence is missing."""
        if not evidence:
            return {
                "status": "M32_EVIDENCE_MISSING",
                "reason": "No evidence provided for agent claims",
            }

        analysis = merged.get("analysis", "")
        if not analysis or analysis.strip() == "":
            return {
                "status": "M32_EVIDENCE_MISSING",
                "reason": "Empty analysis output from agents",
            }

        # Every claim must have at least one evidence reference
        if merged.get("agent_count", 0) > 0 and len(evidence) < merged["agent_count"]:
            return {
                "status": "M32_EVIDENCE_MISSING",
                "reason": f"Evidence count ({len(evidence)}) < agent count ({merged['agent_count']})",
            }

        return None
