"""Agent capability matrix — what each agent is allowed to access."""
# ruff: noqa: E501

from __future__ import annotations

from .models import AgentCapability

CAPABILITY_MATRIX: dict[str, AgentCapability] = {
    "DiscoveryAgent": AgentCapability(
        "DiscoveryAgent",
        allowed_modules=["M1", "M2", "M3", "M4", "M19", "M20"],
        allowed_queries=["investigation", "asset_discovery", "infrastructure", "graph_exploration", "correlation"],
        allowed_memory_access=True,
    ),
    "ThreatAnalyst": AgentCapability(
        "ThreatAnalyst",
        allowed_modules=["M6", "M22", "M23"],
        allowed_queries=["investigation", "campaigns", "apt", "ioc", "threat_correlation"],
        allowed_memory_access=True,
    ),
    "VulnerabilityAnalyst": AgentCapability(
        "VulnerabilityAnalyst",
        allowed_modules=["M5", "M21", "M22", "M24"],
        allowed_queries=["investigation", "vulnerability", "exploitability", "attack_feasibility", "risk"],
        allowed_memory_access=True,
    ),
    "DarkWebAnalyst": AgentCapability(
        "DarkWebAnalyst",
        allowed_modules=["M16", "M18", "M27"],
        allowed_queries=["investigation", "leaked_credentials", "exposed_identities", "source_code_leaks", "dark_web"],
        allowed_memory_access=True,
    ),
    "BrandProtectionAgent": AgentCapability(
        "BrandProtectionAgent",
        allowed_modules=["M14", "M15"],
        allowed_queries=["investigation", "lookalike_domains", "homograph", "typosquatting", "phishing"],
        allowed_memory_access=True,
    ),
    "IncidentInvestigator": AgentCapability(
        "IncidentInvestigator",
        allowed_modules=["M20", "M21", "M22", "M23", "M30"],
        allowed_queries=["investigation", "timeline", "attack_chains", "graph_reasoning", "investigation"],
        allowed_memory_access=True,
    ),
    "ExecutiveAdvisor": AgentCapability(
        "ExecutiveAdvisor",
        allowed_modules=["M24", "M25", "M26", "M28"],
        allowed_queries=["investigation", "executive_summary", "risk_explanation", "business_impact", "roadmap"],
        allowed_memory_access=False,
    ),
}


def check_permission(agent_name: str, module: str, query: str) -> dict | None:
    """Return AGENT_PERMISSION_DENIED if access not allowed, else None."""
    cap = CAPABILITY_MATRIX.get(agent_name)
    if cap is None:
        return {"error": "AGENT_PERMISSION_DENIED", "reason": f"Unknown agent: {agent_name}"}
    if module not in cap.allowed_modules:
        return {"error": "AGENT_PERMISSION_DENIED",
                "reason": f"{agent_name} cannot access module {module}"}
    if query not in cap.allowed_queries:
        return {"error": "AGENT_PERMISSION_DENIED",
                "reason": f"{agent_name} cannot run query '{query}'"}
    return None
