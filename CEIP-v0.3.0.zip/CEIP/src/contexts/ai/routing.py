"""Routing engine — deterministic agent routing strategies."""

from __future__ import annotations

from typing import Any

ROUTING_STRATEGIES = ["single", "parallel", "sequential", "dependency_chain", "consensus"]


class RoutingEngine:
    """Deterministic routing. Maps intent to agents + strategy."""

    INTENT_ROUTING: dict[str, dict[str, Any]] = {
        "Asset_Discovery": {"agents": ["DiscoveryAgent"], "strategy": "single"},
        "Threat_Investigation": {
            "agents": ["ThreatAnalyst", "DiscoveryAgent"], "strategy": "parallel",
        },
        "Vulnerability_Prioritization": {
            "agents": ["VulnerabilityAnalyst"], "strategy": "single",
        },
        "Executive_Summary": {
            "agents": ["ExecutiveAdvisor"], "strategy": "single",
        },
        "Dark_Web": {
            "agents": ["DarkWebAnalyst"], "strategy": "single",
        },
        "Identity_Exposure": {
            "agents": ["DarkWebAnalyst", "DiscoveryAgent"], "strategy": "sequential",
        },
        "Brand_Abuse": {
            "agents": ["BrandProtectionAgent"], "strategy": "single",
        },
        "Attack_Path": {
            "agents": ["IncidentInvestigator", "VulnerabilityAnalyst"],
            "strategy": "sequential",
        },
        "Incident_Investigation": {
            "agents": ["IncidentInvestigator", "ThreatAnalyst", "DiscoveryAgent"],
            "strategy": "dependency_chain",
        },
        "Compliance": {
            "agents": ["ExecutiveAdvisor", "VulnerabilityAnalyst"],
            "strategy": "sequential",
        },
        "General_Question": {"agents": ["ExecutiveAdvisor"], "strategy": "single"},
        "Unknown": {"agents": [], "strategy": "single"},
    }

    @classmethod
    def route(cls, intent: str) -> dict[str, Any]:
        """Return agent list and routing strategy for an intent."""
        config = cls.INTENT_ROUTING.get(intent, {"agents": [], "strategy": "single"})
        if not config.get("agents"):
            return {"agents": ["ExecutiveAdvisor"], "strategy": "single",
                    "fallback": True, "reason": f"No agents for intent '{intent}'"}
        return config
