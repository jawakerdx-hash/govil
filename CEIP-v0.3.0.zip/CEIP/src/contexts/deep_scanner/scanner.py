# ruff: noqa: E501  — report strings are table-format
"""Deep Scanner — AI-orchestrated 6-phase penetration testing framework.

Phases:
  1. RECON      — multi-source subdomains, port scan, HTTP probe, tech stack
  2. SURFACE    — API endpoints, login pages, debug endpoints, admin panels
  3. AUTH       — JWT analysis, OAuth detection, credential surfaces (DETECTION only)
  4. UPLOAD     — upload endpoint discovery, WAF/CDN bypass detection
  5. INFRA      — cloud metadata, internal services, SSRF vectors
  6. PERSISTENCE — exploitation (requires --exploit)

Each phase builds on previous results. AI orchestrates transitions.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

import httpx


class ScanPhase(StrEnum):
    RECON = "recon"
    SURFACE = "surface"
    AUTH = "auth"
    UPLOAD = "upload"
    INFRA = "infra"
    PERSISTENCE = "persistence"


@dataclass
class DeepScanResult:
    phase: ScanPhase
    findings: list[dict[str, Any]] = field(default_factory=list)
    hosts_scanned: int = 0
    endpoints_found: int = 0
    vulnerabilities: int = 0
    critical: int = 0
    duration_s: float = 0.0
    summary: str = ""


# ---------------------------------------------------------------------------
# Sensitive paths for surface mapping (Phase 2)
# ---------------------------------------------------------------------------

DEBUG_PATHS = [
    "/.env", "/.git/config", "/.git/HEAD", "/.svn/entries", "/.DS_Store",
    "/_debugbar", "/_debugbar/open", "/telescope", "/telescope/requests",
    "/horizon", "/horizon/dashboard", "/phpinfo.php", "/info.php",
    "/server-status", "/server-info", "/actuator", "/actuator/health",
    "/.well-known/security.txt", "/robots.txt", "/sitemap.xml",
    "/wp-admin", "/wp-login.php", "/wp-json", "/wp-content/debug.log",
    "/administrator", "/user/login", "/api/", "/api/v1/",
    "/graphql", "/graphiql", "/swagger", "/swagger-ui.html",
    "/openapi.json", "/api-docs", "/api/docs", "/_profiler",
    "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
    "/console", "/admin", "/admin/login", "/login", "/register",
    "/signin", "/signup", "/reset-password", "/.idea/workspace.xml",
    "/.vscode/sftp.json", "/package.json", "/yarn.lock", "/composer.json",
    "/docker-compose.yml", "/Dockerfile", "/.dockerignore",
    "/backup", "/backups", "/dump.sql", "/db.sql", "/export.sql",
    "/test", "/tests", "/testing", "/staging", "/dev",
    "/api/auth/login", "/api/auth/register", "/oauth/authorize",
    "/.aws/credentials", "/.npmrc", "/.pypirc",
]

LOGIN_PATHS = [
    "/login", "/signin", "/auth/login", "/user/login", "/admin/login",
    "/wp-login.php", "/administrator", "/account/login", "/auth",
    "/sign_in", "/log_in", "/oauth/login", "/sso/login",
]

API_PATHS = [
    "/api", "/api/v1", "/api/v2", "/graphql", "/swagger", "/openapi.json",
    "/api-docs", "/api/docs", "/swagger-ui.html", "/swagger/index.html",
    "/.well-known/openid-configuration", "/oauth/authorize",
    "/api/auth", "/api/users", "/api/admin",
]

ADMIN_PATHS = [
    "/admin", "/administrator", "/wp-admin", "/console", "/dashboard",
    "/manage", "/panel", "/control", "/cpanel", "/phpmyadmin",
    "/adminer", "/_dash", "/admin/login",
]


# ---------------------------------------------------------------------------
# Deep Scanner
# ---------------------------------------------------------------------------


class DeepScanner:
    """AI-orchestrated multi-phase security scanner.

    Usage::

        scanner = DeepScanner(settings, ai_engine, exploit=False)
        results = await scanner.run(domain)
    """

    def __init__(
        self,
        settings: Any,  # Settings
        ai_engine: Any = None,  # AIIntelligenceEngine
        *,
        exploit: bool = False,
        quiet: bool = False,
    ) -> None:
        self._settings = settings
        self._ai = ai_engine
        self._exploit = exploit
        self._quiet = quiet
        self._live_findings = 0  # Updated during scan for progress display
        self._http = httpx.AsyncClient(
            timeout=httpx.Timeout(10),
            follow_redirects=True,
            max_redirects=3,
        )
        self._c99_results: dict[str, Any] = {}
        self.results: list[DeepScanResult] = []

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    async def run(self, domain: str, initial_hosts: list[str] | None = None) -> dict[str, Any]:
        """Execute all enabled phases and return combined results."""
        t_start = time.perf_counter()
        hosts = initial_hosts or [domain]

        all_findings: list[dict[str, Any]] = []
        phase_summaries: list[str] = []

        # Phase 1: RECON (always)
        if not self._quiet:
            self._print_phase(1, "RECON — multi-source subdomains, C99, port scan, tech detection")
        r1 = await self._phase_recon(domain, hosts)
        self.results.append(r1)
        all_findings.extend(r1.findings)
        phase_summaries.append(f"RECON: {r1.summary}")

        # Phase 2: SURFACE (always)
        if not self._quiet:
            self._print_phase(2, "SURFACE — API endpoints, debug paths, admin panels, login pages")
        r2 = await self._phase_surface(domain, hosts)
        self.results.append(r2)
        all_findings.extend(r2.findings)
        phase_summaries.append(f"SURFACE: {r2.summary}")

        # Phase 3: AUTH (always — detection only)
        if not self._quiet:
            self._print_phase(3, "AUTH — JWT analysis, OAuth endpoints, credential surfaces")
        r3 = await self._phase_auth(domain, hosts)
        self.results.append(r3)
        all_findings.extend(r3.findings)
        phase_summaries.append(f"AUTH: {r3.summary}")

        # Phase 4: UPLOAD (always — detection only)
        if not self._quiet:
            self._print_phase(4, "UPLOAD — file upload endpoints, WAF/CDN detection")
        r4 = await self._phase_upload(domain, hosts)
        self.results.append(r4)
        all_findings.extend(r4.findings)
        phase_summaries.append(f"UPLOAD: {r4.summary}")

        # Phase 5: INFRA (always — detection only)
        if not self._quiet:
            self._print_phase(5, "INFRA — cloud metadata, internal services, SSRF vectors")
        r5 = await self._phase_infra(domain, hosts)
        self.results.append(r5)
        all_findings.extend(r5.findings)
        phase_summaries.append(f"INFRA: {r5.summary}")

        # Phase 6: PERSISTENCE (requires --exploit)
        if self._exploit:
            if not self._quiet:
                self._print_phase(6, "PERSISTENCE — exploitation (AUTHORIZED)")
            r6 = await self._phase_persistence(domain, hosts)
            self.results.append(r6)
            all_findings.extend(r6.findings)
            phase_summaries.append(f"PERSISTENCE: {r6.summary}")
        else:
            phase_summaries.append("PERSISTENCE: skipped (requires --exploit)")

        await self._http.aclose()

        total_findings = len(all_findings)
        critical_count = sum(1 for f in all_findings if f.get("severity") == "critical")

        return {
            "phases_executed": len(self.results),
            "total_findings": total_findings,
            "critical_findings": critical_count,
            "phase_summaries": phase_summaries,
            "findings": all_findings,
            "phases": [self._result_to_dict(r) for r in self.results],
            "c99_data": self._c99_results,
            "duration_s": round(time.perf_counter() - t_start, 1),
        }

    # ==================================================================
    # PHASE 1: RECON
    # ==================================================================

    async def _phase_recon(self, domain: str, hosts: list[str]) -> DeepScanResult:
        t0 = time.perf_counter()
        findings: list[dict[str, Any]] = []

        # C99 subdomain finder
        from src.contexts.discovery.c99_client import C99Client
        c99 = C99Client(self._settings.c99_api_key)
        if c99.enabled:
            try:
                c99_names = await c99.subdomain_finder(domain)
                self._c99_results["subdomains"] = c99_names
                if c99_names:
                    findings.append({
                        "phase": "recon", "severity": "info",
                        "title": f"C99 subdomain finder: {len(c99_names)} found",
                        "source": "c99.nl",
                        "subdomains": c99_names,
                    })
            except Exception:
                pass

            # C99 WHOIS
            try:
                whois_data = await c99.whois(domain)
                if whois_data:
                    self._c99_results["whois"] = whois_data
                    registrar = whois_data.get("registrar", "unknown")
                    creation = whois_data.get("creation_date", "unknown")
                    findings.append({
                        "phase": "recon", "severity": "info",
                        "title": f"WHOIS: registrar={registrar}, created={creation}",
                        "source": "c99.nl",
                    })
            except Exception:
                pass

            # C99 WAF/firewall detection
            try:
                waf_data = await c99.firewall_detector(domain)
                if waf_data:
                    self._c99_results["firewall"] = waf_data
                    waf_name = waf_data.get("firewall", waf_data.get("waf", "detected"))
                    findings.append({
                        "phase": "recon", "severity": "info",
                        "title": f"WAF/Firewall detected: {waf_name}",
                        "source": "c99.nl",
                    })
            except Exception:
                pass

            await c99.close()

        # Title extraction from main hosts
        for host in hosts[:5]:
            for scheme in ("https://", "http://"):
                try:
                    resp = await self._http.get(f"{scheme}{host}")
                    text = resp.text[:2000]
                    # Extract <title>
                    import re
                    title_m = re.search(r'<title>(.*?)</title>', text, re.IGNORECASE)
                    if title_m:
                        title = title_m.group(1).strip()[:120]
                        findings.append({
                            "phase": "recon", "severity": "info",
                            "host": host, "scheme": scheme,
                            "title": f"Page title: {title}",
                            "status_code": resp.status_code,
                            "server": resp.headers.get("server", ""),
                        })
                    # Technology detection from headers
                    tech_indicators = []
                    powered = resp.headers.get("x-powered-by", "")
                    if powered:
                        tech_indicators.append(powered)
                    generator = ""
                    gen_m = re.search(r'<meta name="generator" content="([^"]+)"', text, re.IGNORECASE)
                    if gen_m:
                        generator = gen_m.group(1)
                        tech_indicators.append(f"generator={generator}")
                    if tech_indicators:
                        findings.append({
                            "phase": "recon", "severity": "info",
                            "host": host,
                            "title": f"Technology: {', '.join(tech_indicators)}",
                        })
                    break  # One successful scheme is enough
                except Exception:
                    continue

        duration = round(time.perf_counter() - t0, 1)
        return DeepScanResult(
            phase=ScanPhase.RECON,
            findings=findings,
            hosts_scanned=len(hosts),
            duration_s=duration,
            summary=f"{len(findings)} recon findings in {duration}s",
        )

    # ==================================================================
    # PHASE 2: SURFACE MAPPING
    # ==================================================================

    async def _phase_surface(self, domain: str, hosts: list[str]) -> DeepScanResult:
        t0 = time.perf_counter()
        findings: list[dict[str, Any]] = []

        async def _check_path(host: str, path: str, category: str) -> None:
            for scheme in ("https://", "http://"):
                try:
                    resp = await self._http.head(f"{scheme}{host}{path}")
                    if resp.status_code < 500:
                        findings.append({
                            "phase": "surface", "severity": "medium" if category == "debug" else "low",
                            "host": host, "path": path, "category": category,
                            "title": f"[{category}] {host}{path} → HTTP {resp.status_code}",
                            "status_code": resp.status_code,
                            "content_length": resp.headers.get("content-length", "?"),
                        })
                except Exception:
                    pass

        # Scan all paths across all hosts (concurrent)
        tasks = []
        for host in hosts[:8]:  # Limit hosts for speed
            # Debug paths (high priority)
            for path in DEBUG_PATHS[:20]:
                tasks.append(_check_path(host, path, "debug"))
            # Login paths
            for path in LOGIN_PATHS[:8]:
                tasks.append(_check_path(host, path, "login"))
            # API paths
            for path in API_PATHS:
                tasks.append(_check_path(host, path, "api"))
            # Admin paths
            for path in ADMIN_PATHS[:8]:
                tasks.append(_check_path(host, path, "admin"))

        # Run in batches to avoid overwhelming the server
        for i in range(0, len(tasks), 20):
            batch = tasks[i:i + 20]
            await asyncio.gather(*batch, return_exceptions=True)

        # Count by category
        debug_found = sum(1 for f in findings if f.get("category") == "debug")
        login_found = sum(1 for f in findings if f.get("category") == "login")
        api_found = sum(1 for f in findings if f.get("category") == "api")
        admin_found = sum(1 for f in findings if f.get("category") == "admin")

        duration = round(time.perf_counter() - t0, 1)
        return DeepScanResult(
            phase=ScanPhase.SURFACE,
            findings=findings,
            hosts_scanned=len(hosts[:8]),
            endpoints_found=len(findings),
            duration_s=duration,
            summary=f"Debug:{debug_found} Login:{login_found} API:{api_found} Admin:{admin_found} in {duration}s",
        )

    # ==================================================================
    # PHASE 3: AUTH ATTACK SURFACE (detection only)
    # ==================================================================

    async def _phase_auth(self, domain: str, hosts: list[str]) -> DeepScanResult:
        t0 = time.perf_counter()
        findings: list[dict[str, Any]] = []

        for host in hosts[:5]:
            for scheme in ("https://", "http://"):
                try:
                    resp = await self._http.get(f"{scheme}{host}", headers={
                        "User-Agent": "CEIP-DeepScan/0.3",
                        "Accept": "text/html,application/json,*/*",
                    })
                    text = resp.text[:5000]
                    headers = resp.headers

                    # JWT token detection in responses
                    import re
                    set_cookie = headers.get("set-cookie", "")
                    if set_cookie:
                        cookies = set_cookie if isinstance(set_cookie, str) else ", ".join(set_cookie)
                        if "jwt" in cookies.lower() or "token=" in cookies.lower():
                            findings.append({
                                "phase": "auth", "severity": "info",
                                "host": host,
                                "title": f"JWT/Token cookie detected on {host}",
                                "cookie": cookies[:200],
                            })

                    # JWT in response body
                    jwt_pattern = r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'
                    jwts = re.findall(jwt_pattern, text)
                    if jwts:
                        findings.append({
                            "phase": "auth", "severity": "low",
                            "host": host,
                            "title": f"{len(jwts)} JWT token(s) found in response body on {host}",
                        })

                    # OAuth/SSO endpoints
                    oauth_indicators = [
                        "oauth", "openid", "saml", "sso", "single-sign-on",
                        "signin-oidc", "connect/authorize", "auth/realms",
                    ]
                    for indicator in oauth_indicators:
                        if indicator in text.lower():
                            findings.append({
                                "phase": "auth", "severity": "info",
                                "host": host,
                                "title": f"OAuth/SSO indicator found: '{indicator}' on {host}",
                            })
                            break

                    # Registration pages
                    reg_indicators = ["register", "signup", "sign-up", "create-account", "join"]
                    for indicator in reg_indicators:
                        if indicator in text.lower():
                            findings.append({
                                "phase": "auth", "severity": "low",
                                "host": host,
                                "title": f"Registration page detected: '{indicator}' on {host}",
                            })
                            break

                    # Default credential indicators
                    if "default" in text.lower() and any(
                        w in text.lower() for w in ["password", "credential", "login"]
                    ):
                        findings.append({
                            "phase": "auth", "severity": "medium",
                            "host": host,
                            "title": f"Default credential reference on {host} — investigate",
                        })

                    break
                except Exception:
                    continue

        duration = round(time.perf_counter() - t0, 1)
        return DeepScanResult(
            phase=ScanPhase.AUTH,
            findings=findings,
            hosts_scanned=min(len(hosts), 5),
            duration_s=duration,
            summary=f"{len(findings)} auth surface findings in {duration}s",
        )

    # ==================================================================
    # PHASE 4: FILE UPLOAD DETECTION
    # ==================================================================

    async def _phase_upload(self, domain: str, hosts: list[str]) -> DeepScanResult:
        t0 = time.perf_counter()
        findings: list[dict[str, Any]] = []

        upload_indicators = [
            "upload", "file", "attachment", "import", "media", "image",
            "photo", "avatar", "document", "csv", "excel",
        ]

        for host in hosts[:5]:
            for scheme in ("https://", "http://"):
                try:
                    resp = await self._http.get(f"{scheme}{host}")
                    text = resp.text[:5000].lower()

                    # Upload form detection
                    upload_forms = []
                    for indicator in upload_indicators:
                        if 'type="file"' in text and indicator in text:
                            upload_forms.append(indicator)
                    if upload_forms:
                        findings.append({
                            "phase": "upload", "severity": "medium",
                            "host": host,
                            "title": f"Upload form(s) detected: {', '.join(upload_forms[:5])} on {host}",
                        })

                    # WAF/CDN detection from headers
                    waf_headers = {
                        "x-cdn": resp.headers.get("x-cdn", ""),
                        "cf-ray": resp.headers.get("cf-ray", ""),
                        "x-amz-cf-id": resp.headers.get("x-amz-cf-id", ""),
                        "x-sucuri-id": resp.headers.get("x-sucuri-id", ""),
                        "x-waf": resp.headers.get("x-waf", ""),
                        "server": resp.headers.get("server", ""),
                    }
                    detected_wafs = []
                    if waf_headers["cf-ray"]:
                        detected_wafs.append("Cloudflare")
                    if waf_headers["x-amz-cf-id"]:
                        detected_wafs.append("AWS CloudFront")
                    if waf_headers["x-sucuri-id"]:
                        detected_wafs.append("Sucuri")
                    if "cloudflare" in waf_headers["server"].lower():
                        detected_wafs.append("Cloudflare (Server)")
                    if detected_wafs:
                        findings.append({
                            "phase": "upload", "severity": "info",
                            "host": host,
                            "title": f"WAF/CDN: {', '.join(detected_wafs)} on {host}",
                        })

                    break
                except Exception:
                    continue

        duration = round(time.perf_counter() - t0, 1)
        return DeepScanResult(
            phase=ScanPhase.UPLOAD,
            findings=findings,
            hosts_scanned=min(len(hosts), 5),
            duration_s=duration,
            summary=f"{len(findings)} upload/WAF findings in {duration}s",
        )

    # ==================================================================
    # PHASE 5: INFRA ATTACK SURFACE
    # ==================================================================

    async def _phase_infra(self, domain: str, hosts: list[str]) -> DeepScanResult:
        t0 = time.perf_counter()
        findings: list[dict[str, Any]] = []

        # Cloud metadata endpoints
        cloud_targets = [
            "http://169.254.169.254/latest/meta-data/",
            "http://169.254.169.254/metadata/instance?api-version=2021-02-01",
            "http://metadata.google.internal/computeMetadata/v1/",
            "http://100.100.100.200/latest/meta-data/",
        ]

        for target in cloud_targets[:2]:
            try:
                resp = await self._http.get(target, headers={"Host": domain}, timeout=3)
                if resp.status_code < 500:
                    findings.append({
                        "phase": "infra", "severity": "critical",
                        "host": domain,
                        "title": f"Cloud metadata endpoint accessible: {target} → HTTP {resp.status_code}",
                        "note": "SSRF vector — attacker can access instance metadata",
                    })
            except Exception:
                pass

        # Check for SSRF-indicating parameters in responses
        for host in hosts[:3]:
            for scheme in ("https://", "http://"):
                try:
                    resp = await self._http.get(f"{scheme}{host}")
                    text = resp.text[:5000].lower()
                    ssrf_indicators = ["url=", "path=", "file=", "fetch=", "proxy=", "redirect="]
                    found = [i for i in ssrf_indicators if i in text]
                    if found:
                        findings.append({
                            "phase": "infra", "severity": "medium",
                            "host": host,
                            "title": f"Potential SSRF parameters: {', '.join(found[:3])} on {host}",
                        })
                    break
                except Exception:
                    continue

        # Database ports check on hosts
        db_ports = [(3306, "MySQL"), (5432, "PostgreSQL"), (27017, "MongoDB"), (6379, "Redis")]
        for host in hosts[:3]:
            for port, name in db_ports:
                try:
                    _, writer = await asyncio.wait_for(
                        asyncio.open_connection(host, port), timeout=2,
                    )
                    writer.close()
                    findings.append({
                        "phase": "infra", "severity": "critical",
                        "host": host, "port": port,
                        "title": f"Database port OPEN: {name} ({port}) on {host}",
                    })
                except Exception:
                    continue

        duration = round(time.perf_counter() - t0, 1)
        return DeepScanResult(
            phase=ScanPhase.INFRA,
            findings=findings,
            hosts_scanned=len(hosts[:3]),
            duration_s=duration,
            summary=f"{len(findings)} infra findings in {duration}s",
        )

    # ==================================================================
    # PHASE 6: PERSISTENCE (requires --exploit)
    # ==================================================================

    async def _phase_persistence(self, domain: str, hosts: list[str]) -> DeepScanResult:
        """Exploitation phase — ONLY runs with explicit --exploit authorization."""
        t0 = time.perf_counter()
        findings: list[dict[str, Any]] = []

        if not self._exploit:
            return DeepScanResult(
                phase=ScanPhase.PERSISTENCE,
                duration_s=0,
                summary="Skipped — requires --exploit flag",
            )

        # Web shell detection — check if common shells already exist
        shell_paths = [
            "/shell.php", "/cmd.php", "/c99.php", "/r57.php", "/b374k.php",
            "/upload/shell.php", "/assets/shell.php", "/images/shell.php",
            "/wp-content/shell.php", "/admin/shell.php",
            "/api/cmd", "/api/shell", "/api/exec", "/api/run",
        ]

        for host in hosts[:3]:
            for path in shell_paths[:8]:
                try:
                    resp = await self._http.get(f"https://{host}{path}")
                    if resp.status_code == 200 and len(resp.text) > 10:
                        findings.append({
                            "phase": "persistence", "severity": "critical",
                            "host": host, "path": path,
                            "title": f"CRITICAL: Potential existing webshell at {host}{path}",
                        })
                except Exception:
                    pass

        # Check for writable upload directories
        writable_checks = [
            "/uploads/", "/assets/", "/images/", "/files/", "/media/", "/tmp/",
        ]
        for host in hosts[:3]:
            for path in writable_checks:
                try:
                    resp = await self._http.get(f"https://{host}{path}")
                    if resp.status_code in (200, 403) and "Index of" in resp.text[:500]:
                        findings.append({
                            "phase": "persistence", "severity": "high",
                            "host": host, "path": path,
                            "title": f"Directory listing enabled: {host}{path}",
                        })
                except Exception:
                    pass

        duration = round(time.perf_counter() - t0, 1)
        return DeepScanResult(
            phase=ScanPhase.PERSISTENCE,
            findings=findings,
            hosts_scanned=len(hosts[:3]),
            duration_s=duration,
            summary=f"{len(findings)} persistence findings in {duration}s",
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _result_to_dict(r: DeepScanResult) -> dict[str, Any]:
        return {
            "phase": r.phase.value,
            "findings_count": len(r.findings),
            "hosts_scanned": r.hosts_scanned,
            "endpoints_found": r.endpoints_found,
            "vulnerabilities": r.vulnerabilities,
            "critical": r.critical,
            "duration_s": r.duration_s,
            "summary": r.summary,
            "findings": r.findings,
        }

    @staticmethod
    def _print_phase(num: int, name: str) -> None:
        c, b, r, d = "\033[96m", "\033[1m", "\033[0m", "\033[2m"
        print(f"\n  {b}{c}[DEEP PHASE {num}]{r} {d}{name}{r}")
