"""Deep Scanner — AI-orchestrated multi-phase penetration testing framework.

Phases are ordered and AI-driven: each phase's findings inform the next.
Exploitation (Phase 6) requires explicit --exploit authorization.
"""

from .scanner import DeepScanner, ScanPhase

__all__ = ["DeepScanner", "ScanPhase"]
