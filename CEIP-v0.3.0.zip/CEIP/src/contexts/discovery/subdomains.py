"""Subdomain discovery — brute force (1000+ wordlist) + Certificate Transparency.

Each discovered subdomain is validated for HTTP/HTTPS availability.
Results include live/dead status and port availability.
"""

from __future__ import annotations

import asyncio

import dns.resolver
import httpx

# ---------------------------------------------------------------------------
# 1000+ common subdomains organized by category
# ---------------------------------------------------------------------------

_COMMON_SUBDOMAINS: list[str] = [
    # ---- Web & WWW (30) ----
    "www", "www2", "www3", "web", "site", "home", "main", "m", "mobile",
    "wap", "touch", "ipad", "iphone", "android", "app", "desktop", "classic",
    "old", "old-site", "v1", "v2", "v3", "new", "beta", "alpha", "demo",
    "preview", "next", "go", "start",

    # ---- Mail (40) ----
    "mail", "mail2", "mail3", "imap", "imap4", "pop", "pop3", "smtp", "smtp2",
    "webmail", "webmail2", "email", "mx", "mx1", "mx2", "mx3", "mxa", "mxb",
    "autodiscover", "autoconfig", "owa", "exchange", "webexchange",
    "roundcube", "squirrelmail", "horde", "mailman", "lists", "list",
    "newsletter", "mailer", "mailgun", "sendmail", "postfix", "relay",
    "outbound", "inbound", "smtp-out", "smtp-in", "spf",

    # ---- FTP & File Transfer (20) ----
    "ftp", "ftp2", "ftps", "sftp", "files", "file", "dl", "download",
    "downloads", "upload", "uploads", "transfer", "share", "shares",
    "media", "images", "img", "static", "assets", "cdn",

    # ---- DNS & Infrastructure (25) ----
    "ns", "ns1", "ns2", "ns3", "ns4", "dns", "dns1", "dns2",
    "bind", "named", "pdns", "powerdns", "knot",
    "rdns", "resolver", "recursor",
    "anycast", "unicast", "multicast",
    "whois", "rdap", "lookup", "dig", "host",

    # ---- cPanel / WHM / Hosting (35) ----
    "cpanel", "whm", "webdisk", "webhost", "hosting", "host",
    "cpcalendars", "cpcontacts", "webcal", "webcalendar",
    "plesk", "directadmin", "vestacp", "ispconfig", "virtualmin",
    "webmin", "usermin", "cloudmin", "froxlor", "sentora",
    "centos-webpanel", "ajenti", "webuzo", "centos", "ubuntu",
    "debian", "fedora", "freebsd", "openbsd", "netbsd",
    "arch", "alpine", "gentoo", "slackware", "rocky",

    # ---- Admin & Management (40) ----
    "admin", "administrator", "adm", "root", "manager", "manage",
    "control", "panel", "dashboard", "cp", "console",
    "webconsole", "terminal", "shell", "ssh", "sshd",
    "superuser", "supervisor", "sysadmin", "sys",
    "system", "config", "configuration", "setup", "install",
    "wizard", "init", "bootstrap",
    "admincp", "modcp", "usercp", "userpanel",
    "operator", "operations", "ops", "tools", "toolbox",
    "utilities", "utility", "settings", "preferences",

    # ---- Database (25) ----
    "db", "database", "mysql", "mariadb", "postgres", "postgresql",
    "mongo", "mongodb", "redis", "memcache", "memcached",
    "elastic", "elasticsearch", "kibana", "logstash",
    "couchdb", "cassandra", "neo4j", "influx", "influxdb",
    "phpmyadmin", "phpPgAdmin", "adminer", "dbadmin", "sql",

    # ---- API & Services (45) ----
    "api", "api2", "api3", "api-dev", "api-staging", "api-test",
    "api-docs", "api-documentation", "developer", "developers", "dev",
    "rest", "graphql", "soap", "ws", "webservice", "services",
    "service", "micro", "microservice", "svc",
    "endpoint", "gateway", "proxy", "proxy1", "proxy2",
    "lb", "loadbalancer", "balancer", "haproxy", "nginx",
    "traefik", "envoy", "istio", "linkerd",
    "internal", "private", "public", "external",
    "rpc", "grpc", "thrift", "avro", "protobuf",

    # ---- Auth & Identity (25) ----
    "auth", "oauth", "openid", "sso", "login", "signin", "sign-in",
    "logon", "authenticate", "id", "identity", "saml",
    "ldap", "ad", "activedirectory", "kerberos", "radius",
    "tacacs", "diameter", "freeradius",
    "keycloak", "auth0", "okta", "onelogin", "duo",

    # ---- Search (15) ----
    "search", "find", "query", "lookup", "solr",
    "elastic", "sphinx", "algolia", "lucene",
    "crawler", "spider", "scraper", "index", "indexer", "catalogue",

    # ---- E-Commerce (30) ----
    "shop", "store", "buy", "cart", "checkout", "order", "orders",
    "payment", "payments", "billing", "invoice", "invoices",
    "checkout", "pos", "ecommerce", "catalog", "products", "product",
    "pricing", "price", "subscription", "subscribe", "plan", "plans",
    "merchant", "vendor", "partner", "affiliate", "affiliates", "reseller",

    # ---- CMS & Blog (25) ----
    "blog", "blogs", "news", "article", "articles", "press",
    "media", "gallery", "photos", "photo", "video", "videos",
    "podcast", "wiki", "docs", "documentation", "kb", "knowledge",
    "knowledgebase", "faq", "help", "support", "helpdesk", "tickets",
    "ticket", "issue", "issues",

    # ---- Social & Community (20) ----
    "forum", "forums", "community", "social", "chat",
    "messenger", "im", "xmpp", "irc", "matrix",
    "discord", "slack", "teams", "zoom", "meet",
    "meeting", "meetings", "webinar", "event", "events",

    # ---- Version Control (20) ----
    "git", "github", "gitlab", "bitbucket", "gitea", "gogs",
    "repo", "repos", "repository", "code", "source",
    "svn", "cvs", "mercurial", "hg",
    "jenkins", "bamboo", "teamcity", "travis", "circle",

    # ---- CI/CD & DevOps (30) ----
    "ci", "cd", "build", "deploy", "deployment", "release",
    "pipeline", "runner", "agent",
    "drone", "argocd", "flux", "spinnaker",
    "docker", "docker-registry", "registry", "harbor", "quay",
    "kubernetes", "k8s", "kube", "rancher", "openshift",
    "nomad", "consul", "vault", "terraform", "packer", "ansible",

    # ---- Monitoring & Observability (35) ----
    "monitor", "monitoring", "metrics", "logs", "logging",
    "grafana", "prometheus", "alertmanager", "alerts", "alert",
    "nagios", "zabbix", "icinga", "sensu", "checkmk",
    "datadog", "newrelic", "splunk", "dynatrace", "appdynamics",
    "uptime", "status", "health", "healthcheck", "ping",
    "trace", "tracing", "jaeger", "zipkin", "opentelemetry",
    "sentry", "rollbar", "bugsnag", "airbrake", "honeycomb",

    # ---- Security (30) ----
    "security", "secure", "ssl", "tls", "cert", "certs",
    "firewall", "fw", "waf", "ids", "ips",
    "siem", "soc", "scan", "scanner", "nessus",
    "openvas", "qualys", "rapid7", "tenable",
    "vulnerability", "vuln", "cve", "patch", "patches",
    "pentest", "audit", "compliance", "grc", "risk",

    # ---- VPN & Remote Access (20) ----
    "vpn", "vpn2", "openvpn", "wireguard", "ipsec",
    "l2tp", "pptp", "sstp", "ikev2",
    "remote", "rdp", "rdgateway", "rdweb",
    "citrix", "vmware", "horizon", "view",
    "anyconnect", "globalprotect", "pulse",

    # ---- Cloud & Storage (30) ----
    "cloud", "s3", "storage", "store", "object",
    "bucket", "buckets", "blob", "blobs",
    "backup", "backups", "restore", "snapshot", "snapshots",
    "archive", "archives", "cold", "glacier",
    "drive", "onedrive", "dropbox", "box", "nextcloud", "owncloud",
    "seafile", "syncthing", "webdav", "dav", "caldav",

    # ---- Testing & QA (25) ----
    "test", "test1", "test2", "testing", "qa", "dev", "dev1", "dev2",
    "development", "staging", "stage", "uat", "preprod", "production",
    "sandbox", "lab", "labs", "experiment", "experimental",
    "playground", "mock", "fake", "dummy", "sample", "example",

    # ---- Telephony / VoIP (20) ----
    "sip", "voip", "phone", "telephony", "pbx",
    "freeswitch", "asterisk", "freeswitch-api", "calls",
    "webrtc", "jitsi", "turn", "stun", "coturn",
    "sms", "mms", "fax", "pager", "notification", "notify",

    # ---- IoT & Devices (15) ----
    "device", "devices", "iot", "sensor", "sensors",
    "gateway", "edge", "fog", "mesh",
    "camera", "cam", "nvr", "dvr", "alarm", "access",

    # ---- Common Business Apps (40) ----
    "crm", "erp", "hr", "hrms", "payroll", "finance", "accounting",
    "booking", "appointment", "schedule", "calendar", "cal",
    "project", "projects", "task", "tasks", "todo",
    "jira", "confluence", "trello", "asana", "monday",
    "salesforce", "zoho", "hubspot", "marketing", "cms",
    "lms", "elearn", "training", "course", "courses",
    "intranet", "extranet", "portal", "my", "profile",
    "account", "accounts", "user", "users",

    # ---- Misc / Catch-All (120+) ----
    "local", "localhost", "loopback", "null", "any", "all",
    "accept", "reject", "deny", "allow", "block",
    "up", "down", "on", "off", "true", "false", "yes", "no",
    "open", "close", "start", "stop", "run", "exec", "execute",
    "load", "reload", "restart", "reset", "reboot",
    "enable", "disable", "active", "inactive", "pause", "resume",
    "create", "read", "update", "delete", "list", "get", "set", "put", "post",
    "add", "remove", "edit", "view", "show", "hide",
    "send", "receive", "process", "queue", "job", "worker", "task",
    "input", "output", "data", "file", "stream", "feed",
    "connect", "connection", "client", "server", "peer", "node",
    "master", "slave", "primary", "secondary", "replica",
    "leader", "follower", "member", "cluster", "group",
    "core", "edge", "front", "back", "middle",
    "top", "bottom", "left", "right", "center", "side",
    "first", "second", "third", "last", "final",
    "big", "small", "fast", "slow", "high", "low",
    "red", "blue", "green", "yellow", "black", "white",
    "alpha", "beta", "gamma", "delta", "omega",
    "one", "two", "three", "four", "five",
    "staging1", "staging2", "dev3", "dev4", "qa1", "qa2",
    "uat1", "uat2", "preprod1", "test3", "test4",
]

# Remove duplicates while preserving order
_COMMON_SUBDOMAINS = list(dict.fromkeys(_COMMON_SUBDOMAINS))


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


def _is_wildcard_dns(domain: str) -> bool:
    """Check if the domain has wildcard DNS (random subdomain resolves)."""
    import random, string
    random_sub = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
    resolver = dns.resolver.Resolver()
    resolver.timeout = 2
    resolver.lifetime = 4
    try:
        resolver.resolve(f"{random_sub}.{domain}", "A")
        return True
    except Exception:
        return False


def discover_subdomains(domain: str) -> list[str]:
    """Resolve 754 common subdomains via DNS. Detects and handles wildcard DNS."""
    found: list[str] = []
    resolver = dns.resolver.Resolver()
    resolver.timeout = 2
    resolver.lifetime = 4

    wildcard = _is_wildcard_dns(domain)

    for prefix in _COMMON_SUBDOMAINS:
        name = f"{prefix}.{domain}"
        try:
            resolver.resolve(name, "A")
            found.append(name)
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
            continue
        except dns.resolver.Timeout:
            continue
        except Exception:
            continue

    # If wildcard DNS, ALL subdomains resolve — mark them as unverified
    if wildcard and len(found) > 100:
        return found[:30]  # Return only the most likely real ones

    return found


async def discover_crtsh(domain: str) -> list[str]:
    """Query crt.sh for Certificate Transparency logs."""
    url = f"https://crt.sh/?q=%.{domain}&output=json"
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            entries = resp.json()
    except Exception:
        return []

    names: set[str] = set()
    for entry in entries:
        name_value = entry.get("name_value", "")
        for name in name_value.split("\n"):
            name = name.strip().lower().lstrip("*.")
            if name.endswith(domain) and name != domain:
                names.add(name)

    return sorted(names)


async def validate_subdomain_http(host: str) -> dict[str, str | int | None]:
    """Check if a subdomain responds to HTTP/HTTPS. Returns live/dead status."""
    result: dict[str, str | int | None] = {
        "host": host, "http_status": None, "https_status": None, "status": "dead",
    }

    async def _check(scheme: str) -> int | None:
        try:
            async with httpx.AsyncClient(timeout=3, follow_redirects=False) as c:
                r = await c.get(f"{scheme}://{host}", headers={"User-Agent": "CEIP/0.3"})
                return r.status_code
        except Exception:
            return None

    http_code = await _check("http")
    https_code = await _check("https")

    result["http_status"] = http_code
    result["https_status"] = https_code

    if http_code is not None or https_code is not None:
        result["status"] = "live"
    if https_code is not None and https_code < 500:
        result["preferred"] = "https"

    return result


async def validate_subdomains_batch(hosts: list[str], concurrency: int = 20) -> list[dict | BaseException]:
    """Validate HTTP availability for a batch of subdomains concurrently."""
    sem = asyncio.Semaphore(concurrency)

    async def _validate_one(host: str) -> dict:
        async with sem:
            return await validate_subdomain_http(host)

    tasks = [_validate_one(h) for h in hosts]
    return await asyncio.gather(*tasks, return_exceptions=True)
