"""DNS resolution using dnspython — A, AAAA, NS, MX, TXT, SOA, CNAME."""

from __future__ import annotations

from typing import Any

import dns.resolver


def resolve_dns(domain: str) -> list[dict[str, str | int]]:
    """Resolve all standard record types for a domain.

    Returns a list of dicts with keys: record_type, name, value, ttl.
    """
    records: list[dict[str, str | int]] = []
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 10

    record_types = ["A", "AAAA", "NS", "MX", "TXT", "SOA", "CNAME"]

    for rtype in record_types:
        try:
            answers = resolver.resolve(domain, rtype)
            for answer in answers:
                value = _format_value(rtype, answer)
                records.append({
                    "record_type": rtype,
                    "name": domain,
                    "value": value,
                    "ttl": answers.ttl,
                })
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
            continue
        except dns.resolver.Timeout:
            continue
        except Exception:
            continue

    return records


def resolve_ptr(ip: str) -> str | None:
    """Reverse DNS lookup — resolve an IP to a hostname."""
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 3
        resolver.lifetime = 5
        addr = dns.reversename.from_address(ip)
        answers = resolver.resolve(addr, "PTR")
        return str(answers[0]).rstrip(".")
    except Exception:
        return None


def _format_value(rtype: str, answer: Any) -> str:
    """Extract the display value from a DNS answer based on type."""
    if rtype == "MX":
        return str(answer.exchange).rstrip(".")
    if rtype == "SOA":
        return f"{answer.mname} {answer.rname} ({answer.serial})"
    if rtype == "TXT":
        raw = str(answer)
        return raw.strip('"')
    if rtype == "CNAME":
        return str(answer.target).rstrip(".")
    return str(answer)
