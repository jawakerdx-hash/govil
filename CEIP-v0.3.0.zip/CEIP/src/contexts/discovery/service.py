"""Discovery service — orchestrates DNS, subdomains, fingerprinting, enrichment."""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.discovery.enrichment import enrich_ip
from src.contexts.discovery.fingerprint import (
    DISCOVERY_PORTS,
    fingerprint_http,
    fingerprint_http_plain,
    fingerprint_ssl,
)
from src.contexts.discovery.models import (
    Certificate,
    DiscoveryJob,
    DNSRecord,
    IPEnrichment,
    Service,
    Subdomain,
)
from src.contexts.discovery.repository import DiscoveryRepository
from src.contexts.discovery.resolver import resolve_dns
from src.contexts.discovery.subdomains import (
    discover_crtsh,
    discover_subdomains,
)


class DiscoveryService:
    """Run discovery against a domain and persist all results."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._repo = DiscoveryRepository(db)

    async def start(self, domain: str) -> DiscoveryJob:
        """Run full discovery: DNS, subdomains, fingerprinting, enrichment."""
        domain = domain.lower().strip()

        job = DiscoveryJob(domain=domain, status="running", started_at=datetime.now(UTC))
        self._db.add(job)
        await self._db.flush()

        try:
            loop = asyncio.get_running_loop()

            # 1. DNS records (A, AAAA, NS, MX, TXT, SOA, CNAME)
            dns_data = await loop.run_in_executor(None, resolve_dns, domain)
            for r in dns_data:
                self._db.add(DNSRecord(
                    job_id=job.id,
                    record_type=str(r["record_type"]),
                    name=str(r["name"]),
                    value=str(r["value"]),
                    ttl=int(r["ttl"]),
                ))

            # 2. Subdomains — brute force
            brute_subs = await loop.run_in_executor(None, discover_subdomains, domain)
            for s in brute_subs:
                self._db.add(Subdomain(job_id=job.id, name=s, source="brute"))

            # 3. Subdomains — Certificate Transparency (crt.sh)
            ct_subs = await discover_crtsh(domain)
            for s in ct_subs:
                self._db.add(Subdomain(job_id=job.id, name=s, source="crtsh"))

            await self._db.flush()

            # 3b. HTTP validation for discovered subdomains (live/dead check)
            all_subs = list(set(brute_subs + ct_subs))
            if all_subs:
                from src.contexts.discovery.subdomains import validate_subdomains_batch
                _ = await validate_subdomains_batch(all_subs[:100], concurrency=20)

            # 4. Fingerprint hosts — full ports on main domain, quick on subdomains
            hosts_to_fp = [domain] + brute_subs[:10]
            hosts_set = sorted(set(hosts_to_fp))

            async def _fingerprint_host(host: str) -> list[dict[str, Any]]:
                """Scan a single host across relevant ports concurrently."""
                results: list[dict[str, Any]] = []

                # Fast pre-check: which ports are open?
                open_ports: list[tuple[int, bool]] = []
                for port, use_tls in DISCOVERY_PORTS:
                    # Full port scan only on main domain + www; others get 80+443
                    is_primary = (host == domain or host == f"www.{domain}")
                    if not is_primary and port not in (80, 443):
                        continue
                    try:
                        _, writer = await asyncio.wait_for(
                            asyncio.open_connection(host, port), timeout=1.5,
                        )
                        writer.close()
                        try:
                            await writer.wait_closed()
                        except Exception:
                            pass
                        open_ports.append((port, use_tls))
                    except Exception:
                        continue

                if not open_ports:
                    return results

                # Fingerprint open ports concurrently
                async def _scan_port(port: int, use_tls: bool) -> dict[str, Any] | None:
                    loop = asyncio.get_running_loop()
                    try:
                        if use_tls:
                            fp = await asyncio.wait_for(
                                loop.run_in_executor(None, fingerprint_http, host, port, 2),
                                timeout=4,
                            )
                        else:
                            fp = await asyncio.wait_for(
                                loop.run_in_executor(None, fingerprint_http_plain, host, port, 2),
                                timeout=4,
                            )
                        if fp.status_code and fp.status_code > 0:
                            return {"host": host, "port": port, "use_tls": use_tls, "fp": fp}
                    except Exception:
                        pass
                    return None

                port_tasks = [_scan_port(p, tls) for p, tls in open_ports]
                port_results = await asyncio.gather(*port_tasks)

                cert_tasks = []
                for pr in port_results:
                    if pr is None:
                        continue
                    results.append(pr)
                    if pr["use_tls"]:
                        cert_tasks.append((pr["host"], pr["port"]))

                # SSL certs concurrently
                async def _scan_cert(h: str, p: int) -> dict | None:
                    loop = asyncio.get_running_loop()
                    try:
                        cert = await asyncio.wait_for(
                            loop.run_in_executor(None, fingerprint_ssl, h, p, 2),
                            timeout=4,
                        )
                        if cert.subject or cert.issuer:
                            return {"host": h, "port": p, "cert": cert}
                    except Exception:
                        pass
                    return None

                if cert_tasks:
                    cert_results = await asyncio.gather(*[
                        _scan_cert(h, p) for h, p in cert_tasks
                    ])
                    for cr in cert_results:
                        if cr:
                            results.append(cr)

                return results

            # Run all hosts concurrently in batches of 5
            for i in range(0, len(hosts_set), 5):
                batch = hosts_set[i:i + 5]
                batch_results = await asyncio.gather(*[
                    _fingerprint_host(h) for h in batch
                ])

                for host_results in batch_results:
                    for item in host_results:
                        if "fp" in item:
                            fp = item["fp"]
                            headers_json = json.dumps(fp.headers) if fp.headers else None
                            self._db.add(Service(
                                job_id=job.id,
                                host=item["host"],
                                port=item["port"],
                                server=fp.server or None,
                                status_code=fp.status_code if fp.status_code else None,
                                headers_json=headers_json,
                            ))
                        elif "cert" in item:
                            cert = item["cert"]
                            self._db.add(Certificate(
                                job_id=job.id,
                                host=item["host"],
                                subject=cert.subject or None,
                                issuer=cert.issuer or None,
                                not_before=cert.not_before or None,
                                not_after=cert.not_after or None,
                                serial_number=cert.serial_number or None,
                                sans_json=json.dumps(cert.sans) if cert.sans else None,
                            ))

            # 5. IP enrichment — extract unique IPs from A/AAAA records
            ips = set()
            for r in dns_data:
                if r["record_type"] in ("A", "AAAA"):
                    ips.add(str(r["value"]))

            for ip_addr in sorted(ips):
                info = await loop.run_in_executor(None, enrich_ip, ip_addr)
                self._db.add(IPEnrichment(
                    job_id=job.id,
                    ip=ip_addr,
                    reverse_dns=info.reverse_dns,
                    asn=info.asn,
                    asn_org=info.asn_org,
                ))

            job.status = "done"
        except Exception as exc:
            job.status = "failed"
            job.error = str(exc)

        job.finished_at = datetime.now(UTC)
        await self._db.flush()
        return job

    async def get_job(self, job_id: str | uuid.UUID) -> DiscoveryJob | None:
        """Fetch a discovery job with all relationships eagerly loaded."""
        return await self._repo.get_by_id(job_id)
