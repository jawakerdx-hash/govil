"""Entity linking — connect discovered assets to canonical entities."""

from __future__ import annotations

import hashlib
from typing import Any


class EntityLinkingEngine:
    """Links discovered assets to M18 canonical_entity_id and infrastructure clusters."""

    def link_asset(
        self, domain: str, asset_type: str, asset_value: str
    ) -> dict[str, Any]:
        canonical_id = hashlib.sha256(
            f"entity:{domain}:{asset_type}:{asset_value}".encode()
        ).hexdigest()[:16]
        cluster = hashlib.sha256(
            f"cluster:{domain}".encode()
        ).hexdigest()[:12]

        return {
            "canonical_entity_id": canonical_id,
            "organization_entity": domain,
            "infrastructure_cluster": cluster,
        }

    def link_batch(
        self, domain: str, assets: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        results = []
        for asset in assets:
            links = self.link_asset(
                domain=domain,
                asset_type=asset.get("asset_type", "subdomain"),
                asset_value=asset.get("value", ""),
            )
            asset.update(links)
            results.append(asset)
        return results
