"""C99.nl OSINT API client — subdomains, IP reputation, WHOIS, DNS, GeoIP, WAF.

API format: https://api.c99.nl/{endpoint}?key={key}&domain={domain}&json

Endpoints used:
  subdomainfinder — advanced subdomain discovery with CloudFlare resolution
  dnschecker      — DNS records for a domain
  whois           — WHOIS registration data
  ipreputation    — malicious IP check
  firewalldetector — WAF/CDN detection
  gethostname     — reverse DNS (IP to hostname)
  geoip           — IP/host geolocation
"""

from __future__ import annotations

from typing import Any

import httpx


class C99Client:
    """Async client for the C99.nl OSINT API."""

    BASE = "https://api.c99.nl"

    def __init__(self, api_key: str, timeout: int = 15) -> None:
        self._key = api_key
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(timeout))

    @property
    def enabled(self) -> bool:
        return bool(self._key)

    # ------------------------------------------------------------------
    # Subdomain discovery
    # ------------------------------------------------------------------

    async def subdomain_finder(self, domain: str) -> list[str]:
        """Advanced subdomain scan — returns clean subdomain names."""
        data = await self._get_json("subdomainfinder", domain)
        if isinstance(data, dict):
            # C99 wraps in 'subdomains' key with list of dicts
            subs = data.get("subdomains", [])
            if isinstance(subs, list):
                return [
                    s["subdomain"] if isinstance(s, dict) and "subdomain" in s else str(s)
                    for s in subs
                ]
        if isinstance(data, list):
            return [
                s["subdomain"] if isinstance(s, dict) and "subdomain" in s else str(s)
                for s in data
            ]
        return []

    # ------------------------------------------------------------------
    # DNS records
    # ------------------------------------------------------------------

    async def dns_checker(self, domain: str, record_type: str = "A") -> list[str]:
        """DNS lookup for a given record type."""
        data = await self._get_json("dnschecker", domain, extra_params={"recordtype": record_type})
        if isinstance(data, dict):
            records = data.get("records", [])
            return [r.get("value", "") for r in records if isinstance(r, dict)]
        return []

    # ------------------------------------------------------------------
    # WHOIS
    # ------------------------------------------------------------------

    async def whois(self, domain: str) -> dict[str, Any]:
        """WHOIS registration data for a domain."""
        return await self._get_json("whois", domain)

    # ------------------------------------------------------------------
    # IP reputation
    # ------------------------------------------------------------------

    async def ip_reputation(self, ip: str) -> dict[str, Any]:
        """Check if an IP is involved in malicious activity."""
        return await self._get_json("ipreputation", ip, param_name="ip")

    # ------------------------------------------------------------------
    # Firewall/WAF detector
    # ------------------------------------------------------------------

    async def firewall_detector(self, domain: str) -> dict[str, Any]:
        """Detect WAF/CDN technology on a site."""
        return await self._get_json("firewalldetector", domain)

    # ------------------------------------------------------------------
    # Reverse DNS (IP to hostname)
    # ------------------------------------------------------------------

    async def get_hostname(self, ip: str) -> str:
        """Reverse DNS lookup for an IP."""
        data = await self._get_json("gethostname", ip, param_name="ip")
        if isinstance(data, dict):
            return str(data.get("hostname", ""))
        return ""

    # ------------------------------------------------------------------
    # GeoIP
    # ------------------------------------------------------------------

    async def geoip(self, target: str) -> dict[str, Any]:
        """Geolocation for an IP or hostname."""
        return await self._get_json("geoip", target)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _get_list(self, endpoint: str, domain: str) -> list[str]:
        """Call an endpoint that returns a list of strings."""
        data = await self._get_json(endpoint, domain)
        if isinstance(data, list):
            return [str(item) for item in data]
        if isinstance(data, dict):
            # Some endpoints wrap in a 'result' or 'subdomains' key
            for key in ("result", "subdomains", "domains", "records"):
                val = data.get(key)
                if isinstance(val, list):
                    return [str(item) for item in val]
        return []

    async def _get_json(
        self,
        endpoint: str,
        domain: str,
        *,
        param_name: str = "domain",
        extra_params: dict[str, str] | None = None,
    ) -> Any:
        """Make a GET request and return parsed JSON."""
        if not self._key:
            return {}
        params: dict[str, str] = {"key": self._key, param_name: domain, "json": ""}
        if extra_params:
            params.update(extra_params)
        try:
            resp = await self._client.get(f"{self.BASE}/{endpoint}", params=params)
            resp.raise_for_status()
            return resp.json()
        except Exception:
            return {}

    async def close(self) -> None:
        await self._client.aclose()
