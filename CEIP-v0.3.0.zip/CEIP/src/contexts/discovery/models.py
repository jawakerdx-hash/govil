"""Discovery ORM models — jobs, DNS records, subdomains."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class DiscoveryJob(UUIDMixin, TimestampMixin, Base):
    """A discovery run against a domain."""

    __tablename__ = "discovery_jobs"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    status: Mapped[str] = mapped_column(
        String(20), default="pending", nullable=False
    )  # pending | running | done | failed
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    dns_records: Mapped[list[DNSRecord]] = relationship(
        back_populates="job", cascade="all, delete-orphan"
    )
    subdomains: Mapped[list[Subdomain]] = relationship(
        back_populates="job", cascade="all, delete-orphan"
    )
    services: Mapped[list[Service]] = relationship(
        back_populates="job", cascade="all, delete-orphan"
    )
    certificates: Mapped[list[Certificate]] = relationship(
        back_populates="job", cascade="all, delete-orphan"
    )
    ip_enrichments: Mapped[list[IPEnrichment]] = relationship(
        back_populates="job", cascade="all, delete-orphan"
    )


class DNSRecord(UUIDMixin, Base):
    """A single DNS record discovered for a domain."""

    __tablename__ = "dns_records"

    job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("discovery_jobs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    record_type: Mapped[str] = mapped_column(
        String(10), nullable=False
    )  # A, AAAA, NS, MX
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    ttl: Mapped[int] = mapped_column(Integer, default=0)

    job: Mapped[DiscoveryJob] = relationship(back_populates="dns_records")


class Subdomain(UUIDMixin, Base):
    """A subdomain discovered during a discovery run."""

    __tablename__ = "subdomains"

    job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("discovery_jobs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    source: Mapped[str] = mapped_column(
        String(20), default="dns"
    )  # dns | brute | crtsh

    job: Mapped[DiscoveryJob] = relationship(back_populates="subdomains")


class Service(UUIDMixin, Base):
    """A detected service running on a host (HTTP, HTTPS, etc.)."""

    __tablename__ = "services"

    job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("discovery_jobs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    host: Mapped[str] = mapped_column(String(255), nullable=False)
    port: Mapped[int] = mapped_column(Integer, default=443)
    server: Mapped[str | None] = mapped_column(String(512), nullable=True)
    status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    headers_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    job: Mapped[DiscoveryJob] = relationship(back_populates="services")


class Certificate(UUIDMixin, Base):
    """SSL/TLS certificate metadata collected during discovery."""

    __tablename__ = "certificates"

    job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("discovery_jobs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    host: Mapped[str] = mapped_column(String(255), nullable=False)
    subject: Mapped[str | None] = mapped_column(Text, nullable=True)
    issuer: Mapped[str | None] = mapped_column(Text, nullable=True)
    not_before: Mapped[str | None] = mapped_column(String(64), nullable=True)
    not_after: Mapped[str | None] = mapped_column(String(64), nullable=True)
    serial_number: Mapped[str | None] = mapped_column(String(128), nullable=True)
    sans_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    job: Mapped[DiscoveryJob] = relationship(back_populates="certificates")


class IPEnrichment(UUIDMixin, Base):
    """Enriched IP information — reverse DNS and ASN."""

    __tablename__ = "ip_enrichments"

    job_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("discovery_jobs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    ip: Mapped[str] = mapped_column(String(45), nullable=False)
    reverse_dns: Mapped[str | None] = mapped_column(String(255), nullable=True)
    asn: Mapped[str | None] = mapped_column(String(32), nullable=True)
    asn_org: Mapped[str | None] = mapped_column(String(255), nullable=True)

    job: Mapped[DiscoveryJob] = relationship(back_populates="ip_enrichments")
