"""Discovery repository — encapsulates all discovery-job queries."""

from __future__ import annotations

import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from .models import DiscoveryJob


class DiscoveryRepository:
    """Data-access layer for discovery jobs and related entities."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def get_latest_done(self, domain: str) -> DiscoveryJob | None:
        """Return the most recent completed discovery job with all relationships eager-loaded."""
        result = await self._db.execute(
            select(DiscoveryJob)
            .options(
                selectinload(DiscoveryJob.dns_records),
                selectinload(DiscoveryJob.subdomains),
                selectinload(DiscoveryJob.services),
                selectinload(DiscoveryJob.certificates),
                selectinload(DiscoveryJob.ip_enrichments),
            )
            .where(
                DiscoveryJob.domain == domain,
                DiscoveryJob.status == "done",
            )
            .order_by(DiscoveryJob.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, job_id: str | uuid.UUID) -> DiscoveryJob | None:
        """Fetch a single job by ID with all relationships eager-loaded."""
        result = await self._db.execute(
            select(DiscoveryJob)
            .options(
                selectinload(DiscoveryJob.dns_records),
                selectinload(DiscoveryJob.subdomains),
                selectinload(DiscoveryJob.services),
                selectinload(DiscoveryJob.certificates),
                selectinload(DiscoveryJob.ip_enrichments),
            )
            .where(DiscoveryJob.id == job_id)
        )
        return result.scalar_one_or_none()

    async def add(self, job: DiscoveryJob) -> None:
        """Stage a new discovery job for insertion."""
        self._db.add(job)

    async def flush(self) -> None:
        """Flush pending changes to the database."""
        await self._db.flush()
