"""Validation engine — deterministic asset validation with failure modes."""

from __future__ import annotations

from typing import Any


class AssetValidator:
    """Validates discovered assets. Returns REJECTED on critical failures."""

    @staticmethod
    def validate(asset_type: str, value: str) -> dict[str, Any]:
        issues: list[str] = []
        confidence = "high"

        # Wildcard handling
        if "*" in value:
            confidence = "low_confidence"
            issues.append("Wildcard not normalized")

        # Subdomain validation
        if asset_type == "subdomain":
            if value.count(".") < 2:
                confidence = "low_confidence"
                issues.append("Insufficient domain levels")

        # IP validation
        if asset_type == "ip_address":
            parts = value.split(".")
            if len(parts) != 4:
                return {"status": "REJECTED_ATTACK_SURFACE_DATA",
                        "reason": f"Invalid IPv4: {value}"}
            if not all(p.isdigit() for p in parts):
                return {"status": "REJECTED_ATTACK_SURFACE_DATA",
                        "reason": f"Non-numeric IPv4: {value}"}

        # DNS/IP mapping
        if asset_type in ("dns_server", "mail_server") and not value:
            confidence = "low_confidence"
            issues.append("Empty DNS/mail server value")

        # Type classification
        if asset_type not in _VALID_TYPES:
            return {"status": "REJECTED_ATTACK_SURFACE_DATA",
                    "reason": f"Unknown asset type: {asset_type}"}

        return {
            "validation_status": confidence,
            "issues": issues,
            "is_valid": confidence != "low_confidence",
        }

    @staticmethod
    def deduplicate(assets: list[dict[str, Any]]) -> list[dict[str, Any]]:
        seen: set[str] = set()
        unique: list[dict[str, Any]] = []
        for a in assets:
            key = f"{a.get('asset_type', '')}:{a.get('value', '').lower()}"
            if key not in seen:
                seen.add(key)
                unique.append(a)
        return unique


_VALID_TYPES = {
    "root_domain", "subdomain", "wildcard_subdomain", "ip_address",
    "cidr_block", "asn", "web_application", "api_endpoint",
    "mail_server", "dns_server", "cloud_resource", "load_balancer",
    "vpn_gateway", "storage_bucket", "exposed_service",
}
