"""Asset enrichment — technology stack, TLS, cloud, geo detection."""
# ruff: noqa: E501

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

REQUIRED_ENRICHMENT_FIELDS = [
    "technology_stack", "service_classification", "cloud_provider",
    "tls_analysis", "header_analysis", "exposure_severity",
]


@dataclass
class EnrichedAsset:
    """Fully structured enrichment output.

    If any required field is missing, mark as ENRICHMENT_INCOMPLETE.
    """
    value: str
    technology_stack: list[str] = field(default_factory=list)
    service_classification: str = "unknown"
    cloud_provider: str = ""
    hosting_provider: str = ""
    cdn_detected: str = ""
    waf_detected: str = ""
    geo_location: str = ""
    service_exposure: str = "unknown"
    tls_analysis: dict[str, Any] = field(default_factory=dict)
    header_analysis: dict[str, Any] = field(default_factory=dict)
    exposure_severity: str = "low"
    enrichment_status: str = "ENRICHMENT_INCOMPLETE"
    enriched_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def validate(self) -> list[str]:
        """Return list of missing required fields."""
        missing = []
        for f in REQUIRED_ENRICHMENT_FIELDS:
            val = getattr(self, f, None)
            if val is None or val == "" or val == [] or val == {}:
                missing.append(f)
        self.enrichment_status = "ENRICHMENT_INCOMPLETE" if missing else "COMPLETE"
        return missing

    def to_dict(self) -> dict[str, Any]:
        return {
            "technology_stack": self.technology_stack,
            "service_classification": self.service_classification,
            "cloud_provider": self.cloud_provider,
            "hosting_provider": self.hosting_provider,
            "cdn_detected": self.cdn_detected,
            "waf_detected": self.waf_detected,
            "geo_location": self.geo_location,
            "service_exposure": self.service_exposure,
            "tls_analysis": self.tls_analysis,
            "header_analysis": self.header_analysis,
            "exposure_severity": self.exposure_severity,
            "enrichment_status": self.enrichment_status,
            "enriched_at": self.enriched_at,
        }


class EnrichmentEngine:
    """Detects technology stack, cloud, CDN, WAF from HTTP fingerprints."""

    CDN_SIGNATURES = {"cloudflare", "akamai", "fastly", "cloudfront", "cdn", "edgecast", "keycdn"}
    WAF_SIGNATURES = {"cloudflare", "akamai", "imperva", "f5", "barracuda", "sucuri", "aws"}
    CLOUD_SIGNATURES = {"aws", "amazon", "azure", "gcp", "google cloud", "digitalocean", "linode", "vultr"}
    TECH_SIGNATURES = {
        "Apache": "apache", "nginx": "nginx", "IIS": "microsoft-iis",
        "Cloudflare": "cloudflare", "Varnish": "varnish", "Express": "express",
        "Django": "django", "Rails": "rails", "Laravel": "laravel",
        "WordPress": "wordpress", "PHP": "php", "Python": "python",
        "Tomcat": "tomcat", "Node.js": "node.js", "Gunicorn": "gunicorn",
    }
    SERVICE_CLASS_MAP = {
        "apache": "web_server", "nginx": "web_server", "iis": "web_server",
        "cloudflare": "cdn", "akamai": "cdn", "fastly": "cdn",
        "gunicorn": "app_server", "tomcat": "app_server", "express": "app_server",
    }

    def enrich(self, host: str, server_header: str = "",
               headers: dict[str, str] | None = None) -> EnrichedAsset:
        result = EnrichedAsset(value=host)
        hdr = headers or {}
        server_lower = server_header.lower()

        # Technology fingerprinting
        for name, sig in self.TECH_SIGNATURES.items():
            if sig in server_lower:
                result.technology_stack.append(name)

        # Service classification
        for sig, cls in self.SERVICE_CLASS_MAP.items():
            if sig in server_lower:
                result.service_classification = cls
                break

        # Cloud provider attribution
        for pattern in self.CLOUD_SIGNATURES:
            if pattern in server_lower:
                result.cloud_provider = pattern.title()
                break

        # CDN detection
        for pattern in self.CDN_SIGNATURES:
            if pattern in server_lower or pattern in str(hdr).lower():
                result.cdn_detected = pattern.title()
                break

        # WAF detection
        for pattern in self.WAF_SIGNATURES:
            if pattern in server_lower:
                result.waf_detected = pattern.title()
                break

        # HTTP header analysis
        interesting_headers = [
            "Server", "X-Powered-By", "Set-Cookie", "Content-Type",
            "X-Frame-Options", "Strict-Transport-Security",
            "Content-Security-Policy", "X-Content-Type-Options",
        ]
        for key in interesting_headers:
            if key in hdr:
                result.header_analysis[key] = hdr[key]

        # TLS analysis placeholder
        result.tls_analysis = {
            "tls_version": "unknown",
            "certificate_valid": "unknown",
            "certificate_issuer": "unknown",
        }

        # Exposure severity tagging
        if result.waf_detected and result.cdn_detected:
            result.exposure_severity = "low"
        elif result.cdn_detected:
            result.exposure_severity = "medium"
        elif server_header:
            result.exposure_severity = "high"
        else:
            result.exposure_severity = "unknown"

        # Service exposure level
        if result.cdn_detected and not result.waf_detected:
            result.service_exposure = "medium"
        elif result.waf_detected:
            result.service_exposure = "low"
        elif server_header:
            result.service_exposure = "high"

        # Validate completeness
        result.validate()
        return result
