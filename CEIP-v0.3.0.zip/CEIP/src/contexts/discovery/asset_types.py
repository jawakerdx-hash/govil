"""Strict asset type enumeration and output schema."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

ASSET_TYPES: list[str] = [
    "root_domain", "subdomain", "wildcard_subdomain", "ip_address",
    "cidr_block", "asn", "web_application", "api_endpoint",
    "mail_server", "dns_server", "cloud_resource", "load_balancer",
    "vpn_gateway", "storage_bucket", "exposed_service",
]

REQUIRED_ASSET_FIELDS = [
    "asset_id", "asset_type", "value", "organization_entity",
    "canonical_entity_id", "infrastructure_cluster", "discovery_sources",
    "enrichment_data", "technology_stack", "exposure_signals",
    "graph_edges", "risk_surface_score", "validation_status",
    "first_seen", "last_seen",
]


@dataclass
class AttackSurfaceAsset:
    """Standardized attack surface asset output."""

    asset_id: str
    asset_type: str
    value: str
    organization_entity: str = ""
    canonical_entity_id: str = ""
    infrastructure_cluster: str = ""
    discovery_sources: list[str] = field(default_factory=list)
    enrichment_data: dict[str, Any] = field(default_factory=dict)
    technology_stack: list[str] = field(default_factory=list)
    exposure_signals: list[str] = field(default_factory=list)
    graph_edges: list[dict[str, Any]] = field(default_factory=list)
    risk_surface_score: float = 0.0
    validation_status: str = "low_confidence"
    first_seen: str = ""
    last_seen: str = ""

    def validate(self) -> dict[str, Any] | None:
        """Return error if required fields are missing, else None."""
        missing = []
        for f in REQUIRED_ASSET_FIELDS:
            val = getattr(self, f, None)
            if val is None or val == "" or val == [] or val == 0.0:
                if f not in ("risk_surface_score",):
                    missing.append(f)
        if missing:
            return {"status": "REJECTED_INCOMPLETE_ATTACK_SURFACE_DATA", "missing": missing}
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "asset_id": self.asset_id,
            "asset_type": self.asset_type,
            "value": self.value,
            "organization_entity": self.organization_entity,
            "canonical_entity_id": self.canonical_entity_id,
            "infrastructure_cluster": self.infrastructure_cluster,
            "discovery_sources": self.discovery_sources,
            "enrichment_data": self.enrichment_data,
            "technology_stack": self.technology_stack,
            "exposure_signals": self.exposure_signals,
            "graph_edges": self.graph_edges,
            "risk_surface_score": self.risk_surface_score,
            "validation_status": self.validation_status,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
        }


def classify_asset(value: str, record_type: str = "") -> str:
    """Deterministic asset type classification."""
    if record_type.upper() in ("A", "AAAA"):
        return "ip_address"
    if record_type.upper() in ("NS",):
        return "dns_server"
    if record_type.upper() in ("MX",):
        return "mail_server"
    if record_type.upper() in ("SOA", "CNAME"):
        return "subdomain"
    v = value.lower()
    if v.startswith("api.") or "/api" in v:
        return "api_endpoint"
    if any(k in v for k in ("admin", "login", "dashboard", "panel")):
        return "web_application"
    if "cdn" in v or "static" in v:
        return "cloud_resource"
    if "mail" in v or "smtp" in v:
        return "mail_server"
    return "subdomain"
