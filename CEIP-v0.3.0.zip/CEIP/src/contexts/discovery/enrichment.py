"""IP enrichment — reverse DNS and basic ASN lookup."""

from __future__ import annotations

from dataclasses import dataclass

from src.contexts.discovery.resolver import resolve_ptr


@dataclass
class IPInfo:
    """Enriched information about an IP address."""

    ip: str
    reverse_dns: str | None = None
    asn: str | None = None
    asn_org: str | None = None


def enrich_ip(ip: str) -> IPInfo:
    """Enrich an IP address with reverse DNS and ASN information.

    ASN lookup uses Team Cymru's free WHOIS service (no API key needed).
    """
    info = IPInfo(ip=ip)

    # Reverse DNS
    ptr = resolve_ptr(ip)
    if ptr:
        info.reverse_dns = ptr

    # ASN via Team Cymru (free, no API key)
    try:
        info.asn, info.asn_org = _lookup_asn_cymru(ip)
    except Exception:
        pass

    return info


def _lookup_asn_cymru(ip: str, timeout: int = 5) -> tuple[str | None, str | None]:
    """Query Team Cymru's WHOIS for ASN and organization name.

    Uses the origin DNS TXT record: AS{N}.origin.asn.cymru.com
    """
    import dns.resolver

    # Reverse IP for the query
    parts = ip.split(".")
    parts.reverse()
    rev = ".".join(parts)

    resolver = dns.resolver.Resolver()
    resolver.timeout = timeout
    resolver.lifetime = timeout

    try:
        answers = resolver.resolve(f"{rev}.origin.asn.cymru.com", "TXT")
        raw = str(answers[0]).strip('"')
        # Format: "ASN | Prefix | Country | Registry | Allocated | Org Name"
        fields = [f.strip() for f in raw.split("|")]
        asn = fields[0].strip() if len(fields) > 0 else None
        org = fields[-1].strip() if len(fields) > 1 else None
        return asn, org
    except Exception:
        return None, None
