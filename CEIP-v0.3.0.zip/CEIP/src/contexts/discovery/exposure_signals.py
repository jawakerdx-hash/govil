"""Passive exposure signal detection — never intrusive."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any

SIGNAL_PATTERNS = {
    "admin_panel": ["/admin", "/login", "/dashboard", "/panel", "/wp-admin", "/phpmyadmin"],
    "open_directory": ["/uploads", "/backup", "/files", "/static", "/assets"],
    "backup_exposure": [".bak", ".backup", ".sql", ".zip", ".tar.gz", ".old"],
    "api_endpoint": ["/api", "/graphql", "/rest", "/v1", "/v2", "/swagger"],
    "outdated_service": [],  # populated from version detection
    "misconfigured": ["index of /", "directory listing"],
}


class ExposureSignalDetector:
    """Detects passive exposure signals from discovered assets. Never intrusive."""

    def detect(self, host: str, headers: dict[str, str] | None = None, server: str = "") -> list[str]:
        signals: list[str] = []
        host_lower = host.lower()
        hdr_str = str(headers).lower() if headers else ""

        for signal_type, patterns in SIGNAL_PATTERNS.items():
            for pattern in patterns:
                if pattern in host_lower or pattern in hdr_str:
                    if signal_type not in signals:
                        signals.append(signal_type)

        # Server version exposure
        if server and any(c.isdigit() for c in server):
            signals.append("version_disclosure")

        return signals

    def assess(self, assets: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for asset in assets:
            signals = self.detect(
                host=asset.get("value", ""),
                headers=asset.get("headers"),
                server=asset.get("server", ""),
            )
            asset["exposure_signals"] = signals
        return assets
