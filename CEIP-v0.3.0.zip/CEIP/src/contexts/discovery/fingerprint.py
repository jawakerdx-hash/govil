"""Technology fingerprinting — HTTP headers + SSL certificate metadata.

SSL certificates are parsed using the ``cryptography`` library, which
provides consistent ``getpeercert()`` behavior across Windows, Linux, and
macOS (the stdlib ``ssl.getpeercert(binary_form=False)`` returns empty
dicts on Windows).

Security note: certificate verification is intentionally disabled
(``verify_mode = ssl.CERT_NONE``) because the purpose is *fingerprinting*,
not trust validation. The cert chain validity is reported as metadata.
"""

from __future__ import annotations

import socket
import ssl
from dataclasses import dataclass, field
from typing import Any


@dataclass
class HTTPFingerprint:
    """Fingerprint from an HTTP(S) response."""

    host: str
    status_code: int = 0
    server: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    error: str | None = None


@dataclass
class SSLFingerprint:
    """SSL/TLS certificate metadata."""

    host: str
    subject: str = ""
    issuer: str = ""
    not_before: str = ""
    not_after: str = ""
    serial_number: str = ""
    sans: list[str] = field(default_factory=list)
    error: str | None = None


def fingerprint_http(host: str, port: int = 443, timeout: int = 2) -> HTTPFingerprint:
    """Connect to a host via HTTPS, grab headers, detect server technology."""
    return _fingerprint_http_inner(host, port, timeout, use_tls=True)


def fingerprint_http_plain(host: str, port: int = 80, timeout: int = 2) -> HTTPFingerprint:
    """Connect via plain HTTP (no SSL) — used for port 80 and non-HTTPS ports."""
    return _fingerprint_http_inner(host, port, timeout, use_tls=False)


def _fingerprint_http_inner(
    host: str, port: int, timeout: int, *, use_tls: bool,
) -> HTTPFingerprint:
    """Core HTTP fingerprinting — TLS or plain, same logic."""
    result = HTTPFingerprint(host=host)

    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            if use_tls:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                stream = ctx.wrap_socket(sock, server_hostname=host)
            else:
                stream = sock

            stream.settimeout(timeout)
            request = (
                f"GET / HTTP/1.0\r\n"
                f"Host: {host}\r\n"
                f"User-Agent: CEIP/0.2\r\n"
                f"Accept: */*\r\n"
                f"Connection: close\r\n\r\n"
            )
            stream.sendall(request.encode())

            response = b""
            while True:
                try:
                    chunk = stream.recv(4096)
                    if not chunk:
                        break
                    response += chunk
                except TimeoutError:
                    break

        if not response:
            result.error = "Empty response"
            return result

        text = response.decode("utf-8", errors="replace")
        lines = text.split("\r\n")
        if lines and lines[0].startswith("HTTP/"):
            parts = lines[0].split()
            if len(parts) >= 2:
                try:
                    result.status_code = int(parts[1])
                except ValueError:
                    pass

        body_start = 0
        for i, line in enumerate(lines[1:], 1):
            if ": " in line:
                key, value = line.split(": ", 1)
                result.headers[key.lower()] = value
            if line == "":
                body_start = i + 1
                break

        result.server = result.headers.get("server", "")

        # Capture first 2KB of response body for AI content analysis
        body = "\n".join(lines[body_start:body_start + 50]) if body_start else ""
        result.headers["_ceip_body_preview"] = body[:2048]

        # Store port in headers for service analysis
        result.headers["_ceip_port"] = str(port)
        result.headers["_ceip_tls"] = "true" if use_tls else "false"

    except ssl.SSLError:
        result.error = "TLS handshake failed"
    except TimeoutError:
        result.error = "Connection timed out"
    except (ConnectionRefusedError, ConnectionResetError):
        result.error = f"Connection refused on port {port}"
    except socket.gaierror as exc:
        result.error = str(exc)
    except OSError as exc:
        result.error = str(exc)

    return result


# Common ports to scan beyond 443
DISCOVERY_PORTS: list[tuple[int, bool]] = [
    (443, True),    # HTTPS
    (80, False),    # HTTP
    (8080, False),  # HTTP alt
    (8443, True),   # HTTPS alt
    (3000, False),  # Node.js / React dev
    (5000, False),  # Flask / dev
    (9090, False),  # Prometheus / admin
]


def fingerprint_ssl(host: str, port: int = 443, timeout: int = 5) -> SSLFingerprint:
    """Retrieve SSL/TLS certificate metadata from a host.

    Uses ``cryptography.x509`` to parse the DER-encoded certificate, which
    works consistently across all platforms (unlike the stdlib dict-based
    API which returns empty results on Windows).

    Returns an SSLFingerprint whose ``subject`` will be empty if the host
    does not speak TLS on *port* or the handshake fails.
    """
    result = SSLFingerprint(host=host)

    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as tls:
                der = tls.getpeercert(binary_form=True)
                if not der:
                    result.error = "No certificate returned by peer"
                    return result

                _populate_from_der(result, der)

    except ssl.SSLError as exc:
        result.error = f"TLS handshake failed: {exc}"
    except (ConnectionRefusedError, ConnectionResetError):
        result.error = f"Connection refused on port {port}"
    except TimeoutError:
        result.error = "Connection timed out"
    except socket.gaierror as exc:
        result.error = f"DNS resolution failed: {exc}"
    except OSError as exc:
        result.error = str(exc)

    return result


def _populate_from_der(result: SSLFingerprint, der: bytes) -> None:
    """Parse a DER-encoded X.509 certificate and populate *result*."""
    from cryptography import x509
    from cryptography.x509.oid import NameOID

    try:
        cert = x509.load_der_x509_certificate(der)
    except Exception:
        result.error = "Failed to parse DER certificate"
        return

    # Subject
    cn = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    org = cert.subject.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)
    result.subject = ", ".join(
        f"CN={a.value}" for a in cn
    ) or ", ".join(
        f"O={a.value}" for a in org
    ) or ""

    # Issuer
    issuer_cn = cert.issuer.get_attributes_for_oid(NameOID.COMMON_NAME)
    result.issuer = ", ".join(f"CN={a.value}" for a in issuer_cn) if issuer_cn else ""

    # Dates
    if cert.not_valid_before_utc:
        result.not_before = cert.not_valid_before_utc.isoformat()
    if cert.not_valid_after_utc:
        result.not_after = cert.not_valid_after_utc.isoformat()

    # Serial number
    result.serial_number = format(cert.serial_number, "x")

    # Subject Alternative Names
    try:
        ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        result.sans = ext.value.get_values_for_type(x509.DNSName)
    except x509.ExtensionNotFound:
        pass


def _format_asn1_time(value: str) -> str:
    """Normalise ASN.1 time strings (e.g. '20240101000000Z') to ISO-8601.

    Kept for backward compatibility with the dict-based API on Linux.
    """
    if not value or not isinstance(value, str):
        return ""
    if "-" in value:
        return value
    if len(value) == 15 and value.endswith("Z"):
        return (
            f"{value[0:4]}-{value[4:6]}-{value[6:8]}"
            f"T{value[8:10]}:{value[10:12]}:{value[12:14]}Z"
        )
    return value


def _fmt_dn(parts: Any) -> str:
    """Format a Distinguished Name into a readable string."""
    if not parts:
        return ""
    items = [f"{k}={v}" for k, v in parts]
    return ", ".join(items)
