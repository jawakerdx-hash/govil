"""Lightweight deterministic risk pre-scoring for attack surface assets.

risk_surface_score = exposure_level + internet_visibility
                    + service_criticality + misconfiguration_signals
                    + asset_reachability
"""

from __future__ import annotations

from typing import Any

EXPOSURE_LEVELS = {"unknown": 15, "low": 8, "medium": 30, "high": 55}
VISIBILITY_MODIFIERS = {"cdn_detected": -8, "waf_detected": -12, "public_ip": 25, "no_tls": 15}
CRITICALITY_MAP = {
    "mail_server": 70, "api_endpoint": 65, "web_application": 55,
    "vpn_gateway": 80, "storage_bucket": 60, "dns_server": 50,
    "cloud_resource": 45, "subdomain": 20, "root_domain": 30,
    "exposed_service": 60, "load_balancer": 50,
}
REACHABILITY_MAP = {
    "public_internet": 30, "cdn_only": 10, "internal": 0, "unknown": 15,
}


class RiskPreScorer:
    """Deterministic risk pre-scoring for attack surface.

    All components required: exposure, visibility, criticality,
    misconfiguration, and reachability.
    """

    def score(self, asset: dict[str, Any]) -> dict[str, Any]:
        asset_type = asset.get("asset_type", "subdomain")
        exposure = asset.get("service_exposure", "unknown")
        signals = asset.get("exposure_signals", [])

        # 1. Exposure level
        exp_score = EXPOSURE_LEVELS.get(exposure, 15)

        # 2. Internet visibility
        vis_score = 20
        if asset.get("cdn_detected"):
            vis_score += VISIBILITY_MODIFIERS["cdn_detected"]
        if asset.get("waf_detected"):
            vis_score += VISIBILITY_MODIFIERS["waf_detected"]
        if asset.get("value") and _is_public(asset.get("value", "")):
            vis_score += VISIBILITY_MODIFIERS["public_ip"]

        # 3. Service criticality
        crit_score = CRITICALITY_MAP.get(asset_type, 25)

        # 4. Misconfiguration signals
        misc_score = len(signals) * 10

        # 5. Asset reachability
        reach = _determine_reachability(asset)
        reach_score = REACHABILITY_MAP.get(reach, 15)

        raw = exp_score + vis_score + crit_score + misc_score + reach_score
        score = min(100.0, max(0.0, round(raw, 1)))

        return {
            "risk_surface_score": score,
            "exposure_level": exp_score,
            "internet_visibility": vis_score,
            "service_criticality": crit_score,
            "misconfiguration_signals": misc_score,
            "asset_reachability": reach_score,
        }

    def score_all(self, assets: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for asset in assets:
            result = self.score(asset)
            asset["risk_surface_score"] = result["risk_surface_score"]
            asset["risk_breakdown"] = {k: v for k, v in result.items()
                                       if k != "risk_surface_score"}
        return assets


def _is_public(value: str) -> bool:
    parts = value.split(".")
    if len(parts) == 4 and all(p.isdigit() for p in parts):
        octets = [int(p) for p in parts]
        if octets[0] in (10, 127):
            return False
        if octets[0] == 172 and 16 <= octets[1] <= 31:
            return False
        if octets[0] == 192 and octets[1] == 168:
            return False
        return True
    return True


def _determine_reachability(asset: dict[str, Any]) -> str:
    cdn = asset.get("cdn_detected", "")
    waf = asset.get("waf_detected", "")
    value = asset.get("value", "")
    if cdn and not waf:
        return "cdn_only"
    if _is_public(value):
        return "public_internet"
    if not value or value.startswith("10.") or value.startswith("192.168."):
        return "internal"
    return "unknown"
