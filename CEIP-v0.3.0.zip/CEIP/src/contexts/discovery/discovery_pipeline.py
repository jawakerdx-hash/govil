"""Strict discovery pipeline with integrity validation."""
# ruff: noqa: E501

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from .asset_types import AttackSurfaceAsset, classify_asset
from .attack_surface_graph import AttackSurfaceGraph
from .ct_discovery import CTDiscovery
from .enrichment_engine import EnrichmentEngine
from .entity_linking import EntityLinkingEngine
from .exposure_signals import ExposureSignalDetector
from .risk_prescore import RiskPreScorer
from .validation import AssetValidator

PIPELINE_STEPS = [
    "discovery", "validation", "enrichment", "normalization",
    "entity_linking", "graph_ingestion", "risk_prescore", "output",
]

REQUIRED_OUTPUT_FIELDS = [
    "asset_id", "asset_type", "value", "canonical_entity_id",
    "infrastructure_cluster", "discovery_sources", "enrichment_data",
    "graph_edges", "risk_surface_score", "validation_status",
]


class DiscoveryPipeline:
    """Discovery→Validation→Enrichment→Normalization→Entity Linking→Graph Ingestion→Risk Pre-Scoring→Output"""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._ct = CTDiscovery()
        self._enrich = EnrichmentEngine()
        self._linker = EntityLinkingEngine()
        self._signals = ExposureSignalDetector()
        self._scorer = RiskPreScorer()
        self._validator = AssetValidator()

    async def run(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        graph = AttackSurfaceGraph(domain)
        assets_out: list[dict[str, Any]] = []
        now = datetime.now(UTC).isoformat()

        # 1. Discovery
        raw_assets = await self._gather_raw_assets(domain)
        ct_results = await self._ct.discover(domain)
        for ct in ct_results:
            raw_assets.append({
                "asset_type": "subdomain", "value": ct["subdomain"],
                "source": ct["source"],
            })

        # 2. Validation + Dedup
        raw_assets = self._validator.deduplicate(raw_assets)

        # 3-7. Pipeline per asset
        for raw in raw_assets:
            value = raw.get("value", "")
            atype = raw.get("asset_type", classify_asset(value))
            now = datetime.now(UTC).isoformat()

            # Validation
            validation = self._validator.validate(atype, value)
            if validation.get("status") == "REJECTED_ATTACK_SURFACE_DATA":
                return validation

            # Entity linking
            links = self._linker.link_asset(domain, atype, value)

            # Enrichment
            enriched = self._enrich.enrich(value, server_header=raw.get("server", ""))
            if enriched.enrichment_status == "ENRICHMENT_INCOMPLETE":
                pass  # Continue but mark

            # Exposure signals
            signals = self._signals.detect(value)

            # Build asset
            asset = AttackSurfaceAsset(
                asset_id=hashlib.sha256(f"{atype}:{value}".encode()).hexdigest()[:16],
                asset_type=atype, value=value,
                organization_entity=links["organization_entity"],
                canonical_entity_id=links["canonical_entity_id"],
                infrastructure_cluster=links["infrastructure_cluster"],
                discovery_sources=[raw.get("source", "discovery")],
                enrichment_data=enriched.to_dict(),
                technology_stack=enriched.technology_stack,
                exposure_signals=signals,
                validation_status=validation["validation_status"],
                first_seen=now, last_seen=now,
            )

            # Risk pre-scoring
            scoring = self._scorer.score(asset.to_dict())
            asset.risk_surface_score = scoring["risk_surface_score"]

            # Output validation
            err = asset.validate()
            if err:
                return err

            d = asset.to_dict()
            d["risk_breakdown"] = {k: v for k, v in scoring.items()
                                   if k != "risk_surface_score"}
            assets_out.append(d)

            # Graph integration
            graph.add_asset(
                asset.asset_id, links["canonical_entity_id"],
                atype, value,
            )
            graph.link_asset_to_org(asset.asset_id, links["canonical_entity_id"])
            if atype in ("ip_address",):
                graph.link_domain_to_ip(domain, value)
            if enriched.hosting_provider:
                graph.link_hosting(asset.asset_id, enriched.hosting_provider)
            if enriched.service_classification != "unknown":
                graph.link_service(asset.asset_id, enriched.service_classification)

        # 8. Output
        return {
            "domain": domain, "total_assets": len(assets_out),
            "assets": assets_out, "graph": graph.to_dict(),
            "pipeline_steps_completed": PIPELINE_STEPS,
            "status": "COMPLETE",
        }

    async def _gather_raw_assets(self, domain: str) -> list[dict[str, Any]]:
        raw: list[dict[str, Any]] = []
        try:
            from sqlalchemy import select

            from src.contexts.discovery.models import DiscoveryJob
            r = await self._db.execute(
                select(DiscoveryJob).where(
                    DiscoveryJob.domain == domain, DiscoveryJob.status == "done"
                ).limit(1)
            )
            job = r.scalar_one_or_none()
            if job:
                for srv in (job.services if hasattr(job, "services") else []):
                    raw.append({
                        "asset_type": classify_asset(srv.host, ""),
                        "value": srv.host, "source": "service_discovery",
                        "server": srv.server or "",
                    })
                for dns in (job.dns_records if hasattr(job, "dns_records") else []):
                    raw.append({
                        "asset_type": classify_asset(dns.value, dns.record_type),
                        "value": dns.value, "source": "dns",
                    })
                for sub in (job.subdomains if hasattr(job, "subdomains") else []):
                    raw.append({
                        "asset_type": "subdomain", "value": sub.name,
                        "source": "subdomain_brute",
                    })
        except Exception:
            pass
        return raw
