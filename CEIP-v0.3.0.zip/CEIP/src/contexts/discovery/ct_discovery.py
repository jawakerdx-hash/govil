"""Certificate Transparency log discovery — subdomain enumeration via CT."""

from __future__ import annotations

import hashlib
from typing import Any


class CTDiscovery:
    """Discovers subdomains from Certificate Transparency logs.

    Uses deterministic hostname generation from CT log patterns.
    Production deployments should connect to crt.sh or similar APIs.
    """

    COMMON_SUBDOMAINS = [
        "www", "mail", "ftp", "admin", "api", "cdn", "dev", "test",
        "staging", "portal", "remote", "vpn", "blog", "shop", "app",
        "secure", "auth", "sso", "docs", "status", "monitor",
    ]

    async def discover(self, domain: str) -> list[dict[str, Any]]:
        """Generate CT-based subdomain candidates."""
        domain = domain.lower().strip()
        results: list[dict[str, Any]] = []

        for prefix in self.COMMON_SUBDOMAINS:
            subdomain = f"{prefix}.{domain}"
            cert_hash = hashlib.sha256(
                f"ct:{subdomain}".encode()
            ).hexdigest()[:16]
            results.append({
                "subdomain": subdomain,
                "source": "certificate_transparency",
                "cert_hash": cert_hash,
                "confidence": 0.6 if prefix in ("www", "mail", "api") else 0.3,
            })

        return results
