"""Pydantic schemas for discovery API."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class DiscoveryRequest(BaseModel):
    """Request to start a discovery job."""

    domain: str = Field(min_length=3, max_length=255)


class DNSRecordResponse(BaseModel):
    """A single DNS record."""

    id: UUID
    record_type: str
    name: str
    value: str
    ttl: int

    model_config = {"from_attributes": True}


class SubdomainResponse(BaseModel):
    """A single subdomain."""

    id: UUID
    name: str
    source: str

    model_config = {"from_attributes": True}


class ServiceResponse(BaseModel):
    """A detected service."""

    id: UUID
    host: str
    port: int
    server: str | None = None
    status_code: int | None = None

    model_config = {"from_attributes": True}


class CertificateResponse(BaseModel):
    """SSL certificate metadata."""

    id: UUID
    host: str
    subject: str | None = None
    issuer: str | None = None
    not_before: str | None = None
    not_after: str | None = None
    sans: list[str] = []

    model_config = {"from_attributes": True}


class IPEnrichmentResponse(BaseModel):
    """IP enrichment data."""

    id: UUID
    ip: str
    reverse_dns: str | None = None
    asn: str | None = None
    asn_org: str | None = None

    model_config = {"from_attributes": True}


class DiscoveryJobResponse(BaseModel):
    """A discovery job with all results."""

    id: UUID
    domain: str
    status: str
    error: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    finished_at: datetime | None = None
    dns_records: list[DNSRecordResponse] = []
    subdomains: list[SubdomainResponse] = []
    services: list[ServiceResponse] = []
    certificates: list[CertificateResponse] = []
    ip_enrichments: list[IPEnrichmentResponse] = []

    model_config = {"from_attributes": True}
