"""Attack surface graph — nodes and edges with temporal metadata."""
# ruff: noqa: E501

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

STRICT_EDGE_TYPES = frozenset({
    "resolves_to", "hosted_on", "belongs_to",
    "shares_infrastructure_with", "exposes_service",
})


@dataclass
class GraphNode:
    """A node in the attack surface graph."""
    asset_id: str
    canonical_entity_id: str
    asset_type: str
    value: str = ""
    first_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "asset_id": self.asset_id,
            "canonical_entity_id": self.canonical_entity_id,
            "asset_type": self.asset_type,
            "value": self.value,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "metadata": self.metadata,
        }


@dataclass
class GraphEdge:
    """A directed edge between two nodes."""
    from_node: str
    to_node: str
    edge_type: str
    strength_score: float = 50.0
    evidence_source: str = ""
    first_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def __post_init__(self) -> None:
        if self.edge_type not in STRICT_EDGE_TYPES:
            raise ValueError(
                f"Invalid edge_type '{self.edge_type}'. "
                f"Must be one of: {sorted(STRICT_EDGE_TYPES)}"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "from": self.from_node, "to": self.to_node,
            "type": self.edge_type, "strength": self.strength_score,
            "source": self.evidence_source,
            "first_seen": self.first_seen, "last_seen": self.last_seen,
        }


class AttackSurfaceGraph:
    """In-memory graph of attack surface assets with temporal tracking."""

    def __init__(self, domain: str) -> None:
        self.domain = domain
        self.nodes: dict[str, GraphNode] = {}
        self.edges: list[GraphEdge] = []

    def add_asset(self, asset_id: str, canonical_id: str, asset_type: str, value: str = "") -> GraphNode:
        now = datetime.now(UTC).isoformat()
        existing = self.nodes.get(asset_id)
        if existing:
            existing.last_seen = now
            return existing
        node = GraphNode(
            asset_id=asset_id, canonical_entity_id=canonical_id,
            asset_type=asset_type, value=value, first_seen=now, last_seen=now,
        )
        self.nodes[asset_id] = node
        return node

    def add_edge(self, from_node: str, to_node: str, edge_type: str,
                 strength: float = 50.0, source: str = "") -> GraphEdge:
        now = datetime.now(UTC).isoformat()
        edge = GraphEdge(
            from_node=from_node, to_node=to_node, edge_type=edge_type,
            strength_score=strength, evidence_source=source,
            first_seen=now, last_seen=now,
        )
        self.edges.append(edge)
        return edge

    def link_domain_to_ip(self, domain: str, ip: str, source: str = "dns") -> GraphEdge:
        return self.add_edge(domain, ip, "resolves_to", strength=90.0, source=source)

    def link_asset_to_org(self, asset_id: str, org_id: str) -> GraphEdge:
        return self.add_edge(asset_id, org_id, "belongs_to", strength=95.0, source="entity_linking")

    def link_shared_infra(self, a: str, b: str, evidence: str) -> GraphEdge:
        return self.add_edge(a, b, "shares_infrastructure_with", strength=60.0, source=evidence)

    def link_service(self, asset_id: str, service_type: str) -> GraphEdge:
        return self.add_edge(asset_id, service_type, "exposes_service", strength=70.0, source="fingerprint")

    def link_hosting(self, asset_id: str, provider: str) -> GraphEdge:
        return self.add_edge(asset_id, provider, "hosted_on", strength=75.0, source="enrichment")

    def to_dict(self) -> dict[str, Any]:
        return {
            "domain": self.domain,
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [e.to_dict() for e in self.edges],
        }
