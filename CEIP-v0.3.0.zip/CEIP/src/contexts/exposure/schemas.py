"""Pydantic schemas for identity exposure API."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class CredentialExposureResponse(BaseModel):
    """A single credential exposure finding."""

    id: UUID
    entity: str
    entity_type: str
    exposure_type: str
    source_name: str | None = None
    source_type: str
    severity: str
    confidence: float
    description: str | None = None

    model_config = {"from_attributes": True}


class DarkWebIntelResponse(BaseModel):
    """A single dark web intelligence signal."""

    id: UUID
    title: str
    intel_type: str
    source: str | None = None
    severity: str
    confidence: float
    description: str | None = None

    model_config = {"from_attributes": True}


class IdentityExposureResponse(BaseModel):
    """Complete identity exposure view for a domain."""

    domain: str
    exposures_count: int
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    exposures: list[CredentialExposureResponse] = []
    dark_web_count: int = 0
    dark_web_intel: list[DarkWebIntelResponse] = []
    summary: str = ""
