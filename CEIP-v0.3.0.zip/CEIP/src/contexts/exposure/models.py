"""Identity exposure ORM models — credential leaks, identity graph, dark web intel."""

from __future__ import annotations

from sqlalchemy import Float, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class CredentialExposure(UUIDMixin, TimestampMixin, Base):
    """A leaked credential or identity exposure finding."""

    __tablename__ = "credential_exposures"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    entity: Mapped[str] = mapped_column(String(512), nullable=False)
    entity_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # email, domain, username, name
    exposure_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # credential_leak, mention, metadata, breach
    source_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    source_type: Mapped[str] = mapped_column(
        String(32), default="simulated"
    )  # simulated, breach_db, paste, forum
    severity: Mapped[str] = mapped_column(
        String(16), nullable=False
    )  # LOW, MEDIUM, HIGH, CRITICAL
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    linked_assets_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class DarkWebIntel(UUIDMixin, TimestampMixin, Base):
    """Dark web or external threat intelligence about an organization."""

    __tablename__ = "dark_web_intel"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    intel_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # mention, listing, breach, sale, discussion
    source: Mapped[str | None] = mapped_column(String(128), nullable=True)
    source_type: Mapped[str] = mapped_column(String(32), default="simulated")
    severity: Mapped[str] = mapped_column(String(16), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    url_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
