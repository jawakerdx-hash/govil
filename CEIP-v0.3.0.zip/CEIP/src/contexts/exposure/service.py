"""Identity exposure + dark web intelligence service.

Matches simulated/ingested external threat data against discovered assets.
Cross-correlates with risk engine.
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.discovery.models import DiscoveryJob
from src.contexts.exposure.leak_data import DARKWEB_DATASET, EXPOSURE_DATASET
from src.contexts.exposure.models import CredentialExposure, DarkWebIntel


class ExposureService:
    """Match identity/credential exposures against organizational assets."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def assess_identity(self, domain: str) -> dict[str, Any]:
        """Run identity exposure assessment."""
        domain = domain.lower().strip()

        job = await self._get_job(domain)
        if job is None:
            return {"domain": domain, "exposures_count": 0,
                    "exposures": [], "summary": f"No discovery data for {domain}"}

        exposures: list[dict[str, Any]] = []
        subdomains = {s.name for s in job.subdomains} | {domain}

        for entry in EXPOSURE_DATASET:
            etype, entity, exptype, source, stype, severity, confidence, desc = entry
            entity_name = entity.replace("{domain}", domain)

            matched = False
            linked_assets: list[str] = []

            if etype == "email":
                for sub in subdomains:
                    if entity_name.endswith(f"@{sub}") or entity_name.endswith(sub):
                        matched = True
                        linked_assets.append(sub)
                        break
            elif etype == "domain":
                if domain in entity_name:
                    matched = True
                    linked_assets.append(domain)
            elif etype == "name":
                matched = True  # Always include name mentions
                linked_assets.append(domain)

            if matched:
                exposures.append({
                    "entity": entity_name,
                    "entity_type": etype,
                    "exposure_type": exptype,
                    "source_name": source,
                    "source_type": stype,
                    "severity": severity,
                    "confidence": confidence,
                    "description": desc,
                    "linked_assets_json": json.dumps(linked_assets),
                })

        # Persist
        await self._persist_exposures(domain, job.id, exposures)

        sev = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for e in exposures:
            sev[e["severity"]] = sev.get(e["severity"], 0) + 1

        return {
            "domain": domain,
            "exposures_count": len(exposures),
            "critical": sev["CRITICAL"], "high": sev["HIGH"],
            "medium": sev["MEDIUM"], "low": sev["LOW"],
            "exposures": exposures,
            "summary": (
                f"{len(exposures)} identity exposures: "
                f"{sev['CRITICAL']} critical, {sev['HIGH']} high, "
                f"{sev['MEDIUM']} medium, {sev['LOW']} low"
            ),
        }

    async def assess_darkweb(self, domain: str) -> dict[str, Any]:
        """Run dark web intelligence assessment."""
        domain = domain.lower().strip()

        job = await self._get_job(domain)
        if job is None:
            return {"domain": domain, "dark_web_count": 0,
                    "dark_web_intel": [], "summary": f"No discovery data for {domain}"}

        intel_items: list[dict[str, Any]] = []
        for entry in DARKWEB_DATASET:
            itype, title, source, stype, severity, conf, url, desc = entry
            intel_items.append({
                "title": title.replace("{domain}", domain),
                "intel_type": itype,
                "source": source,
                "source_type": stype,
                "severity": severity,
                "confidence": conf,
                "url_reference": url,
                "description": desc.replace("{domain}", domain) if desc else None,
            })

        await self._persist_darkweb(domain, job.id, intel_items)

        sev = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for i in intel_items:
            sev[i["severity"]] = sev.get(i["severity"], 0) + 1

        return {
            "domain": domain,
            "dark_web_count": len(intel_items),
            "critical": sev["CRITICAL"], "high": sev["HIGH"],
            "medium": sev["MEDIUM"], "low": sev["LOW"],
            "dark_web_intel": intel_items,
            "summary": (
                f"{len(intel_items)} dark web signals: "
                f"{sev['CRITICAL']} critical, {sev['HIGH']} high"
            ),
        }

    # ------------------------------------------------------------------

    async def _get_job(self, domain: str) -> DiscoveryJob | None:
        from sqlalchemy.orm import selectinload

        r = await self._db.execute(
            select(DiscoveryJob)
            .options(
                selectinload(DiscoveryJob.subdomains),
                selectinload(DiscoveryJob.dns_records),
            )
            .where(DiscoveryJob.domain == domain, DiscoveryJob.status == "done")
            .order_by(DiscoveryJob.created_at.desc())
            .limit(1)
        )
        return r.scalar_one_or_none()

    async def _persist_exposures(
        self, domain: str, job_id: Any, exposures: list[dict[str, Any]]
    ) -> None:
        old = await self._db.execute(
            select(CredentialExposure).where(CredentialExposure.domain == domain)
        )
        for row in old.scalars().all():
            await self._db.delete(row)

        for e in exposures:
            self._db.add(CredentialExposure(
                domain=domain,
                entity=e["entity"],
                entity_type=e["entity_type"],
                exposure_type=e["exposure_type"],
                source_name=e.get("source_name"),
                source_type=e.get("source_type", "simulated"),
                severity=e["severity"],
                confidence=e["confidence"],
                description=e.get("description"),
                linked_assets_json=e.get("linked_assets_json"),
            ))
        await self._db.flush()

    async def _persist_darkweb(
        self, domain: str, job_id: Any, items: list[dict[str, Any]]
    ) -> None:
        old = await self._db.execute(
            select(DarkWebIntel).where(DarkWebIntel.domain == domain)
        )
        for row in old.scalars().all():
            await self._db.delete(row)

        for i in items:
            self._db.add(DarkWebIntel(
                domain=domain,
                title=i["title"],
                intel_type=i["intel_type"],
                source=i.get("source"),
                source_type=i.get("source_type", "simulated"),
                severity=i["severity"],
                confidence=i["confidence"],
                description=i.get("description"),
                url_reference=i.get("url_reference"),
            ))
        await self._db.flush()
