"""Simulated identity exposure and dark web intelligence dataset.

For MVP testing only. In production, this would be backed by:
- HaveIBeenPwned API
- DeHashed
- SpyCloud
- DarkOwl / Recorded Future
- Custom breach data ingestion pipelines
"""

from __future__ import annotations

# (entity_type, entity, exposure_type, source_name, source_type, severity, confidence, description)
EXPOSURE_DATASET: list[tuple[str, str, str, str | None, str, str, float, str]] = [
    # --- Credential leaks ---
    ("email", "admin@{domain}", "credential_leak", "BreachDB-2024",
     "simulated", "CRITICAL", 0.85,
     "Email and password hash found in 2024 breach compilation. "
     "Exposed: bcrypt hash, last login IP, account creation date."),

    ("email", "info@{domain}", "credential_leak", "LeakBase-2025",
     "simulated", "HIGH", 0.70,
     "Email found in marketing platform breach. "
     "Potential exposure of contact form submissions and customer metadata."),

    ("email", "support@{domain}", "credential_leak", "ComboList-Q1-2026",
     "simulated", "MEDIUM", 0.55,
     "Email listed in credential stuffing combo list. "
     "No password hash confirmed, but email is being targeted."),

    ("email", "developer@{domain}", "credential_leak", "GitHub-SecretScan",
     "simulated", "CRITICAL", 0.90,
     "API key and database credentials found in public GitHub repository. "
     "Active for 47 days before detection. Key has been rotated."),

    ("username", "ceip_admin", "credential_leak", "DarkWeb-Forum",
     "simulated", "HIGH", 0.65,
     "Administrator username found in dark web forum signature. "
     "Indicates potential reconnaissance activity."),

    # --- Domain mentions in leaks ---
    ("domain", "{domain}", "mention", "PasteBin-Scrape",
     "simulated", "MEDIUM", 0.60,
     "Organization domain referenced in paste discussing vulnerability exploitation. "
     "Mentions 'easy target' and lists subdomain names."),

    ("domain", "{domain}", "metadata", "Shodan-Export",
     "simulated", "LOW", 0.80,
     "Organization assets indexed by Shodan with technology stack metadata. "
     "Publicly available but increases reconnaissance surface."),

    # --- Executive / personnel exposure ---
    ("name", "John Smith", "mention", "Forum-Post",
     "simulated", "MEDIUM", 0.50,
     "Employee name mentioned in hacking forum. "
     "Discussion of social engineering potential."),

    ("email", "ceo@{domain}", "credential_leak", "LinkedIn-Scrape-2025",
     "simulated", "HIGH", 0.75,
     "Executive email found in LinkedIn data scrape. "
     "Combined with other OSINT enables targeted spear-phishing."),
]

# Dark web intelligence signals
DARKWEB_DATASET: list[tuple[str, str, str | None, str, str, float, str | None, str]] = [
    ("mention", "Organization listed on dark web forum",
     "DarkWeb-Forum-X", "simulated", "HIGH", 0.60,
     "https://darkweb.forum/thread/12345",
     "Organization named in thread discussing 'companies with weak security'. "
     "Thread has 47 replies and 1200 views."),

    ("sale", "Database access sold on marketplace",
     "DarkMarket-2025", "simulated", "CRITICAL", 0.55,
     "https://darkmarket.onion/listing/7890",
     "Seller claims to have database access for {domain}. "
     "Asking price: $500. Verification status: unconfirmed."),

    ("breach", "Historical breach data being traded",
     "BreachTrader", "simulated", "MEDIUM", 0.45,
     None,
     "2023 breach dataset containing {domain} customer records "
     "appears in a breach trading circle. Data may be stale."),

    ("discussion", "Phishing campaign targeting organization",
     "PhishTalk-Forum", "simulated", "HIGH", 0.70,
     None,
     "Discussions about a targeted phishing campaign against {domain} employees. "
     "Mentions specific department names and email formats."),

    ("listing", "SSL certificates and IP ranges offered",
     "CertMarket", "simulated", "MEDIUM", 0.50,
     "https://certmarket.onion/listing/4567",
     "TLS certificates and IP ranges for {domain} subdomains "
     "offered for sale. May indicate past compromise or recon."),
]
