"""Monitoring ORM models — jobs, snapshots, changes, alerts, executions."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class MonitoringJob(UUIDMixin, TimestampMixin, Base):
    """A recurring or one-time monitoring job for a domain."""

    __tablename__ = "monitoring_jobs"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    schedule: Mapped[str] = mapped_column(
        String(20), default="manual"
    )  # manual, hourly, daily, weekly
    enabled: Mapped[bool] = mapped_column(default=True)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class MonitoringExecution(UUIDMixin, Base):
    """A single execution of a monitoring job."""

    __tablename__ = "monitoring_executions"

    job_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now()
    )
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="running")
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    trigger: Mapped[str] = mapped_column(String(20), default="manual")
    scan_version: Mapped[int] = mapped_column(Integer, default=1)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)


class MonitoringSnapshot(UUIDMixin, Base):
    """A normalized snapshot of all assets at a point in time."""

    __tablename__ = "monitoring_snapshots"

    execution_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    snapshot_type: Mapped[str] = mapped_column(String(32), nullable=False)
    data_json: Mapped[str] = mapped_column(Text, nullable=False)
    checksum: Mapped[str] = mapped_column(String(64), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now()
    )


class MonitoringChange(UUIDMixin, Base):
    """A detected change between two snapshots."""

    __tablename__ = "monitoring_changes"

    execution_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    change_type: Mapped[str] = mapped_column(String(32), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(32), nullable=False)
    entity_identifier: Mapped[str] = mapped_column(String(512), nullable=False)
    previous_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    new_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    severity: Mapped[str] = mapped_column(String(16), default="INFO")
    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now()
    )


class MonitoringAlert(UUIDMixin, Base):
    """An alert generated from a detected change."""

    __tablename__ = "monitoring_alerts"

    execution_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    alert_type: Mapped[str] = mapped_column(String(32), nullable=False)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    severity: Mapped[str] = mapped_column(String(16), default="INFO")
    acknowledged: Mapped[bool] = mapped_column(default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now()
    )
