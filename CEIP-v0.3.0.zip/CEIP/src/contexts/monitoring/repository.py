"""Repository layer for monitoring context."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.monitoring.models import (
    MonitoringAlert,
    MonitoringChange,
    MonitoringExecution,
    MonitoringJob,
    MonitoringSnapshot,
)


class MonitoringRepository:
    """Data access for monitoring. Service never touches SQL directly."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def get_job(self, domain: str) -> MonitoringJob | None:
        r = await self._db.execute(
            select(MonitoringJob).where(MonitoringJob.domain == domain)
        )
        return r.scalar_one_or_none()

    async def create_job(self, job: MonitoringJob) -> None:
        self._db.add(job)
        await self._db.flush()

    async def add_execution(self, execution: MonitoringExecution) -> None:
        self._db.add(execution)
        await self._db.flush()

    async def update_execution(self, execution: MonitoringExecution) -> None:
        await self._db.flush()

    async def add_snapshot(self, snapshot: MonitoringSnapshot) -> None:
        self._db.add(snapshot)

    async def add_change(self, change: MonitoringChange) -> None:
        self._db.add(change)

    async def add_alert(self, alert: MonitoringAlert) -> None:
        self._db.add(alert)

    async def get_executions(self, domain: str, limit: int = 20) -> list[MonitoringExecution]:
        r = await self._db.execute(
            select(MonitoringExecution)
            .where(MonitoringExecution.domain == domain)
            .order_by(MonitoringExecution.started_at.desc())
            .limit(limit)
        )
        return list(r.scalars().all())

    async def get_execution(self, execution_id: str) -> MonitoringExecution | None:
        r = await self._db.execute(
            select(MonitoringExecution).where(MonitoringExecution.id == execution_id)
        )
        return r.scalar_one_or_none()

    async def get_last_snapshot(self, domain: str, snapshot_type: str) -> MonitoringSnapshot | None:
        r = await self._db.execute(
            select(MonitoringSnapshot)
            .where(
                MonitoringSnapshot.domain == domain,
                MonitoringSnapshot.snapshot_type == snapshot_type,
            )
            .order_by(MonitoringSnapshot.created_at.desc())
            .limit(1)
        )
        return r.scalar_one_or_none()

    async def get_changes(self, execution_id: str) -> list[MonitoringChange]:
        r = await self._db.execute(
            select(MonitoringChange).where(MonitoringChange.execution_id == execution_id)
        )
        return list(r.scalars().all())

    async def get_alerts(self, domain: str, limit: int = 50) -> list[MonitoringAlert]:
        r = await self._db.execute(
            select(MonitoringAlert)
            .where(MonitoringAlert.domain == domain)
            .order_by(MonitoringAlert.created_at.desc())
            .limit(limit)
        )
        return list(r.scalars().all())

    async def flush(self) -> None:
        await self._db.flush()
