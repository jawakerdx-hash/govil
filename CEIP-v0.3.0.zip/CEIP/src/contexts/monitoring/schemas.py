"""Pydantic schemas for monitoring API."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class MonitorStartRequest(BaseModel):
    domain: str = Field(min_length=3, max_length=255)
    schedule: str = Field(default="manual", pattern=r"^(manual|hourly|daily|weekly)$")


class MonitorJobResponse(BaseModel):
    id: UUID
    domain: str
    schedule: str
    enabled: bool
    last_run_at: datetime | None = None
    next_run_at: datetime | None = None
    created_at: datetime
    model_config = {"from_attributes": True}


class ExecutionResponse(BaseModel):
    id: UUID
    domain: str
    status: str
    duration_ms: int | None = None
    trigger: str
    scan_version: int
    started_at: datetime
    finished_at: datetime | None = None
    error: str | None = None
    model_config = {"from_attributes": True}


class ChangeResponse(BaseModel):
    id: UUID
    change_type: str
    entity_type: str
    entity_identifier: str
    previous_value: str | None = None
    new_value: str | None = None
    severity: str
    detected_at: datetime
    model_config = {"from_attributes": True}


class AlertResponse(BaseModel):
    id: UUID
    alert_type: str
    title: str
    description: str | None = None
    severity: str
    acknowledged: bool
    created_at: datetime
    model_config = {"from_attributes": True}


class MonitorRunResponse(BaseModel):
    execution_id: UUID
    domain: str
    status: str
    duration_ms: int
    changes_count: int
    alerts_count: int
    changes: list[ChangeResponse] = []
    alerts: list[AlertResponse] = []
    summary: str = ""


class MonitorHistoryResponse(BaseModel):
    domain: str
    executions: list[ExecutionResponse] = []
    total: int = 0
