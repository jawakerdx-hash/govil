"""Monitoring service — orchestrates existing contexts, detects changes, generates alerts."""

from __future__ import annotations

import hashlib
import json
import time
from datetime import UTC, datetime
from typing import Any

from src.contexts.correlation.service import CorrelationService
from src.contexts.discovery.service import DiscoveryService
from src.contexts.monitoring.models import (
    MonitoringAlert,
    MonitoringChange,
    MonitoringExecution,
    MonitoringJob,
    MonitoringSnapshot,
)
from src.contexts.monitoring.repository import MonitoringRepository
from src.contexts.threat.service import ThreatService
from src.contexts.vulnerability.service import VulnerabilityService


class MonitoringService:
    """Orchestrates recurring discovery and change detection across all contexts."""

    def __init__(self, db: Any, repo: MonitoringRepository) -> None:
        self._db = db
        self._repo = repo

    async def start_job(self, domain: str, schedule: str = "manual") -> MonitoringJob:
        """Create or update a monitoring job."""
        job = await self._repo.get_job(domain)
        if job is None:
            job = MonitoringJob(domain=domain, schedule=schedule)
            await self._repo.create_job(job)
        else:
            job.schedule = schedule
            job.enabled = True
            await self._repo.flush()
        return job

    async def run(self, domain: str, trigger: str = "manual") -> dict[str, Any]:
        """Execute a full monitoring run: discover, snapshot, compare, alert."""
        domain = domain.lower().strip()
        t0 = time.perf_counter()

        # Create execution record
        version = await self._next_version(domain)
        execution = MonitoringExecution(
            job_id="manual", domain=domain, status="running",
            trigger=trigger, scan_version=version,
        )
        await self._repo.add_execution(execution)

        snapshot_data: dict[str, Any] = {}
        changes: list[MonitoringChange] = []
        alerts: list[MonitoringAlert] = []
        try:
            # 1. Discovery
            disc_svc = DiscoveryService(self._db)
            job = await disc_svc.start(domain)
            full_job = await disc_svc.get_job(job.id)
            if full_job:
                snapshot_data["discovery"] = {
                    "dns_count": len(full_job.dns_records),
                    "subdomain_count": len(full_job.subdomains),
                    "service_count": len(full_job.services),
                    "certificate_count": len(full_job.certificates),
                    "dns_records": [f"{r.record_type}:{r.value}" for r in full_job.dns_records],
                    "subdomains": [s.name for s in full_job.subdomains],
                    "services": [f"{s.host}:{s.port}:{s.server or ''}" for s in full_job.services],
                    "certificates": [f"{c.host}:{c.issuer or ''}" for c in full_job.certificates],
                }

            # 2. Correlation
            corr_svc = CorrelationService(self._db)
            corr_result = await corr_svc.correlate(domain)
            snapshot_data["correlation"] = {
                "relationship_count": len(corr_result.get("relationships", [])),
                "cluster_count": len(corr_result.get("clusters", [])),
            }

            # 3. Vulnerability
            vuln_svc = VulnerabilityService(self._db)
            vuln_result = await vuln_svc.assess(domain)
            findings_list = vuln_result.get("findings", [])
            snapshot_data["vulnerability"] = {
                "finding_count": len(findings_list),
                "findings": [
                    (
                        f"{f.get('severity')}:"
                        f"{f.get('cve_id') or f.get('finding_type')}:"
                        f"{str(f.get('title',''))[:80]}"
                    )
                    for f in findings_list
                ],
            }

            # 4. Threat
            threat_svc = ThreatService(self._db)
            threat_result = await threat_svc.assess(domain)
            matches = threat_result.get("matches", [])
            snapshot_data["threat"] = {
                "match_count": len(matches),
                "matches": [
                    f"{m.get('severity')}:{m.get('threat_category')}:{m.get('matched_asset')}"
                    for m in matches
                ],
            }

            # 5. Identity Exposure
            try:
                from src.contexts.identity_exposure.repository import IdentityExposureRepository
                from src.contexts.identity_exposure.service import IdentityExposureService
                id_repo = IdentityExposureRepository(self._db)
                id_svc = IdentityExposureService(repo=id_repo)
                id_result = await id_svc.scan(domain)
                snapshot_data["identity"] = {
                    "exposure_count": id_result.get("total_exposures", 0),
                    "exposures": [
                        f"{e.get('severity')}:{e.get('identity_type')}:{e.get('value','')[:60]}"
                        for e in id_result.get("exposures", [])
                    ],
                }
            except Exception:
                snapshot_data["identity"] = {"exposure_count": 0, "exposures": []}

            # 6. Risk
            try:
                from src.contexts.risk.engine import RiskEngine
                risk_engine = RiskEngine(self._db)
                risk_result = await risk_engine.assess(domain)
                snapshot_data["risk"] = {
                    "overall_score": risk_result.get("overall_score", 0),
                    "overall_level": risk_result.get("overall_risk_level", "LOW"),
                }
            except Exception:
                snapshot_data["risk"] = {"overall_score": 0, "overall_level": "LOW"}

            # Save snapshots
            for stype, data in snapshot_data.items():
                data_str = json.dumps(data, sort_keys=True)
                checksum = hashlib.sha256(data_str.encode()).hexdigest()[:16]
                snap = MonitoringSnapshot(
                    execution_id=str(execution.id), domain=domain,
                    snapshot_type=stype, data_json=data_str, checksum=checksum,
                )
                await self._repo.add_snapshot(snap)

            # Detect changes vs previous execution
            changes = await self._detect_changes(domain, str(execution.id), snapshot_data)
            for c in changes:
                await self._repo.add_change(c)

            # Generate alerts
            alerts = self._generate_alerts(domain, str(execution.id), changes)
            for a in alerts:
                await self._repo.add_alert(a)

            execution.status = "completed"
        except Exception as exc:
            execution.status = "failed"
            execution.error = str(exc)

        elapsed = int((time.perf_counter() - t0) * 1000)
        execution.duration_ms = elapsed
        execution.finished_at = datetime.now(UTC)
        await self._repo.update_execution(execution)
        await self._repo.flush()

        return {
            "execution_id": execution.id,
            "domain": domain,
            "status": execution.status,
            "duration_ms": elapsed,
            "changes_count": len(changes),
            "alerts_count": len(alerts),
            "changes": [
                {"change_type": c.change_type, "entity_type": c.entity_type,
                 "entity_identifier": c.entity_identifier, "severity": c.severity,
                 "previous_value": c.previous_value, "new_value": c.new_value,
                 "detected_at": c.detected_at, "id": c.id}
                for c in changes
            ],
            "alerts": [
                {"alert_type": a.alert_type, "title": a.title, "severity": a.severity,
                 "description": a.description, "acknowledged": a.acknowledged,
                 "created_at": a.created_at, "id": a.id}
                for a in alerts
            ],
            "summary": (
                f"Monitoring run completed in {elapsed}ms. "
                f"{len(changes)} changes, "
                f"{len(alerts)} alerts."
            ),
        }

    async def get_history(self, domain: str) -> dict[str, Any]:
        executions = await self._repo.get_executions(domain)
        return {
            "domain": domain,
            "executions": [
                {
                    "id": e.id, "domain": e.domain, "status": e.status,
                    "duration_ms": e.duration_ms, "trigger": e.trigger,
                    "scan_version": e.scan_version, "started_at": e.started_at,
                    "finished_at": e.finished_at, "error": e.error,
                }
                for e in executions
            ],
            "total": len(executions),
        }

    async def get_diff(self, domain: str) -> dict[str, Any]:
        executions = await self._repo.get_executions(domain, limit=2)
        if len(executions) < 2:
            return {
                "domain": domain, "changes": [],
                "summary": "Need at least 2 executions for diff",
            }
        changes = await self._repo.get_changes(str(executions[0].id))
        return {
            "domain": domain,
            "current_execution": str(executions[0].id),
            "previous_execution": str(executions[1].id),
            "changes": [
                {"change_type": c.change_type, "entity_type": c.entity_type,
                 "entity_identifier": c.entity_identifier, "severity": c.severity}
                for c in changes
            ],
            "summary": f"{len(changes)} changes detected",
        }

    async def get_alerts(self, domain: str) -> dict[str, Any]:
        alerts = await self._repo.get_alerts(domain)
        return {
            "domain": domain,
            "alerts": [
                {"id": a.id, "alert_type": a.alert_type, "title": a.title,
                 "severity": a.severity, "acknowledged": a.acknowledged,
                 "created_at": a.created_at}
                for a in alerts
            ],
            "total": len(alerts),
        }

    # ------------------------------------------------------------------
    # Change detection
    # ------------------------------------------------------------------

    async def _detect_changes(
        self, domain: str, execution_id: str, current: dict[str, Any]
    ) -> list[MonitoringChange]:
        """Compare current snapshots against previous and detect changes."""
        changes: list[MonitoringChange] = []
        now = datetime.now(UTC)

        for stype, data in current.items():
            prev = await self._repo.get_last_snapshot(domain, stype)
            if prev is None:
                continue  # First run, no baseline

            try:
                prev_data = json.loads(prev.data_json)
            except json.JSONDecodeError:
                continue

            if stype == "discovery":
                changes.extend(self._diff_lists(
                    execution_id, domain, "discovery", "dns_record",
                    prev_data.get("dns_records", []), data.get("dns_records", []), now,
                ))
                changes.extend(self._diff_lists(
                    execution_id, domain, "discovery", "subdomain",
                    prev_data.get("subdomains", []), data.get("subdomains", []), now,
                ))
                changes.extend(self._diff_lists(
                    execution_id, domain, "discovery", "service",
                    prev_data.get("services", []), data.get("services", []), now,
                ))

            elif stype == "vulnerability":
                prev_count = prev_data.get("finding_count", 0)
                curr_count = data.get("finding_count", 0)
                if curr_count > prev_count:
                    changes.append(MonitoringChange(
                        execution_id=execution_id, domain=domain,
                        change_type="RISK_INCREASE", entity_type="vulnerability",
                        entity_identifier=f"{domain}/findings",
                        previous_value=str(prev_count), new_value=str(curr_count),
                        severity="HIGH", detected_at=now,
                    ))

            elif stype == "threat":
                prev_count = prev_data.get("match_count", 0)
                curr_count = data.get("match_count", 0)
                if curr_count > prev_count:
                    changes.append(MonitoringChange(
                        execution_id=execution_id, domain=domain,
                        change_type="THREAT_MATCH", entity_type="threat",
                        entity_identifier=f"{domain}/threats",
                        previous_value=str(prev_count), new_value=str(curr_count),
                        severity="CRITICAL", detected_at=now,
                    ))

            elif stype == "risk":
                prev_score = prev_data.get("overall_score", 0)
                curr_score = data.get("overall_score", 0)
                if curr_score > prev_score + 5:
                    changes.append(MonitoringChange(
                        execution_id=execution_id, domain=domain,
                        change_type="RISK_INCREASE", entity_type="risk",
                        entity_identifier=f"{domain}/risk",
                        previous_value=str(prev_score), new_value=str(curr_score),
                        severity="HIGH", detected_at=now,
                    ))

        return changes

    @staticmethod
    def _diff_lists(
        execution_id: str, domain: str, change_type: str, entity_type: str,
        prev_list: list[str], curr_list: list[str], now: datetime,
    ) -> list[MonitoringChange]:
        changes: list[MonitoringChange] = []
        prev_set = set(prev_list)
        curr_set = set(curr_list)
        for item in curr_set - prev_set:
            changes.append(MonitoringChange(
                execution_id=execution_id, domain=domain,
                change_type=f"NEW_{entity_type.upper()}", entity_type=entity_type,
                entity_identifier=item,
                previous_value=None, new_value=item,
                severity="MEDIUM", detected_at=now,
            ))
        for item in prev_set - curr_set:
            changes.append(MonitoringChange(
                execution_id=execution_id, domain=domain,
                change_type=f"REMOVED_{entity_type.upper()}", entity_type=entity_type,
                entity_identifier=item,
                previous_value=item, new_value=None,
                severity="LOW", detected_at=now,
            ))
        return changes

    def _generate_alerts(
        self, domain: str, execution_id: str, changes: list[MonitoringChange]
    ) -> list[MonitoringAlert]:
        """Generate alerts for meaningful changes."""
        alerts: list[MonitoringAlert] = []
        alert_map = {
            "NEW_DNS_RECORD": ("NEW_ASSET", "New DNS record detected", "MEDIUM"),
            "NEW_SUBDOMAIN": ("NEW_ASSET", "New subdomain discovered", "MEDIUM"),
            "NEW_SERVICE": ("NEW_PUBLIC_SERVICE", "New service detected", "HIGH"),
            "REMOVED_SERVICE": ("CLOSED_SERVICE", "Service no longer accessible", "LOW"),
            "RISK_INCREASE": ("RISK_INCREASE", "Risk score increased", "HIGH"),
            "THREAT_MATCH": ("THREAT_MATCH", "New threat intelligence match", "CRITICAL"),
            "NEW_CERTIFICATE": ("NEW_CERTIFICATE", "New SSL certificate detected", "MEDIUM"),
        }
        for c in changes:
            alert_def = alert_map.get(c.change_type)
            if alert_def is None:
                if "NEW_" in c.change_type:
                    alert_def = ("NEW_ASSET", f"New {c.entity_type}: {c.entity_identifier}", "INFO")
                else:
                    continue
            alert_type, title, severity = alert_def
            alerts.append(MonitoringAlert(
                execution_id=execution_id, domain=domain,
                alert_type=alert_type,
                title=f"{title}: {c.entity_identifier[:80]}",
                description=(
                    f"{c.change_type}: "
                    f"'{c.previous_value or 'none'}' -> '{c.new_value or 'none'}'"
                ),
                severity=severity,
            ))
        return alerts

    async def _next_version(self, domain: str) -> int:
        executions = await self._repo.get_executions(domain, limit=1)
        if not executions:
            return 1
        return (executions[0].scan_version or 0) + 1
