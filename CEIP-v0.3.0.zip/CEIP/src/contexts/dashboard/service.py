"""Dashboard service — read-only aggregation from persisted data only.

NEVER calls business engines. Reads from repositories and snapshot tables.
"""
# ruff: noqa: E501  — SQLAlchemy queries are naturally long

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


class DashboardService:
    """Read-only aggregation layer. No engines called. Reads persisted data only."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def executive(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        risk = await self._read_risk_snapshot(domain)
        vuln = await self._read_persisted_findings(domain)
        threat = await self._read_persisted_threats(domain)
        identity = await self._read_persisted_exposures(domain)
        monitor = await self._read_monitor_data(domain)
        discovery = await self._read_discovery_snapshot(domain)
        trend = await self._read_trend(domain)

        return {
            "domain": domain,
            "overall_score": risk.get("overall_score", 0),
            "overall_level": risk.get("overall_level", "LOW"),
            "asset_count": discovery.get("service_count", 0),
            "internet_facing": discovery.get("service_count", 0),
            "critical_findings": risk.get("critical_count", 0),
            "high_findings": risk.get("high_count", 0),
            "threat_matches": threat.get("count", 0),
            "identity_exposures": identity.get("count", 0),
            "monitoring_alerts": monitor.get("alert_count", 0),
            "new_assets_24h": monitor.get("changes_24h", 0),
            "risk_trend": trend,
            "top_assets": risk.get("top_assets", []),
            "recent_changes": monitor.get("recent_changes", []),
            "executive_summary": (
                f"{domain}: Overall risk {risk.get('overall_level', 'LOW')} "
                f"({risk.get('overall_score', 0)}/100). "
                f"{vuln.get('count', 0)} findings, "
                f"{threat.get('count', 0)} threat matches, "
                f"{identity.get('count', 0)} identity exposures. "
                f"{monitor.get('alert_count', 0)} monitoring alerts."
            ),
        }

    async def soc(self, domain: str) -> dict[str, Any]:
        domain = domain.lower().strip()
        vuln = await self._read_persisted_findings(domain)
        threat = await self._read_persisted_threats(domain)
        identity = await self._read_persisted_exposures(domain)
        monitor = await self._read_monitor_data(domain)
        discovery = await self._read_discovery_snapshot(domain)

        findings_list = vuln.get("findings", [])
        return {
            "domain": domain,
            "critical_vulnerabilities": [
                f"[{f.get('severity','?').upper()}] {f.get('cve_id') or 'MISCONFIG'}: "
                f"{str(f.get('title',''))[:80]}"
                for f in findings_list if f.get("severity") == "critical"
            ][:5],
            "newest_findings": [
                f"[{f.get('severity','?').upper()}] {f.get('cve_id') or 'MISCONFIG'}: "
                f"{str(f.get('title',''))[:80]}"
                for f in findings_list[:5]
            ],
            "open_alerts": monitor.get("alerts", [])[:5],
            "threat_matches": threat.get("matches", [])[:5],
            "identity_exposures": identity.get("exposures", [])[:5],
            "latest_changes": monitor.get("changes", [])[:10],
            "assets_by_risk": discovery.get("assets_by_risk", {}),
            "assets_by_technology": discovery.get("tech", {}),
            "certs_expiring_soon": [],
            "newest_services": discovery.get("services", [])[:5],
            "recent_dns_changes": [
                c for c in monitor.get("changes", []) if "dns" in c.lower()
            ][:5],
            "recent_cert_changes": [
                c for c in monitor.get("changes", []) if "cert" in c.lower()
            ][:5],
        }

    async def summary(self, domain: str) -> dict[str, Any]:
        exec_data = await self.executive(domain)
        return {"domain": domain, "summary": exec_data.get("executive_summary", "")}

    # ------------------------------------------------------------------
    # Read helpers — load PERSISTED data only, never call engines
    # ------------------------------------------------------------------

    async def _read_risk_snapshot(self, domain: str) -> dict[str, Any]:
        """Read risk from last monitoring snapshot, not from RiskEngine."""
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot
            r = await self._db.execute(
                select(MonitoringSnapshot)
                .where(MonitoringSnapshot.domain == domain, MonitoringSnapshot.snapshot_type == "risk")
                .order_by(MonitoringSnapshot.created_at.desc())
                .limit(1)
            )
            snap = r.scalar_one_or_none()
            if snap:
                data = json.loads(snap.data_json)
                return {
                    "overall_score": data.get("overall_score", 0),
                    "overall_level": data.get("overall_level", "LOW"),
                    "critical_count": 0, "high_count": 0, "top_assets": [],
                }
        except Exception:
            pass
        return {"overall_score": 0, "overall_level": "LOW", "critical_count": 0, "high_count": 0, "top_assets": []}

    async def _read_persisted_findings(self, domain: str) -> dict[str, Any]:
        """Read findings from the security_findings table, not VulnerabilityService."""
        try:
            from src.contexts.vulnerability.models import SecurityFinding
            r = await self._db.execute(
                select(SecurityFinding).where(SecurityFinding.domain == domain)
            )
            findings = r.scalars().all()
            return {
                "count": len(findings),
                "findings": [
                    {"severity": f.severity, "cve_id": f.cve_id, "title": f.title}
                    for f in findings
                ],
            }
        except Exception:
            return {"count": 0, "findings": []}

    async def _read_persisted_threats(self, domain: str) -> dict[str, Any]:
        """Read threats from threat_matches table, not ThreatService."""
        try:
            from src.contexts.threat.models import ThreatMatch
            r = await self._db.execute(
                select(ThreatMatch).where(ThreatMatch.domain == domain)
            )
            matches = r.scalars().all()
            return {
                "count": len(matches),
                "matches": [
                    f"[{m.severity}] {m.threat_category}: {m.matched_asset[:60]}"
                    for m in matches
                ],
            }
        except Exception:
            return {"count": 0, "matches": []}

    async def _read_persisted_exposures(self, domain: str) -> dict[str, Any]:
        """Read exposures from identity_exposures table, not IdentityExposureService."""
        try:
            from src.contexts.identity_exposure.models import IdentityExposure
            r = await self._db.execute(
                select(IdentityExposure).where(IdentityExposure.domain == domain)
            )
            rows = r.scalars().all()
            return {
                "count": len(rows),
                "exposures": [
                    f"[{e.severity}] {e.identity_type}: {e.value[:60]}"
                    for e in rows
                ],
            }
        except Exception:
            return {"count": 0, "exposures": []}

    async def _read_monitor_data(self, domain: str) -> dict[str, Any]:
        """Read monitoring data from persisted tables."""
        try:
            from src.contexts.monitoring.models import MonitoringAlert, MonitoringChange
            alerts_r = await self._db.execute(
                select(MonitoringAlert).where(MonitoringAlert.domain == domain)
                .order_by(MonitoringAlert.created_at.desc()).limit(20)
            )
            alerts = alerts_r.scalars().all()
            changes_r = await self._db.execute(
                select(MonitoringChange).where(MonitoringChange.domain == domain)
                .order_by(MonitoringChange.detected_at.desc()).limit(20)
            )
            changes = changes_r.scalars().all()
            return {
                "alert_count": len(alerts),
                "alerts": [f"[{a.severity}] {a.alert_type}: {a.title[:80]}" for a in alerts],
                "changes_24h": len(changes),
                "recent_changes": [c.entity_identifier for c in changes],
                "changes": [f"{c.change_type}: {c.entity_identifier}" for c in changes],
            }
        except Exception:
            return {"alert_count": 0, "alerts": [], "changes_24h": 0, "recent_changes": [], "changes": []}

    async def _read_discovery_snapshot(self, domain: str) -> dict[str, Any]:
        """Read discovery from last snapshot."""
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot
            r = await self._db.execute(
                select(MonitoringSnapshot)
                .where(MonitoringSnapshot.domain == domain, MonitoringSnapshot.snapshot_type == "discovery")
                .order_by(MonitoringSnapshot.created_at.desc())
                .limit(1)
            )
            snap = r.scalar_one_or_none()
            if snap:
                data = json.loads(snap.data_json)
                return {
                    "service_count": data.get("service_count", 0),
                    "dns_count": data.get("dns_count", 0),
                    "subdomain_count": data.get("subdomain_count", 0),
                    "cert_count": data.get("certificate_count", 0),
                    "services": data.get("services", []),
                    "assets_by_risk": {"critical": 0, "high": 0, "medium": 0, "low": 0},
                    "tech": {
                        "services": data.get("service_count", 0),
                        "dns_records": data.get("dns_count", 0),
                        "subdomains": data.get("subdomain_count", 0),
                        "certificates": data.get("certificate_count", 0),
                    },
                }
        except Exception:
            pass
        return {"service_count": 0, "services": [], "assets_by_risk": {}, "tech": {}}

    async def _read_trend(self, domain: str) -> list[dict[str, Any]]:
        """Read risk trend from monitoring snapshots."""
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot
            r = await self._db.execute(
                select(MonitoringSnapshot)
                .where(MonitoringSnapshot.domain == domain, MonitoringSnapshot.snapshot_type == "risk")
                .order_by(MonitoringSnapshot.created_at.asc())
                .limit(30)
            )
            snaps = r.scalars().all()
            trend = []
            for s in snaps:
                try:
                    data = json.loads(s.data_json)
                    trend.append({
                        "date": s.created_at.isoformat() if s.created_at else "",
                        "score": data.get("overall_score", 0),
                        "level": data.get("overall_level", "LOW"),
                    })
                except (json.JSONDecodeError, TypeError):
                    pass
            return trend
        except Exception:
            return []
