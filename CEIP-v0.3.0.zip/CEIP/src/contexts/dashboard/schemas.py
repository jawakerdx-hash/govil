"""Dashboard response schemas."""

from __future__ import annotations

from pydantic import BaseModel


class RiskTrendPoint(BaseModel):
    date: str
    score: float
    level: str


class TopAsset(BaseModel):
    identifier: str
    asset_type: str
    risk_score: float
    risk_level: str
    critical_findings: int = 0
    threat_matches: int = 0


class ExecutiveDashboard(BaseModel):
    domain: str
    overall_score: float
    overall_level: str
    asset_count: int
    internet_facing: int
    critical_findings: int
    high_findings: int
    threat_matches: int
    identity_exposures: int
    monitoring_alerts: int
    new_assets_24h: int
    risk_trend: list[RiskTrendPoint] = []
    top_assets: list[TopAsset] = []
    recent_changes: list[str] = []
    executive_summary: str = ""


class SOCDashboard(BaseModel):
    domain: str
    critical_vulnerabilities: list[str] = []
    newest_findings: list[str] = []
    open_alerts: list[str] = []
    threat_matches: list[str] = []
    identity_exposures: list[str] = []
    latest_changes: list[str] = []
    assets_by_risk: dict[str, int] = {}
    assets_by_technology: dict[str, int] = {}
    certs_expiring_soon: list[str] = []
    newest_services: list[str] = []
    recent_dns_changes: list[str] = []
    recent_cert_changes: list[str] = []


class DashboardSummary(BaseModel):
    domain: str
    summary: str = ""
