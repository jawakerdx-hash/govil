"""Correlation ORM models — relationships, clusters, exposure groups."""

from __future__ import annotations

from sqlalchemy import Float, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class AssetRelationship(UUIDMixin, TimestampMixin, Base):
    """A directed relationship between two discovered assets."""

    __tablename__ = "asset_relationships"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    source_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # domain, subdomain, ip, service, certificate
    source_value: Mapped[str] = mapped_column(String(512), nullable=False)
    target_type: Mapped[str] = mapped_column(String(32), nullable=False)
    target_value: Mapped[str] = mapped_column(String(512), nullable=False)
    relationship: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # resolves_to, shares_ip, shares_cert, shares_asn, shares_cdn
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)


class AssetCluster(UUIDMixin, TimestampMixin, Base):
    """A group of related assets discovered via correlation rules."""

    __tablename__ = "asset_clusters"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    cluster_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # ip_group, asn_group, cert_group, cdn_group
    criteria: Mapped[str | None] = mapped_column(Text, nullable=True)
    member_count: Mapped[int] = mapped_column(default=0)
    members_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class ExposureGroup(UUIDMixin, TimestampMixin, Base):
    """A high-level grouping of assets by exposure pattern."""

    __tablename__ = "exposure_groups"

    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    group_type: Mapped[str] = mapped_column(
        String(32), nullable=False
    )  # infrastructure, cdn, certificate
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    member_count: Mapped[int] = mapped_column(default=0)
    members_json: Mapped[str | None] = mapped_column(Text, nullable=True)
