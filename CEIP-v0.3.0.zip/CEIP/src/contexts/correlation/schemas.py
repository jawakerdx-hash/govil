"""Pydantic schemas for correlation API."""

from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel


class RelationshipResponse(BaseModel):
    """A single asset relationship."""

    id: UUID
    source_type: str
    source_value: str
    target_type: str
    target_value: str
    relationship: str
    confidence: float
    evidence: str | None = None

    model_config = {"from_attributes": True}


class ClusterResponse(BaseModel):
    """An asset cluster."""

    id: UUID
    name: str
    cluster_type: str
    criteria: str | None = None
    member_count: int = 0
    members_json: str | None = None

    model_config = {"from_attributes": True}


class ExposureGroupResponse(BaseModel):
    """An exposure group."""

    id: UUID
    name: str
    group_type: str
    description: str | None = None
    member_count: int = 0
    members_json: str | None = None

    model_config = {"from_attributes": True}


class CorrelationResponse(BaseModel):
    """Complete correlation results for a domain."""

    domain: str
    relationships: list[RelationshipResponse] = []
    clusters: list[ClusterResponse] = []
    exposure_groups: list[ExposureGroupResponse] = []
    summary: str = ""
