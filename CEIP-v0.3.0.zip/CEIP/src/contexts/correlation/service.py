"""Correlation engine — builds asset relationships from discovery data."""

from __future__ import annotations

import json
from collections import defaultdict
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.correlation.models import AssetCluster, AssetRelationship, ExposureGroup
from src.contexts.discovery.models import (
    Certificate,
    DiscoveryJob,
    DNSRecord,
    IPEnrichment,
    Service,
    Subdomain,
)
from src.contexts.discovery.repository import DiscoveryRepository


class CorrelationService:
    """Analyze discovery data and build an asset relationship graph."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._discovery_repo = DiscoveryRepository(db)

    async def correlate(self, domain: str) -> dict[str, Any]:
        """Run all correlation rules against a domain's discovery data."""

        domain = domain.lower().strip()

        # Load discovery data
        job = await self._latest_job(domain)
        if job is None:
            return {"relationships": [], "clusters": [], "exposure_groups": [],
                    "summary": f"No discovery data found for {domain}"}

        dns: list[DNSRecord] = job.dns_records
        services: list[Service] = job.services
        certs: list[Certificate] = job.certificates
        enrichments: list[IPEnrichment] = job.ip_enrichments

        relationships: list[dict[str, Any]] = []
        clusters: list[dict[str, Any]] = []
        exposure_groups: list[dict[str, Any]] = []

        # ---- Rule 1: Domain/Subdomain → IP mapping ----
        ip_map: dict[str, set[Any]] = defaultdict(set)  # IP → domains
        domain_ips: dict[str, set[Any]] = defaultdict(set)  # domain → IPs

        for r in dns:
            if r.record_type in ("A", "AAAA"):
                ip_map[r.value].add(r.name)
                domain_ips[r.name].add(r.value)

        for name, ips in domain_ips.items():
            for ip_addr in ips:
                relationships.append({
                    "source_type": "subdomain" if name != domain else "domain",
                    "source_value": name,
                    "target_type": "ip",
                    "target_value": ip_addr,
                    "relationship": "resolves_to",
                    "confidence": 1.0,
                    "evidence": f"DNS {self._guess_type(name, dns)} record",
                })

        # ---- Rule 2: Shared IP grouping ----
        for ip_addr, names in ip_map.items():
            if len(names) > 1:
                asn_info = ""
                for e in enrichments:
                    if e.ip == ip_addr:
                        asn_info = f" (ASN={e.asn})"
                        break
                name_list = sorted(names)
                clusters.append({
                    "name": f"Shared IP: {ip_addr}{asn_info}",
                    "cluster_type": "ip_group",
                    "criteria": f"All domains resolving to {ip_addr}",
                    "members_json": json.dumps(name_list),
                    "member_count": len(name_list),
                })

        # ---- Rule 3: Certificate → Domain mapping (SANs) ----
        cert_domains: dict[str, set[Any]] = defaultdict(set)
        for c in certs:
            if c.sans_json:
                try:
                    sans = json.loads(c.sans_json)
                    for san in sans:
                        cert_domains[c.host].add(san)
                except (json.JSONDecodeError, TypeError):
                    pass

        for host, sans in cert_domains.items():
            for san in sans:
                if san != host:
                    relationships.append({
                        "source_type": "certificate",
                        "source_value": host,
                        "target_type": "domain",
                        "target_value": san,
                        "relationship": "shares_cert",
                        "confidence": 0.9,
                        "evidence": f"SAN entry in certificate for {host}",
                    })

        # ---- Rule 4: Shared ASN grouping ----
        asn_ips: dict[str, list[Any]] = defaultdict(list)
        asn_org = ""
        for e in enrichments:
            if e.asn:
                asn_ips[e.asn].append(e.ip)
                if e.asn_org:
                    asn_org = e.asn_org

        for asn, asn_ip_list in asn_ips.items():
            if len(asn_ip_list) > 1:
                ip_list = sorted(str(i) for i in asn_ip_list)
                clusters.append({
                    "name": f"ASN {asn} ({asn_org})",
                    "cluster_type": "asn_group",
                    "criteria": f"All IPs in ASN {asn}",
                    "members_json": json.dumps(ip_list),
                    "member_count": len(ip_list),
                })

        # ---- Rule 5: Shared CDN / hosting provider ----
        server_groups: dict[str, set[Any]] = defaultdict(set)
        for svc in services:
            server = svc.server or "(no header)"
            server_groups[server].add(svc.host)

        for server, hosts in server_groups.items():
            if len(hosts) > 1 and server != "(no header)":
                cdn = "cdn" if any(
                    c in server.lower() for c in ("cloudflare", "akamai", "fastly", "cloudfront")
                ) else "hosting"
                clusters.append({
                    "name": f"Shared server: {server}",
                    "cluster_type": f"{cdn}_group",
                    "criteria": f"Server header '{server}' on multiple hosts",
                    "members_json": json.dumps(sorted(hosts)),
                    "member_count": len(hosts),
                })

        # ---- Rule 6: Shared TLS issuer grouping ----
        issuer_hosts: dict[str, set[Any]] = defaultdict(set)
        for c in certs:
            issuer = c.issuer or "(unknown)"
            issuer_hosts[issuer].add(c.host)

        for issuer, hosts in issuer_hosts.items():
            if len(hosts) > 1 and issuer != "(unknown)":
                clusters.append({
                    "name": f"Shared TLS issuer: {issuer[:60]}",
                    "cluster_type": "cert_group",
                    "criteria": f"TLS certificate issued by {issuer[:80]}",
                    "members_json": json.dumps(sorted(hosts)),
                    "member_count": len(hosts),
                })

        # ---- Exposure Groups (high level) ----
        if ip_map:
            all_ips: set[Any] = set()
            for ip_set in ip_map.values():
                all_ips.update(ip_set)
            exposure_groups.append({
                "name": f"{domain} — Asset Inventory",
                "group_type": "infrastructure",
                "description": (
                    f"{len(domain_ips)} hostnames, {len(all_ips)} unique IPs, "
                    f"{len(services)} services, {len(certs)} certificates"
                ),
                "members_json": json.dumps({
                    "hostnames": list(domain_ips.keys()),
                    "ips": sorted(all_ips),
                }),
                "member_count": len(domain_ips),
            })

        # Persist results
        await self._persist(domain, relationships, clusters, exposure_groups)

        return {
            "domain": domain,
            "relationships": relationships,
            "clusters": clusters,
            "exposure_groups": exposure_groups,
            "summary": (
                f"{len(relationships)} relationships, "
                f"{len(clusters)} clusters, "
                f"{len(exposure_groups)} exposure groups"
            ),
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _latest_job(self, domain: str) -> DiscoveryJob | None:
        """Fetch the most recent completed discovery job for a domain."""
        return await self._discovery_repo.get_latest_done(domain)

    @staticmethod
    def _guess_type(name: str, dns: list[DNSRecord]) -> str:
        for r in dns:
            if r.record_type == "A" and r.name == name:
                return "A"
            if r.record_type == "AAAA" and r.name == name:
                return "AAAA"
        return "A"

    async def _persist(
        self,
        domain: str,
        relationships: list[dict[str, Any]],
        clusters: list[dict[str, Any]],
        exposure_groups: list[dict[str, Any]],
    ) -> None:
        """Store correlation results in the database."""
        # Clear previous results
        for model in (AssetRelationship, AssetCluster, ExposureGroup):
            stmt = select(model).where(model.domain == domain)
            rows = (await self._db.execute(stmt)).scalars().all()
            for row in rows:
                await self._db.delete(row)

        for r in relationships:
            self._db.add(AssetRelationship(
                domain=domain,
                source_type=r["source_type"],
                source_value=r["source_value"],
                target_type=r["target_type"],
                target_value=r["target_value"],
                relationship=r["relationship"],
                confidence=r["confidence"],
                evidence=r.get("evidence"),
            ))

        for c in clusters:
            self._db.add(AssetCluster(
                domain=domain,
                name=c["name"],
                cluster_type=c["cluster_type"],
                criteria=c.get("criteria"),
                members_json=c.get("members_json"),
                member_count=c["member_count"],
            ))

        for g in exposure_groups:
            self._db.add(ExposureGroup(
                domain=domain,
                name=g["name"],
                group_type=g["group_type"],
                description=g.get("description"),
                members_json=g.get("members_json"),
                member_count=g["member_count"],
            ))

        await self._db.flush()
