"""API key management — tenant-scoped, immutable after creation."""

from __future__ import annotations

import hashlib
import secrets
from datetime import UTC, datetime
from typing import Any


class APIKeyManager:
    """Tenant-scoped API key generation and validation. No key storage in plaintext."""

    PREFIX = "ceip_"

    def __init__(self) -> None:
        self._keys: dict[str, dict[str, Any]] = {}  # key_hash -> metadata

    def create_key(self, tenant_id: str, user_id: str, label: str = "") -> dict[str, Any]:
        """Generate a new API key. Returns the key ONCE — store it immediately."""
        raw = f"{self.PREFIX}{secrets.token_hex(24)}"
        key_hash = hashlib.sha256(raw.encode()).hexdigest()

        self._keys[key_hash] = {
            "tenant_id": tenant_id,
            "user_id": user_id,
            "label": label,
            "created_at": datetime.now(UTC).isoformat(),
            "last_used": None,
            "is_active": True,
        }

        return {
            "api_key": raw,
            "key_hash": key_hash[:16],
            "tenant_id": tenant_id,
            "label": label,
            "prefix": self.PREFIX,
            "warning": "Store this key securely. It will not be shown again.",
        }

    def validate(self, api_key: str) -> dict[str, Any] | None:
        """Return key metadata if valid, None if invalid."""
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        meta = self._keys.get(key_hash)
        if meta and meta["is_active"]:
            meta["last_used"] = datetime.now(UTC).isoformat()
            return meta
        return None

    def revoke(self, key_hash: str) -> bool:
        """Revoke an API key. Returns True if found and revoked."""
        meta = self._keys.get(key_hash)
        if meta:
            meta["is_active"] = False
            return True
        return False

    def list_keys(self, tenant_id: str) -> list[dict[str, Any]]:
        """List all keys for a tenant (hashes only, never raw keys)."""
        return [
            {"key_hash": kh[:16], "label": m["label"],
             "created_at": m["created_at"], "last_used": m["last_used"],
             "is_active": m["is_active"]}
            for kh, m in self._keys.items() if m["tenant_id"] == tenant_id
        ]
