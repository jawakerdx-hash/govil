"""JWT authentication — validates tokens on every request using standard PyJWT.

Uses HS256 symmetric signing with the gateway secret. Token payload:
  {"sub": user_id, "tenant_id": tenant_id, "role": role, "exp": now+ttl, "iat": now}
"""

from __future__ import annotations

import os
import time
from typing import Any

import jwt

from .models import ROLE_PERMISSIONS, AuthToken


def _get_secret() -> str:
    """Resolve the signing secret from env, settings, or dev fallback."""
    secret = os.environ.get("CEIP_GATEWAY_SECRET", "")
    if not secret:
        try:
            from src.config import Settings

            secret = Settings().gateway_secret
        except Exception:
            pass
    if not secret:
        secret = "ceip-dev-secret-change-in-production"
    return secret


class AuthEngine:
    """Creates and validates standard JWT tokens (HS256).

    Uses PyJWT for all cryptographic operations — no hand-rolled signing.
    Token expiry is enforced by the library via the standard ``exp`` claim.
    """

    @classmethod
    def validate(cls, token_str: str) -> AuthToken | dict:
        """Validate a JWT token.

        Returns:
            AuthToken on success, error dict on any failure (bad sig, expired, malformed).
        """
        secret = _get_secret()
        try:
            payload: dict[str, Any] = jwt.decode(
                token_str,
                secret,
                algorithms=["HS256"],
                options={"require": ["sub", "tenant_id", "role", "exp"]},
            )
        except jwt.ExpiredSignatureError:
            return {"error": "AUTH_FAILED", "reason": "Token expired"}
        except jwt.InvalidSignatureError:
            return {"error": "AUTH_FAILED", "reason": "Invalid token signature"}
        except jwt.DecodeError:
            return {"error": "AUTH_FAILED", "reason": "Malformed token"}
        except jwt.InvalidTokenError as exc:
            return {"error": "AUTH_FAILED", "reason": str(exc)}
        except Exception as exc:
            return {"error": "AUTH_FAILED", "reason": f"Token validation error: {exc}"}

        user_id = payload.get("sub", "")
        tenant_id = payload.get("tenant_id", "")
        role = payload.get("role", "")
        exp = payload.get("exp")

        if not user_id or not tenant_id or not role:
            return {"error": "AUTH_FAILED", "reason": "Missing required token claims"}

        if role not in ROLE_PERMISSIONS:
            return {"error": "AUTH_FAILED", "reason": f"Unknown role: {role}"}

        permissions = ROLE_PERMISSIONS.get(role, set())

        return AuthToken(
            user_id=user_id,
            tenant_id=tenant_id,
            role=role,
            permissions=permissions,
            expiry=exp,
        )

    @classmethod
    def create_token(
        cls,
        user_id: str,
        tenant_id: str,
        role: str,
        ttl_seconds: int = 3600,
    ) -> str:
        """Create a signed HS256 JWT.

        Args:
            user_id:  The subject identifier (maps to ``sub`` claim).
            tenant_id: Multi-tenancy identifier.
            role:      RBAC role name.
            ttl_seconds: Token lifetime in seconds (default 1 hour).

        Returns:
            Encoded JWT string.
        """
        now = int(time.time())
        payload = {
            "sub": user_id,
            "tenant_id": tenant_id,
            "role": role,
            "iat": now,
            "exp": now + ttl_seconds,
        }
        return jwt.encode(payload, _get_secret(), algorithm="HS256")
