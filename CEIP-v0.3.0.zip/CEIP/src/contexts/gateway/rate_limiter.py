"""Rate limiter — sliding window counter. Per tenant + user + endpoint."""

from __future__ import annotations

import time
from collections import defaultdict


class RateLimiter:
    """Sliding window rate limiter.

    Algorithm: sliding window counter.
    Scope: per tenant_id, per user_id, per endpoint.
    Window size: 60 seconds.
    """

    WINDOW_SIZE_SECONDS = 60

    def __init__(self) -> None:
        self._windows: dict[str, list[float]] = defaultdict(list)

    def remaining(self, tenant_id: str, endpoint: str, limit_rpm: int = 100) -> int:
        key = f"{tenant_id}:{endpoint}"
        now = time.time()
        cutoff = now - self.WINDOW_SIZE_SECONDS
        self._windows[key] = [t for t in self._windows[key] if t > cutoff]
        return max(0, limit_rpm - len(self._windows[key]))

    def check(self, tenant_id: str, endpoint: str, limit_rpm: int = 100) -> dict | None:
        """Return error with retry_after if limit exceeded, None if OK."""
        key = f"{tenant_id}:{endpoint}"
        now = time.time()
        cutoff = now - self.WINDOW_SIZE_SECONDS
        self._windows[key] = [t for t in self._windows[key] if t > cutoff]

        if len(self._windows[key]) >= limit_rpm:
            oldest = self._windows[key][0] if self._windows[key] else now
            retry_after = max(1, int(self.WINDOW_SIZE_SECONDS - (now - oldest)))
            return {
                "error": "RATE_LIMIT_EXCEEDED",
                "retry_after": retry_after,
                "reason": (
                    f"Tenant '{tenant_id}' exceeded {limit_rpm} rpm "
                    f"on '{endpoint}'. Retry after {retry_after}s."
                ),
            }
        self._windows[key].append(now)
        return None
