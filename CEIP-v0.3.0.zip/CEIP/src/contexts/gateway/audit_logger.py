"""Audit logger — immutable, complete request trail."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from .models import AuditEntry


class AuditLogger:
    """Immutable audit log. Logs every gateway request."""

    def __init__(self) -> None:
        self._entries: list[AuditEntry] = []

    def log(self, request_id: str, tenant_id: str, user_id: str,
            endpoint: str, action: str, result_status: str = "success",
            risk_context: str = "", latency_ms: float = 0.0) -> AuditEntry:
        entry = AuditEntry(
            request_id=request_id, tenant_id=tenant_id, user_id=user_id,
            endpoint=endpoint, action=action,
            timestamp=datetime.now(UTC).isoformat(),
            result_status=result_status,
            risk_context_reference=risk_context,
            latency_ms=latency_ms,
        )
        self._entries.append(entry)
        return entry

    def get_entries(self, tenant_id: str | None = None,
                    limit: int = 100) -> list[dict[str, Any]]:
        entries = self._entries
        if tenant_id:
            entries = [e for e in entries if e.tenant_id == tenant_id]
        return [e.to_dict() for e in entries[-limit:]]

    def entry_count(self) -> int:
        return len(self._entries)
