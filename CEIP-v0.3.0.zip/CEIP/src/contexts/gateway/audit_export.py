"""Audit log export — JSON and CSV formats, tenant-scoped."""

from __future__ import annotations

import json
from typing import Any

from .audit_logger import AuditLogger


class AuditExporter:
    """Exports audit logs for compliance and SIEM integration."""

    def __init__(self, logger: AuditLogger) -> None:
        self._logger = logger

    def export_json(self, tenant_id: str, limit: int = 1000) -> str:
        entries = self._logger.get_entries(tenant_id=tenant_id, limit=limit)
        return json.dumps({
            "tenant_id": tenant_id,
            "total_entries": len(entries),
            "exported_at": "",
            "entries": entries,
        }, indent=2, default=str)

    def export_csv(self, tenant_id: str, limit: int = 1000) -> str:
        entries = self._logger.get_entries(tenant_id=tenant_id, limit=limit)
        if not entries:
            return "request_id,tenant_id,user_id,endpoint,method,action,status,timestamp\n"

        headers = ["request_id", "tenant_id", "user_id", "endpoint",
                   "method", "action", "result_status", "timestamp"]
        lines = [",".join(headers)]
        for e in entries:
            lines.append(",".join(
                str(e.get(h, "")) for h in headers
            ))
        return "\n".join(lines)

    def get_summary(self, tenant_id: str) -> dict[str, Any]:
        entries = self._logger.get_entries(tenant_id=tenant_id)
        total = len(entries)
        errors = sum(1 for e in entries if e.get("result_status") == "error")
        return {
            "tenant_id": tenant_id,
            "total_audit_entries": total,
            "error_entries": errors,
            "error_rate": round(errors / max(total, 1), 4),
        }
