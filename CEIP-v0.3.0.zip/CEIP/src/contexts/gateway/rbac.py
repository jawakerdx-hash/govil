"""RBAC engine — deny by default, explicit allow only, no wildcards."""

from __future__ import annotations

from .models import AuthToken


class RBACEngine:
    """Enforces role-based access control. Deny by default."""

    @staticmethod
    def authorize(token: AuthToken, required_permission: str) -> dict | None:
        """Return error dict if access denied, None if allowed."""
        if not token.has_permission(required_permission):
            return {
                "error": "RBAC_ACCESS_DENIED",
                "reason": (
                    f"Role '{token.role}' lacks permission '{required_permission}'. "
                    f"Allowed: {sorted(token.permissions)}"
                ),
            }
        return None

    @staticmethod
    def authorize_any(token: AuthToken, permissions: list[str]) -> dict | None:
        """Allow if user has ANY of the listed permissions."""
        for perm in permissions:
            if token.has_permission(perm):
                return None
        return {
            "error": "RBAC_ACCESS_DENIED",
            "reason": f"None of {permissions} allowed for role '{token.role}'",
        }
