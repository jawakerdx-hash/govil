"""Tenant isolation — every request MUST carry tenant_id. No cross-tenant data."""

from __future__ import annotations

from .models import AuthToken, Tenant

BUILTIN_TENANTS: dict[str, Tenant] = {}


class TenantContext:
    """Enforces tenant isolation. All queries scoped by tenant_id."""

    @staticmethod
    def resolve(token: AuthToken) -> Tenant | dict:
        """Resolve tenant from token. Return error on violation."""
        tenant = BUILTIN_TENANTS.get(token.tenant_id)
        if tenant is None:
            # Auto-create tenant from token context
            tenant = Tenant(
                tenant_id=token.tenant_id,
                organization_id=token.tenant_id,
                name=token.tenant_id,
            )
            BUILTIN_TENANTS[token.tenant_id] = tenant

        if not tenant.is_active:
            return {"error": "TENANT_ISOLATION_VIOLATION",
                    "reason": f"Tenant {token.tenant_id} is deactivated"}

        return tenant

    @staticmethod
    def scope_query(tenant_id: str, query_params: dict) -> dict:
        """Ensure query is scoped to tenant."""
        params = dict(query_params)
        params["tenant_id"] = tenant_id
        return params

    @classmethod
    def validate_cross_tenant(cls, request_tenant: str, data_tenant: str) -> dict | None:
        """Return error if cross-tenant access attempted."""
        if request_tenant != data_tenant:
            return {
                "error": "TENANT_ISOLATION_VIOLATION",
                "reason": f"Cannot access tenant '{data_tenant}' from '{request_tenant}'",
            }
        return None
