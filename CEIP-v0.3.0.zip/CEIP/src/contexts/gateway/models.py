"""Gateway models — tenants, roles, permissions, audit."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

ROLES = frozenset({
    "SUPER_ADMIN", "ORG_ADMIN", "SOC_ANALYST", "THREAT_ANALYST",
    "VIEWER", "API_CLIENT",
})

PERMISSIONS = frozenset({
    "discovery:read", "graph:read", "graph:write",
    "risk:read", "reports:generate", "intel:read",
    "rating:read", "dashboard:read", "analyst:query",
    "admin:manage_users", "admin:manage_tenants",
})

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "admin": PERMISSIONS,
    "analyst": {"discovery:read", "graph:read", "risk:read", "intel:read",
                "rating:read", "dashboard:read", "analyst:query",
                "reports:generate"},
    "viewer": {"rating:read", "dashboard:read", "investigation:read"},
    "SUPER_ADMIN": PERMISSIONS,
    "ORG_ADMIN": {"discovery:read", "graph:read", "graph:write", "risk:read",
                   "reports:generate", "intel:read", "rating:read",
                   "dashboard:read", "analyst:query", "admin:manage_users"},
    "SOC_ANALYST": {"graph:read", "risk:read", "intel:read", "rating:read",
                     "dashboard:read", "analyst:query"},
    "THREAT_ANALYST": {"graph:read", "intel:read", "analyst:query"},
    "VIEWER": {"rating:read", "dashboard:read"},
    "API_CLIENT": {"discovery:read", "graph:read", "risk:read", "rating:read"},
}


@dataclass
class Tenant:
    tenant_id: str
    organization_id: str
    name: str = ""
    environment: str = "prod"  # prod, staging, dev
    is_active: bool = True
    rate_limit_rpm: int = 100
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "tenant_id": self.tenant_id, "organization_id": self.organization_id,
            "name": self.name, "environment": self.environment,
            "is_active": self.is_active, "rate_limit_rpm": self.rate_limit_rpm,
        }


@dataclass
class AuthToken:
    user_id: str
    tenant_id: str
    role: str
    permissions: set[str] = field(default_factory=set)
    expiry: int | None = None  # Standard JWT ``exp`` claim — Unix timestamp

    def has_permission(self, permission: str) -> bool:
        return permission in self.permissions

    def is_expired(self) -> bool:
        """Check if the token has expired based on its ``exp`` claim."""
        if self.expiry is None:
            return False
        return datetime.fromtimestamp(float(self.expiry), tz=UTC) < datetime.now(UTC)

    @property
    def expires_in(self) -> int:
        """Seconds until expiry (0 if expired or unknown)."""
        if self.expiry is None:
            return 0
        remaining = int(self.expiry - datetime.now(UTC).timestamp())
        return max(0, remaining)

    def to_dict(self) -> dict[str, Any]:
        return {
            "user_id": self.user_id,
            "tenant_id": self.tenant_id,
            "role": self.role,
            "permissions": sorted(self.permissions),
            "expiry": self.expiry,
            "expires_in": self.expires_in,
        }


@dataclass
class AuditEntry:
    request_id: str
    tenant_id: str
    user_id: str
    endpoint: str
    method: str = "GET"
    action: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    result_status: str = "success"
    error_code: str | None = None
    module_target: str = ""
    risk_context_reference: str = ""
    latency_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id, "tenant_id": self.tenant_id,
            "user_id": self.user_id, "endpoint": self.endpoint,
            "method": self.method, "action": self.action,
            "timestamp": self.timestamp, "result_status": self.result_status,
            "error_code": self.error_code, "module_target": self.module_target,
            "risk_context_reference": self.risk_context_reference,
            "latency_ms": self.latency_ms,
        }


@dataclass
class GatewayResponse:
    request_id: str
    tenant_id: str
    status: str  # success, error
    data: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        meta = {
            "latency_ms": self.meta.get("latency_ms", 0),
            "role": self.meta.get("role", "unknown"),
            "rate_limit_remaining": self.meta.get("rate_limit_remaining", 0),
            "access_level": self.meta.get("access_level", "none"),
        }
        return {
            "request_id": self.request_id, "tenant_id": self.tenant_id,
            "status": self.status, "data": self.data, "meta": meta,
        }
