"""M29 — Enterprise API Gateway. Single entry point for all CEIP modules.

Pipeline (STRICT ORDER — no alternative paths):
  Auth → Tenant Validation → RBAC → Rate Limit → Route → Audit Log → Response

Security: No cross-tenant leakage. No direct module access. No bypass.
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from .audit_logger import AuditLogger
from .auth import AuthEngine
from .models import GatewayResponse
from .rate_limiter import RateLimiter
from .rbac import RBACEngine
from .tenant_context import TenantContext


class CEIPGateway:
    """Enterprise API Gateway — controls ALL access to M20-M28.

    Auth → Tenant → RBAC → Rate → Route → Audit. No alternative paths.
    """

    ROUTES: dict[str, str] = {
        "discovery:scan": "discovery:read",
        "graph:query": "graph:read",
        "graph:build": "graph:write",
        "risk:calculate": "risk:read",
        "rating:get": "rating:read",
        "reports:generate": "reports:generate",
        "intel:query": "intel:read",
        "dashboard:get": "dashboard:read",
        "analyst:ask": "analyst:query",
    }

    def __init__(self) -> None:
        self._auth = AuthEngine
        self._rbac = RBACEngine()
        self._tenant = TenantContext()
        self._rate_limiter = RateLimiter()
        self._audit = AuditLogger()

    def handle(self, token_str: str, endpoint: str,
               action: str = "read", method: str = "GET",
               params: dict | None = None) -> dict[str, Any]:
        """Process request through all 6 security layers in order."""
        request_id = uuid.uuid4().hex
        t0 = time.perf_counter()

        # ---- STEP 1: Authentication ----
        auth_result = self._auth.validate(token_str)
        if isinstance(auth_result, dict):
            return self._error(request_id, "", auth_result, method, endpoint)
        token = auth_result

        # ---- STEP 2: Tenant Validation + Scoping ----
        if not token.tenant_id:
            return self._error(request_id, "", {
                "error": "TENANT_SCOPE_MISSING",
                "reason": "No tenant_id in token",
            }, method, endpoint)

        tenant_result = self._tenant.resolve(token)
        if isinstance(tenant_result, dict):
            return self._error(request_id, token.tenant_id, tenant_result, method, endpoint)

        # ---- STEP 3: RBAC ----
        required_perm = self.ROUTES.get(endpoint, "graph:read")
        rbac_err = self._rbac.authorize(token, required_perm)
        if rbac_err:
            return self._error(request_id, token.tenant_id, rbac_err, method, endpoint)

        # ---- STEP 4: Rate Limiting ----
        rate_err = self._rate_limiter.check(
            token.tenant_id, endpoint, tenant_result.rate_limit_rpm,
        )
        if rate_err:
            return self._error(request_id, token.tenant_id, rate_err, method, endpoint)

        remaining = self._rate_limiter.remaining(
            token.tenant_id, endpoint, tenant_result.rate_limit_rpm,
        )

        # ---- STEP 5: Route to Module ----
        try:
            data = self._route(endpoint, action, params or {}, token)
        except Exception as exc:
            self._audit.log(
                request_id=request_id, tenant_id=token.tenant_id,
                user_id=token.user_id, endpoint=endpoint, method=method,
                action=action, result_status="error",
                error_code="GATEWAY_ROUTE_FAILED",
                module_target=self._module_for(endpoint),
                latency_ms=(time.perf_counter() - t0) * 1000,
            )
            return self._error(request_id, token.tenant_id, {
                "error": "GATEWAY_ROUTE_FAILED", "reason": str(exc),
            }, method, endpoint)

        latency_ms = (time.perf_counter() - t0) * 1000

        # ---- STEP 6: Audit Log (immutable) ----
        self._audit.log(
            request_id=request_id, tenant_id=token.tenant_id,
            user_id=token.user_id, endpoint=endpoint, method=method,
            action=action, result_status="success",
            module_target=self._module_for(endpoint),
            risk_context_reference=f"role={token.role}",
            latency_ms=latency_ms,
        )

        # Tenant-scoped response — no data without tenant binding
        return GatewayResponse(
            request_id=request_id, tenant_id=token.tenant_id,
            status="success", data=data,
            meta={
                "latency_ms": round(latency_ms, 1),
                "role": token.role,
                "rate_limit_remaining": remaining,
                "access_level": token.role,
            },
        ).to_dict()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _route(self, endpoint: str, action: str, params: dict,
               token: Any) -> dict[str, Any]:
        return {
            "endpoint": endpoint, "action": action,
            "tenant_id": token.tenant_id, "status": "routed",
        }

    @staticmethod
    def _error(request_id: str, tenant_id: str, error: dict,
               method: str, endpoint: str) -> dict:
        return GatewayResponse(
            request_id=request_id, tenant_id=tenant_id,
            status="error", data=error,
            meta={
                "latency_ms": 0, "role": "none",
                "rate_limit_remaining": 0, "access_level": "none",
            },
        ).to_dict()

    @staticmethod
    def _module_for(endpoint: str) -> str:
        mapping = {
            "discovery:scan": "M19", "graph:query": "M20", "graph:build": "M20",
            "risk:calculate": "M24", "rating:get": "M24",
            "reports:generate": "M28", "intel:query": "M23",
            "dashboard:get": "M26", "analyst:ask": "M25",
        }
        return mapping.get(endpoint, "M20")
