"""Report schemas."""

from __future__ import annotations

from pydantic import BaseModel


class ReportResponse(BaseModel):
    domain: str
    report_type: str
    generated_at: str
    title: str
    sections: list[dict[str, object]] = []
    summary: str = ""
    format: str = "json"


class ReportExportRequest(BaseModel):
    domain: str
    report_type: str
    format: str = "json"
