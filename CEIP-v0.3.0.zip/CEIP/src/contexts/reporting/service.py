"""Reporting engine — aggregates persisted data into reusable reports.

NEVER calls business engines. Reads only stored data.
Reports are deterministic from persisted data → generated on demand, not stored.
"""
# ruff: noqa: E501  — SQL queries + report formatting naturally long

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


class ReportingService:
    """Read-only report generation. No engines called. Only persisted data."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    REPORT_TYPES = [
        "executive", "technical", "monitoring", "identity", "threat", "risk", "compliance",
    ]

    async def generate(self, domain: str, report_type: str, fmt: str = "json") -> dict[str, Any]:
        domain = domain.lower().strip()
        now = datetime.now(UTC).isoformat()
        sections: list[dict[str, Any]] = []

        if report_type == "executive":
            sections = await self._executive_sections(domain)
        elif report_type == "technical":
            sections = await self._technical_sections(domain)
        elif report_type == "monitoring":
            sections = await self._monitoring_sections(domain)
        elif report_type == "identity":
            sections = await self._identity_sections(domain)
        elif report_type == "threat":
            sections = await self._threat_sections(domain)
        elif report_type == "risk":
            sections = await self._risk_sections(domain)
        elif report_type == "compliance":
            sections = await self._compliance_sections(domain)

        summary = " | ".join(
            f"{s['title']}: {len(s.get('items', []))} items"
            for s in sections if s.get("items")
        )

        return {
            "domain": domain, "report_type": report_type,
            "generated_at": now,
            "title": f"{report_type.upper()} Report — {domain}",
            "sections": sections,
            "summary": summary,
            "format": fmt,
        }

    async def export_markdown(self, data: dict[str, Any]) -> str:
        """Export report as markdown."""
        lines = [
            f"# {data['title']}",
            f"Generated: {data['generated_at']}",
            f"Domain: {data['domain']}",
            f"Type: {data['report_type']}",
            "",
            "## Summary",
            data.get("summary", ""),
            "",
        ]
        for section in data.get("sections", []):
            lines.append(f"## {section.get('title', '')}")
            if section.get("description"):
                lines.append(section["description"])
                lines.append("")
            for item in section.get("items", []):
                lines.append(f"- {item}")
            lines.append("")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Section builders — read persisted data only
    # ------------------------------------------------------------------

    async def _executive_sections(self, domain: str) -> list[dict[str, Any]]:
        risk = await self._read_snapshot(domain, "risk")
        vuln = await self._read_findings(domain)
        threat = await self._read_threats(domain)
        identity = await self._read_exposures(domain)
        monitor = await self._read_alerts(domain)

        return [
            {"title": "Risk Overview", "description": f"Score: {risk.get('overall_score', 0)}/100 ({risk.get('overall_level', 'LOW')})", "items": []},
            {"title": "Vulnerabilities", "items": [f.get("title", "") for f in vuln.get("findings", [])[:10]]},
            {"title": "Threat Intelligence", "items": threat.get("matches", [])[:5]},
            {"title": "Identity Exposure", "items": identity.get("exposures", [])[:5]},
            {"title": "Monitoring Alerts", "items": monitor.get("alerts", [])[:5]},
        ]

    async def _technical_sections(self, domain: str) -> list[dict[str, Any]]:
        vuln = await self._read_findings(domain)
        discovery = await self._read_snapshot(domain, "discovery")
        return [
            {"title": "Critical Vulnerabilities", "items": [
                f"[{f.get('severity')}] {f.get('cve_id') or 'MISCONFIG'}: {f.get('title','')[:100]}"
                for f in vuln.get("findings", []) if f.get("severity") == "critical"
            ]},
            {"title": "All Findings", "items": [
                f"[{f.get('severity')}] {f.get('cve_id') or 'MISCONFIG'}: {f.get('title','')[:100]}"
                for f in vuln.get("findings", [])
            ]},
            {"title": "Infrastructure", "items": [
                f"Services: {discovery.get('service_count', 0)}",
                f"DNS Records: {discovery.get('dns_count', 0)}",
                f"Subdomains: {discovery.get('subdomain_count', 0)}",
                f"Certificates: {discovery.get('cert_count', 0)}",
            ]},
        ]

    async def _monitoring_sections(self, domain: str) -> list[dict[str, Any]]:
        execs = await self._read_executions(domain)
        changes = await self._read_changes(domain)
        return [
            {"title": "Execution History", "items": [
                f"[{e.status}] v{e.scan_version} {e.started_at} ({e.duration_ms}ms)"
                for e in execs[:10]
            ]},
            {"title": "Recent Changes", "items": [
                f"[{c.severity}] {c.change_type}: {c.entity_identifier}"
                for c in changes[:20]
            ]},
        ]

    async def _identity_sections(self, domain: str) -> list[dict[str, Any]]:
        identity = await self._read_exposures(domain)
        return [
            {"title": "Identity Exposures", "items": [
                f"[{e.get('severity')}] {e.get('identity_type')}: {e.get('value','')[:80]}"
                for e in identity.get("exposures", [])
            ]},
        ]

    async def _threat_sections(self, domain: str) -> list[dict[str, Any]]:
        threat = await self._read_threats(domain)
        return [
            {"title": "Threat Matches", "items": threat.get("matches", [])},
        ]

    async def _risk_sections(self, domain: str) -> list[dict[str, Any]]:
        risk = await self._read_snapshot(domain, "risk")
        trend = await self._read_trend(domain)
        return [
            {"title": "Risk Score", "items": [
                f"Score: {risk.get('overall_score', 0)}/100 ({risk.get('overall_level', 'LOW')})"
            ]},
            {"title": "Risk Trend", "items": [
                f"{t['date']}: {t['score']:.0f} ({t['level']})"
                for t in trend[-10:]
            ]},
        ]

    async def _compliance_sections(self, domain: str) -> list[dict[str, Any]]:
        vuln = await self._read_findings(domain)
        critical = sum(1 for f in vuln.get("findings", []) if f.get("severity") == "critical")
        high = sum(1 for f in vuln.get("findings", []) if f.get("severity") == "high")
        return [
            {"title": "Compliance Summary", "items": [
                f"Total findings: {vuln.get('count', 0)}",
                f"Critical: {critical} | High: {high}",
                "Frameworks: ISO 27001, NIST CSF, PCI DSS",
                f"Remediation priority: {critical} critical findings require immediate attention",
            ]},
        ]

    # ------------------------------------------------------------------
    # Data readers — purely persisted data
    # ------------------------------------------------------------------

    async def _read_snapshot(self, domain: str, stype: str) -> dict[str, Any]:
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot
            r = await self._db.execute(
                select(MonitoringSnapshot)
                .where(MonitoringSnapshot.domain == domain, MonitoringSnapshot.snapshot_type == stype)
                .order_by(MonitoringSnapshot.created_at.desc()).limit(1)
            )
            snap = r.scalar_one_or_none()
            if snap:
                return dict(json.loads(snap.data_json))
        except Exception:
            pass
        return {}

    async def _read_findings(self, domain: str) -> dict[str, Any]:
        try:
            from src.contexts.vulnerability.models import SecurityFinding
            r = await self._db.execute(
                select(SecurityFinding).where(SecurityFinding.domain == domain)
            )
            findings = r.scalars().all()
            return {
                "count": len(findings),
                "findings": [{"severity": f.severity, "cve_id": f.cve_id, "title": f.title} for f in findings],
            }
        except Exception:
            return {"count": 0, "findings": []}

    async def _read_threats(self, domain: str) -> dict[str, Any]:
        try:
            from src.contexts.threat.models import ThreatMatch
            r = await self._db.execute(
                select(ThreatMatch).where(ThreatMatch.domain == domain)
            )
            rows = r.scalars().all()
            return {
                "matches": [f"[{m.severity}] {m.threat_category}: {m.matched_asset[:60]}" for m in rows],
            }
        except Exception:
            return {"matches": []}

    async def _read_exposures(self, domain: str) -> dict[str, Any]:
        try:
            from src.contexts.identity_exposure.models import IdentityExposure
            r = await self._db.execute(
                select(IdentityExposure).where(IdentityExposure.domain == domain)
            )
            rows = r.scalars().all()
            return {
                "exposures": [
                    {"severity": e.severity, "identity_type": e.identity_type, "value": e.value}
                    for e in rows
                ],
            }
        except Exception:
            return {"exposures": []}

    async def _read_alerts(self, domain: str) -> dict[str, Any]:
        try:
            from src.contexts.monitoring.models import MonitoringAlert
            r = await self._db.execute(
                select(MonitoringAlert).where(MonitoringAlert.domain == domain)
                .order_by(MonitoringAlert.created_at.desc()).limit(10)
            )
            rows = r.scalars().all()
            return {"alerts": [f"[{a.severity}] {a.alert_type}: {a.title[:80]}" for a in rows]}
        except Exception:
            return {"alerts": []}

    async def _read_changes(self, domain: str) -> list[Any]:
        try:
            from src.contexts.monitoring.models import MonitoringChange
            r = await self._db.execute(
                select(MonitoringChange).where(MonitoringChange.domain == domain)
                .order_by(MonitoringChange.detected_at.desc()).limit(30)
            )
            return list(r.scalars().all())
        except Exception:
            return []

    async def _read_executions(self, domain: str) -> list[Any]:
        try:
            from src.contexts.monitoring.models import MonitoringExecution
            r = await self._db.execute(
                select(MonitoringExecution).where(MonitoringExecution.domain == domain)
                .order_by(MonitoringExecution.started_at.desc()).limit(20)
            )
            return list(r.scalars().all())
        except Exception:
            return []

    async def _read_trend(self, domain: str) -> list[dict[str, Any]]:
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot
            r = await self._db.execute(
                select(MonitoringSnapshot)
                .where(MonitoringSnapshot.domain == domain, MonitoringSnapshot.snapshot_type == "risk")
                .order_by(MonitoringSnapshot.created_at.asc()).limit(30)
            )
            trend = []
            for s in r.scalars().all():
                try:
                    data = json.loads(s.data_json)
                    trend.append({
                        "date": s.created_at.isoformat() if s.created_at else "",
                        "score": data.get("overall_score", 0),
                        "level": data.get("overall_level", "LOW"),
                    })
                except (json.JSONDecodeError, TypeError):
                    pass
            return trend
        except Exception:
            return []
