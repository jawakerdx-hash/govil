"""SIB Prioritization Engine — sorts by evidence quality, NOT CVSS.

Prioritization dimensions (weighted):
1. Evidence quality (30%) — number of corroborating sources
2. Confidence (25%) — verification confidence score
3. Business criticality (20%) — crown jewel / business asset status
4. Exploitability (10%) — attack path feasibility
5. Exposure (10%) — internet-facing vs internal
6. Asset importance (3%) — cluster centrality
7. Threat context (2%) — active threat actor interest

CVSS score is deliberately excluded as a primary sort key.
"""

from __future__ import annotations


class SIBPrioritization:
    """Prioritizes intelligence cases by evidence quality, confidence,
    business criticality, exploitability, exposure, and threat context.

    NEVER sorts only by CVSS.
    """

    @staticmethod
    def prioritize_cases(cases: list[dict]) -> list[dict]:
        """Sort cases by multi-factor priority score (descending)."""
        scored = [(SIBPrioritization._score(c), c) for c in cases]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [c for _, c in scored]

    @staticmethod
    def prioritize_findings(findings: list[dict]) -> list[dict]:
        """Sort findings by evidence quality, not severity alone."""
        scored = [(SIBPrioritization._score_finding(f), f) for f in findings]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [f for _, f in scored]

    @staticmethod
    def _score(case: dict) -> float:
        """Compute priority score for an intelligence case."""
        score = 0.0

        # Evidence quality (30%): number of evidence items
        evidence_count = len(case.get("evidence", []))
        score += min(evidence_count / 10.0, 1.0) * 0.30

        # Confidence (25%): direct confidence score
        score += case.get("confidence", 0.5) * 0.25

        # Business criticality (20%): severity of business impact
        sev = {"CRITICAL": 1.0, "HIGH": 0.75, "MEDIUM": 0.5, "LOW": 0.25}
        score += sev.get(case.get("risk_level", "LOW"), 0.25) * 0.20

        # Exploitability (10%): attack path length (longer = more steps to mitigate)
        attack_path_len = len(case.get("attack_path", []))
        score += min(attack_path_len / 6.0, 1.0) * 0.10

        # Exposure (10%): number of affected assets
        asset_count = len(case.get("affected_assets", []))
        score += min(asset_count / 5.0, 1.0) * 0.10

        # Asset importance (3%): findings with recommendations are more actionable
        has_recs = 1.0 if case.get("recommendations") else 0.5
        score += has_recs * 0.03

        # Threat context (2%): active threat indicators
        has_threats = 1.0 if "threat" in (case.get("threat_context", "") or "").lower() else 0.3
        score += has_threats * 0.02

        return round(score, 4)

    @staticmethod
    def _score_finding(finding: dict) -> float:
        """Compute priority score for an individual finding."""
        score = 0.0

        sev = {"CRITICAL": 1.0, "HIGH": 0.75, "MEDIUM": 0.4, "LOW": 0.15}
        score += sev.get(finding.get("severity", "LOW"), 0.15) * 0.25

        score += finding.get("confidence", 0.5) * 0.25

        has_evidence = 1.0 if finding.get("evidence") else 0.3
        score += has_evidence * 0.20

        has_ep = 1.0 if finding.get("endpoint") else 0.5
        score += has_ep * 0.10

        has_rec = 1.0 if finding.get("recommendation") else 0.5
        score += has_rec * 0.10

        risk = finding.get("risk_score", 50) / 100.0
        score += risk * 0.10

        return round(score, 4)
