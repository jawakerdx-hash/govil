"""SIB Risk Correlation Engine — multi-dimensional risk across 8 dimensions.

Does NOT score findings individually.
Computes risk holistically: asset, service, business, organization,
exposure, technology, infrastructure, and threat risk.
"""

from __future__ import annotations

from typing import Any


class SIBRiskCorrelation:
    """Multi-dimensional risk correlation — holistic, not per-finding.

    All 8 dimensions are independently computed from evidence.
    Overall score is a weighted combination, not an average.
    """

    WEIGHTS = {
        "asset_risk": 0.20,
        "service_risk": 0.10,
        "business_risk": 0.20,
        "organization_risk": 0.05,
        "exposure_risk": 0.15,
        "technology_risk": 0.10,
        "infrastructure_risk": 0.05,
        "threat_risk": 0.15,
    }

    @staticmethod
    def compute(
        entity_groups: dict[str, list],
        tech_map: dict[str, set[str]],
        threat_map: dict[str, list[dict]],
        cross_corr: dict[str, Any],
        stats: dict[str, Any],
    ) -> dict[str, Any]:
        """Compute all 8 risk dimensions and overall score."""

        # 1. Asset Risk (0-1): based on finding severity distribution
        asset_risk = SIBRiskCorrelation._compute_asset_risk(entity_groups)

        # 2. Service Risk (0-1): based on exposed services and their technologies
        service_risk = SIBRiskCorrelation._compute_service_risk(entity_groups, tech_map)

        # 3. Business Risk (0-1): based on critical findings and business impact
        business_risk = SIBRiskCorrelation._compute_business_risk(entity_groups)

        # 4. Organization Risk (0-1): based on asset count and diversity
        organization_risk = SIBRiskCorrelation._compute_organization_risk(
            entity_groups, stats,
        )

        # 5. Exposure Risk (0-1): based on external exposure surface
        exposure_risk = SIBRiskCorrelation._compute_exposure_risk(
            entity_groups, cross_corr,
        )

        # 6. Technology Risk (0-1): based on technology diversity and known-vulnerable stacks
        technology_risk = SIBRiskCorrelation._compute_technology_risk(tech_map)

        # 7. Infrastructure Risk (0-1): based on shared infrastructure and clusters
        infrastructure_risk = SIBRiskCorrelation._compute_infrastructure_risk(
            cross_corr, stats,
        )

        # 8. Threat Risk (0-1): based on threat intelligence matches
        threat_risk = SIBRiskCorrelation._compute_threat_risk(threat_map, entity_groups)

        # Overall: weighted combination
        dimensions = {
            "asset_risk": asset_risk,
            "service_risk": service_risk,
            "business_risk": business_risk,
            "organization_risk": organization_risk,
            "exposure_risk": exposure_risk,
            "technology_risk": technology_risk,
            "infrastructure_risk": infrastructure_risk,
            "threat_risk": threat_risk,
        }

        overall = sum(
            dimensions[dim] * SIBRiskCorrelation.WEIGHTS[dim]
            for dim in dimensions
        )

        risk_level = (
            "CRITICAL" if overall >= 0.76 else "HIGH" if overall >= 0.51
            else "MEDIUM" if overall >= 0.26 else "LOW"
        )

        return {
            **dimensions,
            "overall_score": round(overall, 2),
            "risk_level": risk_level,
            "factor_breakdown": [
                {
                    "dimension": dim,
                    "score": round(score, 3),
                    "weight": SIBRiskCorrelation.WEIGHTS[dim],
                    "contribution": round(score * SIBRiskCorrelation.WEIGHTS[dim], 3),
                }
                for dim, score in dimensions.items()
            ],
        }

    # ------------------------------------------------------------------
    # Individual dimension computations
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_asset_risk(entity_groups: dict) -> float:
        sev_rank = {"CRITICAL": 1.0, "HIGH": 0.75, "MEDIUM": 0.5, "LOW": 0.25, "INFO": 0.0}
        scores = []
        for items in entity_groups.values():
            for ev in items:
                scores.append(sev_rank.get(ev.severity, 0.25))
        return min(1.0, sum(scores) / max(len(scores), 1)) if scores else 0.0

    @staticmethod
    def _compute_service_risk(
        entity_groups: dict, tech_map: dict,
    ) -> float:
        service_count = sum(
            1 for items in entity_groups.values()
            if any(ev.evidence_type == "service" for ev in items)
        )
        total_techs = sum(len(techs) for techs in tech_map.values())
        return min(1.0, (service_count * 0.05 + total_techs * 0.03))

    @staticmethod
    def _compute_business_risk(entity_groups: dict) -> float:
        sev_rank = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
        critical_count = 0
        high_count = 0
        for items in entity_groups.values():
            for ev in items:
                if ev.severity == "CRITICAL":
                    critical_count += 1
                elif ev.severity == "HIGH":
                    high_count += 1
        return min(1.0, critical_count * 0.25 + high_count * 0.10)

    @staticmethod
    def _compute_organization_risk(
        entity_groups: dict, stats: dict,
    ) -> float:
        total_entities = stats.get("total_entities", 0)
        return min(1.0, total_entities / 50.0)

    @staticmethod
    def _compute_exposure_risk(
        entity_groups: dict, cross_corr: dict,
    ) -> float:
        exposure_count = sum(
            1 for items in entity_groups.values()
            if any(ev.evidence_type == "exposure" for ev in items)
        )
        vuln_links = len(cross_corr.get("asset_to_vulnerability", []))
        return min(1.0, exposure_count * 0.10 + vuln_links * 0.05)

    @staticmethod
    def _compute_technology_risk(tech_map: dict) -> float:
        total_techs = sum(len(techs) for techs in tech_map.values())
        unique_techs = len({t for techs in tech_map.values() for t in techs})
        return min(1.0, total_techs * 0.02 + unique_techs * 0.03)

    @staticmethod
    def _compute_infrastructure_risk(
        cross_corr: dict, stats: dict,
    ) -> float:
        shared = stats.get("multi_evidence_entities", 0)
        return min(1.0, shared * 0.05)

    @staticmethod
    def _compute_threat_risk(
        threat_map: dict, entity_groups: dict,
    ) -> float:
        total_threats = sum(len(threats) for threats in threat_map.values())
        high_threats = sum(
            1 for threats in threat_map.values()
            for t in threats
            if t.get("severity") == "CRITICAL" or t.get("severity") == "HIGH"
        )
        return min(1.0, total_threats * 0.10 + high_threats * 0.15)
