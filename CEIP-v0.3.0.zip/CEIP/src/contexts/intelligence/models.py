"""Security Intelligence Brain — central intelligence layer for CEIP.

Transforms evidence into SOC-analyst-quality intelligence cases,
attack chains, risk correlations, and relationship graphs.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from src.kernel.base_model import Base, TimestampMixin, UUIDMixin


class IntelligenceCase(UUIDMixin, TimestampMixin, Base):
    """A SOC-analyst-quality intelligence case built from correlated evidence.

    NOT a finding. NOT a vulnerability report. A full intelligence narrative:
    what happened, why it matters, evidence chain, attack path, business impact,
    and recommended response — all evidence-backed.
    """

    __tablename__ = "intelligence_cases"

    investigation_id: Mapped[str] = mapped_column(
        String(36), nullable=False, index=True,
    )
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    executive_summary: Mapped[str] = mapped_column(Text, nullable=False)
    risk_level: Mapped[str] = mapped_column(
        String(16), default="MEDIUM", nullable=False,
    )
    confidence: Mapped[float] = mapped_column(Float, default=0.5, nullable=False)
    priority: Mapped[str] = mapped_column(
        String(16), default="MEDIUM", nullable=False,
    )

    # Evidence chain — IDs of InvestigationEvidence that back this case
    evidence_ids: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Affected assets
    affected_assets: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Attack path — ordered list of steps from entry to impact
    attack_path_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    threat_context: Mapped[str | None] = mapped_column(Text, nullable=True)
    business_impact: Mapped[str | None] = mapped_column(Text, nullable=True)
    root_cause: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Related findings — IDs or titles
    related_findings_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Recommendations — ranked by effectiveness
    recommendations_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Kill chain stages covered
    kill_chain_stages_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Analyst notes — free-form reasoning trail
    analyst_notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class AttackChain(UUIDMixin, TimestampMixin, Base):
    """An attack chain: a sequence of steps from entry point to business impact.

    Built from actual graph traversal, NOT templates.
    Each step is backed by evidence.
    """

    __tablename__ = "intelligence_attack_chains"

    investigation_id: Mapped[str] = mapped_column(
        String(36), nullable=False, index=True,
    )
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    severity: Mapped[str] = mapped_column(String(16), default="MEDIUM", nullable=False)
    risk_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    confidence: Mapped[float] = mapped_column(Float, default=0.5, nullable=False)

    # Steps: JSON array of {step_number, source, target, action, evidence_id}
    steps_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Kill chain mapping
    kill_chain_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Entry points and targets
    entry_points_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    crown_jewels_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    blocked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    blocked_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    mitigations_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class RiskCorrelation(UUIDMixin, TimestampMixin, Base):
    """Multi-dimensional risk correlation — NOT individual scoring.

    Computes 8 risk dimensions independently from evidence, then
    produces a weighted overall score.
    """

    __tablename__ = "intelligence_risk_correlations"

    investigation_id: Mapped[str] = mapped_column(
        String(36), nullable=False, index=True,
    )
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    # 8 risk dimensions
    asset_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    service_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    business_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    organization_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    exposure_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    technology_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    infrastructure_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    threat_risk: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)

    overall_score: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    risk_level: Mapped[str] = mapped_column(String(16), default="LOW", nullable=False)

    # Decomposed factors
    factor_breakdown_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class RelationshipGraph(UUIDMixin, TimestampMixin, Base):
    """A persisted relationship graph: domains→subdomains→IPs→ports→services→techs→findings→threats.

    Stored as nodes_json + edges_json for graph traversal.
    """

    __tablename__ = "intelligence_relationship_graphs"

    investigation_id: Mapped[str] = mapped_column(
        String(36), nullable=False, index=True,
    )
    domain: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    nodes_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    edges_json: Mapped[str | None] = mapped_column(Text, nullable=True)

    node_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    edge_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    crown_jewels_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    entry_points_json: Mapped[str | None] = mapped_column(Text, nullable=True)


class IntelligenceTimeline(UUIDMixin, Base):
    """Timeline of SIB events — when cases are generated, correlations computed, etc."""

    __tablename__ = "intelligence_timeline"

    investigation_id: Mapped[str] = mapped_column(
        String(36), nullable=False, index=True,
    )
    event_type: Mapped[str] = mapped_column(String(32), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    data_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.utcnow, nullable=False,
    )
