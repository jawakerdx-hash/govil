"""Security Intelligence Brain — central reasoning engine.

The SIB transforms thousands of technical observations into
actionable security intelligence.

Pipeline:
1. CorrelationEngine — cross-context correlation
2. Deduplication — merge duplicates at every level
3. CaseBuilder — SOC-analyst quality intelligence cases
4. AttackPathAnalyzer — graph-based attack chains
5. RiskCorrelation — 8-dimensional risk
6. GraphBuilder — full relationship graph
7. Prioritization — evidence-quality-based sorting
"""

from __future__ import annotations

import json
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from src.contexts.intelligence.attack_path_analyzer import SIBAttackPathAnalyzer
from src.contexts.intelligence.case_builder import SIBCaseBuilder
from src.contexts.intelligence.correlation_engine import SIBCorrelationEngine
from src.contexts.intelligence.deduplication import SIBDeduplicator
from src.contexts.intelligence.graph_builder import SIBGraphBuilder
from src.contexts.intelligence.models import (
    AttackChain,
    IntelligenceCase,
    RelationshipGraph,
    RiskCorrelation,
)
from src.contexts.intelligence.prioritization import SIBPrioritization
from src.contexts.intelligence.risk_correlation import SIBRiskCorrelation


class SecurityIntelligenceBrain:
    """THE central intelligence layer of the CEIP platform.

    NOT a reporting module. NOT a vulnerability scanner.
    This is the reasoning engine that correlates everything
    into actionable intelligence.
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._correlation = SIBCorrelationEngine(db)

    async def analyze(
        self,
        investigation_id: str,
        domain: str,
    ) -> dict[str, Any]:
        """Full SIB analysis pipeline.

        Returns: {
            cases: [...],
            attack_chains: [...],
            risk_correlation: {...},
            relationship_graph: {...},
            stats: {...},
        }
        """
        # Store external context in correlation data for downstream use

        # 1. Cross-context correlation
        correlation = await self._correlation.correlate_all(
            investigation_id, domain,
        )

        # Load external context for enrichment
        external = await self._correlation._load_external_context(domain)
        correlation["_external"] = external

        # 2. Deduplicate evidence
        all_evidence = await self._correlation._load_evidence(investigation_id)
        deduped = SIBDeduplicator.deduplicate_evidence(all_evidence)

        # 3. Build intelligence cases
        cases = SIBCaseBuilder.build_cases(correlation)
        cases = SIBDeduplicator.deduplicate_cases(cases)
        cases = SIBPrioritization.prioritize_cases(cases)

        # 4. Build attack chains
        chains = SIBAttackPathAnalyzer.build_attack_chains(correlation, cases)

        # 5. Compute risk correlation
        risk = SIBRiskCorrelation.compute(
            entity_groups=correlation.get("entity_groups", {}),
            tech_map=correlation.get("technology_map", {}),
            threat_map=correlation.get("threat_map", {}),
            cross_corr=correlation.get("cross_correlations", {}),
            stats=correlation.get("stats", {}),
        )

        # 6. Build relationship graph
        graph = SIBGraphBuilder.build(
            entity_groups=correlation.get("entity_groups", {}),
            external=external,
            cross_corr=correlation.get("cross_correlations", {}),
            tech_map=correlation.get("technology_map", {}),
        )

        # 7. Persist results
        await self._persist_cases(investigation_id, domain, cases)
        await self._persist_chains(investigation_id, domain, chains)
        await self._persist_risk(investigation_id, domain, risk)
        await self._persist_graph(investigation_id, domain, graph)

        # 8. Update investigation counters
        await self._update_investigation(investigation_id, len(cases), risk)

        return {
            "cases": cases,
            "attack_chains": chains,
            "risk_correlation": risk,
            "relationship_graph": graph,
            "stats": {
                "total_evidence": len(all_evidence),
                "deduplicated": len(all_evidence) - len(deduped),
                "cases_generated": len(cases),
                "chains_generated": len(chains),
                "graph_nodes": graph["node_count"],
                "graph_edges": graph["edge_count"],
            },
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    async def _persist_cases(
        self, investigation_id: str, domain: str, cases: list[dict],
    ) -> None:
        for case in cases:
            db_case = IntelligenceCase(
                investigation_id=investigation_id,
                domain=domain,
                title=case.get("title", ""),
                executive_summary=case.get("executive_summary", ""),
                risk_level=case.get("risk_level", "MEDIUM"),
                confidence=case.get("confidence", 0.5),
                priority=case.get("priority", "MEDIUM"),
                evidence_ids=json.dumps(case.get("evidence", [])),
                affected_assets=json.dumps(case.get("affected_assets", [])),
                attack_path_json=json.dumps(case.get("attack_path", [])),
                threat_context=case.get("threat_context", ""),
                business_impact=case.get("business_impact", ""),
                root_cause=case.get("root_cause", ""),
                related_findings_json=json.dumps(case.get("related_findings", [])),
                recommendations_json=json.dumps(case.get("recommendations", [])),
                kill_chain_stages_json=json.dumps(case.get("kill_chain_stages", [])),
                analyst_notes=case.get("analyst_notes", ""),
            )
            self._db.add(db_case)
        await self._db.flush()

    async def _persist_chains(
        self, investigation_id: str, domain: str, chains: list[dict],
    ) -> None:
        for chain in chains:
            db_chain = AttackChain(
                investigation_id=investigation_id,
                domain=domain,
                title=chain.get("title", ""),
                description=chain.get("description", ""),
                severity=chain.get("severity", "MEDIUM"),
                risk_score=chain.get("risk_score", 0.0),
                confidence=chain.get("confidence", 0.5),
                steps_json=json.dumps(chain.get("steps", [])),
                kill_chain_json=json.dumps(chain.get("kill_chain_stages", [])),
                entry_points_json=json.dumps([chain.get("entry_point", "")]),
                crown_jewels_json=json.dumps([chain.get("target", "")]),
                blocked=chain.get("blocked", False),
                blocked_reason=chain.get("blocked_reason"),
                mitigations_json=json.dumps(chain.get("mitigations", [])),
            )
            self._db.add(db_chain)
        await self._db.flush()

    async def _persist_risk(
        self, investigation_id: str, domain: str, risk: dict,
    ) -> None:
        db_risk = RiskCorrelation(
            investigation_id=investigation_id,
            domain=domain,
            asset_risk=risk.get("asset_risk", 0),
            service_risk=risk.get("service_risk", 0),
            business_risk=risk.get("business_risk", 0),
            organization_risk=risk.get("organization_risk", 0),
            exposure_risk=risk.get("exposure_risk", 0),
            technology_risk=risk.get("technology_risk", 0),
            infrastructure_risk=risk.get("infrastructure_risk", 0),
            threat_risk=risk.get("threat_risk", 0),
            overall_score=risk.get("overall_score", 0),
            risk_level=risk.get("risk_level", "LOW"),
            factor_breakdown_json=json.dumps(risk.get("factor_breakdown", [])),
        )
        self._db.add(db_risk)
        await self._db.flush()

    async def _persist_graph(
        self, investigation_id: str, domain: str, graph: dict,
    ) -> None:
        db_graph = RelationshipGraph(
            investigation_id=investigation_id,
            domain=domain,
            nodes_json=json.dumps(graph.get("nodes", [])),
            edges_json=json.dumps(graph.get("edges", [])),
            node_count=graph.get("node_count", 0),
            edge_count=graph.get("edge_count", 0),
            crown_jewels_json=json.dumps(graph.get("crown_jewels", [])),
            entry_points_json=json.dumps(graph.get("entry_points", [])),
        )
        self._db.add(db_graph)
        await self._db.flush()

    async def _update_investigation(
        self, investigation_id: str, case_count: int, risk: dict,
    ) -> None:
        """Update the parent investigation with SIB results."""
        from src.contexts.investigation.models import Investigation

        result = await self._db.execute(
            __import__("sqlalchemy").select(Investigation).where(
                Investigation.id == uuid.UUID(investigation_id),
            )
        )
        inv = result.scalar_one_or_none()
        if inv:
            inv.intelligence_cases = case_count
            inv.risk_score = risk.get("overall_score", 0)
            inv.risk_level = risk.get("risk_level", "LOW")
            await self._db.flush()

    # ------------------------------------------------------------------
    # Query API
    # ------------------------------------------------------------------

    async def get_cases(
        self, investigation_id: str,
    ) -> list[IntelligenceCase]:
        """Retrieve all intelligence cases for an investigation."""
        from sqlalchemy import select

        result = await self._db.execute(
            select(IntelligenceCase)
            .where(IntelligenceCase.investigation_id == investigation_id)
            .order_by(IntelligenceCase.confidence.desc())
        )
        return list(result.scalars().all())

    async def get_chains(
        self, investigation_id: str,
    ) -> list[AttackChain]:
        """Retrieve all attack chains."""
        from sqlalchemy import select

        result = await self._db.execute(
            select(AttackChain)
            .where(AttackChain.investigation_id == investigation_id)
            .order_by(AttackChain.risk_score.desc())
        )
        return list(result.scalars().all())

    async def get_risk(
        self, investigation_id: str,
    ) -> RiskCorrelation | None:
        """Get the latest risk correlation for an investigation."""
        from sqlalchemy import select

        result = await self._db.execute(
            select(RiskCorrelation)
            .where(RiskCorrelation.investigation_id == investigation_id)
            .order_by(RiskCorrelation.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_graph(
        self, investigation_id: str,
    ) -> RelationshipGraph | None:
        """Get the relationship graph."""
        from sqlalchemy import select

        result = await self._db.execute(
            select(RelationshipGraph)
            .where(RelationshipGraph.investigation_id == investigation_id)
            .order_by(RelationshipGraph.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()
