"""SIB Relationship Graph Builder — everything becomes a graph.

Domains → Subdomains → IPs → Ports → Services → Technologies → Findings → Threats → Business Assets → Reports

Everything linked. Every edge evidence-backed.
"""

from __future__ import annotations

from typing import Any


class SIBGraphBuilder:
    """Builds a complete relationship graph from all evidence and external context.

    Layers:
    1. Domains / Subdomains
    2. IP Addresses
    3. Ports / Services
    4. Technologies (on services)
    5. Findings (vulnerabilities, misconfigs)
    6. Threats (IOC matches, intel)
    7. Business Assets (crown jewels, critical systems)
    8. Reports (generated documents)
    """

    @staticmethod
    def build(
        entity_groups: dict[str, list],
        external: dict[str, Any],
        cross_corr: dict[str, Any],
        tech_map: dict[str, set[str]],
    ) -> dict[str, Any]:
        """Build the full relationship graph."""

        nodes: list[dict] = []
        edges: list[dict] = []
        node_ids: set[str] = set()

        # Layer 1-2: Domains, Subdomains, IPs from discovery
        discovery = external.get("discovery", {})

        for dns_rec in discovery.get("dns_records", []):
            name = dns_rec.get("name", "")
            value = dns_rec.get("value", "")
            rtype = dns_rec.get("type", "")

            # Domain node
            if name not in node_ids:
                nodes.append({
                    "id": name, "type": "domain", "label": name,
                    "layer": 1, "group": "domains",
                })
                node_ids.add(name)

            # IP node (for A/AAAA records)
            if rtype in ("A", "AAAA") and value not in node_ids:
                nodes.append({
                    "id": value, "type": "ip", "label": value,
                    "layer": 2, "group": "ips",
                })
                node_ids.add(value)

                edges.append({
                    "source": name, "target": value, "type": "resolves_to",
                    "label": rtype, "group": "dns",
                })

        # Layer 3: Ports/Services
        for svc in discovery.get("services", []):
            host = svc.get("host", "")
            port = svc.get("port", 443)
            service_id = f"{host}:{port}"
            server = svc.get("server", "")

            if service_id not in node_ids:
                nodes.append({
                    "id": service_id, "type": "service", "label": f"{host}:{port}",
                    "layer": 3, "group": "services",
                    "server": server,
                })
                node_ids.add(service_id)

            edges.append({
                "source": host, "target": service_id, "type": "hosts_service",
                "label": f":{port}", "group": "infrastructure",
            })

        # Layer 4: Technologies
        for asset, techs in tech_map.items():
            for tech in techs:
                tech_id = f"tech:{tech}"
                if tech_id not in node_ids:
                    nodes.append({
                        "id": tech_id, "type": "technology", "label": tech,
                        "layer": 4, "group": "technologies",
                    })
                    node_ids.add(tech_id)

                edges.append({
                    "source": asset, "target": tech_id, "type": "runs",
                    "label": "technology", "group": "technology",
                })

        # Layer 5: Findings (vulnerabilities, misconfigs)
        for entity_key, items in entity_groups.items():
            etype, evalue = entity_key.split(":", 1)
            for ev in items:
                if ev.evidence_type == "finding":
                    finding_id = str(ev.id)
                    if finding_id not in node_ids:
                        nodes.append({
                            "id": finding_id, "type": "finding",
                            "label": ev.title[:60],
                            "layer": 5, "group": "findings",
                            "severity": ev.severity,
                        })
                        node_ids.add(finding_id)

                    edges.append({
                        "source": evalue, "target": finding_id,
                        "type": "has_finding", "label": ev.severity,
                        "group": "findings",
                    })

        # Layer 6: Threats
        for entity_key, items in entity_groups.items():
            etype, evalue = entity_key.split(":", 1)
            for ev in items:
                if ev.evidence_type == "threat":
                    threat_id = str(ev.id)
                    if threat_id not in node_ids:
                        nodes.append({
                            "id": threat_id, "type": "threat",
                            "label": ev.title[:60],
                            "layer": 6, "group": "threats",
                            "severity": ev.severity,
                        })
                        node_ids.add(threat_id)

                    edges.append({
                        "source": evalue, "target": threat_id,
                        "type": "matched_by", "label": ev.severity,
                        "group": "threats",
                    })

        # Layer 7: Business Assets (crown jewels)
        crown_jewels = [
            n for n in nodes
            if n.get("severity") == "CRITICAL"
        ][:5]
        for jewel in crown_jewels:
            jewel_id = f"business:{jewel['id']}"
            if jewel_id not in node_ids:
                nodes.append({
                    "id": jewel_id, "type": "business_asset",
                    "label": f"Critical: {jewel['label']}",
                    "layer": 7, "group": "business",
                })
                node_ids.add(jewel_id)

            edges.append({
                "source": jewel["id"], "target": jewel_id,
                "type": "impacts", "label": "business_risk",
                "group": "business",
            })

        # Identify entry points (nodes with no incoming edges from outside)
        has_incoming = {e["target"] for e in edges}
        entry_points = [
            n for n in nodes
            if n.get("layer") in (1, 2, 3)
            and n["id"] not in has_incoming
            and n.get("type") != "threat"
        ][:10]

        return {
            "nodes": nodes,
            "edges": edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "crown_jewels": [n["id"] for n in nodes if n.get("type") == "business_asset"],
            "entry_points": [n["id"] for n in entry_points],
            "layers": {
                "1_domains": sum(1 for n in nodes if n.get("layer") == 1),
                "2_ips": sum(1 for n in nodes if n.get("layer") == 2),
                "3_services": sum(1 for n in nodes if n.get("layer") == 3),
                "4_technologies": sum(1 for n in nodes if n.get("layer") == 4),
                "5_findings": sum(1 for n in nodes if n.get("layer") == 5),
                "6_threats": sum(1 for n in nodes if n.get("layer") == 6),
                "7_business": sum(1 for n in nodes if n.get("layer") == 7),
            },
        }
