"""SIB Deduplication Engine — merges duplicate findings, evidence, risks, technologies.

Deduplication runs at every level:
- Evidence: by evidence_key + entity_value
- Findings: by title + affected_asset
- Technologies: by name per asset
- Risks: by asset_identifier
- Cases: by affected_assets intersection
"""

from __future__ import annotations

from typing import Any


class SIBDeduplicator:
    """Multi-level deduplication engine. No duplicate survives."""

    SEVERITY_RANK = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}

    @staticmethod
    def deduplicate_evidence(evidence_items: list[Any]) -> list[Any]:
        """Deduplicate evidence by (evidence_type, entity_value, title) tuple.
        Keep the highest confidence version.
        """
        seen: dict[str, Any] = {}
        for ev in evidence_items:
            key = f"{ev.evidence_type}:{ev.entity_value}:{ev.title}"
            if key not in seen or ev.confidence > seen[key].confidence:
                seen[key] = ev
        return list(seen.values())

    @staticmethod
    def deduplicate_findings(findings: list[dict]) -> list[dict]:
        """Deduplicate findings by (title, affected_asset).
        Keep the highest severity version.
        """
        seen: dict[str, dict] = {}
        for f in findings:
            key = f"{f.get('title', '')}:{f.get('affected_asset', f.get('endpoint', ''))}"
            if key not in seen:
                seen[key] = f
            else:
                existing_rank = SIBDeduplicator.SEVERITY_RANK.get(
                    seen[key].get("severity", "LOW"), 0,
                )
                new_rank = SIBDeduplicator.SEVERITY_RANK.get(
                    f.get("severity", "LOW"), 0,
                )
                if new_rank > existing_rank:
                    seen[key] = f
        return list(seen.values())

    @staticmethod
    def deduplicate_technologies(tech_list: list[dict]) -> list[dict]:
        """Deduplicate technologies by name per asset.
        Merge version info from multiple detections.
        """
        seen: dict[str, dict] = {}
        for tech in tech_list:
            name = tech.get("name", tech.get("entity_value", ""))
            asset = tech.get("asset", tech.get("entity_value", ""))
            key = f"{asset}:{name}"
            if key not in seen:
                seen[key] = tech
            else:
                # Merge — keep highest confidence, aggregate evidence
                if tech.get("confidence", 0) > seen[key].get("confidence", 0):
                    seen[key]["confidence"] = tech.get("confidence", 0)
                if tech.get("version") and not seen[key].get("version"):
                    seen[key]["version"] = tech.get("version")
        return list(seen.values())

    @staticmethod
    def deduplicate_risks(risk_scores: list[dict]) -> list[dict]:
        """Deduplicate risk scores by asset_identifier.
        Keep the most recent (highest score is NOT always correct).
        """
        seen: dict[str, dict] = {}
        for r in risk_scores:
            key = r.get("asset_identifier", "")
            if key not in seen:
                seen[key] = r
            elif r.get("score", 0) > seen[key].get("score", 0):
                seen[key] = r
        return list(seen.values())

    @staticmethod
    def deduplicate_cases(cases: list[dict]) -> list[dict]:
        """Deduplicate intelligence cases by affected_assets intersection.
        Cases covering the same assets with similar findings are merged.
        """
        if len(cases) <= 1:
            return cases

        merged: list[dict] = []
        used: set[int] = set()

        for i, case_a in enumerate(cases):
            if i in used:
                continue
            used.add(i)

            for j, case_b in enumerate(cases):
                if j <= i or j in used:
                    continue

                # Check asset overlap
                assets_a = set(case_a.get("affected_assets", []))
                assets_b = set(case_b.get("affected_assets", []))
                overlap = assets_a & assets_b

                if len(overlap) >= len(assets_a) * 0.5:
                    # Merge case_b into case_a
                    case_a = SIBDeduplicator._merge_cases(case_a, case_b)
                    used.add(j)

            merged.append(case_a)

        return merged

    @staticmethod
    def _merge_cases(a: dict, b: dict) -> dict:
        """Merge two intelligence cases, keeping the higher quality content."""
        merged = dict(a)
        merged["affected_assets"] = list(
            set(a.get("affected_assets", []) + b.get("affected_assets", []))
        )
        merged["evidence"] = list(
            set(a.get("evidence", []) + b.get("evidence", []))
        )
        merged["confidence"] = max(
            a.get("confidence", 0), b.get("confidence", 0),
        )
        merged["risk_level"] = (
            a["risk_level"]
            if SIBDeduplicator.SEVERITY_RANK.get(a.get("risk_level", "LOW"), 0)
            >= SIBDeduplicator.SEVERITY_RANK.get(b.get("risk_level", "LOW"), 0)
            else b["risk_level"]
        )
        # Combine recommendations, deduplicate
        recs_a = a.get("recommendations", [])
        recs_b = b.get("recommendations", [])
        merged["recommendations"] = list(dict.fromkeys(recs_a + recs_b))

        return merged
