"""SIB Correlation Engine — cross-context correlation.

Correlates evidence across all CEIP contexts:
discovery, vulnerability, threat, identity, attack_path,
monitoring snapshots, and historical data.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


class SIBCorrelationEngine:
    """Cross-context correlation — the first stage of the SIB pipeline.

    Takes all InvestigationEvidence for an investigation and:
    1. Groups by entity (asset, service, domain, IP)
    2. Links evidence across jobs (cross-job correlation)
    3. Connects discovery data to vulnerability findings
    4. Maps threat intel to affected assets
    5. Identifies technology stacks per asset
    6. Builds a unified correlation map
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def correlate_all(
        self, investigation_id: str, domain: str,
    ) -> dict[str, Any]:
        """Full correlation pass. Returns the correlation map for case building."""

        # 1. Load all investigation evidence
        evidence = await self._load_evidence(investigation_id)

        # 2. Load external context (discovery, vulnerability, threat data)
        external = await self._load_external_context(domain)

        # 3. Group evidence by entity
        entity_groups = self._group_by_entity(evidence)

        # 4. Cross-correlate entity groups
        cross_corr = self._cross_correlate(entity_groups, external)

        # 5. Build technology-to-asset map
        tech_map = self._build_technology_map(evidence, external)

        # 6. Build threat-to-asset map
        threat_map = self._build_threat_map(evidence, external)

        # 7. Compute correlation statistics
        stats = self._compute_stats(entity_groups, cross_corr)

        return {
            "investigation_id": investigation_id,
            "domain": domain,
            "total_evidence": len(evidence),
            "entity_groups": entity_groups,
            "cross_correlations": cross_corr,
            "technology_map": tech_map,
            "threat_map": threat_map,
            "stats": stats,
        }

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------

    async def _load_evidence(self, investigation_id: str) -> list[Any]:
        """Load all InvestigationEvidence for this investigation."""
        import uuid as _uuid
        from src.contexts.investigation.models import InvestigationEvidence

        inv_uuid = _uuid.UUID(investigation_id)
        result = await self._db.execute(
            select(InvestigationEvidence).where(
                InvestigationEvidence.investigation_id == inv_uuid,
            )
        )
        return list(result.scalars().all())

    async def _load_external_context(self, domain: str) -> dict[str, Any]:
        """Load all external context data for richer correlation."""
        external: dict[str, Any] = {}

        # Discovery data
        try:
            from sqlalchemy.orm import selectinload

            from src.contexts.discovery.models import DiscoveryJob

            r = await self._db.execute(
                select(DiscoveryJob)
                .options(
                    selectinload(DiscoveryJob.services),
                    selectinload(DiscoveryJob.dns_records),
                    selectinload(DiscoveryJob.subdomains),
                    selectinload(DiscoveryJob.certificates),
                    selectinload(DiscoveryJob.ip_enrichments),
                )
                .where(DiscoveryJob.domain == domain, DiscoveryJob.status == "done")
                .order_by(DiscoveryJob.created_at.desc())
                .limit(1)
            )
            job = r.scalar_one_or_none()
            if job:
                external["discovery"] = {
                    "services": [{"host": s.host, "port": s.port, "server": s.server}
                                 for s in job.services],
                    "dns_records": [{"type": r.record_type, "name": r.name, "value": r.value}
                                    for r in job.dns_records],
                    "subdomains": [s.name for s in job.subdomains],
                    "certificates": [{"host": c.host, "issuer": c.issuer} for c in job.certificates],
                    "ips": [{"ip": e.ip, "asn": e.asn, "org": e.asn_org}
                            for e in job.ip_enrichments],
                }
        except Exception:
            external["discovery"] = {}

        # Vulnerability findings
        try:
            from src.contexts.vulnerability.models import SecurityFinding

            r = await self._db.execute(
                select(SecurityFinding).where(SecurityFinding.domain == domain)
            )
            external["vulnerabilities"] = [
                {"cve_id": f.cve_id, "severity": f.severity, "title": f.title,
                 "affected_asset": f.affected_asset}
                for f in r.scalars().all()
            ]
        except Exception:
            external["vulnerabilities"] = []

        # Threat matches
        try:
            from src.contexts.threat.models import ThreatMatch

            r = await self._db.execute(
                select(ThreatMatch).where(ThreatMatch.domain == domain)
            )
            external["threats"] = [
                {"matched_asset": t.matched_asset, "match_type": t.match_type,
                 "threat_category": t.threat_category, "severity": t.severity}
                for t in r.scalars().all()
            ]
        except Exception:
            external["threats"] = []

        # Correlation data (asset relationships, clusters)
        try:
            from src.contexts.correlation.models import AssetCluster, AssetRelationship

            r = await self._db.execute(
                select(AssetRelationship).where(AssetRelationship.domain == domain)
            )
            external["relationships"] = [
                {"source_type": a.source_type, "source_value": a.source_value,
                 "target_type": a.target_type, "target_value": a.target_value,
                 "relationship": a.relationship, "confidence": a.confidence}
                for a in r.scalars().all()
            ]

            r = await self._db.execute(
                select(AssetCluster).where(AssetCluster.domain == domain)
            )
            external["clusters"] = [
                {"name": c.name, "cluster_type": c.cluster_type,
                 "member_count": c.member_count, "members_json": c.members_json}
                for c in r.scalars().all()
            ]
        except Exception:
            external["relationships"] = []
            external["clusters"] = []

        # Monitoring snapshots (historical data)
        try:
            from src.contexts.monitoring.models import MonitoringSnapshot

            r = await self._db.execute(
                select(MonitoringSnapshot)
                .where(MonitoringSnapshot.domain == domain)
                .order_by(MonitoringSnapshot.created_at.desc())
                .limit(10)
            )
            external["snapshots"] = [
                {"snapshot_type": s.snapshot_type, "data_json": s.data_json,
                 "created_at": s.created_at.isoformat() if s.created_at else None}
                for s in r.scalars().all()
            ]
        except Exception:
            external["snapshots"] = []

        # Identity exposures
        try:
            from src.contexts.identity_exposure.models import IdentityExposure

            r = await self._db.execute(
                select(IdentityExposure).where(IdentityExposure.domain == domain)
            )
            external["identities"] = [
                {"identity_type": i.identity_type, "value": i.value,
                 "severity": i.severity}
                for i in r.scalars().all()
            ]
        except Exception:
            external["identities"] = []

        return external

    # ------------------------------------------------------------------
    # Grouping
    # ------------------------------------------------------------------

    def _group_by_entity(self, evidence: list) -> dict[str, list]:
        """Group evidence by entity_type:entity_value."""
        groups: dict[str, list] = {}
        for ev in evidence:
            key = f"{ev.entity_type}:{ev.entity_value}"
            groups.setdefault(key, []).append(ev)
        return groups

    # ------------------------------------------------------------------
    # Cross-correlation
    # ------------------------------------------------------------------

    def _cross_correlate(
        self, entity_groups: dict, external: dict,
    ) -> dict[str, Any]:
        """Cross-correlate evidence groups with external context."""

        corr: dict[str, Any] = {
            "asset_to_vulnerability": [],
            "asset_to_threat": [],
            "asset_to_technology": [],
            "shared_infrastructure": [],
            "exposure_chain": [],
        }

        for entity_key, items in entity_groups.items():
            entity_type, entity_value = entity_key.split(":", 1)

            # Link to vulnerabilities
            for vuln in external.get("vulnerabilities", []):
                if entity_value in vuln.get("affected_asset", ""):
                    corr["asset_to_vulnerability"].append({
                        "asset": entity_value,
                        "vulnerability": vuln.get("cve_id") or vuln.get("title"),
                        "severity": vuln.get("severity"),
                    })

            # Link to threats
            for threat in external.get("threats", []):
                if entity_value in threat.get("matched_asset", ""):
                    corr["asset_to_threat"].append({
                        "asset": entity_value,
                        "threat_category": threat.get("threat_category"),
                        "severity": threat.get("severity"),
                    })

            # Link to technologies
            for tech_ev in items:
                if tech_ev.evidence_type == "technology":
                    corr["asset_to_technology"].append({
                        "asset": entity_value,
                        "technology": tech_ev.entity_value,
                    })

        return corr

    # ------------------------------------------------------------------
    # Technology/Threat maps
    # ------------------------------------------------------------------

    def _build_technology_map(
        self, evidence: list, external: dict,
    ) -> dict[str, set[str]]:
        """Map each asset to its detected technology stack."""
        tech_map: dict[str, set[str]] = {}
        for ev in evidence:
            if ev.evidence_type == "technology":
                asset = getattr(ev, "entity_value", "unknown")
                tech_map.setdefault(asset, set()).add(ev.title)
        return tech_map

    def _build_threat_map(
        self, evidence: list, external: dict,
    ) -> dict[str, list[dict]]:
        """Map each asset to its threat intelligence matches."""
        threat_map: dict[str, list[dict]] = {}
        for ev in evidence:
            if ev.evidence_type == "threat":
                asset = ev.entity_value
                threat_map.setdefault(asset, []).append({
                    "title": ev.title,
                    "severity": ev.severity,
                    "confidence": ev.confidence,
                })
        return threat_map

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def _compute_stats(
        self, entity_groups: dict, cross_corr: dict,
    ) -> dict[str, Any]:
        return {
            "total_entities": len(entity_groups),
            "asset_vuln_links": len(cross_corr["asset_to_vulnerability"]),
            "asset_threat_links": len(cross_corr["asset_to_threat"]),
            "asset_tech_links": len(cross_corr["asset_to_technology"]),
            "multi_evidence_entities": sum(
                1 for items in entity_groups.values() if len(items) > 1
            ),
        }
