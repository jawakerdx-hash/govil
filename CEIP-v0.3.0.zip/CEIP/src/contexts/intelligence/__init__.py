"""Security Intelligence Brain — central reasoning layer for CEIP."""
