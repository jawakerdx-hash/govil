"""Temporal memory — time-aware node tracking with evolution states."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from .models import TemporalNode


class TemporalMemoryGraph:
    """Extends M20 graph with time dimension. Tracks evolution per node."""

    def __init__(self) -> None:
        self._nodes: dict[str, dict[str, TemporalNode]] = {}  # tenant_id -> node_id -> node

    def track(self, tenant_id: str, node_id: str) -> TemporalNode:
        now = datetime.now(UTC).isoformat()
        nodes = self._nodes.setdefault(tenant_id, {})

        if node_id in nodes:
            existing = nodes[node_id]
            existing.last_seen = now
            if existing.evolution_state == "RESOLVED":
                existing.resurface()
            else:
                existing.evolve()
            return existing

        node = TemporalNode(
            node_id=node_id, tenant_id=tenant_id,
            first_seen=now, last_seen=now,
            frequency_score=1, evolution_state="NEW",
        )
        nodes[node_id] = node
        return node

    def resolve(self, tenant_id: str, node_id: str) -> None:
        nodes = self._nodes.get(tenant_id, {})
        if node_id in nodes:
            nodes[node_id].resolve()

    def get_evolution(self, tenant_id: str) -> dict[str, Any]:
        nodes = self._nodes.get(tenant_id, {})
        states = {"NEW": 0, "ACTIVE": 0, "RECURRING": 0, "RESOLVED": 0, "RESURFACED": 0}
        for n in nodes.values():
            states[n.evolution_state] = states.get(n.evolution_state, 0) + 1
        return {
            "total_nodes": len(nodes),
            "evolution_states": states,
            "recurring_nodes": [
                n.to_dict() for n in nodes.values()
                if n.evolution_state == "RECURRING"
            ][:10],
            "resurfaced_count": states["RESURFACED"],
        }

    def get_node(self, tenant_id: str, node_id: str) -> dict[str, Any] | None:
        nodes = self._nodes.get(tenant_id, {})
        node = nodes.get(node_id)
        return node.to_dict() if node else None
