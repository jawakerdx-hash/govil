"""M30 — Memory models. Events, decisions, queries, results."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

EVOLUTION_STATES = frozenset({"NEW", "ACTIVE", "RECURRING", "RESOLVED", "RESURFACED"})


@dataclass
class EventRecord:
    """Raw structured event from any CEIP module."""
    event_id: str
    tenant_id: str
    source_module: str  # M20-M28
    event_type: str
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    entity_refs: list[str] = field(default_factory=list)
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id, "tenant_id": self.tenant_id,
            "source_module": self.source_module, "event_type": self.event_type,
            "timestamp": self.timestamp, "entity_refs": self.entity_refs,
            "payload": self.payload,
        }


@dataclass
class TemporalNode:
    """Time-aware node extending M20 graph node."""
    node_id: str
    tenant_id: str
    first_seen: str = ""
    last_seen: str = ""
    frequency_score: int = 1
    evolution_state: str = "NEW"

    def evolve(self) -> None:
        transitions = {
            "NEW": "ACTIVE", "ACTIVE": "RECURRING",
            "RECURRING": "RECURRING", "RESURFACED": "ACTIVE",
        }
        self.evolution_state = transitions.get(self.evolution_state, self.evolution_state)
        self.frequency_score += 1

    def resolve(self) -> None:
        self.evolution_state = "RESOLVED"

    def resurface(self, new_evidence: bool = False) -> None:
        """Only trigger RESURFACED if RESOLVED AND new evidence exists."""
        if self.evolution_state == "RESOLVED" and new_evidence:
            self.evolution_state = "RESURFACED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_id": self.node_id, "tenant_id": self.tenant_id,
            "first_seen": self.first_seen, "last_seen": self.last_seen,
            "frequency_score": self.frequency_score,
            "evolution_state": self.evolution_state,
        }


@dataclass
class DecisionRecord:
    """Immutable reasoning trace from M24/M25."""
    decision_id: str
    tenant_id: str
    module_origin: str = ""  # M24, M25
    input_state_hash: str = ""
    output_result: dict[str, Any] = field(default_factory=dict)
    reasoning_trace: list[str] = field(default_factory=list)
    confidence_score: float = 0.5
    contributing_factors: list[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision_id": self.decision_id, "tenant_id": self.tenant_id,
            "module_origin": self.module_origin,
            "input_state_hash": self.input_state_hash,
            "output_result": self.output_result,
            "reasoning_trace": self.reasoning_trace,
            "confidence_score": self.confidence_score,
            "contributing_factors": self.contributing_factors,
            "timestamp": self.timestamp,
        }


@dataclass
class MemoryQuery:
    tenant_id: str
    query_text: str = ""
    filters: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "tenant_id": self.tenant_id, "query_text": self.query_text,
            "filters": self.filters,
        }


@dataclass
class MemoryResult:
    tenant_id: str
    memory_hits: list[dict[str, Any]] = field(default_factory=list)
    temporal_context: dict[str, Any] = field(default_factory=dict)
    semantic_context: dict[str, Any] = field(default_factory=dict)
    decision_history: list[dict[str, Any]] = field(default_factory=list)
    confidence_score: float = 0.5

    def to_dict(self) -> dict[str, Any]:
        return {
            "tenant_id": self.tenant_id,
            "memory_hits": self.memory_hits,
            "temporal_context": self.temporal_context,
            "semantic_context": self.semantic_context,
            "decision_history": self.decision_history,
            "confidence_score": self.confidence_score,
        }
