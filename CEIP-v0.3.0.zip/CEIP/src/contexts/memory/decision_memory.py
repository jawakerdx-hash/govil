"""Decision memory — immutable reasoning traces from M24/M25."""

from __future__ import annotations

import hashlib
from typing import Any

from .models import DecisionRecord


class DecisionMemory:
    """Stores AI reasoning outputs. Immutable. Full audit trail."""

    def __init__(self) -> None:
        self._decisions: dict[str, list[DecisionRecord]] = {}  # tenant_id -> decisions

    def record(self, tenant_id: str, output_result: dict[str, Any],
               reasoning_trace: list[str] | None = None,
               confidence: float = 0.5,
               contributing_factors: list[str] | None = None) -> DecisionRecord:
        input_hash = hashlib.sha256(
            str(output_result).encode()
        ).hexdigest()[:16]

        decision = DecisionRecord(
            decision_id=hashlib.sha256(
                f"{tenant_id}:{input_hash}".encode()
            ).hexdigest()[:16],
            tenant_id=tenant_id,
            input_state_hash=input_hash,
            output_result=output_result,
            reasoning_trace=reasoning_trace or [],
            confidence_score=confidence,
            contributing_factors=contributing_factors or [],
        )
        self._decisions.setdefault(tenant_id, []).append(decision)
        return decision

    def query(self, tenant_id: str, limit: int = 20) -> list[dict[str, Any]]:
        decisions = self._decisions.get(tenant_id, [])
        return [d.to_dict() for d in decisions[-limit:]]

    def history_count(self, tenant_id: str) -> int:
        return len(self._decisions.get(tenant_id, []))
