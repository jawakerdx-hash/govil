"""Vector memory — deterministic semantic retrieval. Tenant-isolated."""

from __future__ import annotations

import hashlib
from typing import Any


class VectorMemory:
    """Deterministic embedding-based retrieval.

    Uses content hashing for similarity. Tenant-isolated vector space.
    No cross-tenant semantic leakage. No ML models — deterministic only.
    """

    def __init__(self) -> None:
        self._documents: dict[str, list[dict[str, Any]]] = {}  # tenant_id -> docs

    def index(self, tenant_id: str, doc_id: str, content: str,
              metadata: dict[str, Any] | None = None) -> str:
        """Index a document. Returns embedding hash."""
        embedding = hashlib.sha256(content.encode()).hexdigest()
        self._documents.setdefault(tenant_id, []).append({
            "doc_id": doc_id, "content": content[:500],
            "embedding_hash": embedding[:32],
            "metadata": metadata or {},
            "tenant_id": tenant_id,
        })
        return embedding[:32]

    def search(self, tenant_id: str, query_text: str,
               top_k: int = 5, filters: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Search by content hash similarity. Tenant-scoped."""
        docs = self._documents.get(tenant_id, [])
        if not docs:
            return []

        query_hash = hashlib.sha256(query_text.encode()).hexdigest()

        scored = []
        for doc in docs:
            if filters:
                meta = doc.get("metadata", {})
                if "module_source" in filters:
                    if meta.get("source_module") not in filters["module_source"]:
                        continue
            score = self._hash_similarity(query_hash, doc["embedding_hash"])
            scored.append((score, doc))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [{"doc_id": d["doc_id"], "content": d["content"][:200],
                 "similarity_score": round(s, 3), "metadata": d["metadata"]}
                for s, d in scored[:top_k]]

    @staticmethod
    def _hash_similarity(h1: str, h2: str) -> float:
        """Hex hash character overlap ratio."""
        if not h1 or not h2:
            return 0.0
        matches = sum(1 for a, b in zip(h1, h2, strict=False) if a == b)
        return matches / max(len(h1), len(h2))

    def count(self, tenant_id: str) -> int:
        return len(self._documents.get(tenant_id, []))

    def validate_tenant(self, tenant_id: str, request_tenant: str) -> dict | None:
        if tenant_id != request_tenant:
            return {
                "status": "M30_TENANT_MEMORY_VIOLATION",
                "reason": "Cross-tenant vector space access denied",
            }
        return None
