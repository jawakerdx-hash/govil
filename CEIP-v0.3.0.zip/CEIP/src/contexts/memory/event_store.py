"""Event memory store — records all M20-M28 events with tenant isolation."""

from __future__ import annotations

from typing import Any

from .models import EventRecord


class EventStore:
    """Append-only event store. Tenant-isolated. No cross-tenant access."""

    def __init__(self) -> None:
        self._events: dict[str, list[EventRecord]] = {}  # tenant_id -> events

    def record(self, tenant_id: str, source_module: str, event_type: str,
               event_id: str, entity_refs: list[str] | None = None,
               payload: dict[str, Any] | None = None) -> EventRecord:
        event = EventRecord(
            event_id=event_id, tenant_id=tenant_id,
            source_module=source_module, event_type=event_type,
            entity_refs=entity_refs or [], payload=payload or {},
        )
        self._events.setdefault(tenant_id, []).append(event)
        return event

    def query(self, tenant_id: str, source_module: str | None = None,
              event_type: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        events = self._events.get(tenant_id, [])
        if source_module:
            events = [e for e in events if e.source_module == source_module]
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        return [e.to_dict() for e in events[-limit:]]

    def count(self, tenant_id: str) -> int:
        return len(self._events.get(tenant_id, []))

    def validate_tenant(self, tenant_id: str, request_tenant: str) -> dict | None:
        """Return violation if cross-tenant access attempted."""
        if tenant_id != request_tenant:
            return {
                "status": "M30_TENANT_MEMORY_VIOLATION",
                "reason": f"Cannot access tenant '{tenant_id}' from '{request_tenant}'",
            }
        return None
