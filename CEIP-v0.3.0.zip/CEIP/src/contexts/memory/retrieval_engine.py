"""Unified memory retrieval engine — query across all 4 memory layers."""

from __future__ import annotations

from typing import Any

from .decision_memory import DecisionMemory
from .event_store import EventStore
from .models import MemoryQuery
from .temporal_memory import TemporalMemoryGraph
from .vector_memory import VectorMemory


class MemoryRetrievalEngine:
    """Unified query interface across event, vector, temporal, and decision memory."""

    def __init__(self) -> None:
        self._events = EventStore()
        self._temporal = TemporalMemoryGraph()
        self._decisions = DecisionMemory()
        self._vectors = VectorMemory()

    def query(self, query: MemoryQuery) -> dict[str, Any]:
        tid = query.tenant_id
        filters = query.filters

        # Hard tenant validation — cross-tenant MUST fail
        if "request_tenant" in filters and filters["request_tenant"] != tid:
            return {
                "status": "M30_TENANT_MEMORY_VIOLATION",
                "reason": f"Cross-tenant access denied: {filters['request_tenant']} != {tid}",
            }

        # STRICT ORDER: temporal → semantic → event → decision
        # 1. Temporal filtering FIRST (prevents stale semantic pollution)
        temporal = self._temporal.get_evolution(tid)

        # 2. Semantic vector search SECOND
        memory_hits = self._vectors.search(tid, query.query_text, top_k=5, filters=filters)

        # 3. Event store lookup THIRD
        events = self._events.query(tid, limit=10)

        # 4. Decision trace query LAST
        decisions = self._decisions.query(tid, limit=20)

        conf = min(1.0, (
            len(memory_hits) * 0.15
            + (len(decisions) > 0) * 0.3
            + (temporal.get("total_nodes", 0) > 0) * 0.2
        ))

        return {
            "tenant_id": tid,
            "results": memory_hits,
            "semantic_context": {"hits": memory_hits, "total_docs": self._vectors.count(tid)},
            "temporal_context": temporal,
            "decision_trace": decisions,
            "event_context": events,
            "confidence_score": round(conf, 3),
        }

    def record_event(self, tenant_id: str, source_module: str, event_type: str,
                     event_id: str, entity_refs: list[str] | None = None,
                     payload: dict[str, Any] | None = None) -> Any:
        return self._events.record(tenant_id, source_module, event_type,
                                   event_id, entity_refs, payload)

    def track_node(self, tenant_id: str, node_id: str) -> Any:
        return self._temporal.track(tenant_id, node_id)

    def record_decision(self, tenant_id: str, output: dict[str, Any],
                        trace: list[str] | None = None,
                        confidence: float = 0.5) -> Any:
        return self._decisions.record(tenant_id, output, trace, confidence)

    def index_document(self, tenant_id: str, doc_id: str, content: str,
                       metadata: dict[str, Any] | None = None) -> Any:
        return self._vectors.index(tenant_id, doc_id, content, metadata)
