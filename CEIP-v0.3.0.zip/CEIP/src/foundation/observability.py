"""Observability layer — distributed tracing, structured logging, audit stream.

Every scan gets a trace_id. Every module execution gets a span.
All state changes are recorded in the audit log.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass
class TraceSpan:
    """A single execution span within a trace."""
    span_id: str
    trace_id: str
    parent_span_id: str = ""
    operation: str = ""
    module: str = ""
    scan_id: str = ""
    started_at: float = 0.0
    finished_at: float = 0.0
    status: str = "ok"  # ok | error | timeout
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def duration_ms(self) -> float:
        return (self.finished_at - self.started_at) * 1000 if self.finished_at > 0 else 0


class AuditLogger:
    """Records every significant state change for traceability."""

    def __init__(self) -> None:
        self._events: list[dict[str, Any]] = []

    def record(self, event_type: str, scan_id: str, message: str, **kwargs: Any) -> None:
        self._events.append({
            "timestamp": datetime.now(UTC).isoformat(),
            "event_type": event_type,
            "scan_id": scan_id,
            "message": message,
            **kwargs,
        })

    def get_events(self, scan_id: str | None = None) -> list[dict]:
        if scan_id:
            return [e for e in self._events if e["scan_id"] == scan_id]
        return list(self._events)

    def replay(self, scan_id: str) -> list[dict]:
        """Reconstruct the exact timeline for a scan."""
        events = self.get_events(scan_id)
        return sorted(events, key=lambda e: e["timestamp"])


class ScanTracer:
    """Distributed tracing — one trace per scan, spans per module."""

    def __init__(self) -> None:
        self._spans: dict[str, list[TraceSpan]] = {}

    def start_trace(self, scan_id: str) -> str:
        trace_id = uuid.uuid4().hex[:16]
        self._spans[scan_id] = []
        return trace_id

    def start_span(
        self, scan_id: str, operation: str, module: str = "",
        parent_span_id: str = "", trace_id: str = "",
    ) -> TraceSpan:
        span = TraceSpan(
            span_id=uuid.uuid4().hex[:12],
            trace_id=trace_id or uuid.uuid4().hex[:16],
            parent_span_id=parent_span_id,
            operation=operation,
            module=module,
            scan_id=scan_id,
            started_at=time.perf_counter(),
        )
        self._spans.setdefault(scan_id, []).append(span)
        return span

    def end_span(self, span: TraceSpan, status: str = "ok", **metadata: Any) -> None:
        span.finished_at = time.perf_counter()
        span.status = status
        span.metadata.update(metadata)

    def get_spans(self, scan_id: str) -> list[TraceSpan]:
        return self._spans.get(scan_id, [])

    def get_trace_summary(self, scan_id: str) -> dict[str, Any]:
        spans = self.get_spans(scan_id)
        if not spans:
            return {"scan_id": scan_id, "spans": 0}
        total_ms = sum(s.duration_ms for s in spans)
        errors = [s for s in spans if s.status != "ok"]
        return {
            "scan_id": scan_id,
            "total_spans": len(spans),
            "total_duration_ms": round(total_ms, 1),
            "error_spans": len(errors),
            "modules": list({s.module for s in spans if s.module}),
        }


# Singletons
audit_logger = AuditLogger()
scan_tracer = ScanTracer()
