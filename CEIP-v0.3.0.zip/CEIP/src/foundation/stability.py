"""Stability hardening — concurrency control, timeouts, memory safety.

Enforces production-grade runtime safety on the InvestigationOrchestrator.
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ConcurrencyLimit:
    """Limits concurrent scans per tenant."""
    max_per_tenant: int = 5
    max_total: int = 20


@dataclass
class TimeoutConfig:
    """Module-level timeout configuration."""
    default_seconds: int = 120
    per_module: dict[str, int] = field(default_factory=lambda: {
        "dns_resolution": 60,
        "port_scan": 60,
        "ssl_fingerprint": 30,
        "http_fingerprint": 30,
        "tech_stack_detect": 60,
        "ioc_matching": 30,
        "evidence_verification": 180,
        "intelligence_case_building": 300,
        "executive_report_generation": 120,
    })

    def get(self, module_name: str) -> int:
        return self.per_module.get(module_name, self.default_seconds)


class ConcurrencyGuard:
    """Prevents resource exhaustion by limiting concurrent scans."""

    def __init__(self, limits: ConcurrencyLimit | None = None) -> None:
        self._limits = limits or ConcurrencyLimit()
        self._active: dict[str, set[str]] = defaultdict(set)  # tenant_id -> {scan_ids}
        self._total: int = 0

    def can_start(self, tenant_id: str) -> bool:
        if self._total >= self._limits.max_total:
            return False
        tenant_count = len(self._active.get(tenant_id, set()))
        return tenant_count < self._limits.max_per_tenant

    def register(self, tenant_id: str, scan_id: str) -> None:
        self._active[tenant_id].add(scan_id)
        self._total += 1

    def release(self, tenant_id: str, scan_id: str) -> None:
        if scan_id in self._active.get(tenant_id, set()):
            self._active[tenant_id].discard(scan_id)
            self._total = max(0, self._total - 1)
            if not self._active[tenant_id]:
                del self._active[tenant_id]

    def status(self) -> dict:
        return {
            "total_active": self._total,
            "max_total": self._limits.max_total,
            "by_tenant": {t: len(s) for t, s in self._active.items()},
        }


class TimeoutExecutor:
    """Enforces per-module execution time limits."""

    def __init__(self, config: TimeoutConfig | None = None) -> None:
        self._config = config or TimeoutConfig()

    async def execute_with_timeout(
        self,
        coro: Any,
        module_name: str,
        timeout_seconds: int | None = None,
    ) -> Any:
        timeout = timeout_seconds or self._config.get(module_name)
        try:
            return await asyncio.wait_for(coro, timeout=timeout)
        except asyncio.TimeoutError:
            return TimeoutError(f"{module_name} timed out after {timeout}s")


class MemoryGuard:
    """Prevents memory leaks from accumulated scan data."""

    MAX_EVENTS_PER_SCAN = 5000
    MAX_EVIDENCE_PER_SCAN = 10000

    @classmethod
    def should_trim_events(cls, current_count: int) -> bool:
        return current_count > cls.MAX_EVENTS_PER_SCAN

    @classmethod
    def should_reject_evidence(cls, current_count: int) -> bool:
        return current_count > cls.MAX_EVIDENCE_PER_SCAN

    @classmethod
    def cleanup_scan(cls, scan_id: str, event_bus: Any) -> None:
        """Unsubscribe all channels and clean up event bus for a scan."""
        channel = f"investigation:{scan_id}"
        # EventBus cleanup — remove references to prevent memory leaks
        if hasattr(event_bus, "_subscribers"):
            event_bus._subscribers.pop(channel, None)


# Singletons
concurrency_guard = ConcurrencyGuard()
timeout_executor = TimeoutExecutor()
memory_guard = MemoryGuard()
