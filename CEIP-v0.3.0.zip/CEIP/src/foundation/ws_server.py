"""WebSocket server for real-time scan updates. Tenant-isolated channels."""

from __future__ import annotations

import asyncio
import json
from typing import Any

from .event_bus import event_bus


class ScanWebSocketServer:
    """Manages WebSocket connections. Subscribes clients to scan channels.

    ws://server:port?scanId=XYZ
    """

    def __init__(self) -> None:
        self._clients: dict[str, set[Any]] = {}  # scan_id -> set of websocket connections

    async def handle_connection(self, websocket: Any, scan_id: str) -> None:
        """Handle a single WebSocket client connection."""
        # Register client
        self._clients.setdefault(scan_id, set()).add(websocket)

        async def forward_to_client(event: dict[str, Any]) -> None:
            try:
                await websocket.send_text(json.dumps(event))
            except Exception:
                pass  # Client disconnected

        channel = event_bus.channel_for_scan(scan_id)
        event_bus.subscribe(channel, forward_to_client)

        try:
            # Send current state
            await websocket.send_text(json.dumps({
                "type": "connected", "scanId": scan_id,
            }))
            # Keep connection alive
            while True:
                try:
                    msg = await asyncio.wait_for(websocket.receive_text(), timeout=30)
                    if msg == "ping":
                        await websocket.send_text(json.dumps({"type": "pong"}))
                except TimeoutError:
                    await websocket.send_text(json.dumps({"type": "ping"}))
        except Exception:
            pass
        finally:
            event_bus.unsubscribe(channel, forward_to_client)
            clients = self._clients.get(scan_id, set())
            clients.discard(websocket)
            if not clients:
                self._clients.pop(scan_id, None)

    def client_count(self, scan_id: str) -> int:
        return len(self._clients.get(scan_id, set()))


# Global singleton
ws_server = ScanWebSocketServer()
