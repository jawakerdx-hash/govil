"""Security Intelligence Brain — correlates findings into actionable intelligence. Agent-written (GLM-5.2)."""
# ruff: noqa: E501

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class IntelligenceCase:
    case_id: str
    title: str
    executive_summary: str
    risk_level: str
    confidence: float
    evidence: list[str]
    affected_assets: list[str]
    attack_path: list[str]
    threat_context: str
    business_impact: str
    root_cause: str
    related_findings: list[str]
    recommendations: list[str]
    priority: str
    timeline: list[str]
    severity: str

    def to_dict(self) -> dict[str, Any]:
        return {"case_id": self.case_id, "title": self.title, "executive_summary": self.executive_summary, "risk_level": self.risk_level, "confidence": self.confidence, "evidence": self.evidence, "affected_assets": self.affected_assets, "attack_path": self.attack_path, "threat_context": self.threat_context, "business_impact": self.business_impact, "root_cause": self.root_cause, "related_findings": self.related_findings, "recommendations": self.recommendations, "priority": self.priority, "timeline": self.timeline, "severity": self.severity}


@dataclass
class AttackChain:
    chain_id: str
    steps: list[dict]
    overall_risk: float
    confidence: float
    description: str

    def to_dict(self) -> dict[str, Any]:
        return {"chain_id": self.chain_id, "steps": self.steps, "overall_risk": self.overall_risk, "confidence": self.confidence, "description": self.description}


@dataclass
class RiskCorrelation:
    asset_risk: float
    service_risk: float
    business_risk: float
    organization_risk: float
    exposure_risk: float
    technology_risk: float
    threat_risk: float
    overall_score: float

    def to_dict(self) -> dict[str, Any]:
        return {"asset_risk": self.asset_risk, "service_risk": self.service_risk, "business_risk": self.business_risk, "organization_risk": self.organization_risk, "exposure_risk": self.exposure_risk, "technology_risk": self.technology_risk, "threat_risk": self.threat_risk, "overall_score": self.overall_score}


class IntelligenceBrain:
    """Security Intelligence Brain — correlates 40 findings into 6 Intelligence Cases."""

    async def correlate(self, findings: list[dict], assets: list[dict], threats: list[dict], technologies: list[dict]) -> dict:
        total = len(findings)
        deduped = self._deduplicate(findings)
        cases = self._prioritize(self._build_cases(deduped, assets, threats))
        chains = self._build_attack_chains(deduped, assets)
        risk = self._compute_risk_correlation(deduped, assets, threats)
        return {"cases": [c.to_dict() for c in cases], "attack_chains": [c.to_dict() for c in chains], "risk_correlation": risk.to_dict(), "dedup_count": total - len(deduped), "total_original_findings": total}

    def _build_cases(self, findings: list[dict], assets: list[dict], threats: list[dict]) -> list[IntelligenceCase]:
        groups: dict[str, list[dict]] = {}
        for f in findings:
            groups.setdefault(f.get("affected_asset", f.get("asset_id", "unknown")), []).append(f)
        sev_rank = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
        cases = []
        for asset_id, group in groups.items():
            count = len(group)
            max_sev = max(group, key=lambda f: sev_rank.get(f.get("severity", "LOW"), 0)).get("severity", "LOW")
            priority = "CRITICAL" if max_sev == "CRITICAL" else "HIGH" if count >= 3 else "MEDIUM" if count >= 5 else "LOW"
            evidence = list({e for f in group for e in (f.get("evidence", []) if isinstance(f.get("evidence"), list) else [str(f.get("evidence", ""))])})
            recs = list({f.get("recommendation", "") for f in group if f.get("recommendation")})
            cases.append(IntelligenceCase(
                case_id=f"CASE-{asset_id}", title=f"Security Intelligence: {asset_id}",
                executive_summary=f"{count} findings affecting {asset_id}. Max severity: {max_sev}.",
                risk_level=max_sev, confidence=sum(f.get("confidence", 0.5) for f in group) / count,
                evidence=evidence, affected_assets=[asset_id],
                attack_path=[f.get("endpoint", "") for f in group],
                threat_context="Correlated threat activity detected.",
                business_impact="Potential operational disruption.",
                root_cause="Multiple security posture weaknesses.",
                related_findings=[f.get("title", "") for f in group],
                recommendations=recs, priority=priority, timeline=[], severity=max_sev,
            ))
        return cases

    def _build_attack_chains(self, findings: list[dict], assets: list[dict]) -> list[AttackChain]:
        chains = []
        for f in findings:
            if f.get("severity") not in ("CRITICAL", "HIGH"): continue
            if len(chains) >= 10: break
            chains.append(AttackChain(
                chain_id=f"CHAIN-{f.get('subdomain', f.get('endpoint', 'unknown'))}",
                steps=[{"step": 1, "action": "Exposed service", "target": f.get("endpoint", "")}, {"step": 2, "action": "Vulnerability exploited", "target": f.get("title", "")}, {"step": 3, "action": "Privilege escalation", "target": "System"}, {"step": 4, "action": "Business impact", "target": "Data compromise"}],
                overall_risk=min(1.0, f.get("risk_score", 80) / 100), confidence=f.get("confidence", 0.8),
                description=f"Attack chain via {f.get('endpoint', 'unknown')}.",
            ))
        return chains

    def _compute_risk_correlation(self, findings: list[dict], assets: list[dict], threats: list[dict]) -> RiskCorrelation:
        if not findings: return RiskCorrelation(0, 0, 0, 0, 0, 0, 0, 0)
        n = len(findings)
        a_risk = sum(f.get("risk_score", 0) for f in findings) / (n * 100)
        s_risk = len({f.get("subdomain", "") for f in findings}) * 10 / 100
        b_risk = sum(1 for f in findings if f.get("severity") == "CRITICAL") * 25 / 100
        e_risk = sum(1 for a in assets if a.get("exposure") == "public") / max(len(assets), 1)
        t_risk = sum(1 for f in findings if f.get("type") == "technology") / max(n, 1)
        th_risk = min(1.0, len(threats) / 10)
        overall = (a_risk + s_risk + b_risk + e_risk + t_risk + th_risk) / 6
        return RiskCorrelation(a_risk, s_risk, b_risk, overall, e_risk, t_risk, th_risk, overall)

    def _deduplicate(self, findings: list[dict]) -> list[dict]:
        sev_rank = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
        unique: dict[tuple, dict] = {}
        for f in findings:
            key = (f.get("title", ""), f.get("endpoint", ""))
            if key not in unique or sev_rank.get(f.get("severity", "LOW"), 0) > sev_rank.get(unique[key].get("severity", "LOW"), 0):
                unique[key] = f
        return list(unique.values())

    def _prioritize(self, cases: list[IntelligenceCase]) -> list[IntelligenceCase]:
        sev_rank = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
        return sorted(cases, key=lambda c: (-sev_rank.get(c.severity, 0), -c.confidence, -len(c.evidence)))

    def generate_intelligence_report(self, findings: list[dict], assets: list[dict], threats: list[dict], technologies: list[dict]) -> dict:
        return self.correlate(findings, assets, threats, technologies)
