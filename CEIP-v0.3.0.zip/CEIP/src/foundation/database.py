"""Database engine, session factory, and dependency."""

from __future__ import annotations

from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from src.config import Settings


def create_engine(settings: Settings) -> AsyncEngine:
    """Build an async SQLAlchemy engine from application settings."""
    return create_async_engine(
        settings.database_url,
        echo=settings.debug,
        pool_size=5,
        max_overflow=10,
        pool_pre_ping=True,
    )


def create_session_factory(
    engine: AsyncEngine,
) -> async_sessionmaker[AsyncSession]:
    """Create an async session factory bound to the given engine."""
    return async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def init_db(settings: Settings) -> None:
    """Create all tables if they don't exist (dev convenience)."""
    # Import all models so SQLAlchemy discovers their tables
    from src.contexts.attack_path import models as _am  # noqa: F401
    from src.contexts.brand_protection import models as _bm  # noqa: F401
    from src.contexts.correlation import models as _cm  # noqa: F401
    from src.contexts.discovery import models as _dm  # noqa: F401
    from src.contexts.gateway import models as _gm  # noqa: F401
    from src.contexts.identity import models as _idm  # noqa: F401
    from src.contexts.identity_exposure import models as _im  # noqa: F401
    from src.contexts.monitoring import models as _mm  # noqa: F401
    from src.contexts.risk import models as _rm  # noqa: F401
    from src.contexts.threat import models as _tm  # noqa: F401
    from src.contexts.vulnerability import models as _vm  # noqa: F401
    from src.kernel.base_model import Base

    engine = create_engine(settings)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await engine.dispose()


async def get_db(
    settings: Settings,
) -> AsyncGenerator[AsyncSession]:
    """FastAPI dependency — yields an async database session."""
    engine = create_engine(settings)
    session_factory = create_session_factory(engine)
    async with session_factory() as session:
        try:
            yield session
        finally:
            await engine.dispose()
