"""Redis Pub/Sub compatible event bus. In-memory implementation.

Production: swap to aioredis pub/sub with same interface.
Channel format: scan:{scanId}
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from typing import Any

Subscriber = Callable[[dict[str, Any]], None]


class EventBus:
    """Pub/Sub event bus. Tenant-isolated channels."""

    def __init__(self) -> None:
        self._subscribers: dict[str, list[Subscriber]] = {}

    def subscribe(self, channel: str, callback: Subscriber) -> None:
        """Subscribe to a channel. channel = scan:{scanId}"""
        self._subscribers.setdefault(channel, []).append(callback)

    def unsubscribe(self, channel: str, callback: Subscriber) -> None:
        subs = self._subscribers.get(channel, [])
        if callback in subs:
            subs.remove(callback)

    async def publish(self, channel: str, event: dict[str, Any]) -> None:
        """Publish event to all subscribers on a channel."""
        event["timestamp"] = int(time.time() * 1000)
        subs = self._subscribers.get(channel, [])
        for cb in subs:
            try:
                if asyncio.iscoroutinefunction(cb):
                    await cb(event)
                else:
                    cb(event)
            except Exception:
                pass  # Log in production

    def channel_for_scan(self, scan_id: str) -> str:
        return f"scan:{scan_id}"

    def emit_module_update(self, scan_id: str, module: str, status: str,
                           progress: int, findings: list | None = None) -> None:
        """Emit a module_update event to the scan channel."""
        asyncio.create_task(self.publish(
            self.channel_for_scan(scan_id),
            {
                "type": "module_update",
                "scanId": scan_id,
                "module": module,
                "status": status,
                "progress": progress,
                "findings": findings or [],
            },
        ))

    def emit_scan_started(self, scan_id: str, domain: str) -> None:
        asyncio.create_task(self.publish(
            self.channel_for_scan(scan_id),
            {"type": "scan_started", "scanId": scan_id, "domain": domain, "progress": 0},
        ))

    def emit_scan_completed(self, scan_id: str, result: dict) -> None:
        asyncio.create_task(self.publish(
            self.channel_for_scan(scan_id),
            {"type": "scan_completed", "scanId": scan_id, "progress": 100, "result": result},
        ))

    def channel_count(self) -> int:
        return len(self._subscribers)


# Global singleton
event_bus = EventBus()
