"""Redis-compatible task queue. In-memory. Swap to Redis/BullMQ in production."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

SCAN_PIPELINE = [
    ("M1-Recon", 5), ("M2-Subdomains", 15), ("M3-DNS", 25),
    ("M4-HTTP-Fingerprint", 35), ("M5-Headers", 45), ("M6-Vulnerability", 55),
    ("M7-ThreatIntel", 65), ("M8-RiskEngine", 75), ("M9-AIAnalyst", 85),
    ("M10-Reports", 100),
]


@dataclass
class ScanJob:
    scan_id: str
    tenant_id: str
    domain: str
    status: str = "pending"
    progress: int = 0
    current_module: str = ""
    logs: list[str] = field(default_factory=list)
    result: dict[str, Any] | None = None
    retries: int = 0
    max_retries: int = 3


class TaskQueue:
    """Async job queue. Replace with Redis/BullMQ in production."""

    def __init__(self) -> None:
        self._queue: asyncio.Queue[ScanJob] = asyncio.Queue()
        self._results: dict[str, ScanJob] = {}
        self._workers: list[asyncio.Task] = []
        self._running = False

    async def enqueue(self, job: ScanJob) -> None:
        """Push job into queue. Never execute directly."""
        self._results[job.scan_id] = job
        await self._queue.put(job)

    async def get_job(self, scan_id: str) -> ScanJob | None:
        return self._results.get(scan_id)

    async def start_workers(self, count: int = 2, processor: Callable | None = None) -> None:
        self._running = True
        for i in range(count):
            t = asyncio.create_task(self._worker_loop(i, processor))
            self._workers.append(t)

    async def stop_workers(self) -> None:
        self._running = False
        for t in self._workers:
            t.cancel()
        self._workers.clear()

    async def _worker_loop(self, wid: int, processor: Callable | None) -> None:
        while self._running:
            try:
                job = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                job.status = "running"
                if processor:
                    await processor(job)
                self._queue.task_done()
            except TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                import traceback
                print(f"[Worker {wid}] Error: {exc}\n{traceback.format_exc()}", flush=True)


# Global singleton
task_queue = TaskQueue()
