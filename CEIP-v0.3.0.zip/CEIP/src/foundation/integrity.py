"""Scan Integrity Validator — anti-fake, anti-corruption enforcement.

Every module output is validated before acceptance.
No fake data, no empty results, no placeholders survive this layer.
"""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from typing import Any


class IntegrityViolation(Exception):
    """Raised when a module output fails integrity checks."""
    pass


class ScanIntegrityGuard:
    """Rejects fake/empty/synthetic data at the boundary.

    Called after every phase completes. Validates:
    - Evidence items are non-empty
    - DNS records have valid format
    - CVE IDs match expected format
    - No placeholder or template strings exist
    """

    # Patterns that indicate fake/placeholder data
    FAKE_PATTERNS = [
        "example.com", "placeholder", "TODO", "FIXME",
        "template", "synthetic", "mock", "fake", "hardcoded",
    ]

    @classmethod
    def validate_evidence(cls, evidence_items: list[dict]) -> None:
        """Raise IntegrityViolation if any evidence item fails checks."""
        if not evidence_items:
            raise IntegrityViolation("Phase produced zero evidence items")

        for item in evidence_items:
            title = str(item.get("title", "")).lower()
            desc = str(item.get("description", "")).lower()

            # Check for fake patterns
            for pattern in cls.FAKE_PATTERNS:
                if pattern in title or pattern in desc:
                    raise IntegrityViolation(
                        f"Evidence contains fake pattern '{pattern}': {item.get('title', '')}"
                    )

            # Check for empty content
            if not item.get("title", "").strip():
                raise IntegrityViolation("Evidence item has empty title")

            # Validate CVE format
            if "cve" in title or "CVE" in str(item.get("data", {})):
                cve_check = str(item.get("data", {}))
                if "CVE-" in cve_check:
                    import re
                    if not re.search(r"CVE-\d{4}-\d{4,}", cve_check):
                        raise IntegrityViolation(
                            f"Invalid CVE format in evidence: {item.get('title', '')}"
                        )

        return None  # All checks passed

    @classmethod
    def compute_checksum(cls, data: dict[str, Any]) -> str:
        """Compute a deterministic checksum for scan result integrity."""
        canonical = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    @classmethod
    def validate_scan_completion(
        cls,
        investigation_data: dict[str, Any],
        expected_phases: int = 19,
    ) -> dict[str, Any]:
        """Verify a scan is genuinely complete — no missing phases, no faked results."""
        phases = investigation_data.get("phases", [])
        errors = []

        # Check all phases exist
        completed_phases = [p for p in phases if p.get("status") in ("completed", "completed_with_errors")]
        if len(completed_phases) < expected_phases:
            errors.append(
                f"Only {len(completed_phases)}/{expected_phases} phases completed"
            )

        # Check evidence exists
        if investigation_data.get("evidence_count", 0) == 0:
            errors.append("Zero evidence — scan may be fake")

        # Check no phase has zero evidence
        for p in phases:
            if p.get("status") == "completed" and p.get("completed_jobs", 0) == 0:
                errors.append(f"Phase {p.get('phase_number')} completed with 0 jobs")

        if errors:
            raise IntegrityViolation("; ".join(errors))

        return {
            "valid": True,
            "checksum": cls.compute_checksum(investigation_data),
            "validated_at": datetime.now(UTC).isoformat(),
        }


# Singleton
integrity_guard = ScanIntegrityGuard()
