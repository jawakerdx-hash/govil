"""Prometheus metrics exporter for CEIP services.

Exports: HTTP latency, graph traversal time, risk calc time,
memory usage, queue depth, PDF render time.
"""

from __future__ import annotations

import time
from collections import defaultdict
from typing import Any


class MetricsRegistry:
    """Simple in-memory metrics registry. Export-ready for Prometheus."""

    def __init__(self) -> None:
        self._counters: dict[str, int] = defaultdict(int)
        self._histograms: dict[str, list[float]] = defaultdict(list)
        self._gauges: dict[str, float] = defaultdict(float)

    def counter_inc(self, name: str, value: int = 1) -> None:
        self._counters[name] += value

    def histogram_observe(self, name: str, value: float) -> None:
        self._histograms[name].append(value)

    def gauge_set(self, name: str, value: float) -> None:
        self._gauges[name] = value

    def export_prometheus(self) -> str:
        lines: list[str] = []
        for name, val in self._counters.items():
            lines.append(f"ceip_{name}_total {val}")
        for name, vals in self._histograms.items():
            if vals:
                avg = sum(vals) / len(vals)
                lines.append(f"ceip_{name}_seconds_avg {avg:.4f}")
                lines.append(f"ceip_{name}_seconds_max {max(vals):.4f}")
                lines.append(f"ceip_{name}_count {len(vals)}")
        for name, val in self._gauges.items():
            lines.append(f"ceip_{name} {val}")
        return "\n".join(lines) + "\n"

    def snapshot(self) -> dict[str, Any]:
        return {
            "counters": dict(self._counters),
            "gauges": dict(self._gauges),
            "histogram_avgs": {
                k: round(sum(v) / len(v), 4) for k, v in self._histograms.items() if v
            },
        }


# Global singleton
metrics = MetricsRegistry()


def track_latency(metric_name: str):
    """Decorator to track function latency in histogram."""

    def decorator(func):
        async def wrapper(*args, **kwargs):
            t0 = time.perf_counter()
            result = await func(*args, **kwargs)
            elapsed = (time.perf_counter() - t0) * 1000
            metrics.histogram_observe(metric_name, elapsed)
            metrics.counter_inc(f"{metric_name}_calls")
            return result

        return wrapper

    return decorator
