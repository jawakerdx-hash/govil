"""Technology Intelligence Engine — 12 modular detectors. Agent-written (GLM-5.2)."""
# ruff: noqa: E501, E701

from __future__ import annotations

import re
from dataclasses import dataclass, field

CATEGORIES = [
    "web_server", "reverse_proxy", "cdn", "cloud", "framework", "cms",
    "language", "database", "cache", "auth", "api_type", "security_header",
    "waf", "tls", "certificate", "javascript_lib", "analytics", "monitoring",
    "os", "container",
]


@dataclass
class TechSignal:
    category: str
    name: str
    version: str
    confidence: float
    evidence: str
    source: str


class BaseDetector:
    def detect(self, headers: dict, body: str, url: str, tls_info: dict) -> list[TechSignal]:
        try:
            return self._detect(headers, body, url, tls_info)
        except Exception:
            return []

    def _detect(self, headers: dict, body: str, url: str, tls_info: dict) -> list[TechSignal]:
        raise NotImplementedError


class WebServerDetector(BaseDetector):
    MAPPING = {"apache": "Apache", "nginx": "Nginx", "iis": "Microsoft-IIS", "litespeed": "LiteSpeed", "caddy": "Caddy", "tomcat": "Apache Tomcat", "gunicorn": "gunicorn", "uwsgi": "uWSGI", "express": "Express.js"}

    def _detect(self, h, b, u, t):
        sigs = []
        for k, n in self.MAPPING.items():
            if k in str(h.get("Server", "")).lower() or k in str(h.get("server", "")).lower():
                sigs.append(TechSignal("web_server", n, "", 0.9, "Server header", "http_header"))
            if k in str(h.get("X-Powered-By", "")).lower():
                sigs.append(TechSignal("web_server", n, "", 0.8, "X-Powered-By", "http_header"))
        return sigs


class CDNDetector(BaseDetector):
    MAP = {"cloudflare": "Cloudflare", "akamai": "Akamai", "fastly": "Fastly", "cloudfront": "CloudFront", "keycdn": "KeyCDN"}

    def _detect(self, h, b, u, t):
        sigs = []
        combined = " ".join(str(v) for v in h.values()).lower()
        for k, n in self.MAP.items():
            if k in combined:
                sigs.append(TechSignal("cdn", n, "", 0.9, f"CDN signal: {k}", "http_header"))
        return sigs


class CloudDetector(BaseDetector):
    def _detect(self, h, b, u, t):
        sigs = []
        s = " ".join(f"{k}:{v}" for k, v in h.items()).lower()
        if "x-amz-request-id" in s: sigs.append(TechSignal("cloud", "AWS", "", 0.95, "X-Amz-Request-Id", "http_header"))
        if "x-gcp" in s: sigs.append(TechSignal("cloud", "GCP", "", 0.95, "GCP headers", "http_header"))
        if "x-azure" in s: sigs.append(TechSignal("cloud", "Azure", "", 0.95, "Azure headers", "http_header"))
        return sigs


class FrameworkDetector(BaseDetector):
    MAP = {"next.js": "Next.js", "react": "React", "vue": "Vue.js", "angular": "Angular", "django": "Django", "rails": "Ruby on Rails", "laravel": "Laravel", "spring": "Spring Boot", "express": "Express.js", "flask": "Flask"}

    def _detect(self, h, b, u, t):
        sigs = []
        pb = str(h.get("X-Powered-By", ""))
        ck = str(h.get("Set-Cookie", ""))
        gm = re.search(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)["\']', b, re.I)
        gen = gm.group(1) if gm else ""
        combined = f"{pb} {ck} {gen}".lower()
        for k, n in self.MAP.items():
            if k in combined: sigs.append(TechSignal("framework", n, "", 0.85, f"Framework: {k}", "header_or_body"))
        return sigs


class CMSDetector(BaseDetector):
    MAP = {"wordpress": "WordPress", "drupal": "Drupal", "joomla": "Joomla", "shopify": "Shopify", "magento": "Magento", "ghost": "Ghost"}

    def _detect(self, h, b, u, t):
        sigs = []
        if "wp-content" in b.lower(): sigs.append(TechSignal("cms", "WordPress", "", 0.95, "wp-content path", "body"))
        gen = str(h.get("X-Generator", ""))
        gm = re.search(r'<meta[^>]+name=["\']generator["\'][^>]+content=["\']([^"\']+)["\']', b, re.I)
        if gm: gen += " " + gm.group(1)
        for k, n in self.MAP.items():
            if k in gen.lower(): sigs.append(TechSignal("cms", n, "", 0.85, f"CMS: {k}", "header_or_body"))
        return sigs


class LanguageDetector(BaseDetector):
    def _detect(self, h, b, u, t):
        sigs = []
        ck = str(h.get("Set-Cookie", "")).lower()
        if "phpsessid" in ck: sigs.append(TechSignal("language", "PHP", "", 0.9, "PHPSESSID cookie", "http_header"))
        if "csrftoken" in ck: sigs.append(TechSignal("language", "Python", "", 0.8, "CSRF token cookie", "http_header"))
        if "jsessionid" in ck: sigs.append(TechSignal("language", "Java", "", 0.8, "JSESSIONID cookie", "http_header"))
        pb = str(h.get("X-Powered-By", "")).lower()
        for k, n in {"php": "PHP", "python": "Python", "node.js": "Node.js", "ruby": "Ruby", "java": "Java"}.items():
            if k in pb: sigs.append(TechSignal("language", n, "", 0.75, f"Language: {k}", "http_header"))
        return sigs


class SecurityHeaderDetector(BaseDetector):
    HEADERS = ["Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy"]

    def _detect(self, h, b, u, t):
        sigs = []
        lh = {k.lower(): v for k, v in h.items()}
        for hdr in self.HEADERS:
            if hdr.lower() in lh: sigs.append(TechSignal("security_header", hdr, "", 1.0, f"{hdr} present", "http_header"))
            else: sigs.append(TechSignal("security_header", hdr, "", 1.0, f"{hdr} MISSING", "http_header"))
        return sigs


class WAFDetector(BaseDetector):
    MAP = {"cloudflare": "Cloudflare WAF", "akamai": "Akamai WAF", "imperva": "Imperva", "f5": "F5 ASM", "sucuri": "Sucuri", "aws": "AWS WAF"}

    def _detect(self, h, b, u, t):
        sigs = []
        s = " ".join(f"{k}:{v}" for k, v in h.items()).lower()
        for k, n in self.MAP.items():
            if k in s: sigs.append(TechSignal("waf", n, "", 0.9, f"WAF: {k}", "http_header"))
        return sigs


class TLSDetector(BaseDetector):
    def _detect(self, h, b, u, t):
        sigs = []
        if not t: return sigs
        ver = t.get("tls_version", "")
        if ver:
            conf = 0.2 if ver in ("TLSv1", "TLSv1.1") else 0.8 if ver == "TLSv1.2" else 1.0
            sigs.append(TechSignal("tls", ver, "", conf, f"TLS: {ver}", "tls_info"))
        iss = t.get("certificate_issuer", "")
        if iss: sigs.append(TechSignal("certificate", iss, "", 1.0, f"Cert: {iss}", "tls_info"))
        return sigs


class JavaScriptLibDetector(BaseDetector):
    MAP = {"jquery": "jQuery", "react": "React", "vue": "Vue.js", "angular": "Angular", "bootstrap": "Bootstrap", "lodash": "Lodash", "moment": "Moment.js", "d3": "D3.js", "axios": "Axios", "chart.js": "Chart.js"}

    def _detect(self, h, b, u, t):
        sigs = []
        scripts = " ".join(re.findall(r'<script[^>]+src=["\']([^"\']+)["\']', b, re.I)).lower()
        for k, n in self.MAP.items():
            if k in scripts: sigs.append(TechSignal("javascript_lib", n, "", 0.8, f"JS lib: {k}", "body"))
        return sigs


class AnalyticsDetector(BaseDetector):
    MAP = {"ga.js": "Google Analytics", "gtag": "Google Analytics", "gtm": "Google Tag Manager", "fbevents": "Facebook Pixel", "hotjar": "Hotjar", "segment": "Segment", "amplitude": "Amplitude", "mixpanel": "Mixpanel", "plausible": "Plausible", "matomo": "Matomo"}

    def _detect(self, h, b, u, t):
        sigs = []
        bl = b.lower()
        for k, n in self.MAP.items():
            if k in bl: sigs.append(TechSignal("analytics", n, "", 0.85, f"Analytics: {k}", "body"))
        return sigs


class DatabaseDetector(BaseDetector):
    MAP = {"mysql": "MySQL", "postgresql": "PostgreSQL", "mongodb": "MongoDB", "redis": "Redis", "elasticsearch": "Elasticsearch"}

    def _detect(self, h, b, u, t):
        sigs = []
        s = (" ".join(f"{k}:{v}" for k, v in h.items()) + " " + b).lower()
        for k, n in self.MAP.items():
            if k in s: sigs.append(TechSignal("database", n, "", 0.6, f"DB pattern: {k}", "header_or_body"))
        return sigs


@dataclass
class TechProfile:
    asset_id: str
    tech_stack: list[TechSignal] = field(default_factory=list)
    relationships: dict = field(default_factory=dict)
    risk_indicators: list = field(default_factory=list)
    confidence: float = 0.0

    def to_dict(self) -> dict:
        return {"asset_id": self.asset_id, "tech_stack": [vars(ts) for ts in self.tech_stack], "relationships": self.relationships, "risk_indicators": self.risk_indicators, "confidence": self.confidence}


class TechIntelligenceEngine:
    """12-detector technology fingerprinting engine. Agent-written (GLM-5.2)."""

    def __init__(self) -> None:
        self.detectors = [WebServerDetector(), CDNDetector(), CloudDetector(), FrameworkDetector(), CMSDetector(), LanguageDetector(), SecurityHeaderDetector(), WAFDetector(), TLSDetector(), JavaScriptLibDetector(), AnalyticsDetector(), DatabaseDetector()]

    async def analyze(self, url: str, headers: dict, body: str, tls_info: dict) -> TechProfile:
        profile = TechProfile(asset_id=url)
        signals: list[TechSignal] = []
        for d in self.detectors:
            signals.extend(d.detect(headers, body, url, tls_info))
        profile.tech_stack = signals
        cats = {s.category for s in signals}
        if "cdn" in cats and "web_server" in cats: profile.relationships["cdn_to_origin"] = "CDN fronting web server"
        if "waf" in cats: profile.relationships["waf_protection"] = "WAF active"
        for s in signals:
            if s.category == "tls" and s.confidence <= 0.2: profile.risk_indicators.append(f"Weak TLS: {s.name}")
            if s.category == "security_header" and "MISSING" in s.evidence: profile.risk_indicators.append(f"Missing: {s.name}")
        profile.confidence = round(sum(s.confidence for s in signals) / len(signals), 2) if signals else 0.0
        return profile
