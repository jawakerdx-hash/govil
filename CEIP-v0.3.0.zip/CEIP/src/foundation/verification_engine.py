"""Verification & Evidence Engine — every finding must be evidence-backed."""
# ruff: noqa: E501

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EvidenceItem:
    source: str
    timestamp: str
    confidence: float
    collector: str
    stage: str
    data: dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def to_dict(self) -> dict:
        return {"source": self.source, "timestamp": self.timestamp, "confidence": self.confidence, "collector": self.collector, "stage": self.stage, "data": self.data}


@dataclass
class VerifiedFinding:
    finding_id: str
    title: str = ""
    severity: str = "LOW"
    description: str = ""
    technical_details: str = ""
    evidence: list[EvidenceItem] = field(default_factory=list)
    detection_confidence: float = 0.0
    verification_confidence: float = 0.0
    evidence_strength: float = 0.0
    business_confidence: float = 0.0
    overall_confidence: float = 0.0
    affected_assets: list[str] = field(default_factory=list)
    affected_endpoints: list[str] = field(default_factory=list)
    technologies: list[str] = field(default_factory=list)
    risk_score: float = 0.0
    business_impact: str = ""
    verification_result: str = "PENDING"
    verification_notes: str = ""
    recommendations: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    false_positive_risk: float = 0.0

    def to_dict(self) -> dict:
        return {"finding_id": self.finding_id, "title": self.title, "severity": self.severity, "description": self.description, "technical_details": self.technical_details, "evidence": [e.to_dict() for e in self.evidence], "detection_confidence": self.detection_confidence, "verification_confidence": self.verification_confidence, "evidence_strength": self.evidence_strength, "business_confidence": self.business_confidence, "overall_confidence": self.overall_confidence, "affected_assets": self.affected_assets, "affected_endpoints": self.affected_endpoints, "technologies": self.technologies, "risk_score": self.risk_score, "business_impact": self.business_impact, "verification_result": self.verification_result, "verification_notes": self.verification_notes, "recommendations": self.recommendations, "references": self.references, "false_positive_risk": self.false_positive_risk}


class EvidenceCollector:
    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        enriched = list(evidence)
        for item in enriched:
            item.stage = "evidence_collection"
        notes = f"Collected {len(enriched)} evidence items"
        if len(enriched) < 2:
            notes += " (WEAK: single source)"
        elif len(enriched) >= 3:
            notes += " (STRONG: 3+ sources)"
        return finding, notes, enriched


class EvidenceCorrelator:
    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        sources = list({e.source for e in evidence})
        if len(sources) >= 3:
            boost = 0.2
            notes = f"3+ independent sources ({', '.join(sources[:3])}): confidence boost +{boost:.0%}"
        elif len(sources) == 1:
            notes = f"WEAK_EVIDENCE: only 1 source ({sources[0]})"
        else:
            notes = f"{len(sources)} sources: moderate confidence"
        return finding, notes, evidence


class ConfidenceEvaluator:
    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        sev_map = {"CRITICAL": 0.95, "HIGH": 0.85, "MEDIUM": 0.65, "LOW": 0.40}
        detection = sev_map.get(finding.get("severity", "LOW"), 0.5)
        verification = min(1.0, len(evidence) * 0.25) if evidence else 0.2
        evidence_strength = min(1.0, sum(e.confidence for e in evidence) / max(len(evidence), 1))
        business = 0.7 if finding.get("severity") in ("CRITICAL", "HIGH") else 0.5
        overall = round(detection * 0.30 + verification * 0.30 + evidence_strength * 0.25 + business * 0.15, 2)
        finding["detection_confidence"] = detection
        finding["verification_confidence"] = verification
        finding["evidence_strength"] = evidence_strength
        finding["business_confidence"] = business
        finding["overall_confidence"] = overall
        notes = f"Overall confidence: {overall:.0%} (det={detection:.0%}, ver={verification:.0%}, evd={evidence_strength:.0%}, biz={business:.0%})"
        return finding, notes, evidence


class VerificationLogic:
    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        overall = finding.get("overall_confidence", 0.5)
        strength = finding.get("evidence_strength", 0.5)
        if overall >= 0.85 and strength >= 0.7:
            result = "CONFIRMED"
        elif overall >= 0.65:
            result = "LIKELY"
        elif overall >= 0.40:
            result = "POSSIBLE"
        else:
            result = "FALSE_POSITIVE"
        finding["verification_result"] = result
        fp_risk = 1.0 - overall
        finding["false_positive_risk"] = round(fp_risk, 2)
        notes = f"Verification: {result} (FP risk: {fp_risk:.0%})"
        return finding, notes, evidence


class DuplicateDetector:
    def __init__(self) -> None:
        self._seen: set[str] = set()

    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        key = f"{finding.get('title','')}|{finding.get('endpoint','')}|{finding.get('severity','')}"
        if key in self._seen:
            return finding, "DUPLICATE: finding already reported", evidence
        self._seen.add(key)
        return finding, "Unique finding", evidence


class RiskValidator:
    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        sev = finding.get("severity", "LOW")
        conf = finding.get("overall_confidence", 0.5)
        if sev == "CRITICAL" and conf < 0.5:
            return finding, "RISK_MISMATCH: CRITICAL severity with low confidence evidence", evidence
        if sev == "HIGH" and conf < 0.3:
            return finding, "RISK_MISMATCH: HIGH severity with very low confidence", evidence
        return finding, "Risk validation passed", evidence


class BusinessImpactEstimator:
    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        sev = finding.get("severity", "LOW")
        impact = {"CRITICAL": "Immediate action required — patch within 24 hours", "HIGH": "Action required this week", "MEDIUM": "Address within 30 days", "LOW": "Monitor and address in next cycle"}
        finding["business_impact"] = impact.get(sev, "Monitor")
        return finding, f"Business impact: {finding['business_impact']}", evidence


class AnalystSummaryGenerator:
    def execute(self, finding: dict, evidence: list[EvidenceItem]) -> tuple[dict, str, list[EvidenceItem]]:
        what = finding.get("title", "Unknown finding")
        where = finding.get("endpoint", finding.get("subdomain", "unknown asset"))
        why = f"Severity: {finding.get('severity', 'LOW')}, Confidence: {finding.get('overall_confidence', 0):.0%}"
        action = finding.get("recommendation", finding.get("business_impact", "Review and assess"))
        summary = f"WHAT: {what} | WHERE: {where} | WHY: {why} | ACTION: {action}"
        finding["description"] = summary
        return finding, summary, evidence


class VerificationPipeline:
    """8-stage verification pipeline. Every finding must pass through."""

    def __init__(self) -> None:
        self.stages = [EvidenceCollector(), EvidenceCorrelator(), ConfidenceEvaluator(), VerificationLogic(), DuplicateDetector(), RiskValidator(), BusinessImpactEstimator(), AnalystSummaryGenerator()]

    async def verify(self, finding: dict, evidence: list[EvidenceItem]) -> VerifiedFinding:
        ev = list(evidence)
        notes_log: list[str] = []
        for stage in self.stages:
            try:
                finding, notes, ev = stage.execute(finding, ev)
                notes_log.append(f"[{stage.__class__.__name__}] {notes}")
            except Exception as exc:
                notes_log.append(f"[{stage.__class__.__name__}] ERROR: {exc}")

        return VerifiedFinding(
            finding_id=finding.get("scan_id", "") + "_" + (finding.get("title", "unknown")[:30]),
            title=finding.get("title", ""), severity=finding.get("severity", "LOW"),
            description=finding.get("description", ""),
            technical_details=finding.get("description", ""),
            evidence=ev, detection_confidence=finding.get("detection_confidence", 0),
            verification_confidence=finding.get("verification_confidence", 0),
            evidence_strength=finding.get("evidence_strength", 0),
            business_confidence=finding.get("business_confidence", 0),
            overall_confidence=finding.get("overall_confidence", 0),
            affected_assets=[finding.get("subdomain", finding.get("asset", ""))],
            affected_endpoints=[finding.get("endpoint", "")],
            technologies=[],
            risk_score=finding.get("risk_score", 50),
            business_impact=finding.get("business_impact", ""),
            verification_result=finding.get("verification_result", "PENDING"),
            verification_notes=" | ".join(notes_log),
            recommendations=[finding.get("recommendation", "Review and assess")],
            references=[r.get("source", "") for r in evidence],
            false_positive_risk=finding.get("false_positive_risk", 0.5),
        )
