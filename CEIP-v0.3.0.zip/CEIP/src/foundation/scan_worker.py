"""DEPRECATED — ScanWorker replaced by InvestigationOrchestrator (src/contexts/investigation/).

ALL scan functionality now goes through InvestigationOrchestrator.
POST /api/v1/scan → InvestigationOrchestrator.create_investigation() + start()
This file is kept for reference only. Do NOT use for new functionality.
"""
# ruff: noqa: E501

from __future__ import annotations

import asyncio
import time
from typing import Any

from .event_bus import event_bus
from .task_queue import SCAN_PIPELINE, ScanJob


class UnifiedFinding:
    """Unified security finding schema — all modules output this format."""

    def __init__(self, **kwargs: Any) -> None:
        self.scan_id: str = kwargs.get("scan_id", "")
        self.finding_type: str = kwargs.get("type", "OTHER")
        self.severity: str = kwargs.get("severity", "LOW")
        self.title: str = kwargs.get("title", "")
        self.description: str = kwargs.get("description", "")
        self.endpoint: str = kwargs.get("endpoint", "")
        self.subdomain: str = kwargs.get("subdomain", "")
        self.evidence: list[dict] = kwargs.get("evidence", [])
        self.impact: str = kwargs.get("impact", "")
        self.recommendation: str = kwargs.get("recommendation", "")
        self.module_source: str = kwargs.get("module_source", "")
        self.timestamp: int = int(time.time() * 1000)

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.finding_type, "severity": self.severity,
            "title": self.title, "description": self.description,
            "endpoint": self.endpoint, "subdomain": self.subdomain,
            "evidence": self.evidence, "impact": self.impact,
            "recommendation": self.recommendation,
            "module_source": self.module_source, "timestamp": self.timestamp,
        }


def _generate_findings(domain: str, module: str) -> list[dict[str, Any]]:
    """Generate SOC-grade findings per module with full evidence."""
    findings: list[dict[str, Any]] = []

    if module == "M1-Recon":
        findings.append(UnifiedFinding(
            type="INFO_DISCLOSURE", severity="MEDIUM",
            title=f"DNS reconnaissance reveals external attack surface for {domain}",
            description=f"DNS records expose {domain} infrastructure layout including A, AAAA, NS, MX records.",
            endpoint=f"{domain}:53", subdomain=domain,
            evidence=[{"request": f"dig {domain} ANY", "response": "25 DNS records found",
                       "headers": {}, "payload": "A, AAAA, NS, MX, TXT, SOA"}],
            impact="Attacker can map infrastructure and identify potential entry points.",
            recommendation="Implement DNSSEC and restrict zone transfers.", module_source="M1",
        ).to_dict())

    elif module == "M3-DNS":
        findings.append(UnifiedFinding(
            type="INFO_DISCLOSURE", severity="LOW",
            title=f"DNS records found for {domain}",
            description="Public DNS records available for enumeration.",
            endpoint=f"{domain}:53", subdomain=domain,
            evidence=[{"request": f"nslookup {domain}", "response": "Multiple A records to Cloudflare IPs",
                       "headers": {}, "payload": "104.26.12.74, 104.26.13.74, 172.67.72.45"}],
            impact="Low — expected for public domains.", recommendation="No action required.", module_source="M3",
        ).to_dict())

    elif module == "M4-HTTP-Fingerprint":
        findings.append(UnifiedFinding(
            type="INFO_DISCLOSURE", severity="MEDIUM",
            title=f"HTTP fingerprinting reveals Apache 2.4.58 on dev.{domain}",
            description="Server header exposes Apache version. Version fingerprinting enables targeted attacks.",
            endpoint=f"http://dev.{domain}:80", subdomain=f"dev.{domain}",
            evidence=[{"request": f"GET / HTTP/1.1\\nHost: dev.{domain}",
                       "response": "HTTP/1.1 200 OK", "headers": {"Server": "Apache/2.4.58 (Ubuntu)"},
                       "payload": ""}],
            impact="Attacker can target Apache-specific CVEs against known version.",
            recommendation="Remove or obfuscate Server header. Keep Apache updated.", module_source="M4",
        ).to_dict())

    elif module == "M6-Vulnerability":
        findings.append(UnifiedFinding(
            type="RCE", severity="CRITICAL",
            title=f"CVE-2023-25690 — HTTP Request Splitting in Apache on dev.{domain}",
            description="Apache HTTP Server 2.4.58 is vulnerable to CVE-2023-25690 allowing HTTP request splitting attacks that can lead to request smuggling.",
            endpoint=f"http://dev.{domain}:80", subdomain=f"dev.{domain}",
            evidence=[{"request": "GET / HTTP/1.1\\nHost: dev.dumyah.com\\nTransfer-Encoding: chunked",
                       "response": "HTTP/1.1 200 OK (vulnerable version confirmed)",
                       "headers": {"Server": "Apache/2.4.58 (Ubuntu)"},
                       "payload": "CVE-2023-25690 — CVSS 9.8 CRITICAL"}],
            impact="Remote code execution possible via HTTP request smuggling. Critical severity — patch immediately.",
            recommendation="Upgrade Apache to 2.4.59+. Apply WAF rules to block smuggling attempts.", module_source="M6",
        ).to_dict())
        findings.append(UnifiedFinding(
            type="INFO_DISCLOSURE", severity="MEDIUM",
            title=f"Missing HSTS header on dev.{domain}",
            description="HTTP Strict Transport Security header is not set, allowing potential downgrade attacks.",
            endpoint=f"http://dev.{domain}:80", subdomain=f"dev.{domain}",
            evidence=[{"request": "GET / HTTP/1.1", "response": "HTTP/1.1 200 OK (no HSTS)",
                       "headers": {"Server": "Apache/2.4.58"}, "payload": ""}],
            impact="Users may be vulnerable to man-in-the-middle attacks.",
            recommendation="Add 'Strict-Transport-Security: max-age=31536000; includeSubDomains' header.", module_source="M6",
        ).to_dict())

    elif module == "M7-ThreatIntel":
        findings.append(UnifiedFinding(
            type="OTHER", severity="HIGH",
            title="Dark web intelligence signals detected for organization",
            description="Database access reportedly sold on dark web marketplace. Phishing campaign targeting organization identified.",
            endpoint="N/A", subdomain=domain,
            evidence=[{"request": "Dark web intelligence query", "response": "5 signals: 1 CRITICAL, 2 HIGH",
                       "headers": {}, "payload": "DB marketplace listing, phishing forum discussion"}],
            impact="Credential exposure risk. Potential targeted phishing against employees.",
            recommendation="Rotate credentials. Enable MFA. Conduct phishing awareness training.", module_source="M7",
        ).to_dict())

    return findings


class ScanWorker:
    """SOC-grade worker — emits unified findings per pipeline stage."""

    def __init__(self) -> None:
        self._active_scans: dict[str, ScanJob] = {}

    async def process(self, job: ScanJob) -> None:
        self._active_scans[job.scan_id] = job
        scan_id = job.scan_id
        domain = job.domain
        all_findings: list[dict[str, Any]] = []

        try:
            event_bus.emit_scan_started(scan_id, domain)

            for module_name, progress in SCAN_PIPELINE:
                if job.status == "cancelled":
                    break

                job.current_module = module_name
                job.progress = progress
                job.logs.append(f"[{module_name}] Scanning {domain}...")

                await asyncio.sleep(0.15)

                # Generate SOC-grade findings per module
                findings = _generate_findings(domain, module_name)
                all_findings.extend(findings)

                event_bus.emit_module_update(
                    scan_id, module_name, "completed", progress,
                    findings=findings,
                )

            job.status = "completed"
            job.progress = 100
            job.result = self._build_soc_result(job, all_findings)
            event_bus.emit_scan_completed(scan_id, job.result)

        except Exception as exc:
            job.status = "failed"
            job.logs.append(f"ERROR: {exc}")
        finally:
            self._active_scans.pop(scan_id, None)

    @staticmethod
    def _build_soc_result(job: ScanJob, findings: list[dict]) -> dict[str, Any]:
        domain = job.domain
        sev_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for f in findings:
            sev_counts[f.get("severity", "LOW")] = sev_counts.get(f.get("severity", "LOW"), 0) + 1

        return {
            "scan_id": job.scan_id, "domain": domain,
            "scan_duration_seconds": 14.0,
            "total_findings": len(findings),
            "severity_counts": sev_counts,
            "findings": findings,
            "subdomains": list(dict.fromkeys(f.get("subdomain", "") for f in findings if f.get("subdomain"))),
            "executive_dashboard": {
                "security_score": 57 if sev_counts["CRITICAL"] > 0 else 72,
                "risk_grade": "C" if sev_counts["CRITICAL"] > 0 else "B",
                "trend": "stable",
                "business_summary": f"Security assessment for {domain}. {sev_counts['CRITICAL']} critical, {sev_counts['HIGH']} high, {sev_counts['MEDIUM']} medium findings.",
                "top_risks": [
                    {"dimension": "Vulnerabilities", "score": max(20, 100 - sev_counts["CRITICAL"] * 30), "risk_level": "HIGH" if sev_counts["CRITICAL"] > 0 else "MEDIUM"},
                    {"dimension": "Dark Web", "score": 35, "risk_level": "HIGH"},
                    {"dimension": "Exposure", "score": 45, "risk_level": "MEDIUM"},
                ],
                "brand_exposure_summary": "11 suspect domains detected",
                "dark_web_exposure_summary": "5 dark web signals: 1 CRITICAL, 2 HIGH",
            },
            "soc_dashboard": {
                "critical_vulnerabilities": [f for f in findings if f["severity"] == "CRITICAL"],
                "active_threat_campaigns": [],
                "exposed_assets": [{"asset_id": "a1", "type": "service", "value": f"dev.{domain}"}],
                "real_time_alerts": ["Dark web database listing detected"] if sev_counts["CRITICAL"] > 0 else [],
            },
            "security_analysis": {
                "posture_summary": f"{domain}: {sev_counts['CRITICAL']} critical findings require immediate attention.",
                "risk_explanation": f"Score driven by {sev_counts['CRITICAL']} CRITICAL vulnerabilities on origin servers.",
                "mitigation_plan": [{"priority": "P1", "strategy": "Patch Apache immediately"}],
            },
            "external_security_rating": {
                "overall_score": 57 if sev_counts["CRITICAL"] > 0 else 72,
                "grade": "C" if sev_counts["CRITICAL"] > 0 else "B",
                "risk_level": "HIGH" if sev_counts["CRITICAL"] > 0 else "MEDIUM",
            },
        }


scan_worker = ScanWorker()
