"""CEIP — Cyber Exposure Intelligence Platform."""

__version__ = "0.1.0"
