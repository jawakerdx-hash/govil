"""FastAPI auth dependency — validates tokens via Gateway AuthEngine.

All /api/v1/* routes MUST pass through get_current_user.
Health endpoints are excluded.
"""

from __future__ import annotations

from collections.abc import Callable

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from src.contexts.gateway.auth import AuthEngine
from src.contexts.gateway.models import AuthToken
from src.contexts.gateway.rbac import RBACEngine

security = HTTPBearer(auto_error=False)
_rbac = RBACEngine()


# ---------------------------------------------------------------------------
# FastAPI dependency — validates token and returns AuthToken
# ---------------------------------------------------------------------------


async def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(security),  # noqa: B008
) -> AuthToken:
    """Validate the Bearer token on every request.

    Raises 401 if token is missing, invalid, or expired.
    Routes that don't require auth should NOT include this dependency.
    """
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    result = AuthEngine.validate(credentials.credentials)

    if isinstance(result, dict) and "error" in result:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=result.get("reason", "Invalid token"),
            headers={"WWW-Authenticate": "Bearer"},
        )

    if isinstance(result, AuthToken) and result.is_expired():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return result  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# RBAC permission checker factory
# ---------------------------------------------------------------------------


def require_role(role: str) -> Callable:
    """Factory: returns a dependency that checks the user has the required role."""

    async def check_role(
        user: AuthToken = Depends(get_current_user),  # noqa: B008
    ) -> AuthToken:
        if not _rbac.has_role(user, role):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{role}' required. You have '{user.role}'.",
            )
        return user

    return check_role


def require_permission(permission: str) -> Callable:
    """Factory: returns a dependency that checks the user has the required permission."""

    async def check_permission(
        user: AuthToken = Depends(get_current_user),  # noqa: B008
    ) -> AuthToken:
        if not _rbac.has_permission(user, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission '{permission}' required.",
            )
        return user

    return check_permission


# ---------------------------------------------------------------------------
# Tenant isolation helper
# ---------------------------------------------------------------------------


def get_tenant_id(user: AuthToken = Depends(get_current_user)) -> str:  # noqa: B008
    """Extract tenant_id from authenticated user token."""
    return user.tenant_id
