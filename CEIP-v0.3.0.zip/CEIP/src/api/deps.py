"""FastAPI dependency injection."""

from __future__ import annotations

from functools import lru_cache

from src.config import Settings


@lru_cache
def get_settings() -> Settings:
    """Return cached application settings."""
    return Settings()
