"""FastAPI application factory — auth enforced on all /api/v1/* routes."""

from __future__ import annotations

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.api.routes.analyst import router as analyst_router
from src.api.routes.attack_path_api import router as attack_path_router
from src.api.routes.auth_router import router as auth_router
from src.api.routes.brand_protection_api import router as brand_router
from src.api.routes.correlation import router as correlation_router
from src.api.routes.dashboard import router as dashboard_router
from src.api.routes.discovery import router as discovery_router
from src.api.routes.exposure import router as exposure_router
from src.api.routes.health import router as health_router
from src.api.routes.identity_exposure_api import router as identity_exposure_router
from src.api.routes.intelligence import router as intelligence_router
from src.api.routes.investigation_api import router as investigation_router
from src.api.routes.monitoring import router as monitoring_router
from src.api.routes.provider_api import router as provider_router
from src.api.routes.reporting import router as reporting_router
from src.api.routes.risk import router as risk_router
from src.api.routes.scan_api import router as scan_router
from src.api.routes.threat import router as threat_router
from src.api.routes.vulnerability import router as vulnerability_router


def create_app() -> FastAPI:
    # ------------------------------------------------------------------
    # Lifespan — runs DB migrations at startup (replaces deprecated on_event)
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        from src.config import Settings as _Settings
        from src.contexts.intelligence import models as _intel_models  # noqa: F401
        from src.contexts.investigation import models as _inv_models  # noqa: F401
        from src.foundation.database import create_engine
        from src.kernel.base_model import Base

        settings = _Settings()
        engine = create_engine(settings)
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        await engine.dispose()
        yield

    app = FastAPI(
        title="CEIP",
        version="0.1.0",
        docs_url="/docs" if __debug__ else None,
        redoc_url=None,
        lifespan=lifespan,
    )

    # ------------------------------------------------------------------
    # Auth middleware — validates tokens on /api/v1/* routes
    # ------------------------------------------------------------------

    @app.middleware("http")
    async def auth_middleware(request: Request, call_next):
        path = request.url.path

        # Public paths — no auth required
        public_prefixes = (
            "/health", "/metrics", "/docs", "/openapi.json",
            "/auth/", "/ws/",  # WebSocket uses query params for auth
        )
        is_public = any(path.startswith(p) for p in public_prefixes)
        is_options = request.method == "OPTIONS"

        if not is_public and not is_options and path.startswith("/api/"):
            from src.contexts.gateway.auth import AuthEngine

            auth_header = request.headers.get("Authorization", "")
            if not auth_header.startswith("Bearer "):
                return JSONResponse(
                    status_code=401,
                    content={"detail": "Missing authentication token"},
                    headers={"WWW-Authenticate": "Bearer"},
                )

            token = auth_header[7:]  # strip "Bearer "
            result = AuthEngine.validate(token)

            if isinstance(result, dict) and "error" in result:
                return JSONResponse(
                    status_code=401,
                    content={"detail": result.get("reason", "Invalid token")},
                    headers={"WWW-Authenticate": "Bearer"},
                )

            # Store user info in request state for downstream use
            request.state.user = result

            # RBAC: viewers can only GET, analysts/admins can write
            user_role = getattr(result, 'role', 'viewer')
            if request.method in ("POST", "PUT", "DELETE", "PATCH"):
                if user_role == "viewer":
                    return JSONResponse(
                        status_code=403,
                        content={"detail": "Write access denied for viewer role"},
                    )

        response = await call_next(request)
        return response

    # ------------------------------------------------------------------
    # Middleware
    # ------------------------------------------------------------------

    origins = os.environ.get("CEIP_CORS_ORIGINS", "http://localhost:3000,http://localhost:3002").split(",")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[o.strip() for o in origins],
        allow_credentials=True,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-TENANT-ID"],
    )

    # ------------------------------------------------------------------
    # Route registration
    # ------------------------------------------------------------------

    # Public routes (no auth)
    app.include_router(health_router)
    app.include_router(auth_router)
    app.include_router(provider_router, prefix="/api/v1")

    # Protected routes (auth enforced by middleware)
    app.include_router(scan_router, prefix="/api/v1")
    app.include_router(discovery_router, prefix="/api/v1")
    app.include_router(correlation_router, prefix="/api/v1")
    app.include_router(vulnerability_router, prefix="/api/v1")
    app.include_router(threat_router, prefix="/api/v1")
    app.include_router(risk_router, prefix="/api/v1")
    app.include_router(analyst_router, prefix="/api/v1")
    app.include_router(exposure_router, prefix="/api/v1")
    app.include_router(identity_exposure_router, prefix="/api/v1")
    app.include_router(investigation_router, prefix="/api/v1")
    app.include_router(intelligence_router, prefix="/api/v1")
    app.include_router(monitoring_router, prefix="/api/v1")
    app.include_router(dashboard_router, prefix="/api/v1")
    app.include_router(reporting_router, prefix="/api/v1")
    app.include_router(attack_path_router, prefix="/api/v1")
    app.include_router(brand_router, prefix="/api/v1")

    return app
