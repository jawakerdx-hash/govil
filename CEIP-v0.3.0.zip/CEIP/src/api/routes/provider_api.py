"""Provider health and status API — check all intelligence connectors."""

from __future__ import annotations

from fastapi import APIRouter

from src.contexts.threat.providers.registry import threat_registry

router = APIRouter(prefix="/providers", tags=["providers"])


@router.get("/health")
async def provider_health() -> dict:
    """Check health of all configured threat intelligence providers."""
    health = await threat_registry.health_check_all()
    return {
        "total": len(health),
        "healthy": sum(1 for h in health.values() if h.status == "healthy"),
        "degraded": sum(1 for h in health.values() if h.status == "degraded"),
        "down": sum(1 for h in health.values() if h.status == "down"),
        "providers": {
            name: {
                "status": h.status,
                "latency_ms": h.latency_ms,
                "error": h.error,
            }
            for name, h in health.items()
        },
    }


@router.get("/providers")
async def list_providers() -> dict:
    """List all registered threat intelligence providers."""
    return {
        "providers": threat_registry.list_providers(),
        "total": len(threat_registry.list_providers()),
    }
