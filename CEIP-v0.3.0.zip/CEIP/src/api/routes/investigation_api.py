"""Investigation API — REST + WebSocket endpoints for the Investigation Orchestrator.

Backward compatible: old /scan endpoints route through investigation system.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.deps import get_settings
from src.config import Settings
from src.contexts.investigation.job_registry import PHASE_NAMES, JobRegistry
from src.contexts.investigation.models import (
    Investigation,
)
from src.contexts.investigation.orchestrator import InvestigationOrchestrator
from src.contexts.investigation.schemas import (
    CreateInvestigationRequest,
    EvidenceItem,
    IntelligenceCaseResponse,
    InvestigationDetail,
    InvestigationListResponse,
    InvestigationProgress,
    InvestigationSummary,
    PhaseSummary,
    TimelineEvent,
)
from src.foundation.database import create_engine, create_session_factory, init_db
from src.foundation.event_bus import event_bus

router = APIRouter(prefix="/investigations", tags=["investigations"])


# ---------------------------------------------------------------------------
# Dependency: get DB session
# ---------------------------------------------------------------------------


async def get_db(
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> AsyncGenerator[AsyncSession]:
    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as session:
        yield session
    await engine.dispose()


async def get_orchestrator(
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> InvestigationOrchestrator:
    return InvestigationOrchestrator(db, event_bus)


# ---------------------------------------------------------------------------
# Investigation CRUD
# ---------------------------------------------------------------------------


@router.post("", response_model=InvestigationDetail, status_code=201)
async def create_investigation(
    body: CreateInvestigationRequest,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationDetail:
    """Create a new investigation for a domain. Optionally start immediately."""
    inv = await orch.create_investigation(
        domain=body.domain,
        tenant_id=body.tenant_id,
        priority=body.priority,
    )

    if body.start_immediately:
        inv = await orch.start(inv.id)

    return _to_detail(inv)


@router.get("", response_model=InvestigationListResponse)
async def list_investigations(
    tenant_id: str = Query("default"),
    status: str | None = Query(None),
    limit: int = Query(50, le=100),
    offset: int = Query(0, ge=0),
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationListResponse:
    """List investigations for a tenant."""
    investigations = await orch.list_investigations(
        tenant_id=tenant_id, status=status, limit=limit, offset=offset,
    )
    return InvestigationListResponse(
        investigations=[_to_summary(inv) for inv in investigations],
        total=len(investigations),
        offset=offset,
        limit=limit,
    )


@router.get("/{investigation_id}", response_model=InvestigationDetail)
async def get_investigation(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationDetail:
    """Get full investigation details."""
    inv = await orch._load_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return _to_detail(inv)


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


@router.post("/{investigation_id}/start", response_model=InvestigationDetail)
async def start_investigation(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationDetail:
    """Start a pending investigation."""
    inv = await orch.start(investigation_id)
    return _to_detail(inv)


@router.post("/{investigation_id}/pause", response_model=InvestigationDetail)
async def pause_investigation(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationDetail:
    """Pause a running investigation."""
    inv = await orch.pause(investigation_id)
    return _to_detail(inv)


@router.post("/{investigation_id}/resume", response_model=InvestigationDetail)
async def resume_investigation(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationDetail:
    """Resume a paused investigation."""
    inv = await orch.resume(investigation_id)
    return _to_detail(inv)


@router.post("/{investigation_id}/cancel", response_model=InvestigationDetail)
async def cancel_investigation(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationDetail:
    """Cancel an investigation."""
    inv = await orch.cancel(investigation_id)
    return _to_detail(inv)


# ---------------------------------------------------------------------------
# Progress
# ---------------------------------------------------------------------------


@router.get("/{investigation_id}/progress", response_model=InvestigationProgress)
async def get_progress(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> InvestigationProgress:
    """Get detailed investigation progress."""
    progress = await orch.get_progress(investigation_id)
    if "error" in progress:
        raise HTTPException(status_code=404, detail=progress["error"])

    phases = [
        PhaseSummary(
            phase_number=p["phase_number"],
            name=p["name"],
            status=p["status"],
            job_count=p["job_count"],
            completed_jobs=p["completed_jobs"],
            failed_jobs=p["failed_jobs"],
            started_at=p.get("started_at"),
            completed_at=p.get("completed_at"),
        )
        for p in progress.get("phases", [])
    ]

    return InvestigationProgress(
        investigation_id=uuid.UUID(progress["investigation_id"]),
        domain=progress["domain"],
        status=progress["status"],
        current_phase=progress["current_phase"],
        progress_pct=progress["progress_pct"],
        total_jobs=progress["total_jobs"],
        completed_jobs=progress["completed_jobs"],
        failed_jobs=progress["failed_jobs"],
        running_jobs=progress["running_jobs"],
        evidence_count=progress["evidence_count"],
        asset_count=progress["asset_count"],
        finding_count=progress["finding_count"],
        risk_score=progress["risk_score"],
        risk_level=progress["risk_level"],
        phases=phases,
    )


# ---------------------------------------------------------------------------
# Evidence
# ---------------------------------------------------------------------------


@router.get("/{investigation_id}/evidence")
async def get_evidence(
    investigation_id: uuid.UUID,
    evidence_type: str | None = Query(None),
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> list[EvidenceItem]:
    """Get all evidence for an investigation."""
    items = await orch.get_evidence(investigation_id, evidence_type)
    return [
        EvidenceItem(
            id=ev.id,
            evidence_type=ev.evidence_type,
            severity=ev.severity,
            title=ev.title,
            description=ev.description,
            source_module=ev.source_module,
            entity_type=ev.entity_type,
            entity_value=ev.entity_value,
            confidence=ev.confidence,
            verified=ev.verified,
        )
        for ev in items
    ]


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------


@router.get("/{investigation_id}/jobs")
async def get_jobs(
    investigation_id: uuid.UUID,
    phase: int | None = Query(None, ge=1, le=19),
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> list[dict]:
    """Get all jobs for an investigation."""
    jobs = await orch.get_jobs(investigation_id, phase)
    return [
        {
            "id": str(j.id),
            "phase": j.phase,
            "job_type": j.job_type,
            "worker": j.worker,
            "status": j.status,
            "attempt": j.attempt,
            "max_attempts": j.max_attempts,
            "duration_ms": j.duration_ms,
            "error": (json.loads(j.error_json).get("error") if j.error_json else None),
            "started_at": j.started_at.isoformat() if j.started_at else None,
            "completed_at": j.completed_at.isoformat() if j.completed_at else None,
        }
        for j in jobs
    ]


@router.post("/{investigation_id}/jobs/{job_id}/retry")
async def retry_job(
    investigation_id: uuid.UUID,
    job_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> dict:
    """Manually retry a failed job."""
    job = await orch._load_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")

    job.status = "pending"
    job.attempt = 0
    job.error_json = None
    await orch._db.commit()

    # Re-dispatch the phase to execute this job
    import asyncio as _asyncio
    _asyncio.create_task(orch._execute_phase_jobs_bg(investigation_id, job.phase))

    return {"status": "dispatched", "job_id": str(job_id), "phase": job.phase}


# ---------------------------------------------------------------------------
# Timeline
# ---------------------------------------------------------------------------


@router.get("/{investigation_id}/timeline")
async def get_timeline(
    investigation_id: uuid.UUID,
    limit: int = Query(100, le=500),
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> list[TimelineEvent]:
    """Get investigation timeline events."""
    entries = await orch.get_timeline(investigation_id, limit)
    return [
        TimelineEvent(
            id=ev.id,
            phase=ev.phase,
            event_type=ev.event_type,
            message=ev.message,
            sequence=ev.sequence,
            created_at=ev.created_at,
        )
        for ev in entries
    ]


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------


@router.get("/{investigation_id}/report")
async def get_report(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> dict:
    """Get generated investigation report."""
    inv = await orch._load_investigation(investigation_id)
    if inv is None:
        raise HTTPException(status_code=404, detail="Investigation not found")

    evidence = await orch.get_evidence(investigation_id)

    # Try to generate intelligence cases
    try:
        from src.foundation.intelligence_brain import IntelligenceBrain

        findings = [
            {
                "title": ev.title,
                "severity": ev.severity,
                "endpoint": ev.entity_value,
                "affected_asset": ev.entity_value,
                "asset_id": ev.entity_value,
                "confidence": ev.confidence,
                "risk_score": ev.confidence * 100,
                "subdomain": ev.entity_value if ev.entity_type == "subdomain" else inv.domain,
            }
            for ev in evidence
        ]
        assets = [
            {"id": ev.entity_value, "exposure": "public" if ev.severity == "HIGH" else "internal"}
            for ev in evidence if ev.evidence_type == "asset"
        ]
        threats = [
            {"indicator": ev.entity_value, "severity": ev.severity}
            for ev in evidence if ev.evidence_type == "threat"
        ]
        technologies = [
            {"name": ev.entity_value}
            for ev in evidence if ev.evidence_type == "technology"
        ]

        brain = IntelligenceBrain()
        intel_result = brain.correlate(findings, assets, threats, technologies)
        cases = intel_result.get("cases", [])
        chains = intel_result.get("attack_chains", [])
    except Exception:
        cases = []
        chains = []

    return {
        "investigation_id": str(inv.id),
        "domain": inv.domain,
        "status": inv.status,
        "generated_at": inv.completed_at.isoformat() if inv.completed_at else None,
        "risk_score": inv.risk_score,
        "risk_level": inv.risk_level,
        "asset_count": inv.asset_count,
        "finding_count": inv.finding_count,
        "evidence_count": inv.evidence_count,
        "intelligence_cases": inv.intelligence_cases,
        "attack_paths": [c for c in chains],
        "intelligence": [dict(c) for c in cases],
        "sections": [
            {
                "title": "Risk Overview",
                "description": f"Risk Score: {inv.risk_score}/100 ({inv.risk_level})",
            },
            {
                "title": "Asset Inventory",
                "description": f"{inv.asset_count} assets discovered",
            },
            {
                "title": "Findings",
                "description": f"{inv.finding_count} findings from {inv.evidence_count} evidence items",
            },
        ],
    }


# ---------------------------------------------------------------------------
# Intelligence
# ---------------------------------------------------------------------------


@router.get("/{investigation_id}/intelligence")
async def get_intelligence(
    investigation_id: uuid.UUID,
    orch: InvestigationOrchestrator = Depends(get_orchestrator),  # noqa: B008
) -> list[IntelligenceCaseResponse]:
    """Get intelligence cases for an investigation."""
    evidence = await orch.get_evidence(investigation_id)

    try:
        from src.foundation.intelligence_brain import IntelligenceBrain

        findings = [
            {
                "title": ev.title,
                "severity": ev.severity,
                "endpoint": ev.entity_value,
                "affected_asset": ev.entity_value,
                "asset_id": ev.entity_value,
                "confidence": ev.confidence,
                "risk_score": ev.confidence * 100,
                "recommendation": ev.description or "",
            }
            for ev in evidence
        ]
        brain = IntelligenceBrain()
        intel_result = brain.correlate(
            findings,
            [{"id": ev.entity_value, "exposure": "public"} for ev in evidence if ev.evidence_type == "asset"],
            [{"indicator": ev.entity_value, "severity": ev.severity} for ev in evidence if ev.evidence_type == "threat"],
            [{"name": ev.entity_value} for ev in evidence if ev.evidence_type == "technology"],
        )

        return [
            IntelligenceCaseResponse(
                case_id=c.get("case_id", ""),
                title=c.get("title", ""),
                executive_summary=c.get("executive_summary", ""),
                risk_level=c.get("risk_level", c.get("severity", "LOW")),
                confidence=c.get("confidence", 0.5),
                evidence=c.get("evidence", []) if isinstance(c.get("evidence"), list) else [str(c.get("evidence", ""))],
                affected_assets=c.get("affected_assets", []),
                attack_path=c.get("attack_path", []) if isinstance(c.get("attack_path"), list) else [str(c.get("attack_path", ""))],
                threat_context=str(c.get("threat_context", "")),
                business_impact=str(c.get("business_impact", "")),
                root_cause=str(c.get("root_cause", "")),
                recommendations=c.get("recommendations", []) if isinstance(c.get("recommendations"), list) else [str(c.get("recommendations", ""))],
                priority=c.get("priority", c.get("severity", "MEDIUM")),
            )
            for c in intel_result.get("cases", [])
        ]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# WebSocket
# ---------------------------------------------------------------------------


@router.websocket("/ws/{investigation_id}")
async def investigation_websocket(
    websocket: WebSocket,
    investigation_id: str,
) -> None:
    """WebSocket endpoint for real-time investigation updates."""
    origin = websocket.headers.get("origin", "")
    allowed = ["http://localhost:3000", "http://localhost", "http://127.0.0.1:3000"]
    if origin and not any(o in origin for o in allowed):
        await websocket.close(code=1008)
        return

    await websocket.accept()

    # Subscribe to investigation events
    async def forward_to_client(event: dict) -> None:
        try:
            await websocket.send_text(json.dumps(event))
        except Exception:
            pass

    channel = f"investigation:{investigation_id}"
    event_bus.subscribe(channel, forward_to_client)

    await websocket.send_text(json.dumps({
        "type": "connected",
        "investigationId": investigation_id,
    }))

    try:
        while True:
            try:
                msg = await asyncio.wait_for(websocket.receive_text(), timeout=30)
                if msg == "ping":
                    await websocket.send_text(json.dumps({"type": "pong"}))
            except TimeoutError:
                await websocket.send_text(json.dumps({"type": "ping"}))
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        event_bus.unsubscribe(channel, forward_to_client)


# ---------------------------------------------------------------------------
# Phases info
# ---------------------------------------------------------------------------


@router.get("/phases/info")
async def get_phases_info() -> dict:
    """Get information about the 19 investigation phases and their job types."""
    return {
        "phases": {
            num: {
                "name": PHASE_NAMES[num],
                "job_types": [
                    {
                        "job_type": jd.job_type,
                        "description": jd.description,
                        "produces_evidence": jd.produces_evidence,
                    }
                    for jd in JobRegistry.get_phase_jobs(num)
                ],
            }
            for num in sorted(PHASE_NAMES.keys())
        },
        "total_job_types": JobRegistry.total_count(),
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_detail(inv: Investigation) -> InvestigationDetail:
    phases = [
        PhaseSummary(
            phase_number=p.phase_number,
            name=p.name,
            status=p.status,
            job_count=p.job_count,
            completed_jobs=p.completed_jobs,
            failed_jobs=p.failed_jobs,
            started_at=p.started_at,
            completed_at=p.completed_at,
        )
        for p in sorted(inv.phases, key=lambda x: x.phase_number)
    ]

    timeline = [
        TimelineEvent(
            id=t.id,
            phase=t.phase,
            event_type=t.event_type,
            message=t.message,
            sequence=t.sequence,
            created_at=t.created_at,
        )
        for t in sorted(inv.timeline_events, key=lambda x: x.sequence)[-20:]
    ]

    return InvestigationDetail(
        id=inv.id,
        domain=inv.domain,
        tenant_id=inv.tenant_id,
        status=inv.status,
        priority=inv.priority,
        current_phase=inv.current_phase,
        progress_pct=inv.progress_pct,
        total_jobs=inv.total_jobs,
        completed_jobs=inv.completed_jobs,
        failed_jobs=inv.failed_jobs,
        running_jobs=inv.running_jobs,
        evidence_count=inv.evidence_count,
        asset_count=inv.asset_count,
        finding_count=inv.finding_count,
        risk_score=inv.risk_score,
        risk_level=inv.risk_level,
        intelligence_cases=inv.intelligence_cases,
        error_message=inv.error_message,
        created_at=inv.created_at,
        started_at=inv.started_at,
        completed_at=inv.completed_at,
        phases=phases,
        recent_timeline=timeline,
    )


def _to_summary(inv: Investigation) -> InvestigationSummary:
    return InvestigationSummary(
        id=inv.id,
        domain=inv.domain,
        tenant_id=inv.tenant_id,
        status=inv.status,
        priority=inv.priority,
        current_phase=inv.current_phase,
        progress_pct=inv.progress_pct,
        risk_score=inv.risk_score,
        risk_level=inv.risk_level,
        evidence_count=inv.evidence_count,
        created_at=inv.created_at,
        started_at=inv.started_at,
        completed_at=inv.completed_at,
    )
