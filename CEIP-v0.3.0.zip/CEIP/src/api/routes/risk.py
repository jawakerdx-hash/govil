"""Risk API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.risk.engine import RiskEngine
from src.contexts.risk.schemas import RiskResponse

router = APIRouter(prefix="/risk", tags=["risk"])


@router.get("/{domain}", response_model=RiskResponse)
async def get_risk(
    domain: str,
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> RiskResponse:
    """Get risk assessment for a domain."""
    engine = RiskEngine(db)
    result = await engine.assess(domain)

    if "No discovery" in result.get("summary", ""):
        raise HTTPException(
            status_code=404,
            detail=f"No discovery data for '{domain}'. Run discovery first.",
        )

    return RiskResponse.model_validate(result)
