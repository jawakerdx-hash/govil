"""Dashboard API endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.dashboard.schemas import DashboardSummary, ExecutiveDashboard, SOCDashboard
from src.contexts.dashboard.service import DashboardService

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


async def get_service(
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> DashboardService:
    return DashboardService(db)


@router.get("/executive/{domain}", response_model=ExecutiveDashboard)
async def executive(
    domain: str,
    svc: DashboardService = Depends(get_service),  # noqa: B008
) -> ExecutiveDashboard:
    result = await svc.executive(domain)
    return ExecutiveDashboard(**result)


@router.get("/soc/{domain}", response_model=SOCDashboard)
async def soc(
    domain: str,
    svc: DashboardService = Depends(get_service),  # noqa: B008
) -> SOCDashboard:
    result = await svc.soc(domain)
    return SOCDashboard(**result)


@router.get("/summary/{domain}", response_model=DashboardSummary)
async def summary(
    domain: str,
    svc: DashboardService = Depends(get_service),  # noqa: B008
) -> DashboardSummary:
    result = await svc.summary(domain)
    return DashboardSummary(**result)


@router.get("/trends/{domain}")
async def trends(
    domain: str,
    svc: DashboardService = Depends(get_service),  # noqa: B008
) -> dict[str, Any]:
    result = await svc.executive(domain)
    return {"domain": domain, "risk_trend": result.get("risk_trend", [])}


@router.get("/top-assets/{domain}")
async def top_assets(
    domain: str,
    svc: DashboardService = Depends(get_service),  # noqa: B008
) -> dict[str, Any]:
    result = await svc.executive(domain)
    return {"domain": domain, "top_assets": result.get("top_assets", [])}
