"""Discovery API endpoints."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.deps import get_settings
from src.config import Settings
from src.contexts.discovery.schemas import DiscoveryJobResponse, DiscoveryRequest
from src.contexts.discovery.service import DiscoveryService
from src.foundation.database import create_engine, create_session_factory

router = APIRouter(prefix="/discovery", tags=["discovery"])


async def get_db(
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> AsyncGenerator[AsyncSession]:
    """Yield an async DB session for request-scoped use."""
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as session:
        yield session
    await engine.dispose()


@router.post("", response_model=DiscoveryJobResponse, status_code=201)
async def start_discovery(
    body: DiscoveryRequest,
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> DiscoveryJobResponse:
    """Start a discovery job for a domain."""
    svc = DiscoveryService(db)
    job = await svc.start(body.domain)
    return DiscoveryJobResponse.model_validate(job)


@router.get("/assets/{job_id}", response_model=DiscoveryJobResponse)
async def get_assets(
    job_id: UUID,
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> DiscoveryJobResponse:
    """Get fully enriched assets for a discovery job."""
    svc = DiscoveryService(db)
    job = await svc.get_job(str(job_id))
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return DiscoveryJobResponse.model_validate(job)


@router.get("/{job_id}", response_model=DiscoveryJobResponse)
async def get_discovery(
    job_id: UUID,
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> DiscoveryJobResponse:
    """Get a discovery job by ID, including all results."""
    svc = DiscoveryService(db)
    job = await svc.get_job(str(job_id))
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return DiscoveryJobResponse.model_validate(job)
