"""Identity exposure + dark web API endpoints — honest provider, no simulated data."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.exposure.schemas import IdentityExposureResponse


router = APIRouter(tags=["exposure"])


@router.get("/identity/exposure/{domain}", response_model=IdentityExposureResponse)
async def get_identity_exposure(
    domain: str,
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> IdentityExposureResponse:
    """Get identity exposure intelligence — no simulated data.

    Uses the honest IdentityExposureService which returns empty results
    until a real provider (HaveIBeenPwned, Dehashed, SpyCloud) is configured.
    """
    from src.contexts.identity_exposure.repository import IdentityExposureRepository
    from src.contexts.identity_exposure.service import IdentityExposureService
    from src.config import Settings

    repo = IdentityExposureRepository(db)
    svc = IdentityExposureService(repo=repo)
    result = await svc.scan(domain)

    return IdentityExposureResponse(
        domain=domain,
        exposures_count=result.get("total_exposures", 0),
        critical=result.get("severity_counts", {}).get("CRITICAL", 0),
        high=result.get("severity_counts", {}).get("HIGH", 0),
        medium=result.get("severity_counts", {}).get("MEDIUM", 0),
        low=result.get("severity_counts", {}).get("LOW", 0),
        exposures=[],
        dark_web_count=0,
        dark_web_intel=[],
        summary=result.get("summary", f"No exposures found for {domain}"),
    )
