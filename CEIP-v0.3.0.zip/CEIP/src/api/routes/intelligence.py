"""SIB Intelligence API — cases, attack paths, risk correlation, relationship graph."""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.deps import get_settings
from src.config import Settings
from src.contexts.intelligence.service import SecurityIntelligenceBrain
from src.foundation.database import create_engine, create_session_factory

router = APIRouter(prefix="/intelligence", tags=["intelligence"])


async def get_db(
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> AsyncGenerator[AsyncSession]:
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as session:
        yield session
    await engine.dispose()


async def get_sib(
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> SecurityIntelligenceBrain:
    return SecurityIntelligenceBrain(db)


# ---------------------------------------------------------------------------
# Analyze — run the full SIB pipeline
# ---------------------------------------------------------------------------


@router.post("/analyze/{investigation_id}")
async def analyze_investigation(
    investigation_id: str,
    domain: str = Query(..., description="Target domain"),
    sib: SecurityIntelligenceBrain = Depends(get_sib),  # noqa: B008
) -> dict:
    """Run the full Security Intelligence Brain analysis pipeline.

    Correlates evidence → builds cases → maps attack chains
    → computes risk → builds relationship graph.
    """
    result = await sib.analyze(investigation_id, domain)
    return {
        "status": "completed",
        "investigation_id": investigation_id,
        **result["stats"],
        "case_count": len(result["cases"]),
        "chain_count": len(result["attack_chains"]),
    }


# ---------------------------------------------------------------------------
# Intelligence Cases
# ---------------------------------------------------------------------------


@router.get("/cases/{investigation_id}")
async def list_cases(
    investigation_id: str,
    sib: SecurityIntelligenceBrain = Depends(get_sib),  # noqa: B008
) -> list[dict]:
    """List all intelligence cases for an investigation."""
    cases = await sib.get_cases(investigation_id)
    return [
        {
            "case_id": c.case_id if hasattr(c, "case_id") else str(c.id),
            "title": c.title,
            "executive_summary": c.executive_summary,
            "risk_level": c.risk_level,
            "confidence": c.confidence,
            "priority": c.priority,
            "evidence": json.loads(c.evidence_ids or "[]"),
            "affected_assets": json.loads(c.affected_assets or "[]"),
            "attack_path": json.loads(c.attack_path_json or "[]"),
            "threat_context": c.threat_context,
            "business_impact": c.business_impact,
            "root_cause": c.root_cause,
            "related_findings": json.loads(c.related_findings_json or "[]"),
            "recommendations": json.loads(c.recommendations_json or "[]"),
            "kill_chain_stages": json.loads(c.kill_chain_stages_json or "[]"),
            "analyst_notes": c.analyst_notes,
            "created_at": c.created_at.isoformat() if c.created_at else None,
        }
        for c in cases
    ]


# ---------------------------------------------------------------------------
# Attack Chains
# ---------------------------------------------------------------------------


@router.get("/attack-chains/{investigation_id}")
async def list_attack_chains(
    investigation_id: str,
    sib: SecurityIntelligenceBrain = Depends(get_sib),  # noqa: B008
) -> list[dict]:
    """List all attack chains for an investigation."""
    chains = await sib.get_chains(investigation_id)
    return [
        {
            "chain_id": str(c.id),
            "title": c.title,
            "description": c.description,
            "severity": c.severity,
            "risk_score": c.risk_score,
            "confidence": c.confidence,
            "steps": json.loads(c.steps_json or "[]"),
            "kill_chain_stages": json.loads(c.kill_chain_json or "[]"),
            "entry_points": json.loads(c.entry_points_json or "[]"),
            "crown_jewels": json.loads(c.crown_jewels_json or "[]"),
            "blocked": c.blocked,
            "blocked_reason": c.blocked_reason,
            "mitigations": json.loads(c.mitigations_json or "[]"),
        }
        for c in chains
    ]


# ---------------------------------------------------------------------------
# Risk Correlation
# ---------------------------------------------------------------------------


@router.get("/risk-correlation/{investigation_id}")
async def get_risk_correlation(
    investigation_id: str,
    sib: SecurityIntelligenceBrain = Depends(get_sib),  # noqa: B008
) -> dict:
    """Get multi-dimensional risk correlation for an investigation."""
    risk = await sib.get_risk(investigation_id)
    if risk is None:
        raise HTTPException(status_code=404, detail="Risk correlation not found")

    return {
        "investigation_id": investigation_id,
        "domain": risk.domain,
        "dimensions": {
            "asset_risk": risk.asset_risk,
            "service_risk": risk.service_risk,
            "business_risk": risk.business_risk,
            "organization_risk": risk.organization_risk,
            "exposure_risk": risk.exposure_risk,
            "technology_risk": risk.technology_risk,
            "infrastructure_risk": risk.infrastructure_risk,
            "threat_risk": risk.threat_risk,
        },
        "overall_score": risk.overall_score,
        "risk_level": risk.risk_level,
        "factor_breakdown": json.loads(risk.factor_breakdown_json or "[]"),
    }


# ---------------------------------------------------------------------------
# Relationship Graph
# ---------------------------------------------------------------------------


@router.get("/graph/{investigation_id}")
async def get_relationship_graph(
    investigation_id: str,
    sib: SecurityIntelligenceBrain = Depends(get_sib),  # noqa: B008
) -> dict:
    """Get the full relationship graph for an investigation."""
    graph = await sib.get_graph(investigation_id)
    if graph is None:
        raise HTTPException(status_code=404, detail="Graph not found")

    return {
        "investigation_id": investigation_id,
        "domain": graph.domain,
        "nodes": json.loads(graph.nodes_json or "[]"),
        "edges": json.loads(graph.edges_json or "[]"),
        "node_count": graph.node_count,
        "edge_count": graph.edge_count,
        "crown_jewels": json.loads(graph.crown_jewels_json or "[]"),
        "entry_points": json.loads(graph.entry_points_json or "[]"),
    }
