"""Brand protection API endpoints."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.brand_protection.repository import BrandRepository
from src.contexts.brand_protection.schemas import BrandScanRequest, BrandSummary
from src.contexts.brand_protection.service import BrandProtectionService

router = APIRouter(prefix="/brand", tags=["brand_protection"])


async def get_service(db: AsyncSession = Depends(get_db)) -> BrandProtectionService:  # noqa: B008
    return BrandProtectionService(BrandRepository(db))


@router.post("/scan", response_model=BrandSummary)
async def scan_brand(body: BrandScanRequest, svc: BrandProtectionService = Depends(get_service)) -> BrandSummary:  # noqa: B008
    return BrandSummary(**await svc.scan(body.brand))


@router.get("/{brand}", response_model=BrandSummary)
async def get_brand(brand: str, svc: BrandProtectionService = Depends(get_service)) -> BrandSummary:  # noqa: B008
    return BrandSummary(**await svc.scan(brand))


@router.get("/{brand}/summary", response_model=BrandSummary)
async def get_brand_summary(brand: str, svc: BrandProtectionService = Depends(get_service)) -> BrandSummary:  # noqa: B008
    return BrandSummary(**await svc.scan(brand))


@router.get("/{brand}/risk")
async def get_brand_risk(brand: str, svc: BrandProtectionService = Depends(get_service)) -> dict[str, Any]:  # noqa: B008
    result = await svc.scan(brand)
    return {"brand": brand, "risk_summary": result["summary"]}
