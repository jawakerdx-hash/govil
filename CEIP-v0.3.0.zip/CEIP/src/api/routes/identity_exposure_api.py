"""Identity exposure API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.deps import get_settings
from src.api.routes.discovery import get_db
from src.config import Settings
from src.contexts.identity_exposure.repository import IdentityExposureRepository
from src.contexts.identity_exposure.schemas import IdentityScanRequest, IdentitySummaryResponse
from src.contexts.identity_exposure.service import IdentityExposureService

router = APIRouter(prefix="/identity", tags=["identity_exposure"])


async def get_service(
    db: AsyncSession = Depends(get_db),  # noqa: B008
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> IdentityExposureService:
    repo = IdentityExposureRepository(db)
    return IdentityExposureService(repo=repo, settings=settings)


@router.post("/scan", response_model=IdentitySummaryResponse)
async def scan_identity(
    body: IdentityScanRequest,
    svc: IdentityExposureService = Depends(get_service),  # noqa: B008
) -> IdentitySummaryResponse:
    result = await svc.scan(body.domain)
    return IdentitySummaryResponse.model_validate(result)


@router.get("/{domain}", response_model=IdentitySummaryResponse)
async def get_identity(
    domain: str,
    svc: IdentityExposureService = Depends(get_service),  # noqa: B008
) -> IdentitySummaryResponse:
    result = await svc.scan(domain)
    return IdentitySummaryResponse.model_validate(result)


@router.get("/{domain}/summary", response_model=IdentitySummaryResponse)
async def get_identity_summary(
    domain: str,
    svc: IdentityExposureService = Depends(get_service),  # noqa: B008
) -> IdentitySummaryResponse:
    result = await svc.scan(domain)
    return IdentitySummaryResponse.model_validate(result)
