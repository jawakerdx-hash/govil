"""Correlation API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.correlation.schemas import CorrelationResponse
from src.contexts.correlation.service import CorrelationService

router = APIRouter(prefix="/correlation", tags=["correlation"])


@router.get("/{domain}", response_model=CorrelationResponse)
async def get_correlation(
    domain: str,
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> CorrelationResponse:
    """Run correlation analysis on discovery data for a domain."""
    svc = CorrelationService(db)
    result = await svc.correlate(domain)

    if not result.get("relationships") and not result.get("clusters"):
        raise HTTPException(
            status_code=404,
            detail=f"No discovery data found for '{domain}'. Run discovery first.",
        )

    return CorrelationResponse.model_validate(result)
