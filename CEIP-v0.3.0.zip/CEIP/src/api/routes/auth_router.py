"""Auth endpoints — login, token creation, health check.

Health endpoints are public. Token endpoint requires credentials.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from src.api.auth import get_current_user, require_role
from src.contexts.gateway.auth import AuthEngine
from src.contexts.gateway.models import AuthToken

router = APIRouter(tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    tenant_id: str
    role: str
    expires_in: int


# Simple dev credentials — production must use proper identity provider
_DEV_USERS = {
    "admin": {"password": "admin123", "role": "admin", "tenant_id": "default"},
    "analyst": {"password": "analyst123", "role": "analyst", "tenant_id": "default"},
    "viewer": {"password": "viewer123", "role": "viewer", "tenant_id": "default"},
}


@router.post("/auth/login", response_model=TokenResponse)
async def login(body: LoginRequest) -> TokenResponse:
    """Authenticate and return a JWT token.

    Uses dev credentials in development. Production: LDAP/OAuth/OIDC.
    """
    user = _DEV_USERS.get(body.username)
    if not user or user["password"] != body.password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )

    ttl = 86400  # 24 hours
    token = AuthEngine.create_token(
        user_id=body.username,
        tenant_id=user["tenant_id"],
        role=user["role"],
        ttl_seconds=ttl,
    )

    return TokenResponse(
        access_token=token,
        tenant_id=user["tenant_id"],
        role=user["role"],
        expires_in=ttl,
    )


@router.get("/auth/me")
async def whoami(user: AuthToken = Depends(get_current_user)) -> dict:  # noqa: B008
    """Return current authenticated user info."""
    return user.to_dict()


@router.post("/auth/token")
async def create_token(
    user_id: str,
    tenant_id: str = "default",
    role: str = "viewer",
    ttl: int = 3600,
    _admin: AuthToken = Depends(require_role("admin")),  # noqa: B008
) -> TokenResponse:
    """Admin-only: create a token for another user."""
    token = AuthEngine.create_token(
        user_id=user_id,
        tenant_id=tenant_id,
        role=role,
        ttl_seconds=ttl,
    )
    return TokenResponse(
        access_token=token,
        tenant_id=tenant_id,
        role=role,
        expires_in=ttl,
    )
