"""Reporting API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.responses import PlainTextResponse
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.reporting.service import ReportingService

router = APIRouter(prefix="/reports", tags=["reports"])


async def get_service(
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> ReportingService:
    return ReportingService(db)


@router.get("/{report_type}/{domain}")
async def get_report(
    report_type: str,
    domain: str,
    fmt: str = "json",
    svc: ReportingService = Depends(get_service),  # noqa: B008
) -> object:
    if report_type not in ReportingService.REPORT_TYPES:
        return {"error": f"Unknown report type: {report_type}"}
    result = await svc.generate(domain, report_type, fmt)
    if fmt == "markdown":
        md = await svc.export_markdown(result)
        return PlainTextResponse(md, media_type="text/markdown")
    return result
