"""Attack path API endpoints."""
# ruff: noqa: E501

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.attack_path.engine import AttackPathEngine
from src.contexts.attack_path.repository import AttackPathRepository
from src.contexts.attack_path.schemas import AttackPathSummary
from src.contexts.attack_path.service import AttackPathService

router = APIRouter(prefix="/attack-path", tags=["attack_path"])


async def get_service(db: AsyncSession = Depends(get_db)) -> AttackPathService:  # noqa: B008
    return AttackPathService(AttackPathRepository(db), AttackPathEngine(db))


@router.post("/run", response_model=AttackPathSummary)
async def run_attack_path(
    body: dict[str, Any], svc: AttackPathService = Depends(get_service)  # noqa: B008
) -> AttackPathSummary:
    return AttackPathSummary(**await svc.run(body["domain"]))


@router.get("/{domain}", response_model=AttackPathSummary)
async def get_attack_paths(
    domain: str, svc: AttackPathService = Depends(get_service)  # noqa: B008
) -> AttackPathSummary:
    return AttackPathSummary(**await svc.run(domain))


@router.get("/{domain}/summary", response_model=AttackPathSummary)
async def get_attack_path_summary(
    domain: str, svc: AttackPathService = Depends(get_service)  # noqa: B008
) -> AttackPathSummary:
    return AttackPathSummary(**await svc.run(domain))
