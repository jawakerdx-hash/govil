"""Monitoring API endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.monitoring.repository import MonitoringRepository
from src.contexts.monitoring.schemas import (
    MonitorHistoryResponse,
    MonitorRunResponse,
    MonitorStartRequest,
)
from src.contexts.monitoring.service import MonitoringService

router = APIRouter(prefix="/monitor", tags=["monitoring"])


async def get_service(
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> MonitoringService:
    repo = MonitoringRepository(db)
    return MonitoringService(db, repo)


@router.post("/start", response_model=MonitorRunResponse)
async def start_monitor(
    body: MonitorStartRequest,
    svc: MonitoringService = Depends(get_service),  # noqa: B008
) -> MonitorRunResponse:
    await svc.start_job(body.domain, body.schedule)
    result = await svc.run(body.domain, trigger="api")
    return MonitorRunResponse(**result)


@router.post("/run", response_model=MonitorRunResponse)
async def run_monitor(
    body: MonitorStartRequest,
    svc: MonitoringService = Depends(get_service),  # noqa: B008
) -> MonitorRunResponse:
    result = await svc.run(body.domain, trigger="api")
    return MonitorRunResponse(**result)


@router.get("/history/{domain}", response_model=MonitorHistoryResponse)
async def get_history(
    domain: str,
    svc: MonitoringService = Depends(get_service),  # noqa: B008
) -> MonitorHistoryResponse:
    result = await svc.get_history(domain)
    return MonitorHistoryResponse(**result)


@router.get("/diff/{domain}")
async def get_diff(
    domain: str,
    svc: MonitoringService = Depends(get_service),  # noqa: B008
) -> dict[str, Any]:
    return await svc.get_diff(domain)


@router.get("/alerts/{domain}")
async def get_alerts(
    domain: str,
    svc: MonitoringService = Depends(get_service),  # noqa: B008
) -> dict[str, Any]:
    return await svc.get_alerts(domain)
