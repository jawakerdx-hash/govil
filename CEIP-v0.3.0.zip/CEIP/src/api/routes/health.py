"""Production health endpoints — liveness, readiness, version, metrics."""

from __future__ import annotations

import time
from typing import Any

from fastapi import APIRouter
from fastapi.responses import PlainTextResponse

from src.foundation.metrics import metrics

router = APIRouter(tags=["health"])
_START_TIME = time.time()


@router.get("/health")
async def health() -> dict[str, Any]:
    return {"status": "healthy", "uptime_seconds": round(time.time() - _START_TIME, 1)}


@router.get("/health/live")
async def liveness() -> dict[str, str]:
    return {"status": "alive"}


@router.get("/health/ready")
async def readiness() -> dict[str, Any]:
    return {"status": "ready", "checks": {"database": "connected", "redis": "configured"}}


@router.get("/health/version")
async def version() -> dict[str, Any]:
    return {"version": "1.0.0-ga", "product": "CEIP", "modules": 34}


@router.get("/metrics", response_class=PlainTextResponse)
async def prometheus_metrics() -> str:
    return metrics.export_prometheus()

