"""Scan API — ALL routes delegate to InvestigationOrchestrator (single pipeline).

No more task_queue. No more scan_worker. One pipeline, one truth.
POST /api/v1/scan → InvestigationOrchestrator.create_investigation() + start()
Status/Result/WS → InvestigationOrchestrator progress/evidence/report
"""

from __future__ import annotations

import json
import uuid
from typing import Any

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect

from src.api.deps import get_settings
from src.config import Settings
from src.contexts.investigation.job_registry import PHASE_NAMES
from src.foundation.database import create_engine, create_session_factory, init_db
from src.foundation.event_bus import event_bus

router = APIRouter(tags=["scan"])


# ---------------------------------------------------------------------------
# Unified scan endpoint — ONE pipeline (InvestigationOrchestrator)
# ---------------------------------------------------------------------------


@router.post("/scan")
async def start_scan(
    body: dict[str, Any],
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> dict[str, Any]:
    """Start a new investigation. Tenant from authenticated context."""
    from fastapi import Request as _FR
    raw = body.get("domain", "").strip().lower()
    domain = (
        raw.replace("https://", "").replace("http://", "")
        .replace("www.", "").split("/")[0].rstrip(".")
    )
    # Tenant from authenticated token (set by auth middleware), not request body
    tenant_id = "default"  # override in production with token extraction

    if not domain or "." not in domain:
        return {"error": "Invalid domain", "received": raw[:100]}

    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        from src.contexts.investigation.orchestrator import InvestigationOrchestrator

        orch = InvestigationOrchestrator(db, event_bus)
        inv = await orch.create_investigation(
            domain=domain, tenant_id=tenant_id,
        )
        inv = await orch.start(inv.id)

        return {
            "scan_id": str(inv.id),
            "domain": domain,
            "status": "running",
            "total_phases": len(inv.phases),
            "total_jobs": inv.total_jobs,
        }
    await engine.dispose()


@router.get("/scan/status/{scan_id}")
async def scan_status(
    scan_id: str,
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> dict[str, Any]:
    """Get current investigation progress."""
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        from src.contexts.investigation.orchestrator import InvestigationOrchestrator

        orch = InvestigationOrchestrator(db, event_bus)
        try:
            progress = await orch.get_progress(uuid.UUID(scan_id))
        except ValueError:
            return {"error": "Scan not found"}

        if "error" in progress:
            return {"error": "Scan not found"}

        return {
            "scan_id": scan_id,
            "domain": progress["domain"],
            "status": progress["status"],
            "progress": int(progress["progress_pct"]),
            "current_module": PHASE_NAMES.get(
                progress["current_phase"],
                f"Phase {progress['current_phase']}",
            ),
            "logs": [],
        }
    await engine.dispose()


@router.get("/scan/result/{scan_id}")
async def scan_result(
    scan_id: str,
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> dict[str, Any]:
    """Get full investigation result."""
    engine = create_engine(settings)
    factory = create_session_factory(engine)
    async with factory() as db:
        from src.contexts.investigation.orchestrator import InvestigationOrchestrator

        orch = InvestigationOrchestrator(db, event_bus)
        try:
            inv = await orch._load_investigation(uuid.UUID(scan_id))
        except ValueError:
            return {"error": "Scan not found"}

        if inv is None:
            return {"error": "Scan not found"}
        if inv.status not in ("completed", "failed"):
            return {"error": "Scan not complete", "status": inv.status}

        # Build unified result from investigation data
        evidence = await orch.get_evidence(uuid.UUID(scan_id))

        findings_list = [e for e in evidence if e.evidence_type == "finding"]
        sev_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for f in findings_list:
            s = f.severity.upper()
            if s in sev_counts:
                sev_counts[s] += 1

        return {
            "scan_id": str(inv.id),
            "domain": inv.domain,
            "status": inv.status,
            "total_findings": len(findings_list),
            "severity_counts": sev_counts,
            "findings": [
                {
                    "type": e.evidence_type,
                    "severity": e.severity,
                    "title": e.title,
                    "description": e.description,
                    "subdomain": e.entity_value,
                    "evidence": [],
                    "recommendation": e.description,
                }
                for e in findings_list[:50]
            ],
            "subdomains": list({
                e.entity_value
                for e in evidence if e.entity_type == "subdomain"
            }),
            "executive_dashboard": {
                "security_score": int((inv.risk_score or 0) * 100),
                "risk_grade": (
                    "A" if (inv.risk_score or 0) < 0.25
                    else "B" if (inv.risk_score or 0) < 0.5
                    else "C" if (inv.risk_score or 0) < 0.75
                    else "D"
                ),
                "trend": "stable",
                "business_summary": (
                    f"Investigation of {inv.domain}: "
                    f"{sev_counts['CRITICAL']} critical, "
                    f"{sev_counts['HIGH']} high, "
                    f"{sev_counts['MEDIUM']} medium findings."
                ),
                "top_risks": [],
                "brand_exposure_summary": "",
                "dark_web_exposure_summary": "",
            },
            "soc_dashboard": {
                "critical_vulnerabilities": [
                    f"[{e.severity}] {e.title[:80]}"
                    for e in findings_list if e.severity == "CRITICAL"
                ][:5],
                "active_threat_campaigns": [],
                "exposed_assets": [],
                "real_time_alerts": [],
            },
            "security_analysis": {
                "posture_summary": (
                    f"{inv.domain}: {inv.finding_count} findings, "
                    f"Risk Score {inv.risk_score:.0f}/100"
                ),
                "risk_explanation": f"Risk level: {inv.risk_level}",
                "mitigation_plan": [],
            },
            "external_security_rating": {
                "overall_score": int((inv.risk_score or 0) * 100),
                "grade": (
                    "A" if (inv.risk_score or 0) < 0.25 else "D"
                ),
                "risk_level": inv.risk_level,
            },
        }
    await engine.dispose()


@router.websocket("/ws/scan/{scan_id}")
async def scan_websocket(websocket: WebSocket, scan_id: str) -> None:
    """WebSocket for real-time investigation updates."""
    origin = websocket.headers.get("origin", "")
    allowed = ["http://localhost:3000", "http://localhost", "http://127.0.0.1:3000"]
    if origin and not any(o in origin for o in allowed):
        await websocket.close(code=1008)
        return

    await websocket.accept()

    # Subscribe to investigation events on the event bus
    async def forward(event: dict) -> None:
        try:
            await websocket.send_text(json.dumps(event))
        except Exception:
            pass

    channel = f"investigation:{scan_id}"
    event_bus.subscribe(channel, forward)

    await websocket.send_text(json.dumps({
        "type": "connected", "scanId": scan_id,
    }))

    try:
        while True:
            try:
                msg = await __import__("asyncio").wait_for(
                    websocket.receive_text(), timeout=30,
                )
                if msg == "ping":
                    await websocket.send_text(json.dumps({"type": "pong"}))
            except TimeoutError:
                await websocket.send_text(json.dumps({"type": "ping"}))
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        event_bus.unsubscribe(channel, forward)
