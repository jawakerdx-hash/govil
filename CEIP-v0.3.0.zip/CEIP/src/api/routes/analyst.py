"""AI Analyst API endpoint."""

from __future__ import annotations

import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.deps import get_settings
from src.api.routes.discovery import get_db
from src.config import Settings
from src.contexts.analyst.service import AIAnalystService

router = APIRouter(prefix="/ai", tags=["ai"])


@router.get("/analysis/{domain}")
async def get_analysis(
    domain: str,
    db: AsyncSession = Depends(get_db),  # noqa: B008
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> dict[str, object]:
    """Get AI-powered security analyst report for a domain."""
    http_client = httpx.AsyncClient(timeout=httpx.Timeout(120))
    try:
        svc = AIAnalystService(db, settings, http_client)
        result = await svc.analyze(domain)

        if result.get("error") and not result.get("report"):
            raise HTTPException(status_code=404, detail=result["error"])

        return result
    finally:
        await http_client.aclose()
