"""Threat intelligence API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from src.api.routes.discovery import get_db
from src.contexts.threat.schemas import ThreatResponse
from src.contexts.threat.service import ThreatService

router = APIRouter(prefix="/threats", tags=["threats"])


@router.get("/{domain}", response_model=ThreatResponse)
async def get_threats(
    domain: str,
    db: AsyncSession = Depends(get_db),  # noqa: B008
) -> ThreatResponse:
    """Get threat intelligence matches for a domain."""
    svc = ThreatService(db)
    result = await svc.assess(domain)

    if "No discovery" in result.get("summary", ""):
        raise HTTPException(
            status_code=404,
            detail=f"No discovery data for '{domain}'. Run discovery first.",
        )

    return ThreatResponse.model_validate(result)
