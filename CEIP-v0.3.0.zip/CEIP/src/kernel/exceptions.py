"""Domain exceptions for Milestone 1."""

from __future__ import annotations


class ConfigurationError(Exception):
    """Required configuration is missing or invalid."""


class APIError(Exception):
    """An external API call failed."""


class NotFoundError(Exception):
    """A requested resource was not found."""


class ConflictError(Exception):
    """The operation conflicts with existing state."""
