#!/usr/bin/env python3
# ruff: noqa: E501  — report format strings are table columns, breaking them is worse
"""CEIP — Cyber Exposure Intelligence Platform.

Single-command full security assessment::

    python CEIP.py example.com
    python CEIP.py example.com --output report.txt

Runs the complete pipeline: Discovery → Correlation → Vulnerability →
Threat Intel → Risk → Attack Path → Brand Protection → Dashboard.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import structlog

from src.config import Settings
from src.foundation.database import create_engine, create_session_factory, init_db
from src.foundation.logging_config import setup_logging

# ---------------------------------------------------------------------------
# Terminal formatting (no external deps needed)
# ---------------------------------------------------------------------------

GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"
CHECK = "[OK]"
CROSS = "[FAIL]"
ARROW = "->"


def _status(msg: str) -> None:
    """Print a progress status line."""
    print(f"  {CYAN}{ARROW}{RESET} {msg} ...", end=" ", flush=True)


def _ok() -> None:
    """Print a success checkmark."""
    print(f"{GREEN}{CHECK} done{RESET}")


def _warn(msg: str) -> None:
    """Print a warning."""
    print(f"{YELLOW}{CHECK} {msg}{RESET}")


def _fail(msg: str) -> None:
    """Print a failure mark."""
    print(f"{RED}{CROSS} {msg}{RESET}")


# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------

BANNER = f"""
{BOLD}{CYAN}   ___ ___ ___ ___   {RESET}{BOLD}Cyber Exposure Intelligence Platform{RESET}
{BOLD}{CYAN}  | {RESET}{BOLD}C{RESET}{BOLD}{CYAN} | {RESET}{BOLD}E{RESET}{BOLD}{CYAN} | {RESET}{BOLD}I{RESET}{BOLD}{CYAN} | {RESET}{BOLD}P{RESET}{BOLD}{CYAN} |  {RESET}{DIM}v0.2.0 - External Attack Surface Management{RESET}
{BOLD}{CYAN}  |___|___|___|___|  {RESET}{DIM}Discovery | Vuln | Threat | Risk | Brand{RESET}
"""


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="CEIP",
        description="Run a full security assessment against a domain.",
    )
    parser.add_argument(
        "domain", nargs="?", default="",
        help="Target domain (e.g. example.com) — interactive if omitted",
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file path (default: ceip-report-<domain>-<timestamp>.txt)",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress progress output (still writes report file)",
    )
    parser.add_argument(
        "--deep", "-d",
        action="store_true",
        help="Enable Deep Scan: 6-phase AI-orchestrated penetration testing",
    )
    parser.add_argument(
        "--exploit", "-x",
        action="store_true",
        help="Enable Phase 6 (PERSISTENCE): exploitation — REQUIRES authorization",
    )
    args = parser.parse_args(argv)

    # Interactive mode when no domain given
    if not args.domain:
        print(BANNER)
        domain = input(f"  {CYAN}Domain to scan:{RESET} ").strip()
        if not domain:
            print(f"{RED}No domain provided. Exiting.{RESET}")
            return 1
        deep_choice = input(f"  {CYAN}Deep scan? (y/N):{RESET} ").strip().lower()
        args.deep = deep_choice in ("y", "yes")
        if args.deep:
            exploit_choice = input(f"  {RED}Enable exploitation? (y/N):{RESET} ").strip().lower()
            args.exploit = exploit_choice in ("y", "yes")
        print()
    else:
        domain = args.domain

    domain = domain.lower().strip()
    output_path = args.output or _default_output(domain)

    # Bootstrap
    try:
        settings = Settings()
    except Exception as exc:
        print(f"{RED}Configuration error: {exc}{RESET}", file=sys.stderr)
        return 1

    # Suppress structlog during scan — only show CEIP progress output
    import logging
    logging.getLogger("structlog").setLevel(logging.WARNING)
    logging.getLogger("src").setLevel(logging.WARNING)

    logger = setup_logging("WARNING").bind(component="ceip-cli")

    if not args.quiet:
        print(BANNER)

    # Run
    t_start = time.perf_counter()
    try:
        results = asyncio.run(_run_pipeline(
            domain, settings, logger,
            quiet=args.quiet, deep=args.deep, exploit=args.exploit,
        ))
    except KeyboardInterrupt:
        print(f"\n{YELLOW}Scan cancelled by user.{RESET}")
        return 130
    except Exception as exc:
        logger.error("pipeline_failed", error=str(exc))
        print(f"\n{RED}Pipeline error: {exc}{RESET}")
        return 1

    elapsed = time.perf_counter() - t_start
    results["_meta"]["total_duration_s"] = round(elapsed, 1)

    # Write report
    report = _render_report(results)
    Path(output_path).write_text(report, encoding="utf-8")

    # Terminal summary
    if not args.quiet:
        _print_summary(results)

    print(f"\n{GREEN}Report saved to:{RESET} {BOLD}{output_path}{RESET}")
    print(f"{DIM}Total scan time: {elapsed:.1f}s{RESET}")
    return 0


# ---------------------------------------------------------------------------
# Pipeline orchestrator
# ---------------------------------------------------------------------------


async def _run_pipeline(
    domain: str,
    settings: Settings,
    logger: structlog.BoundLogger,
    quiet: bool = False,
    deep: bool = False,
    exploit: bool = False,
) -> dict[str, Any]:
    """Execute the full assessment pipeline in order.

    After each major phase, findings are sent to the AI Intelligence Layer
    for verification, correlation, and task generation. The AI never blocks
    the pipeline — if unavailable, the scan continues without it.
    """
    results: dict[str, Any] = {"_meta": {"domain": domain, "started_at": datetime.now(UTC).isoformat()}}

    # AI Intelligence Layer — lazily initialised
    ai_engine = None

    await init_db(settings)
    engine = create_engine(settings)
    factory = create_session_factory(engine)

    async with factory() as db:
        # ---- Phase 1: Discovery ----
        if not quiet:
                _status("Discovering assets")
        t0 = time.perf_counter()
        from src.contexts.discovery.service import DiscoveryService

        disc_svc = DiscoveryService(db)
        job = await disc_svc.start(domain)
        full_job = await disc_svc.get_job(job.id)
        results["discovery"] = _format_discovery(full_job, job)
        results["_meta"]["discovery_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            dns_n = len(full_job.dns_records) if full_job else 0
            subs_n = len(full_job.subdomains) if full_job else 0
            svcs_n = len(full_job.services) if full_job else 0
            certs_n = len(full_job.certificates) if full_job else 0
            _ok()
            print(f"      {DIM}{dns_n} DNS | {subs_n} subs | {svcs_n} services | {certs_n} certs{RESET}")

        # ---- Phase 2: Correlation ----
        if not quiet:
                _status("Correlating assets")
        t0 = time.perf_counter()
        from src.contexts.correlation.service import CorrelationService
        corr_svc = CorrelationService(db)
        corr_result = await corr_svc.correlate(domain)
        results["correlation"] = corr_result
        results["_meta"]["correlation_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
                _ok()
        # ---- Phase 3: Vulnerability ----
        if not quiet:
                _status("Mapping vulnerabilities")
        t0 = time.perf_counter()
        from src.contexts.vulnerability.service import VulnerabilityService
        vuln_svc = VulnerabilityService(db)
        vuln_result = await vuln_svc.assess(domain)
        results["vulnerability"] = vuln_result
        results["_meta"]["vulnerability_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            c = vuln_result.get("critical", 0)
            h = vuln_result.get("high", 0)
            _ok()
            sev = f" {RED}{c} crit{RESET}" if c else ""
            print(f"      {DIM}{vuln_result.get('findings_count', 0)} findings ({c}C/{h}H){sev}{RESET}")

        # ---- Phase 4: Threat Intelligence ----
        if not quiet:
                _status("Threat intel")
        t0 = time.perf_counter()
        from src.contexts.threat.service import ThreatService
        threat_svc = ThreatService(db)
        threat_result = await threat_svc.assess(domain)
        results["threats"] = threat_result
        results["_meta"]["threat_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            m = len(threat_result.get("matches", []))
        _ok() if m == 0 else print(f"      {RED}{m} matches{RESET}")

        # ---- Phase 5: Risk Assessment ----
        if not quiet:
                _status("Computing risk")
        t0 = time.perf_counter()
        from src.contexts.risk.engine import RiskEngine
        risk_engine = RiskEngine(db)
        risk_result = await risk_engine.assess(domain)
        results["risk"] = risk_result
        results["_meta"]["risk_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            score = risk_result.get("overall_score", 0)
            level = risk_result.get("overall_risk_level", "?")
            _ok()
            print(f"      {DIM}{score}/100 {level}{RESET}")

        # ---- AI Analysis ----
        if not quiet:
            _status("AI analysis")
        t0 = time.perf_counter()
        ai_output = await _run_ai_analysis(results, domain, settings, logger, ai_engine)
        results["ai_analysis"] = ai_output
        results["_meta"]["ai_analysis_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            if ai_output.get("performed"):
                _ok()
                conf = ai_output.get("confidence", 0)
                fp = ai_output.get("false_positives_flagged", 0)
                print(f"      {DIM}conf={conf:.0%} fp={fp}{RESET}")
            else:
                print(f"      {YELLOW}skipped{RESET}")

        # ---- AI Deep Hunt (--deep: 5-min autonomous red-team investigation) ----
        if deep and ai_output.get("performed"):
            if not quiet:
                _status("AI deep hunt (5min)")
            t0 = time.perf_counter()
            deadline = t0 + 300
            hunt_rounds = 0
            total_new = 0
            from src.contexts.deep_scanner import DeepScanner

            # Gather live hosts for deep scanning
            live_hosts = [domain]
            disc = results.get("discovery", {})
            for svc in disc.get("services", []):
                host = svc.get("host", "")
                if host and host not in live_hosts:
                    live_hosts.append(host)

            while time.perf_counter() < deadline:
                tasks = ai_output.get("new_tasks", [])
                hunt_rounds += 1

                if tasks:
                    # Execute AI-recommended tasks
                    for task in tasks[:3]:
                        try:
                            target = task.get("target", domain)
                            action = task.get("action", "")
                            if action == "assess_vulnerability":
                                from src.contexts.vulnerability.service import VulnerabilityService
                                r = await VulnerabilityService(db).assess(target)
                                total_new += len(r.get("findings", []))
                            elif action == "check_threats":
                                from src.contexts.threat.service import ThreatService
                                await ThreatService(db).assess(target)
                            elif action == "simulate_attack_path":
                                from src.contexts.attack_path.engine import AttackPathEngine
                                await AttackPathEngine(db).assess(target)
                        except Exception:
                            pass
                else:
                    # No AI tasks — run full deep scanner phases on live hosts
                    if not quiet:
                        rem = int(deadline - time.perf_counter())
                        print(f"\r      {DIM}Hunt round {hunt_rounds}: scanning {len(live_hosts[:5])} hosts ({rem}s remaining)...{RESET}", end="")
                    ds = DeepScanner(settings, ai_engine=ai_engine, exploit=exploit, quiet=True)
                    deep_result = await ds.run(domain, live_hosts[:5])
                    new_f = deep_result.get("total_findings", 0)
                    total_new += new_f
                    results["deep_scan"] = deep_result
                    if not quiet:
                        phases = deep_result.get("phases_executed", 0)
                        print(f"\r      {DIM}Hunt round {hunt_rounds}: {new_f} findings across {phases} phases{RESET}")

                # Re-analyze with new evidence
                ai_output = await _run_ai_analysis(results, domain, settings, logger, ai_engine)
                results["ai_analysis"] = ai_output

                # Break early if nothing new after 2 rounds
                if hunt_rounds >= 2 and total_new == 0:
                    break

            results["_meta"]["ai_hunt_rounds"] = hunt_rounds
            results["_meta"]["ai_hunt_findings"] = total_new
            if not quiet:
                _ok()
                print(f"      {DIM}{hunt_rounds} rounds, {total_new} new{RESET}")

        # ---- Phase 6: Attack Paths ----
        if not quiet:
                _status("Attack paths")
        t0 = time.perf_counter()
        try:
            from src.contexts.attack_path.engine import AttackPathEngine
            from src.contexts.attack_path.repository import AttackPathRepository
            from src.contexts.attack_path.service import AttackPathService
            ap_repo = AttackPathRepository(db)
            ap_engine = AttackPathEngine(db)
            ap_svc = AttackPathService(ap_repo, ap_engine)
            ap_result = await ap_svc.run(domain)
            results["attack_paths"] = ap_result
        except Exception:
            results["attack_paths"] = {"path_count": 0, "overall_exposure": "N/A"}
        results["_meta"]["attack_path_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            n = results["attack_paths"].get("path_count", 0)
            _ok()
            print(f"      {DIM}{n} paths{RESET}")

        # ---- Phase 7: Brand ----
        if not quiet:
                _status("Brand protection")
        t0 = time.perf_counter()
        try:
            from src.contexts.brand_protection.repository import BrandRepository
            from src.contexts.brand_protection.service import BrandProtectionService
            brand_name = domain.split(".")[0]
            brand_repo = BrandRepository(db)
            brand_svc = BrandProtectionService(brand_repo)
            brand_result = await brand_svc.scan(brand_name)
            results["brand_protection"] = brand_result
        except Exception:
            results["brand_protection"] = {"total_domains": 0}
        results["_meta"]["brand_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            _ok()
            print(f"      {DIM}{results['brand_protection'].get('total_domains', 0)} suspects{RESET}")

        # ---- Phase 8: Dashboard ----
        if not quiet:
                _status("Dashboard")
        t0 = time.perf_counter()
        try:
            from src.contexts.dashboard.service import DashboardService
            dash_svc = DashboardService(db)
            results["dashboard"] = await dash_svc.executive(domain)
        except Exception:
            results["dashboard"] = {}
        results["_meta"]["dashboard_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
                _ok()
        # ---- Phase 9: Email ----
        if not quiet:
                _status("Email security")
        t0 = time.perf_counter()
        results["email_security"] = await _check_email_security(domain)
        results["_meta"]["email_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            es = results["email_security"]
            _ok()
            print(f"      {DIM}SPF:{'OK' if es.get('spf',{}).get('present') else 'NO'} DMARC:{'OK' if es.get('dmarc',{}).get('present') else 'NO'}{RESET}")

        # ---- Phase 10: Headers + Wildcard ----
        if not quiet:
                _status("Headers & wildcard")
        t0 = time.perf_counter()
        results["security_headers"] = _analyze_security_headers(results)
        results["wildcard_dns"] = _detect_wildcard(results)
        results["_meta"]["headers_duration_s"] = round(time.perf_counter() - t0, 1)
        if not quiet:
            sh = results["security_headers"]
            _ok()
            print(f"      {DIM}HSTS: {sh.get('hsts_count',0)}/{sh.get('total_hosts',0)} CSP: {sh.get('csp_count',0)}{RESET}")

        # ---- Phase 11: Deep Scan ----
        if deep:
            if not quiet:
                _status("Deep scan (6 phases)")
            t0 = time.perf_counter()
            try:
                from src.contexts.deep_scanner import DeepScanner
                live_hosts = [domain]
                disc = results.get("discovery", {})
                for svc in disc.get("services", []):
                    host = svc.get("host", "")
                    if host and host not in live_hosts:
                        live_hosts.append(host)
                scanner = DeepScanner(settings, ai_engine=ai_engine, exploit=exploit, quiet=quiet)
                deep_results = await scanner.run(domain, live_hosts[:15])
                results["deep_scan"] = deep_results
            except Exception as exc:
                results["deep_scan"] = {"error": str(exc)[:200], "phases_executed": 0}
            results["_meta"]["deep_scan_duration_s"] = round(time.perf_counter() - t0, 1)
            if not quiet:
                _ok()
                print(f"      {DIM}{deep_results.get('total_findings',0)} findings{RESET}")

        await db.commit()

    await engine.dispose()
    return results

SEP = "-" * 72

# The old re-scan loop was removed — now handled by AI Deep Hunt above.
# Everything below is helper functions.
_BROKEN_CODE_REMOVED = True



def _format_discovery(full_job: Any, job: Any) -> dict[str, Any]:
    """Extract structured data from a discovery job."""
    if full_job is None:
        return {"status": job.status, "error": job.error, "dns_records": [], "subdomains": [], "services": [], "certificates": [], "ip_enrichments": []}

    return {
        "status": job.status,
        "dns_records": [
            {"type": r.record_type, "name": r.name, "value": r.value, "ttl": r.ttl}
            for r in full_job.dns_records
        ],
        "subdomains": [
            {"name": s.name, "source": s.source} for s in full_job.subdomains
        ],
        "services": [
            {"host": s.host, "port": s.port, "server": s.server or "",
             "status_code": s.status_code, "headers_json": s.headers_json or ""}
            for s in full_job.services
        ],
        "certificates": [
            {"host": c.host, "subject": c.subject or "", "issuer": c.issuer or "",
             "not_before": c.not_before or "", "not_after": c.not_after or ""}
            for c in full_job.certificates
        ],
        "ip_enrichments": [
            {"ip": e.ip, "reverse_dns": e.reverse_dns or "", "asn": e.asn or "", "asn_org": e.asn_org or ""}
            for e in full_job.ip_enrichments
        ],
    }


# ---------------------------------------------------------------------------
# AI Intelligence Layer integration
# ---------------------------------------------------------------------------


async def _run_ai_analysis(
    results: dict[str, Any],
    domain: str,
    settings: Settings,
    logger: structlog.BoundLogger,
    ai_engine: Any = None,
) -> dict[str, Any]:
    """Send vuln/threat/risk findings to the AI for structured analysis.

    Returns a dict with AI assessment results. If AI is unavailable,
    returns ``{"performed": False}`` — the scan continues normally.
    """
    if not settings.ai_enabled or not settings.ai_api_key:
        return {"performed": False, "reason": "AI disabled or no API key"}

    try:
        from src.contexts.ai_intelligence import AIIntelligenceEngine, EvidenceItem

        if ai_engine is None:
            ai_engine = AIIntelligenceEngine(settings=settings)

        # Collect evidence from all previous phases
        evidence: list[EvidenceItem] = []

        # From vulnerability — group identical findings across hosts
        vuln = results.get("vulnerability", {})
        seen_types: set[str] = set()
        for f in vuln.get("findings", []):
            # Deduplicate: same title on multiple hosts → one entry with host list
            key = f.get("title", "")[:60]
            if key in seen_types:
                continue
            seen_types.add(key)
            evidence.append(EvidenceItem(
                tool_name="assess_vulnerability",
                agent_name="VulnerabilityAnalyst",
                target=f.get("affected_asset", domain),
                finding_type=f.get("finding_type", "cve"),
                severity=f.get("severity", "medium"),
                raw_result=f.get("title", ""),
                raw_data=f,
                confidence=0.8,
            ))

        # From threat intel
        threats = results.get("threats", {})
        for m in threats.get("matches", []):
            evidence.append(EvidenceItem(
                tool_name="check_threats",
                agent_name="ThreatAnalyst",
                target=m.get("matched_asset", domain),
                finding_type="threat_match",
                severity=m.get("severity", "medium"),
                raw_result=f"Threat: {m.get('threat_category', 'unknown')}",
                raw_data=m,
                confidence=0.7,
            ))

        # From discovery — services summary
        disc = results.get("discovery", {})
        svc_summary = ", ".join(
            f"{s.get('host', '?')}({s.get('server', '?')})"
            for s in disc.get("services", [])[:10]
        )
        evidence.append(EvidenceItem(
            tool_name="discover",
            agent_name="DiscoveryAgent",
            target=domain,
            finding_type="service_inventory",
            severity="info",
            raw_result=f"Services: {svc_summary}",
            raw_data={"services": disc.get("services", []), "dns": disc.get("dns_records", [])},
            confidence=1.0,
        ))

        # Attack path context
        ap = results.get("attack_paths", {})
        ap_ctx = [
            {"path": p.get("name", ""), "level": p.get("level", ""), "score": p.get("overall_score", 0)}
            for p in ap.get("paths", [])
        ]

        # Risk summary
        risk = results.get("risk", {})
        risk_summary = risk.get("summary", "")

        # Correlation summary
        corr = results.get("correlation", {})
        asset_graph = corr.get("summary", "")

        output = await ai_engine.analyze_phase(
            phase="post_risk",
            evidence_items=evidence,
            related_findings=list(vuln.get("findings", [])),
            attack_path_context=ap_ctx,
            asset_graph_summary=asset_graph,
            risk_summary=risk_summary,
            scan_target=domain,
        )

        # Extract actionable results
        false_positives = [
            fa for fa in output.finding_assessments
            if fa.is_false_positive or fa.false_positive_probability > 0.7
        ]

        return {
            "performed": True,
            "confidence": output.confidence,
            "priority": output.priority,
            "reasoning_summary": output.reasoning_summary,
            "false_positives_flagged": len(false_positives),
            "false_positive_details": [
                {"finding_id": fp.finding_id, "probability": fp.false_positive_probability,
                 "reasoning": fp.reasoning}
                for fp in false_positives
            ],
            "finding_assessments": [
                {"finding_id": fa.finding_id, "credible": fa.is_credible,
                 "severity": fa.severity, "confidence": fa.confidence}
                for fa in output.finding_assessments
            ],
            "evidence_gaps": output.evidence_gaps,
            "correlation_results": output.correlation_results,
            "recommended_actions": output.recommended_next_actions,
            "recommended_agent": output.recommended_agent,
            "recommended_tool": output.recommended_tool,
            "new_tasks": output.new_tasks,
            "tokens_used": ai_engine.provider.tokens_used,
        }

    except Exception as exc:
        logger.warning("ai_analysis_failed", error=str(exc)[:200])
        return {"performed": False, "reason": str(exc)[:200]}


# ---------------------------------------------------------------------------
# Post-discovery analysis helpers
# ---------------------------------------------------------------------------


async def _check_email_security(domain: str) -> dict[str, Any]:
    """Check SPF, DMARC, DKIM, and MX configuration."""
    import dns.resolver

    r = dns.resolver.Resolver()
    r.timeout = 5
    r.lifetime = 10
    result: dict[str, Any] = {
        "spf": {"present": False, "record": "", "issues": []},
        "dmarc": {"present": False, "record": "", "policy": "none", "issues": []},
        "dkim": {"present": False, "selectors_found": [], "issues": []},
        "mx": {"hosts": [], "issues": []},
    }

    # SPF
    try:
        for txt in r.resolve(domain, "TXT"):
            val = str(txt).strip('"')
            if val.startswith("v=spf1"):
                result["spf"]["present"] = True
                result["spf"]["record"] = val
                if "~all" in val:
                    result["spf"]["issues"].append("SoftFail (~all) — should be strict (-all)")
                elif "-all" in val:
                    pass  # Good
                elif "?all" in val:
                    result["spf"]["issues"].append("Neutral (?all) — effectively disables SPF")
                elif "all" not in val:
                    result["spf"]["issues"].append("Missing 'all' mechanism — SPF not enforced")
    except Exception:
        result["spf"]["issues"].append("No SPF record found — email spoofing possible")

    # DMARC
    try:
        for txt in r.resolve(f"_dmarc.{domain}", "TXT"):
            val = str(txt).strip('"')
            if val.startswith("v=DMARC1"):
                result["dmarc"]["present"] = True
                result["dmarc"]["record"] = val
                if "p=reject" in val:
                    result["dmarc"]["policy"] = "reject"
                elif "p=quarantine" in val:
                    result["dmarc"]["policy"] = "quarantine"
                elif "p=none" in val:
                    result["dmarc"]["policy"] = "none"
                    result["dmarc"]["issues"].append("Policy is 'none' — DMARC not enforced")
    except Exception:
        result["dmarc"]["issues"].append("No DMARC record — email spoofing possible")

    # DKIM — check common selectors
    common_selectors = [
        "google", "selector1", "selector2", "dkim", "mail", "default",
        "amazonses", "ses", "key1", "s1", "s2", "everly", "sendgrid",
        "protonmail", "zoho", "mimecast",
    ]
    for sel in common_selectors:
        try:
            answers = r.resolve(f"{sel}._domainkey.{domain}", "TXT")
            for a in answers:
                val = str(a).strip('"')
                if "v=DKIM1" in val or "k=rsa" in val or "p=" in val:
                    result["dkim"]["present"] = True
                    result["dkim"]["selectors_found"].append(sel)
        except Exception:
            continue

    if not result["dkim"]["present"]:
        result["dkim"]["issues"].append("No DKIM selectors found — emails may fail DMARC alignment")

    # MX
    try:
        for mx in r.resolve(domain, "MX"):
            host = str(mx.exchange).rstrip(".").lower()
            priority = mx.preference
            result["mx"]["hosts"].append({"host": host, "priority": priority})
    except Exception:
        result["mx"]["issues"].append("No MX records — domain cannot receive email")

    # Overall score
    score = 0
    if result["spf"]["present"] and not result["spf"]["issues"]:
        score += 1
    elif result["spf"]["present"]:
        score += 0.5
    if result["dmarc"]["present"] and result["dmarc"]["policy"] == "reject":
        score += 1
    elif result["dmarc"]["present"]:
        score += 0.5
    if result["dkim"]["present"]:
        score += 1
    result["score"] = score
    result["max_score"] = 3
    result["rating"] = (
        "strong" if score >= 2.5 else "partial" if score >= 1.5
        else "weak" if score >= 0.5 else "none"
    )

    return result


def _analyze_security_headers(results: dict[str, Any]) -> dict[str, Any]:
    """Extract security header status from discovered services."""
    import json

    services = results.get("discovery", {}).get("services", [])
    analysis: dict[str, Any] = {
        "total_hosts": len(services),
        "hsts_count": 0,
        "csp_count": 0,
        "x_frame_count": 0,
        "x_content_type_count": 0,
        "referrer_policy_count": 0,
        "hosts_missing_csp": [],
        "hosts_missing_hsts": [],
    }

    for svc in services:
        host = svc.get("host", "?")
        headers_json = svc.get("headers_json")
        if headers_json:
            try:
                hdrs = json.loads(headers_json)
            except (json.JSONDecodeError, TypeError):
                continue
            if "strict-transport-security" in hdrs:
                analysis["hsts_count"] += 1
            else:
                analysis["hosts_missing_hsts"].append(host)
            if "content-security-policy" in hdrs:
                analysis["csp_count"] += 1
            else:
                analysis["hosts_missing_csp"].append(host)
            if "x-frame-options" in hdrs:
                analysis["x_frame_count"] += 1
            if "x-content-type-options" in hdrs:
                analysis["x_content_type_count"] += 1
            if "referrer-policy" in hdrs:
                analysis["referrer_policy_count"] += 1

    return analysis


def _detect_wildcard(results: dict[str, Any]) -> dict[str, Any]:
    """Detect wildcard DNS by comparing response bodies/content across subdomains."""
    import hashlib
    import json

    disc = results.get("discovery", {})
    services = disc.get("services", [])

    # Group services by content hash
    content_groups: dict[str, list[str]] = {}
    for svc in services:
        headers_json = svc.get("headers_json")
        server = svc.get("server", "")
        host = svc.get("host", "")
        if not headers_json:
            continue
        try:
            hdrs = json.loads(headers_json)
        except (json.JSONDecodeError, TypeError):
            continue
        # Use etag + content-length + content-type as a fingerprint
        etag = hdrs.get("etag", "")
        cl = hdrs.get("content-length", "")
        ct = hdrs.get("content-type", "")
        fp = hashlib.md5(f"{etag}|{cl}|{ct}|{server}".encode()).hexdigest()[:8]
        content_groups.setdefault(fp, []).append(host)

    # Find groups with >1 host (identical content)
    wildcard_groups = {k: v for k, v in content_groups.items() if len(v) > 1}
    total_affected = sum(len(v) for v in wildcard_groups.values())

    return {
        "detected": len(wildcard_groups) > 0,
        "group_count": len(wildcard_groups),
        "affected_hosts": total_affected,
        "groups": [
            {"fingerprint": fp, "hosts": hosts, "count": len(hosts)}
            for fp, hosts in sorted(wildcard_groups.items(), key=lambda x: -len(x[1]))
        ],
        "summary": (
            f"{len(wildcard_groups)} wildcard group(s) found"
            if wildcard_groups
            else "No wildcard DNS detected"
        ),
    }


# ---------------------------------------------------------------------------
# Report renderer
# ---------------------------------------------------------------------------


def _render_report(results: dict[str, Any]) -> str:
    """Render the full assessment to a formatted text report."""
    meta = results.get("_meta", {})
    domain = meta.get("domain", "unknown")
    started = meta.get("started_at", "")

    lines: list[str] = []
    lines.append("=" * 72)
    lines.append("  CEIP — Cyber Exposure Intelligence Platform")
    lines.append("  Full Security Assessment Report")
    lines.append("=" * 72)
    lines.append(f"  Target:       {domain}")
    lines.append(f"  Scan date:    {started[:19]}")
    lines.append(f"  Duration:     {meta.get('total_duration_s', 0):.1f}s")
    lines.append("=" * 72)
    lines.append("")

    # ---- Executive Summary ----
    risk = results.get("risk", {})
    vuln = results.get("vulnerability", {})
    ap = results.get("attack_paths", {})
    brand = results.get("brand_protection", {})

    lines.append(SEP)
    lines.append("  EXECUTIVE SUMMARY")
    lines.append(SEP)
    lines.append(f"  Overall Risk Score:  {risk.get('overall_score', 0):.0f}/100 ({risk.get('overall_risk_level', 'N/A')})")
    lines.append(f"  Exposure Level:      {ap.get('overall_exposure', 'N/A')}")
    lines.append(f"  Critical Findings:   {vuln.get('critical', 0)}")
    lines.append(f"  High Findings:       {vuln.get('high', 0)}")
    lines.append(f"  Threat Matches:      {len(results.get('threats', {}).get('matches', []))}")
    lines.append(f"  Attack Paths:        {ap.get('path_count', 0)}")
    lines.append(f"  Brand Suspects:      {brand.get('total_domains', 0)}")
    lines.append("")

    # ---- Risk Breakdown ----
    lines.append(SEP)
    lines.append("  RISK ASSESSMENT")
    lines.append(SEP)
    lines.append(f"  {risk.get('summary', 'N/A')}")
    lines.append("")

    top_risks = risk.get("scores", [])
    top_risks_sorted = sorted(top_risks, key=lambda s: s.get("score", 0), reverse=True)[:10]
    if top_risks_sorted:
        lines.append(f"  {'Asset':<40} {'Score':>6} {'Level':>10}")
        lines.append(f"  {'-'*40} {'-'*6} {'-'*10}")
        for s in top_risks_sorted:
            identifier = s.get("asset_identifier", "?")[:38]
            lines.append(f"  {identifier:<40} {s.get('score', 0):>6.0f} {s.get('level', '?'):>10}")
        lines.append("")

    if risk.get("top_risks"):
        lines.append("  Top Mitigations:")
        for r in risk["top_risks"]:
            lines.append(f"    - {r}")
        lines.append("")

    # ---- Discovery ----
    disc = results.get("discovery", {})
    lines.append(SEP)
    lines.append("  DISCOVERY")
    lines.append(SEP)
    lines.append(f"  DNS Records:     {len(disc.get('dns_records', []))}")
    lines.append(f"  Subdomains:      {len(disc.get('subdomains', []))}")
    lines.append(f"  Services:        {len(disc.get('services', []))}")
    lines.append(f"  Certificates:    {len(disc.get('certificates', []))}")
    lines.append("")

    dns_records = disc.get("dns_records", [])
    if dns_records:
        lines.append("  DNS Records:")
        lines.append(f"  {'Type':<8} {'Name':<30} {'Value'}")
        lines.append(f"  {'-'*8} {'-'*30} {'-'*30}")
        for r in dns_records[:30]:
            val = r.get("value", "")[:50]
            lines.append(f"  {r.get('type', '?'):<8} {r.get('name', '?')[:28]:<30} {val}")
        lines.append("")

    services = disc.get("services", [])
    if services:
        lines.append("  HTTP Services:")
        lines.append(f"  {'Host':<40} {'Code':>5} {'Server'}")
        lines.append(f"  {'-'*40} {'-'*5} {'-'*25}")
        for s in services:
            lines.append(f"  {s.get('host', '?')[:38]:<40} {s.get('status_code', 0) or '?':>5} {s.get('server', '?')[:23]}")
        lines.append("")

    ip_enrich = disc.get("ip_enrichments", [])
    if ip_enrich:
        lines.append("  IP Enrichment:")
        for e in ip_enrich:
            parts = [e.get("ip", "?")]
            if e.get("asn"):
                parts.append(f"ASN={e['asn']}")
            if e.get("asn_org"):
                parts.append(f"Org={e['asn_org']}")
            if e.get("reverse_dns"):
                parts.append(f"PTR={e['reverse_dns']}")
            lines.append(f"    {'  '.join(parts)}")
        lines.append("")

    # ---- Vulnerabilities ----
    lines.append(SEP)
    lines.append("  VULNERABILITIES")
    lines.append(SEP)
    lines.append(f"  {vuln.get('summary', 'N/A')}")
    lines.append("")

    findings = vuln.get("findings", [])
    if findings:
        lines.append(f"  {'Severity':<10} {'CVE':<18} {'Title'}")
        lines.append(f"  {'-'*10} {'-'*18} {'-'*40}")
        for f in findings:
            cve = f.get("cve_id") or "N/A"
            title = f.get("title", "")[:55]
            lines.append(f"  {f.get('severity', '?').upper():<10} {cve:<18} {title}")
        lines.append("")

    # ---- Threat Intelligence ----
    threats = results.get("threats", {})
    lines.append(SEP)
    lines.append("  THREAT INTELLIGENCE")
    lines.append(SEP)
    lines.append(f"  {threats.get('summary', 'N/A')}")
    lines.append("")

    matches = threats.get("matches", [])
    if matches:
        lines.append(f"  {'Severity':<10} {'Category':<12} {'Asset'}")
        lines.append(f"  {'-'*10} {'-'*12} {'-'*40}")
        for m in matches:
            lines.append(f"  {m.get('severity', '?').upper():<10} {m.get('threat_category', '?')[:10]:<12} {m.get('matched_asset', '?')[:38]}")
        lines.append("")

    # ---- Attack Paths ----
    lines.append(SEP)
    lines.append("  ATTACK PATHS")
    lines.append(SEP)
    lines.append(f"  Paths Found:     {ap.get('path_count', 0)}")
    lines.append(f"  Overall Exposure: {ap.get('overall_exposure', 'N/A')}")
    lines.append(f"  Critical: {ap.get('critical_paths', 0)} | High: {ap.get('high_paths', 0)}")
    lines.append("")

    paths = ap.get("paths", [])
    for i, p in enumerate(paths, 1):
        lines.append(f"  Path {i}: {p.get('name', '?')}")
        lines.append(f"    Level: {p.get('level', '?')} | Score: {p.get('overall_score', 0):.0f}")
        lines.append(f"    Likelihood: {p.get('likelihood', 0):.1f} | Impact: {p.get('impact', 0):.1f}")
        lines.append(f"    Complexity: {p.get('complexity', 0):.1f}")
        if p.get("crown_jewels_affected"):
            lines.append(f"    Crown Jewels: {', '.join(p['crown_jewels_affected'])}")
        if p.get("kill_chain_stages"):
            stages = " -> ".join(s.replace("_", " ").title() for s in p["kill_chain_stages"])
            lines.append(f"    Kill Chain: {stages}")
        if p.get("mitigations"):
            lines.append(f"    Mitigations: {p['mitigations'][:120]}")
        lines.append("")

    # ---- Correlation ----
    corr = results.get("correlation", {})
    lines.append(SEP)
    lines.append("  CORRELATION")
    lines.append(SEP)
    lines.append(f"  {corr.get('summary', 'N/A')}")
    lines.append("")

    for r in corr.get("relationships", []):
        src = r.get("source_value", "?")[:30]
        tgt = r.get("target_value", "?")[:30]
        rel = r.get("relationship", "?")
        lines.append(f"    {src:30} --[{rel:12}]--> {tgt}")
    lines.append("")

    for c in corr.get("clusters", []):
        lines.append(f"    [{c.get('cluster_type', '?')}] {c.get('name', '?')} ({c.get('member_count', 0)} members)")
    lines.append("")

    # ---- Brand Protection ----
    lines.append(SEP)
    lines.append("  BRAND PROTECTION")
    lines.append(SEP)
    lines.append(f"  {brand.get('summary', 'N/A')}")
    lines.append("")

    suspects = brand.get("domains", [])
    if suspects:
        lines.append(f"  {'Domain':<35} {'Risk':>8} {'Similarity':>10}")
        lines.append(f"  {'-'*35} {'-'*8} {'-'*10}")
        for d in suspects[:15]:
            lines.append(f"  {d.get('domain', '?')[:33]:<35} {d.get('risk_level', '?'):>8} {d.get('similarity_score', 0):>10.2f}")
        lines.append("")

    # ---- Email Security ----
    email = results.get("email_security", {})
    if email:
        lines.append(SEP)
        lines.append("  EMAIL SECURITY")
        lines.append(SEP)
        lines.append(f"  Score: {email.get('score', 0):.0f}/{email.get('max_score', 3)} ({email.get('rating', 'N/A')})")
        lines.append("")

        spf = email.get("spf", {})
        lines.append(f"  SPF:   {'Present' if spf.get('present') else 'MISSING'}")
        if spf.get("record"):
            lines.append(f"         {spf['record'][:100]}")
        for i in spf.get("issues", []):
            lines.append(f"         ! {i}")

        dmarc = email.get("dmarc", {})
        lines.append(f"  DMARC: {'Present' if dmarc.get('present') else 'MISSING'}")
        if dmarc.get("record"):
            lines.append(f"         {dmarc['record'][:100]}")
        if dmarc.get("policy"):
            lines.append(f"         Policy: {dmarc['policy']}")
        for i in dmarc.get("issues", []):
            lines.append(f"         ! {i}")

        dkim = email.get("dkim", {})
        lines.append(f"  DKIM:  {'Present' if dkim.get('present') else 'MISSING'}")
        if dkim.get("selectors_found"):
            lines.append(f"         Selectors: {', '.join(dkim['selectors_found'])}")
        for i in dkim.get("issues", []):
            lines.append(f"         ! {i}")

        mx = email.get("mx", {})
        if mx.get("hosts"):
            lines.append(f"  MX:    {len(mx['hosts'])} mail exchanger(s)")
            for h in mx["hosts"][:5]:
                lines.append(f"         [{h['priority']}] {h['host']}")
        lines.append("")

    # ---- Security Headers ----
    sh = results.get("security_headers", {})
    if sh:
        lines.append(SEP)
        lines.append("  SECURITY HEADERS")
        lines.append(SEP)
        total = sh.get("total_hosts", 0) or 1
        lines.append(f"  HSTS:                {sh.get('hsts_count', 0)}/{total} hosts")
        lines.append(f"  CSP:                 {sh.get('csp_count', 0)}/{total} hosts")
        lines.append(f"  X-Frame-Options:     {sh.get('x_frame_count', 0)}/{total} hosts")
        lines.append(f"  X-Content-Type-Opts: {sh.get('x_content_type_count', 0)}/{total} hosts")
        lines.append(f"  Referrer-Policy:     {sh.get('referrer_policy_count', 0)}/{total} hosts")
        lines.append("")
        if sh.get("hosts_missing_hsts"):
            lines.append(f"  Hosts missing HSTS: {', '.join(sh['hosts_missing_hsts'][:5])}")
        if sh.get("hosts_missing_csp"):
            lines.append(f"  Hosts missing CSP:  {', '.join(sh['hosts_missing_csp'][:5])}")
        lines.append("")

    # ---- Wildcard DNS Detection ----
    wd = results.get("wildcard_dns", {})
    if wd and wd.get("detected"):
        lines.append(SEP)
        lines.append("  WILDCARD DNS DETECTED")
        lines.append(SEP)
        lines.append(f"  {wd.get('summary', '')}")
        lines.append(f"  {wd.get('affected_hosts', 0)} hosts serve identical content across {wd.get('group_count', 0)} group(s)")
        lines.append("")
        for g in wd.get("groups", []):
            lines.append(f"  Content group (fingerprint={g['fingerprint']}):")
            for h in g["hosts"][:8]:
                lines.append(f"    - {h}")
            if g["count"] > 8:
                lines.append(f"    ... and {g['count'] - 8} more")
            lines.append("")

    # ---- AI Intelligence Analysis ----
    ai = results.get("ai_analysis", {})
    if ai and ai.get("performed"):
        lines.append(SEP)
        lines.append("  AI INTELLIGENCE ANALYSIS")
        lines.append(SEP)
        lines.append(f"  Confidence: {ai.get('confidence', 0):.0%}")
        lines.append(f"  Priority:   {ai.get('priority', 'N/A')}")
        lines.append(f"  Reasoning:  {ai.get('reasoning_summary', 'N/A')}")
        lines.append(f"  Tokens Used: {ai.get('tokens_used', 0)}")
        lines.append("")

        fp = ai.get("false_positives_flagged", 0)
        if fp > 0:
            lines.append(f"  False Positives Flagged: {fp}")
            for detail in ai.get("false_positive_details", []):
                lines.append(f"    - {detail.get('finding_id', '?')}: {detail.get('reasoning', '')[:120]}")
            lines.append("")

        evidence_gaps = ai.get("evidence_gaps", [])
        if evidence_gaps:
            lines.append("  Evidence Gaps Identified:")
            for g in evidence_gaps:
                lines.append(f"    - {g}")
            lines.append("")

        recs = ai.get("recommended_actions", [])
        if recs:
            lines.append(f"  Recommended Next Actions ({ai.get('recommended_agent', 'N/A')}/{ai.get('recommended_tool', 'N/A')}):")
            for r in recs:
                lines.append(f"    - {r}")
            lines.append("")

        new_tasks = ai.get("new_tasks", [])
        if new_tasks:
            lines.append("  AI-Generated Investigation Tasks:")
            for t in new_tasks:
                lines.append(f"    [{t.get('priority', '?')}] {t.get('action', '?')} on {t.get('target', '?')}")
                if t.get("reason"):
                    lines.append(f"         Reason: {t['reason'][:120]}")
            lines.append("")

    # ---- AI Deep Hunt Stats ----
    meta = results.get("_meta", {})
    if meta.get("ai_hunt_rounds", 0) > 0:
        lines.append(f"  AI Deep Hunt: {meta.get('ai_hunt_rounds')} rounds, {meta.get('ai_hunt_findings', 0)} new findings")
        lines.append("")

    # ---- Deep Scan (if enabled) ----
    ds = results.get("deep_scan", {})
    if ds and ds.get("phases_executed", 0) > 0:
        lines.append(SEP)
        lines.append("  DEEP SCAN (6-Phase AI Penetration Testing)")
        lines.append(SEP)
        lines.append(f"  Phases executed: {ds.get('phases_executed', 0)}")
        lines.append(f"  Total findings:  {ds.get('total_findings', 0)}")
        lines.append(f"  Critical:        {ds.get('critical_findings', 0)}")
        lines.append(f"  Duration:        {ds.get('duration_s', 0)}s")
        if ds.get("c99_data", {}).get("subdomains"):
            c99_subs = ds["c99_data"]["subdomains"]
            lines.append(f"  C99 subdomains:  {len(c99_subs)} found")
            for s in c99_subs[:30]:
                lines.append(f"    - {s}")
        lines.append("")

        for phase_summary in ds.get("phase_summaries", []):
            lines.append(f"  {phase_summary}")
        lines.append("")

        for phase_data in ds.get("phases", []):
            findings = phase_data.get("findings", [])
            if findings:
                lines.append(f"  [{phase_data.get('phase', '?').upper()}] {phase_data.get('summary', '')}")
                for f in findings[:10]:
                    sev = f.get("severity", "info").upper()
                    lines.append(f"    [{sev:<8}] {f.get('title', '')[:120]}")
                    # Show subdomain list if present
                    subs = f.get("subdomains", [])
                    if subs:
                        for s in subs[:12]:
                            lines.append(f"              - {s}")
                        if len(subs) > 12:
                            lines.append(f"              ... and {len(subs) - 12} more")
                if len(findings) > 10:
                    lines.append(f"    ... and {len(findings) - 10} more")
                lines.append("")

    # ---- Footer ----
    lines.append("=" * 72)
    lines.append("  Report generated by CEIP v0.2.0")
    lines.append(f"  {datetime.now(UTC).isoformat()}")
    lines.append("=" * 72)

    return "\n".join(lines)


def _print_summary(results: dict[str, Any]) -> None:
    """Print a compact summary to the terminal."""
    risk = results.get("risk", {})
    vuln = results.get("vulnerability", {})
    ap = results.get("attack_paths", {})
    threats = results.get("threats", {})
    brand = results.get("brand_protection", {})

    print(f"\n{BOLD}{'='*60}{RESET}")
    print(f"{BOLD}  SCAN SUMMARY{RESET}")
    print(f"{BOLD}{'='*60}{RESET}")
    print(f"  Risk Score:    {BOLD}{risk.get('overall_score', 0):.0f}/100{RESET} ({risk.get('overall_risk_level', 'N/A')})")
    print(f"  Attack Paths:  {ap.get('path_count', 0)} ({ap.get('overall_exposure', 'N/A')} exposure)")
    print(f"  Findings:      {vuln.get('critical', 0)} critical, {vuln.get('high', 0)} high, {vuln.get('medium', 0)} medium, {vuln.get('low', 0)} low")
    print(f"  Threat Intel:  {len(threats.get('matches', []))} matches")
    print(f"  Brand:         {brand.get('total_domains', 0)} suspect domains")
    print(f"{BOLD}{'='*60}{RESET}")


def _default_output(domain: str) -> str:
    """Generate a default output filename with timestamp."""
    ts = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    return f"ceip-report-{domain}-{ts}.txt"


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    sys.exit(main())
