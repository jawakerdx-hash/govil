/** Executive Report HTML Template — CEO-level, no technical detail */

export function executiveTemplate(report: any): string {
  const er = report.executive_report || {};
  const score = er.security_score ?? 50;
  const grade = er.risk_grade ?? "C";
  const risks = er.top_risks || [];
  const summary = er.business_summary || "";

  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>CEIP Executive Security Report</title>
<style>
  body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #1a1a2e; margin: 0; padding: 40px; }
  .cover { text-align: center; padding: 60px 0; border-bottom: 3px solid #2563eb; margin-bottom: 40px; }
  .score { font-size: 72px; font-weight: 700; color: ${score >= 75 ? "#16a34a" : score >= 50 ? "#ea580c" : "#dc2626"}; }
  .grade { font-size: 36px; color: #64748b; }
  h2 { color: #1e40af; border-bottom: 2px solid #dbeafe; padding-bottom: 8px; }
  table { width: 100%; border-collapse: collapse; margin: 16px 0; }
  th { background: #f1f5f9; text-align: left; padding: 10px; font-size: 11px; text-transform: uppercase; color: #475569; }
  td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
  .risk-high { color: #dc2626; font-weight: 600; }
  .risk-medium { color: #ea580c; }
  .footer { margin-top: 40px; font-size: 10px; color: #94a3b8; text-align: center; }
</style></head>
<body>
  <div class="cover">
    <h1>Executive Security Report</h1>
    <div class="score">${score}</div>
    <div class="grade">Grade ${grade} — ${score >= 75 ? "Strong Posture" : score >= 50 ? "Needs Attention" : "Critical Risk"}</div>
  </div>

  <h2>Business Summary</h2>
  <p>${summary}</p>

  <h2>Top Strategic Risks</h2>
  <table>
    <tr><th>Dimension</th><th>Score</th><th>Risk Level</th></tr>
    ${risks.map((r: any) => `<tr>
      <td>${r.dimension || ""}</td>
      <td>${r.score || 0}/100</td>
      <td class="${(r.risk_level || "") === "CRITICAL" ? "risk-high" : "risk-medium"}">${r.risk_level || "MEDIUM"}</td>
    </tr>`).join("")}
  </table>

  <h2>Brand Exposure</h2>
  <p>${er.brand_exposure || "No brand exposure data available"}</p>

  <h2>Dark Web Exposure</h2>
  <p>${er.dark_web_exposure || "No dark web exposure data available"}</p>

  <div class="footer">
    CEIP v1.0 — Confidential — Generated ${new Date().toISOString().split("T")[0]}
  </div>
</body></html>`;
}
