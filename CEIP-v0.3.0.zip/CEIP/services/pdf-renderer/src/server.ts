/**
 * CEIP PDF Rendering Microservice
 * Stateless. Transforms canonical report JSON into PDFs.
 * Uses Puppeteer + Chromium. No business logic. No data persistence.
 */

import express from "express";
import helmet from "helmet";
import cors from "cors";
import { executiveRouter } from "./routes/executive";
import { technicalRouter } from "./routes/technical";
import { complianceRouter } from "./routes/compliance";

const app = express();
const PORT = parseInt(process.env.PDF_PORT || "8090", 10);
const MAX_PAYLOAD = process.env.MAX_PAYLOAD || "5mb";

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: MAX_PAYLOAD }));

/** Health check */
app.get("/health", (_req, res) => res.json({ status: "healthy" }));
app.get("/version", (_req, res) => res.json({ service: "ceip-pdf-renderer", version: "1.0.0" }));

/** Render endpoints */
app.use("/render", executiveRouter);
app.use("/render", technicalRouter);
app.use("/render", complianceRouter);

app.listen(PORT, () => {
  console.log(`CEIP PDF Renderer listening on :${PORT}`);
});

export default app;
