/** POST /render/technical — Generate Technical PDF Report */

import { Router, Request, Response } from "express";
import { renderPDF } from "../renderer";

export const technicalRouter = Router();

technicalRouter.post("/technical", async (req: Request, res: Response) => {
  try {
    const report = req.body;
    if (!report?.technical_report) {
      return res.status(400).json({ error: "Invalid report schema", required: "technical_report" });
    }
    const tr = report.technical_report;
    const findings = tr.critical_findings || [];
    const campaigns = tr.threat_campaigns || [];
    const exposure = tr.infrastructure_exposure || [];

    const html = `<!DOCTYPE html><html lang="en">
<head><meta charset="UTF-8"><title>CEIP Technical Security Report</title>
<style>
  body { font-family: 'Courier New', monospace; color: #0f172a; padding: 40px; }
  .header { border-bottom: 2px solid #1e40af; margin-bottom: 24px; }
  h1 { color: #1e40af; }
  h2 { color: #334155; font-size: 16px; margin-top: 24px; }
  table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 12px; }
  th { background: #1e293b; color: #f1f5f9; padding: 8px; text-align: left; }
  td { padding: 8px; border-bottom: 1px solid #cbd5e1; }
  .critical { color: #dc2626; font-weight: 700; }
  .summary { background: #f8fafc; padding: 16px; border-left: 4px solid #2563eb; margin: 16px 0; }
</style></head><body>
<div class="header"><h1>Technical Security Assessment</h1></div>
<div class="summary"><strong>Attack Surface:</strong> ${tr.attack_surface_summary || "N/A"}<br>
<strong>Misconfigurations:</strong> ${tr.misconfiguration_summary || "N/A"}</div>

<h2>Critical Findings (P1/P2)</h2>
<table><tr><th>Type</th><th>Severity</th><th>Finding</th><th>Priority</th></tr>
${findings.map((f: any) => `<tr><td>${f.type || ""}</td><td class="${f.severity === 'CRITICAL' ? 'critical' : ''}">${f.severity || ""}</td><td>${f.description || ""}</td><td>${f.priority || ""}</td></tr>`).join("")}
</table>

<h2>Active Threat Campaigns</h2>
<table><tr><th>Campaign ID</th><th>Confidence</th><th>Phases</th></tr>
${campaigns.map((c: any) => `<tr><td>${c.campaign_id || ""}</td><td>${c.confidence || 0}</td><td>${(c.phases || []).join(", ")}</td></tr>`).join("")}
</table>

<h2>Infrastructure Exposure</h2>
<table><tr><th>Asset ID</th><th>Type</th><th>Value</th></tr>
${exposure.map((e: any) => `<tr><td>${e.asset_id || ""}</td><td>${e.type || ""}</td><td>${e.value || ""}</td></tr>`).join("")}
</table>

<div style="margin-top:40px;font-size:10px;color:#94a3b8;text-align:center">
CEIP v1.0 — SOC Technical Report — ${new Date().toISOString().split("T")[0]}
</div></body></html>`;

    const pdf = await renderPDF(html);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="ceip-technical-report.pdf"`);
    res.send(pdf);
  } catch (err: any) {
    res.status(500).json({ error: "PDF generation failed", reason: err.message });
  }
});
