/** POST /render/executive — Generate Executive PDF Report */

import { Router, Request, Response } from "express";
import { renderPDF } from "../renderer";
import { executiveTemplate } from "../templates/executive";

export const executiveRouter = Router();

executiveRouter.post("/executive", async (req: Request, res: Response) => {
  try {
    const report = req.body;
    if (!report?.executive_report) {
      return res.status(400).json({ error: "Invalid report schema", required: "executive_report" });
    }
    const html = executiveTemplate(report);
    const pdf = await renderPDF(html);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="ceip-executive-report.pdf"`);
    res.send(pdf);
  } catch (err: any) {
    res.status(500).json({ error: "PDF generation failed", reason: err.message });
  }
});
