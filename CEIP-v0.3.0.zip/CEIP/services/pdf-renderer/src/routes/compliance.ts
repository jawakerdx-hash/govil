/** POST /render/compliance — Generate Compliance PDF (PCI/ISO/NIST/CIS) */

import { Router, Request, Response } from "express";
import { renderPDF } from "../renderer";

export const complianceRouter = Router();

complianceRouter.post("/compliance", async (req: Request, res: Response) => {
  try {
    const report = req.body;
    if (!report?.compliance_report) {
      return res.status(400).json({ error: "Invalid report schema", required: "compliance_report" });
    }
    const cr = report.compliance_report;
    const frameworks = [
      { name: "PCI DSS", key: "pci_dss" },
      { name: "ISO 27001", key: "iso_27001" },
      { name: "NIST CSF", key: "nist_csf" },
      { name: "CIS Controls", key: "cis_controls" },
    ];

    const html = `<!DOCTYPE html><html lang="en">
<head><meta charset="UTF-8"><title>CEIP Compliance Report</title>
<style>
  body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #1a1a2e; padding: 40px; }
  .header { text-align: center; border-bottom: 3px solid #1e40af; padding-bottom: 20px; margin-bottom: 30px; }
  h1 { color: #1e40af; }
  h2 { color: #334155; font-size: 18px; margin-top: 28px; border-bottom: 1px solid #dbeafe; }
  table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 11px; }
  th { background: #1e293b; color: #f1f5f9; padding: 8px; text-align: left; text-transform: uppercase; }
  td { padding: 8px; border-bottom: 1px solid #e2e8f0; }
  .control { font-family: 'Courier New', monospace; color: #2563eb; }
</style></head><body>
<div class="header"><h1>Compliance Assessment Report</h1></div>
${frameworks.map(fw => {
  const findings = cr[fw.key] || [];
  return `<h2>${fw.name}</h2>
<table><tr><th>Control ID</th><th>Risk Description</th><th>Severity</th><th>Evidence Source</th></tr>
${findings.map((f: any) => `<tr>
  <td class="control">${f.control_id || ""}</td>
  <td>${f.description || f.risk_description || ""}</td>
  <td>${f.severity_level || f.severity || "LOW"}</td>
  <td>${f.mapped_evidence_source || f.evidence_source || "M24"}</td>
</tr>`).join("")}
</table>`;
}).join("")}
<div style="margin-top:40px;font-size:10px;color:#94a3b8;text-align:center">
CEIP v1.0 — Compliance Report — ${new Date().toISOString().split("T")[0]}
</div></body></html>`;

    const pdf = await renderPDF(html);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="ceip-compliance-report.pdf"`);
    res.send(pdf);
  } catch (err: any) {
    res.status(500).json({ error: "PDF generation failed", reason: err.message });
  }
});
